
How this works: 

- craft it by filling the right and left row with glass; place in the middle row (from top to bottom): steel, mese, steel
- place the travelnet box somewhere
- right-click on it; enter name of the station (e.g. "my house", "center of desert city") and name of the network (e.g. "intresting towns","my buildings")
- punch it to update the list of stations on that network
- right-click to use the travelbox

An unconfigured travelnet box can be configured by anyone. If it is misconfigured, just dig it and place it anew.
All stations that have the same network name set and are owned by the same user connect to the same network.
