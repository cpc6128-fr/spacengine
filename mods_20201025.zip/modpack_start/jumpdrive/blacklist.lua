
if minetest.get_modpath("technic") then
	table.insert(jumpdrive.blacklist, "technic:forcefield_emitter_on")
end

-- TODO bedrock, advtrains tracks
