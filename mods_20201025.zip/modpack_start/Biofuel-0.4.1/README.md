## Biofuel
A Minetest-Mod to produce biofuel from unused plants.


![Screenshot](https://github.com/Lokrates/biofuel/blob/master/screenshot.png)


**License for Code:**

GPLv3


**License for Textures:**

biofuel_tb.png = default_steel_block (Createt by Gambit) (WTFPL)

biofuel_bottle_fuel.png ~ vessels_glass_bottle.png (minetest_game) (CC BY-SA 3.0)

Other Textures by Lokrates (CC BY-SA 4.0)

**Installation:**

Minetest 0.4.X: Unzip, rename to 'biofuel' and copy to 'minetest/mod'-folder

Minetest 5.X:	Unzip and copy to 'minetest/mod'-folder or install from the Content Database
