Version 0.1:
------------
First Release.

Version 0.2:
------------
[Pipeworks-Support](https://forum.minetest.net/viewtopic.php?t=2155) (naturefreshmilk)

protection calls added   (naturefreshmilk)

[Pooper Support](https://forum.minetest.net/viewtopic.php?f=11&t=14620)  (Lokrates)

Version 0.3:
------------
[Farming_Redo Hemp Support](https://forum.minetest.net/viewtopic.php?t=9019) (naturefreshmilk/Lokrates)

mod.conf added   (ThorfinnS/Lokrates)

Version 0.4:
------------
[Farming_Redo Ethanol/Hemp-Oil Support](https://forum.minetest.net/viewtopic.php?t=9019)

[ Wine Support Rum/Tequlla]  (https://forum.minetest.net/viewtopic.php?f=11&t=13642)

[Cucina Vegana Support Plants/Oil] (https://forum.minetest.net/viewtopic.php?f=9&t=20001)

Refinery-Output is now a Phial instead of a bottle.

Version 0.4.1
-------------
Temporary fix of dependency error
