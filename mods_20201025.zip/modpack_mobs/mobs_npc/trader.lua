
local S = mobs.intllib

-- define table containing names for use and shop items for sale

mobs.human = {

	names = {
		"Bob", "Duncan", "Bill", "Tom", "James", "Ian", "Lenny",
		"Dylan", "Ethan"
	}
}
mobs.dialogue = {
        "j'ai tout sauf de la biere",
        "no way",
        "tu veut tu de l'aide",
        "can i help you",
        "soit t'achete, soit tu passe ton chemin",
        "la fin du monde approche, depense tout chez moi"
    }

-- Trader ( same as NPC but with right-click shop )

mobs:register_mob("mobs_npc:trader", {
	type = "npc",
	passive = false,
	damage = 3,
	attack_type = "dogfight",
	attacks_monsters = true,
	attack_animals = false,
	attack_npcs = false,
	pathfinding = false,
	hp_min = 10,
	hp_max = 20,
	armor = 100,
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "mobs_character.b3d",
	textures = {
		{"mobs_trader.png"}, -- by Frerin
		
	},
	makes_footstep_sound = true,
	sounds = {},
	walk_velocity = 2,
	run_velocity = 3,
	jump = false,
	drops = {},
	water_damage = 0,
	lava_damage = 4,
	light_damage = 0,
	follow = {"default:diamond"},
	view_range = 15,
	owner = "",
	order = "stand",
	fear_height = 3,
	animation = {
		speed_normal = 30,
		speed_run = 30,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 187,
		run_start = 168,
		run_end = 187,
		punch_start = 200,
		punch_end = 219,
	},
	on_rightclick = function(self, clicker)
		mobs_trader(self, clicker, entity, mobs.human)
	end,
	on_spawn = function(self)
		self.nametag = S("Trader")
		self.object:set_properties({
			nametag = self.nametag,
			nametag_color = "#FFFFFF"
		})
		return true -- return true so on_spawn is run once only
	end,
})


--This code comes almost exclusively from the trader and inventory of mobf, by Sapier.
--The copyright notice below is from mobf:
-------------------------------------------------------------------------------
-- Mob Framework Mod by Sapier
--
-- You may copy, use, modify or do nearly anything except removing this
-- copyright notice.
-- And of course you are NOT allow to pretend you have written it.
--
--! @file inventory.lua
--! @brief component containing mob inventory related functions
--! @copyright Sapier
--! @author Sapier
--! @date 2013-01-02
--
--! @defgroup Inventory Inventory subcomponent
--! @brief Component handling mob inventory
--! @ingroup framework_int
--! @{
--
-- Contact sapier a t gmx net
-------------------------------------------------------------------------------

-- This code has been heavily modified by isaiah658.
-- Trades are saved in entity metadata so they always stay the same after
-- initially being chosen.  Also the formspec uses item image buttons instead of
-- inventory slots.

function mobs.add_goods(self, entity, race,player)

local trade_index = 1
local trades_already_added = ""
local nb_obj=0
local choix_obj=0
local out=0
local price=0
local money="currency:minegeld"
local xp=xp_redo.get_xp(player) -- niveau d'experience minimal pour valider un item (level general du rpg)
local boucle=0
local objet={}
local quantity=0
local change=math.random(80,130)/100
self.trades = {}
-- nb d'item
nb_obj = #citymap.item

for i=1,10 do
--choix item
choix_obj=math.random(1,nb_obj)
boucle=0
out=0

repeat
objet=citymap.item[choix_obj]  --recuperation des données

-- objet deja selectionner ?
if string.find(trades_already_added,objet[1])== nil then

if xp>objet[6] then
local quant_obj=1
price=objet[5]*change
--currency calcul
if price<1 then
quantity=math.ceil(price*20)
money="currency:minegeld_cent_5"
else
if price<50 then
quantity=math.ceil(price)
money="currency:minegeld"

end
if price>49 then
quantity=math.ceil(price/5)
money="currency:minegeld_5"

end
if price>99 then
quantity=math.ceil(price/10)
money="currency:minegeld_10"

end
if price>499 then
quantity=math.ceil(price/50)
money="currency:minegeld_50"

end
if price>999 then
quantity=math.ceil(price/100)
money="currency:minegeld_100"

end
end
self.trades[trade_index]={objet[1].." "..tostring(quant_obj),money.." "..tostring(quantity)}
trades_already_added=trades_already_added.." "..objet[1]
trade_index = trade_index + 1
out=2

end
end
choix_obj=choix_obj+1
if choix_obj>nb_obj then
choix_obj=1
end
boucle=boucle+1
if boucle>19 then
out=2
end
until out>1
end
end


function mobs_trader(self, clicker, entity, race)

	if not self.id then
		self.id = (math.random(1, 1000) * math.random(1, 10000))
			.. self.name .. (math.random(1, 1000) ^ 2)
	end

	if not self.game_name then

		self.game_name = tostring(race.names[math.random(1, #race.names)])
		self.nametag = S("Trader @1", self.game_name)

		self.object:set_properties({
			nametag = self.nametag,
			nametag_color = "#00FF00"
		})
	end
local player = clicker:get_player_name()
	if self.trades == nil then
		mobs.add_goods(self, entity, race,player)
	end

	
local temp=#mobs.dialogue
local alea=math.random(1,temp)
local welcome=mobs.dialogue[alea]
	minetest.chat_send_player(player,
		S("[NPC] <Trader @1> Hello, @2, "..welcome,
		self.game_name, player))

	-- Make formspec trade list
	local formspec_trade_list = ""
	local x, y

	for i = 1, 10 do

		if self.trades[i] and self.trades[i] ~= "" then

			if i < 6 then
				x = 0.5
				y = i - 0.5
			else
				x = 4.5
				y = i - 5.5
			end

			formspec_trade_list = formspec_trade_list
			.. "item_image_button[".. x ..",".. y ..";1,1;"
				.. self.trades[i][2] .. ";prices#".. i .."#".. self.id ..";]"
			.. "item_image_button[".. x + 2 ..",".. y ..";1,1;"
				.. self.trades[i][1] .. ";goods#".. i .."#".. self.id ..";]"
			.. "image[".. x + 1 ..",".. y ..";1,1;gui_arrow_blank.png]"
		end
	end

	minetest.show_formspec(player, "mobs_npc:trade", "size[8,10]"
		.. default.gui_bg_img
		.. default.gui_slots
		.. "label[0.5,-0.1;" .. S("Trader @1's stock:", self.game_name) .. "]"
		.. formspec_trade_list
		.. "list[current_player;main;0,6;8,4;]"
	)
end


minetest.register_on_player_receive_fields(function(player, formname, fields)

	if formname ~= "mobs_npc:trade" then return end

	if fields then

		local trade = ""

		for k, v in pairs(fields) do
			trade = tostring(k)
		end

		local id = trade:split("#")[3]
		local self = nil

		if id ~= nil then

			for k, v in pairs(minetest.luaentities) do

				if v.object and v.id and v.id == id then
					self = v
					break
				end
			end
		end

		if self ~= nil then

			local trade_number = tonumber(trade:split("#")[2])

			if trade_number ~= nil and self.trades[trade_number] ~= nil then

				local price = self.trades[trade_number][2]
				local goods = self.trades[trade_number][1]
				local inv = player:get_inventory()

				if inv:contains_item("main", price) then

					inv:remove_item("main", price)

					local leftover = inv:add_item("main", goods)

					if leftover:get_count() > 0 then

						-- drop item(s) in front of player
						local droppos = player:get_pos()
						local dir = player:get_look_dir()

						droppos.x = droppos.x + dir.x
						droppos.z = droppos.z + dir.z

						minetest.add_item(droppos, leftover)
					end
				end
			end
		end
	end
end)

mobs:spawn({
	name = "mobs_npc:trader",
	nodes = {"default:brick","citymap:sol_shop"},
	min_light = 10,
	chance = 15000,
	min_height = 0,
	day_toggle = true,
})

mobs:register_egg("mobs_npc:trader", S("Trader"), "default_sandstone.png", 1)

-- compatibility
mobs:alias_mob("mobs:trader", "mobs_npc:trader")
