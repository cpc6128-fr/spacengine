
local S = mobs.intllib

-- define table containing names for use and shop items for sale

mobs.human = {

	names = {
		"Bob", "Duncan", "Bill", "Tom", "James", "Ian", "Lenny",
		"Dylan", "Ethan"
	}
}
mobs.dialogue = {
        "j'ai tout sauf de la biere",
        "no way",
        "tu veut tu de l'aide",
        "can i help you",
        "soit t'achete, soit tu passe ton chemin",
        "la fin du monde approche, depense tout chez moi"
    }

-- Trader ( same as NPC but with right-click shop )

mobs:register_mob("mobs_npc:trader", {
	type = "npc",
	passive = false,
	damage = 3,
	attack_type = "dogfight",
	attacks_monsters = true,
	attack_animals = false,
	attack_npcs = false,
	pathfinding = false,
	hp_min = 10,
	hp_max = 20,
	armor = 100,
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "mobs_character.b3d",
	textures = {
		{"mobs_trader.png"}, -- by Frerin
		
	},
	makes_footstep_sound = true,
	sounds = {},
	walk_velocity = 2,
	run_velocity = 3,
	jump = false,
	drops = {},
	water_damage = 0,
	lava_damage = 4,
	light_damage = 0,
	follow = {"default:diamond"},
	view_range = 15,
	owner = "",
	order = "stand",
	fear_height = 3,
	animation = {
		speed_normal = 30,
		speed_run = 30,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 187,
		run_start = 168,
		run_end = 187,
		punch_start = 200,
		punch_end = 219,
	},
	on_rightclick = function(self, clicker)
		mobs_trader(self, clicker, entity, mobs.human)
	end,
	on_spawn = function(self)
		self.nametag = S("Trader")
		self.object:set_properties({
			nametag = self.nametag,
			nametag_color = "#FFFFFF"
		})
		return true -- return true so on_spawn is run once only
	end,
})


--This code comes almost exclusively from the trader and inventory of mobf, by Sapier.
--The copyright notice below is from mobf:
-------------------------------------------------------------------------------
-- Mob Framework Mod by Sapier
--
-- You may copy, use, modify or do nearly anything except removing this
-- copyright notice.
-- And of course you are NOT allow to pretend you have written it.
--
--! @file inventory.lua
--! @brief component containing mob inventory related functions
--! @copyright Sapier
--! @author Sapier
--! @date 2013-01-02
--
--! @defgroup Inventory Inventory subcomponent
--! @brief Component handling mob inventory
--! @ingroup framework_int
--! @{
--
-- Contact sapier a t gmx net
-------------------------------------------------------------------------------

-- This code has been heavily modified by isaiah658.
-- Trades are saved in entity metadata so they always stay the same after
-- initially being chosen.  Also the formspec uses item image buttons instead of
-- inventory slots.

function mobs.add_goods(self, entity, race,player)

  self.pay={}
  self.objet={}
  local trade_index = 1
  local trades_already_added = ""
  local price=0
  local money="currency:minegeld"
  local boucle=0
  local objet={}
  local list_item=""
  local quantity=0
  local trades = {}
  local item_type=0
  
  --par type ou aleatoire ?
  if math.random(1,10)>6 then
      item_type=math.random(1,10)
  end

  -- nb d'item enregistrer
  local nb_item = #citymap.item
  --choix premier objet
  local choix_item=math.random(1,nb_item)

  -- effacement stack
  for i=1,10 do
      self.pay[i]=""
      self.objet[i]=""
  end

	for i=1,10 do
    boucle=19
    --choix objet si type aleatoire
    if item_type==0 then
        choix_item=math.random(1,nb_item)
    end
    
    repeat
      objet=citymap.item[choix_item]  --recuperation des données
      -- objet deja selectionner ?
      if string.find(trades_already_added,objet[2])== nil or boucle==1 then
              
        if item_type==0 or item_type==objet[1] or boucle==1 then
          local quantity=1
          list_item=list_item..choix_item.."/"
          self.pay[i]=money.." "..tostring(quantity)
          self.objet[i]=objet[2]
          trades_already_added=trades_already_added.." "..objet[2]
          boucle=0
        end
      end

      choix_item=choix_item+1
      if choix_item>nb_item then
        choix_item=1
      end
      boucle=boucle-1
    until boucle<1

  end

  local creat_dat=((startest.year-1)*168)+((startest.month-1)*14)+startest.day+42
  self.visit=creat_dat
  self.item=list_item

end


function mobs_trader(self, clicker, entity, race)


	if not self.id then
		self.id = (math.random(1, 1000) * math.random(1, 10000))
			.. self.name .. (math.random(1, 1000) ^ 2)
	end

	if not self.game_name then

		self.game_name = tostring(race.names[math.random(1, #race.names)])
		self.nametag = S("Trader @1", self.game_name)

		self.object:set_properties({
			nametag = self.nametag,
			nametag_color = "#00FF00"
		})
	end
local player = clicker:get_player_name()

	if self.item == nil then
		mobs.add_goods(self, entity, race,player)
	end

  local new_dat=((startest.year-1)*168)+((startest.month-1)*14)+startest.day

  if self.visit<new_dat then --si depasse la date, refill new item
    mobs.add_goods(self, entity, race,player)
  end

local temp=#mobs.dialogue
local alea=math.random(1,temp)
local welcome=mobs.dialogue[alea]
	minetest.chat_send_player(player,
		S("[NPC] <Trader @1> Hello, @2, "..welcome,
		self.game_name, player))

    local xp=xpgetlvl(clicker,"xp_lvl")+1

  local trades
  
  local list_item=string.split(self.item,"/")
  --position du magasin

  local formspec= "size[8,10]" .."bgcolor[#080808BB;true]" .."background[5,5;1,1;gui_formbg.png;true]" .."listcolors[#00000069;#5A5A5A;#141318;#30434C;#FFF]label[0,0;price]label[2,0;take item]button_exit[3,3;2,1;exit;exit]"
  local x, y=0,0.5
	
for i=1,#list_item do
  trades=self.objet[i]

-- effacement stack
  self.pay[i]=""
  local objet=""
  local money="currency:minegeld"
  local quantity=1
  if trades then
    local tmp=tonumber(list_item[i])
    local item_data=citymap.item[tmp]
    objet=item_data[2]
    local price=item_data[3]
    local newprice=price*((25+(xp*4))/100) --taux différent suivant XP            
    --currency calcul
    if newprice>2500 then
      quantity=math.ceil(newprice/100)
      money="currency:minegeld_100"
    elseif newprice>500 then
      quantity=math.ceil(newprice/50)
      money="currency:minegeld_50"
    elseif newprice>250 then
      quantity=math.ceil(newprice/10)
      money="currency:minegeld_10"
    elseif newprice>50 then
      quantity=math.ceil(newprice/5)
      money="currency:minegeld_5"
    elseif newprice>12.5 then
      quantity=math.ceil(newprice)
      money="currency:minegeld"
    elseif newprice>2.5 then
      quantity=math.ceil(newprice/0.25)
      money="currency:minegeld_cent_25"
    elseif newprice>0 then
      quantity=math.ceil(newprice/0.05)
      money="currency:minegeld_cent_5" 
    end
if i < 6 then
    x = 0
    y = i - 0.5
  else
    x = 5
    y = i - 5.5
  end
money=money.." "..tostring(quantity)
  formspec = formspec.. "item_image_button["..x..",".. y ..";1,1;"..money..";prices#".. i .."#".. self.id ..";]"
			.. "item_image_button["..x + 2 ..",".. y ..";1,1;".. objet .. ";goods#".. i .."#".. self.id ..";]"
			.. "image[".. x + 1 ..",".. y ..";1,1;gui_arrow_blank.png]"
self.pay[i]=money
  end

end
formspec = formspec.."list[current_player;main;0,6;8,4;]";




	minetest.show_formspec(player, "mobs_npc:trade", "size[8,10]"
		.. default.gui_bg_img
		.. default.gui_slots
		.. "label[3,-0.1;" .. "Trader "..self.game_name.."'s stock:]"
		.. formspec
	)
end


minetest.register_on_player_receive_fields(function(player, formname, fields)

	if formname ~= "mobs_npc:trade" then return end

	if fields then
    local xp=xpgetlvl(player,"xp_lvl")+1
		local trade = ""

		for k, v in pairs(fields) do
			trade = tostring(k)
		end

		local id = trade:split("#")[3]
		local self = nil

		if id ~= nil then

			for k, v in pairs(minetest.luaentities) do

				if v.object and v.id and v.id == id then
					self = v
					break
				end
			end
		end

		if self ~= nil then

			local trade_number = tonumber(trade:split("#")[2])

			if trade_number ~= nil and self.objet[trade_number] ~= nil then

				local price = self.pay[trade_number]
				local goods = self.objet[trade_number]
				local inv = player:get_inventory()

				if inv:contains_item("main", price) then

					inv:remove_item("main", price)

					local leftover = inv:add_item("main", goods)

					if leftover:get_count() > 0 then

						-- drop item(s) in front of player
						local droppos = player:get_pos()
						local dir = player:get_look_dir()

						droppos.x = droppos.x + dir.x
						droppos.z = droppos.z + dir.z

						minetest.add_item(droppos, leftover)
					end
				end
			end
		end
	end
end)
--
mobs:spawn({
	name = "mobs_npc:trader",
	nodes = {"default:brick"},
	min_light = 10,
	chance = 150000,
	min_height = 0,
	day_toggle = true,
})
--]]
mobs:register_egg("mobs_npc:trader", S("Trader"), "default_sandstone.png", 1)

-- compatibility
mobs:alias_mob("mobs:trader", "mobs_npc:trader")
