
--enable damage
local hurt_active=false
if minetest.setting_getbool("enable_damage") then
  hurt_active=true
end

--node spécial jail, régénère health
minetest.register_node("espace:health_jail", {
	description = "refill health",
	tiles ={"espace_health.png"},
	groups = {cracky=3, not_in_creative_inventory=1},
  on_rightclick=function(pos,node,player,itemstack)
    player:set_hp(20)
    player:set_attribute("fatigue","1000")
  end,
	sounds = default.node_sound_stone_defaults(),
})


--biome t=temperate h=hot c=cold
--***************
--** Hurt Test **
--***************
local hurt_timer=0

hurt_test=function(player)

  if hurt_active==false then return end

  hurt_timer=hurt_timer+1

  local playerpos=player:get_pos()
  local playername = player:get_player_name()
  local fatigue=0
  local hurt = tonumber(player:get_attribute("fatigue"))
  local chg_speed=1000

-- vitesse ralentit quand moins d'énergie, ou alors accelere quand en pleine forme
  if hurt<100 then
    chg_speed=chg_speed-math.ceil(100-hurt)
  elseif hurt>900 then
    chg_speed=math.ceil(hurt-900)+chg_speed
  end

  -- marche dans la neige difficile
  local snowpos=player:get_pos()
  local nodeup = minetest.get_node({x=snowpos.x,y=snowpos.y,z=snowpos.z})
  local nodedn = minetest.get_node({x=snowpos.x,y=snowpos.y-1,z=snowpos.z})

  if string.find(nodedn.name,"snow") or string.find(nodeup.name,"snow") then
    chg_speed=math.max(400,chg_speed-400)
  end

  if chg_speed~=1000 then
    fxadd(player,"snow",2,chg_speed,0,0,1)
  end

  if hurt_timer<3 then return end
  hurt_timer=0

  --on se fatigue quand on marche
  local controls = player:get_player_control()
  if controls.up or controls.down or controls.left or controls.right or controls.jump then
    fatigue=fatigue+5
  end

  --suit dans le slot 1 1:space:suit 2:nuclear_suit 3:toxic_suit
  local inv=player:get_inventory()
  local suit=0
  local w=0
            
  -- test si source de froid
  local ice_pos=minetest.find_node_near(playerpos, 6, {"group:freezer"})
  local ice=false
  if ice_pos~=nil then
    ice=true
  end

  -- test si source de chaleur
  local heat_pos=minetest.find_node_near(playerpos, 6, {"group:fire_heat"})
  local heat=false
  if heat_pos~=nil then
    heat=true
  end

  local suit_tmp=inv:get_stack("main", 1):get_name()
  if suit_tmp=="espace:spacesuit" then --froid/chaud
    suit=1
  elseif suit_tmp=="espace:nuclear_suit" then --chaud
    suit=2
  elseif suit_tmp=="espace:toxic_suit" then --chaud
    suit=3
  end
            
  if suit>0 then
    w=inv:get_stack("main", 1):get_wear()
  end

  -- teste si la temperature est inferieur a 5
  if espace.data[playername].temp<5 then
    if suit>0 then 
      if heat==false then
        w=math.min(65535,w+50)--usure de la combi
      end
    else
      if heat==false then
        --epuisement plus rapide en fonction de la temp.
        local t_actuel=math.ceil(espace.data[playername].temp-5)*2
        fatigue=fatigue-t_actuel
      end
    end
  end

  -- teste si la temperature est superieur a 38
  if espace.data[playername].temp>38 then
    if suit>0 then
      if ice==false then
        w=math.min(65535,w+50)
      end
    else
      if ice==false then
        --epuisement plus rapide quand forte chaleur                    
        local t_actuel=math.floor(espace.data[playername].temp-38)*2
        fatigue=fatigue+t_actuel
      end
    end
  end

  --oxygene
  local o=player:get_breath()
  local node=minetest.get_node(playerpos)
  if espace.data[playername].oxygen==false then
    if not string.find(node.name,"air") and suit~=1 then
      --TODO suffocation sound
      fatigue=fatigue+50
    end
  end

  if suit==1 then
    if o<10 then
      player:set_breath(10)
      w=math.min(65535,w+150)--(500*coef_use))
    
    elseif espace.data[playername].oxygen==false and not string.find(node.name,"air") then
      --player:set_breath(10)
      w=math.min(65535,w+150)--(500*coef_use))
    end
  end

  --radiation
  local radiation=espace.data[playername].radiation
  local radioactive_node=minetest.find_nodes_in_area({x=playerpos.x-3,y=playerpos.y-3,z=playerpos.z-3}, {x=playerpos.x+3,y=playerpos.y+3,z=playerpos.z+3}, {"group:radioactive"})

  if radioactive_node~=nil then radiation=radiation+(#radioactive_node*10) end

  if radiation>0 then
    if suit==1 or suit==2 then
      w=math.min(65535,w+((25*radiation)/suit))
    else
      fatigue=fatigue+radiation
    end
  end

  --nuage toxique
  if minetest.find_node_near(playerpos, 1, {"group:toxic"})~=nil then
    if suit==3 then
      w=math.min(65535,w+150)
    else
      fatigue=fatigue+15
    end
  end

  --meteo
  if not espace.is_inside(playerpos) then
    --pluie et neige légère
    if espace.data[playername].meteo=="weather_snow" or espace.data[playername].meteo=="weather_rain" then
      if suit==3 or suit==4 then
        w=math.min(65535,w+50)
      else
        fatigue=fatigue+5
      end
    end
    --orage et tempete de neige ou de sable
    if espace.data[playername].meteo=="weather_storm" or espace.data[playername].meteo=="weather_snow_storm" then
      if suit==3 or suit==4 then
        w=math.min(65535,w+50)
      else
        fatigue=fatigue+10
      end
    end
  end

  --sauvegarde suit ou enleve si user
  if suit>0 then
    if w>65534 then
      inv:set_stack("main", 1,ItemStack({name=""}))
      suit=0
    end

    if suit==1 then
      inv:set_stack("main", 1,ItemStack({name="espace:spacesuit",wear=w}))
    elseif suit==2 then
      inv:set_stack("main", 1,ItemStack({name="espace:nuclear_suit",wear=w}))
    elseif suit==3 then
      inv:set_stack("main", 1,ItemStack({name="espace:toxic_suit",wear=w}))
    end
  end

  --coeficient de fatigue diminue avec un xp élevé
  local xplvl_coef=math.max(1,101-espace.xpgetlvl(player,"endurance"))*0.02
  hurt=math.ceil(hurt-((fatigue+2.5)*xplvl_coef))
  local hp_lvl=player:get_hp()

  --régénère hp quand énergie>80%
  if hp_lvl<20 and hurt>800 then
    hurt=hurt-20
    player:set_hp(hp_lvl+1)
  end

  if hurt<1 then 
    hurt=0
    player:set_hp(hp_lvl-1)
  end

  player:set_attribute("fatigue",tostring(hurt))

end

-- override core.do_item_eat() so we can redirect hp_change to stamina
core.do_item_eat = function(hp_change, replace_with_item, itemstack, user, pointed_thing)
	local old_itemstack = itemstack
	itemstack = espace.eat(hp_change, replace_with_item, itemstack, user, pointed_thing)
	for _, callback in pairs(core.registered_on_item_eats) do
		local result = callback(hp_change, replace_with_item, itemstack, user, pointed_thing, old_itemstack)
		if result then
			return result
		end
	end
	return itemstack
end

--from STAMINA mod
-- not local since it's called from within core context
function espace.eat(hp_change, replace_with_item, itemstack, user, pointed_thing)
	if not itemstack then
		return itemstack
	end

	if not user then
		return itemstack
	end

	local level = tonumber(user:get_attribute("fatigue"))
	if level > 999 then
		return itemstack
	end

	if hp_change > 0 then
    local coef=math.max(1,101-espace.xpgetlvl(user,"endurance"))
		level = math.min(1000,level + (hp_change*coef))
		--stamina_update_level(user, level)
    user:set_attribute("fatigue", level)
	end

  --incremente level endurance
  espace.xplevel(hp_change,user,"endurance")
    
	minetest.sound_play("stamina_eat", {to_player = user:get_player_name(), gain = 0.7})

	-- particle effect when eating
	local pos = user:getpos()
	pos.y = pos.y + 1.5 -- mouth level
	local itemname = itemstack:get_name()
	local texture  = minetest.registered_items[itemname].inventory_image
	local dir = user:get_look_dir()

	minetest.add_particlespawner({
		amount = 5,
		time = 0.1,
		minpos = pos,
		maxpos = pos,
		minvel = {x = dir.x - 1, y = dir.y, z = dir.z - 1},
		maxvel = {x = dir.x + 1, y = dir.y, z = dir.z + 1},
		minacc = {x = 0, y = -5, z = 0},
		maxacc = {x = 0, y = -9, z = 0},
		minexptime = 1,
		maxexptime = 1,
		minsize = 1,
		maxsize = 2,
		texture = texture,
	})

	itemstack:take_item()

	if replace_with_item then
		if itemstack:is_empty() then
			itemstack:add_item(replace_with_item)
		else
			local inv = user:get_inventory()
			if inv:room_for_item("main", {name=replace_with_item}) then
				inv:add_item("main", replace_with_item)
			else
				pos.y = math.floor(pos.y - 1.0)
				core.add_item(pos, replace_with_item)
			end
		end
	end

	return itemstack
end
