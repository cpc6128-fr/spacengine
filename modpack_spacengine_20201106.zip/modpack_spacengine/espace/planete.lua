--***************************
--** Multi layer generator **
--***************************
--By CPC6128 -- Philippe Romand -- 2019/2020


-- INIT
local height_perlin
local perlin_modifier
local cave_perlin
local cave_perlin_map = {}
--local heigthmap={} --heightmap ->heigth
local nb_layer=#planet_layer
local y_start=0
local pattern_old=""
local pattern_data={}
local surface_data={}
local deco_data={}
local sizex,sizez=1,0
--

for i=1,nb_layer do

--!! init sum ores !!

  local tmp=planet_layer[i].node
  local top= tmp.top
  if planet_layer[i].tsum==nil then
    planet_layer[i]["tsum"]=espace.sum_ores(top)
  end

  local bottom= tmp.bottom
  if planet_layer[i].bsum==nil then
    planet_layer[i]["bsum"]=espace.sum_ores(bottom)
  end

  local ores=tmp.ores
  if  planet_layer[i].osum==nil then
    planet_layer[i]["osum"]=espace.sum_ores(ores)
  end

--!! init decoration !!

  if planet_layer[i].deco~=nil then
    local decoration=planet_layer[i].deco

    for j=1,#decoration do

      local file=decoration[j][2]

        if string.find(file,":") then
          planet_layer[i]["deco"][j][6]=0
          planet_layer[i]["deco"][j][7]="0/0/0"

        elseif string.find(file,"%.mts") then
          --lecture du MTS
          local file_dat = io.open(minetest.get_modpath("espace").."/schematics/"..file)
          local value = file_dat:read(12)--("*a")
          file_dat:close()

          local x = string.byte(string.sub(value, 8, 8)) + string.byte(string.sub(value, 7, 7)) * 256
          local y = string.byte(string.sub(value, 10, 10)) + string.byte(string.sub(value, 9, 9)) * 256
          local z = string.byte(string.sub(value, 12, 12)) + string.byte(string.sub(value, 11, 11)) * 256
          if decoration[j][6]~=nil then
            planet_layer[i]["deco"][j][7]= x .."/".. y .."/".. z
          else
            planet_layer[i]["deco"][j][6]=0
            planet_layer[i]["deco"][j][7]= x .."/".. y .."/".. z
          end
--minetest.log(file.." : "..planet_layer[i]["deco"][j][7])
        elseif string.find(file,"%.we") then

          local file_dat = io.open(minetest.get_modpath("espace").."/schematics/"..file)
          local value = file_dat:read(21)--("*a")
          file_dat:close()
          local version, header=worldedit.read_header(value)
          if version==5 then
            if decoration[j][6]~=nil then
              planet_layer[i]["deco"][j][7]=header
            else
              planet_layer[i]["deco"][j][6]=0
              planet_layer[i]["deco"][j][7]=header
            end
          end
        end

    end

  end
end

--------------
-- function --
--------------

--******************
--** command chat **
--******************
minetest.register_chatcommand("layer_info", {
    params = "",
    description = "show info layer",
    func = function(name)
for i=1,nb_layer do
local phrase="layer nb "..i.." : "..planet_layer[i].name .." ( alt. : "
local tmp=10450+((i-1)*640)+math.abs(planet_layer[i]["water"])+1
phrase=phrase..tmp.." blocs )"
minetest.chat_send_player(name, phrase)
end
end
})
--
--** juste pour les test **
minetest.register_chatcommand("layer", {
    params = "<dst>",
    description = "teleport to layer",
    func = function(player,dst)
  
  local found,_,layer=dst:find("^(%a+)$")
  local alt_pos={x=0,y=0,z=0}
  local phrase=nil
  if layer then
if layer=="earth" then
alt_pos={x=0,y=611,z=0}
        phrase="layer name : "..layer
else 
    for i=1,nb_layer do
      if layer==planet_layer[i].name then
        local calcul=10450+((i-1)*640)+math.abs(planet_layer[i]["water"])+1
        alt_pos={x=0,y=calcul,z=0}
        phrase="layer name : "..layer
      end
    end
end
  else
    found,_,layer=dst:find("^(%d+)$",1)
    if layer then
      local nb=tonumber(layer)
      if nb>0 and nb<=nb_layer then
        local calcul=10450+((nb-1)*640)+math.abs(planet_layer[nb]["water"])+1
        alt_pos={x=0,y=calcul,z=0}
        phrase="layer Nb "..nb
      end
    end
  end

  if phrase then
    phrase=phrase.." : "..minetest.pos_to_string(alt_pos)
    minetest.get_player_by_name(player):set_pos(alt_pos)
    minetest.chat_send_player(player, phrase)
  end
end
})
--]]

--****************************
--** generation espace vide **
--****************************
local default_map=function(minp,maxp)
  local vm, emin, emax = minetest.get_mapgen_object("voxelmanip")
  local area = VoxelArea:new{MinEdge=emin, MaxEdge=emax}
  local data = vm:get_data()
  local side_length = maxp.x - minp.x + 1 -- 80
  local map_lengths_xyz = {x=side_length, y=side_length, z=side_length}
  local c_space=minetest.get_content_id("vacuum:vacuum") -- vacuum

	for z=minp.z,maxp.z do
	for y=minp.y,maxp.y do
	for x=minp.x,maxp.x do
		local index = area:index(x,y,z)
    data[index] = c_space
  end
  end
  end
  
  vm:set_data(data)
	vm:write_to_map()
end

--***************************
--** generation spawn 0/0  **
--***************************
local layer_spawn=function(minp,layer)
if minp.x<-32 or minp.x>0 then return end
if minp.z<-32 or minp.z>0 then return end
  local calcul=10450+((layer-1)*640)+math.abs(planet_layer[layer]["water"])
  local tmp1={x=-3,y=calcul,z=-3}
  local filename = minetest.get_modpath("espace").."/schematics/stargate.mts"
  minetest.place_schematic(tmp1, filename, "0", nil, true)
espace.replace_objet({x=tmp1.x-1,y=tmp1.y-1,z=tmp1.z-1},{x=tmp1.x+7,y=tmp1.y+7,z=tmp1.z+7})
  --local file = io.open(minetest.get_modpath("espace").."/schematics/stargate.we")
  --local value = file:read("*a")
  --file:close()
  --worldedit.deserialize(tmp1, value)

end

--*****************************************************************************

-----------------
--generated map--
-----------------
minetest.register_on_generated(function(minp, maxp, seed)

  if minp.y<10208 then
    return
  end
  --calcul layer multimap 
  layer=math.floor((minp.y-10208)/640)+1

  --
  if layer>nb_layer then --pas de layer execut default map
    default_map(minp,maxp)
    return
  end
  if planet_layer[layer].name=="default" then --default
    default_map(minp,maxp)
    return
  end


  --** init param layer **
  local tmplayer=planet_layer[layer]
  local tmp=tmplayer.perlinpri
  -- basic planet height noise
  local height_params = {
	offset = 0,
	scale = 1,
	spread = {x=tmp.spread, y=tmp.spread, z=tmp.spread},
	seed = tmp.seed,
	octaves = tmp.octaves,
	persist = 1
}

--modifier
local tmp=tmplayer.perlinsec
local modifier = {
	offset = 0,
	scale = 1,
	spread = {x=tmp.spread, y=tmp.spread, z=tmp.spread},
	seed = tmp.seed,
	octaves = tmp.octaves,
	persist = 1
}

-- cave noise
tmp=tmplayer.cave
local cave_params = {
	offset = 0,
	scale = 2,
	spread = {x=tmp.spread, y=tmp.spread, z=tmp.spread},
	seed = tmp.seed,
	octaves = tmp.octave,
	persist = 0.5
}

local scale=tmplayer.scale
local top_level=math.min(60,tmplayer.top)
local bottom_level=tmplayer.bottom
local water_level=tmplayer.water
local cliff_level=tmplayer.cliff
local valley_level=tmplayer.valley
local calc=tmplayer.calc

local rnd_lvl=2
if tmplayer.rnd~=nil then
  rnd_lvl = tmplayer.rnd
end

tmp=tmplayer.node
local c_top= tmp.top
if tmplayer.tsum==nil then
tmplayer["tsum"]=espace.sum_ores(c_top)
end
local tsum=tmplayer.tsum

local c_bottom= tmp.bottom
if tmplayer.bsum==nil then
tmplayer["bsum"]=espace.sum_ores(c_bottom)
end
local bsum=tmplayer.bsum

local ores=tmp.ores
if tmplayer.osum==nil then
tmplayer["osum"]=espace.sum_ores(ores)
end
local osum=tmplayer.osum

local c_special
local nbspecial=0
if tmp.special~=nil then
c_special= tmp.special
nbspecial=#c_special
end

--default
local c_air

if tmp.air~=nil then
  c_air = minetest.get_content_id(tmp.air)
else
  c_air = minetest.get_content_id("air")
end

local c_water
if tmp.water~=nil then
  c_water = minetest.get_content_id(tmp.water)
else
  c_water = minetest.get_content_id("default:water_source")
end

local c_cave1
if tmp.cave1~=nil then
c_cave1 = minetest.get_content_id(tmp.cave1)
else
c_cave1 = minetest.get_content_id("default:lava_source")
end

local c_cave2
if tmp.cave2~=nil then
c_cave2 = minetest.get_content_id(tmp.cave2)
else
c_cave2 = minetest.get_content_id("air")
end

local c_seagrd
if tmp.seagrd~=nil then --fond des oceans different
  c_seagrd = minetest.get_content_id(tmp.seagrd)
else
  c_seagrd = minetest.get_content_id("default:sand")
end


local c_bedrock = minetest.get_content_id("espace:bedrock")

y_start=10208+(layer-1)*640
local y_stop=y_start+641


-- Definition Altitude
  local alt_top = y_start+242+top_level
  local alt_bottom = y_start+242+bottom_level
  local alt_water = y_start+242+math.abs(water_level)
  local alt_stone = y_start+239
  local alt_bedrock=y_start+2
  local alt_cave=y_start+220
  local alt_cloud=y_start+450
  local spawn=false

--local alt_trig=y_start+242+top_level
local trig=top_level
if tmplayer.trig~=nil then
  trig=tmplayer.trig
end

  if minp.x==-32 and minp.z==-32 and minp.y==(y_start+240) then --arriver au spawn
    spawn=true
  end

--
	local vm, emin, emax = minetest.get_mapgen_object("voxelmanip")
	local area = VoxelArea:new{MinEdge=emin, MaxEdge=emax}
	local data = vm:get_data()

	local side_length = maxp.x - minp.x + 1 -- 80
	local map_lengths_xyz = {x=side_length, y=side_length, z=side_length}

  local heightmap={}
  local indexpatt=1 --index heigthmap pattern
	local index2d = 1
  local index3d=0
  local xi=0
  local zi=0

local xx,zz=0,0
local patternx,patternz,pattern_zoom,luminosit,contrast=0,0,0,0,0
local pattern_swap=0
local extendpattern=false

if tmplayer.pattern~=nil then

  if tmplayer.pattern[5]~=nil then
    pattern_swap=tmplayer.pattern[5]
  else
    pattern_swap=1
  end

  pattern_zoom=tmplayer.pattern[2]
  luminosit=tmplayer.pattern[3]/25

  contrast=tmplayer.pattern[4]/100

  if contrast>0 then
    contrast=contrast*4
  else
    contrast=contrast+1
  end

  if tmplayer.pattern[1]~=pattern_old then
    pattern_old=tmplayer.pattern[1]
    pattern_data,sizex,sizez,surface_data,deco_data=espace.load_bmp(tmplayer.pattern[1],pattern_swap)
  end

  if pattern_swap>8 then
    extendpattern=true
    pattern_swap=pattern_swap-8
  end

  local tmpx=minp.x+31000
  local tmpz=minp.z+31000

  tmpx=tmpx/(sizex*pattern_zoom)
  tmpz=tmpz/(sizez*pattern_zoom)
  
  pattern_zoom=1/pattern_zoom

  patternx=(tmpx-math.floor(tmpx))*sizex+1
  patternz=(tmpz-math.floor(tmpz))*sizez
  xx=patternx
  zz=patternz
end
if pattern_swap==0 or pattern_swap==5 then
  height_perlin = minetest.get_perlin_map(height_params, map_lengths_xyz):get2dMap_flat({x=minp.x, y=minp.z})
  perlin_modifier = minetest.get_perlin_map(modifier, map_lengths_xyz):get2dMap_flat({x=minp.x, y=minp.z})
else
  if pattern_swap==2 or pattern_swap==4 then
    height_perlin = minetest.get_perlin_map(height_params, map_lengths_xyz):get2dMap_flat({x=minp.x, y=minp.z})
  else
    perlin_modifier = minetest.get_perlin_map(modifier, map_lengths_xyz):get2dMap_flat({x=minp.x, y=minp.z})
  end
end  

  cave_perlin = minetest.get_perlin_map(cave_params, map_lengths_xyz)
  cave_perlin:get3dMap_flat(minp, cave_perlin_map)

local c_surface

--Start generated
	for z=minp.z,maxp.z do
        
	for x=minp.x, maxp.x do
    local mountain
    local mdf

  indexpatt=math.floor(xx)+(math.floor(zz)*sizez)

if pattern_swap>0 then
  local alt=pattern_data[indexpatt]
  alt=alt*contrast

  if luminosit>0 then
    alt=math.min(4,alt+luminosit)
  else
    alt=math.max(0,alt+luminosit)
  end
    
  if pattern_swap==1 or pattern_swap==3 then
    mountain=alt --/15
    mdf=math.abs(perlin_modifier[index2d])
  elseif pattern_swap==2 or pattern_swap==4 then
    mountain=math.abs(height_perlin[index2d])
    mdf=alt --/60
  end

  if pattern_swap>2 then
    c_surface=math.floor(surface_data[indexpatt]/16)+1
  end
else
  mountain=math.abs(height_perlin[index2d])
  mdf=math.abs(perlin_modifier[index2d])
end

    if mountain>4 then mountain=4 end --limitation
    if mdf>4 then mdf=4 end

--// calcul //

    if calc=="dif" then --difference
      if mountain>mdf then
        mountain=mountain-mdf
      else
        mountain=mdf-mountain
      end
                               
    elseif calc=="squ" then --square
      mountain=(mountain*mountain)
            
    elseif calc=="low" then --si plus bas
      if mdf<mountain then
        mountain=mdf
      end

    elseif calc=="exp" then --exponentielle
      mdf=math.max(0.05,mdf)
      mountain=mountain/mdf
                               
    elseif calc=="add" then --addition
      mountain=mountain+mdf

    elseif calc=="dec" then --soustraction
      mountain=math.max(0,mountain-mdf)

    elseif calc=="mul" then --multiplication
      mountain=mountain*mdf

    elseif calc=="smo" then --smooth
        mountain=((mountain*4.5)-math.sin(mountain*5))/3
        if mountain>mdf then
          mountain=mountain+mdf
        end
    end

    mountain=mountain*scale --mise a l'echelle de la map
    mdf=mdf*scale

      if mountain<valley_level and mdf<valley_level then --valley
          mountain=math.floor(mountain-((valley_level-mdf)/3))
      end

      if mountain>math.abs(cliff_level) and cliff_level~=0 then --cliff
        if cliff_level<0 then
          local tmp=(top_level+cliff_level)/2.5
          mountain=(math.abs(cliff_level)-tmp)-(mountain+cliff_level)                               
        else
          mountain=mountain+((top_level-mountain)/2.5)
        end
      end

    if calc=="trig" then --trig
      if mountain>trig then mountain=trig+(((mountain-trig)/10)*mdf) end
      if pattern_swap>2 then
        if c_surface==11 then
          mountain=0
        elseif c_surface==1 then --plateau
          mountain=math.min(mountain,trig)
        elseif c_surface==2 then --depression
          mountain=mountain-1
        elseif c_surface==15 then --alea
          mountain=mountain*math.min(2,(mdf/(trig+1)))
        end
      end

    end

    if mountain<0 then mountain = 0 end --limitation basse et haute
    if mountain>top_level then mountain = top_level end
    
    if spawn then --aplatir la map au spawn
        local spawnx,spawnz
        if (x-minp.x)<15 then
          spawnx=(minp.x+15)-x
        elseif (x-minp.x)<65 then
          spawnx=0
        elseif (x-minp.x)<80 then
          spawnx=x-(65+minp.x)
        end
        if (z-minp.z)<15 then
          spawnz=(minp.z+15)-z
        elseif (z-minp.z)<65 then
          spawnz=0
        elseif (z-minp.z)<80 then
          spawnz=z-(65+minp.z)
        end

        spawnx=math.max(spawnx,spawnz)*0.06
        mountain=mountain*spawnx
        if mountain<math.abs(water_level) then mountain=math.abs(water_level) end
      end

    alt_top = math.floor(y_start+242+mountain)
    alt_stone=y_start+239+mountain
    
    if alt_top<alt_water then --sauvegarde du heightmap
      if water_level<0 then
        heightmap[index2d]=alt_top
      else  
        heightmap[index2d]=-alt_water
      end
    else
      heightmap[index2d]=alt_top
    end
    
    index3d=xi+zi+1
                              
		for y=minp.y,maxp.y do
      local index = area:index(x,y,z)

      local cave_dat =cave_perlin_map[index3d]
      
			if y <  alt_bedrock then --bedrock
				data[index] = c_bedrock

			elseif y < alt_stone then --underground
                               
				if y < alt_cave then --cave

          if cave_dat>-0.05 and cave_dat<0.05 then
            data[index]=c_cave1
          else
            data[index]=espace.generat_sol(ores,osum,y,y_start)
          end

          if cave_dat>0.7 and cave_dat<0.75 then
            data[index]=c_cave2
          end
 
        else          
            data[index]=espace.generat_sol(ores,osum,y,y_start)
        end
        
      elseif y < alt_top then --mountain
        if pattern_swap>2 and spawn==false then
          if c_surface<11 then
            if c_surface>nbspecial then
              data[index] = espace.generat_sol(c_bottom,bsum,y,y_start)
              heightmap[index2d]=alt_top
            else
              data[index] = minetest.get_content_id(c_special[c_surface])
              heightmap[index2d]=alt_top+(31000*(c_surface))
            end
          elseif c_surface==11 then
            data[index] = c_water
            heightmap[index2d]=-alt_top
          elseif c_surface==12 then
            data[index] = c_seagrd
            heightmap[index2d]=-alt_top
          elseif c_surface==13 then
            data[index] = espace.generat_sol(c_bottom,bsum,y,y_start)
            heightmap[index2d]=alt_top+341000
          elseif c_surface==14 then
            data[index] = espace.generat_sol(c_top,tsum,y,y_start)
            heightmap[index2d]=alt_top+372000
          else
            if y<alt_bottom-math.random(0,rnd_lvl) then --basse altitude
              if water_level~=0 and y<alt_water-1 then --sea
                data[index] = c_seagrd
              else
                data[index] = espace.generat_sol(c_bottom,bsum,y,y_start)
              end
            else
              data[index] = espace.generat_sol(c_top,tsum,y,y_start)
            end
          end

        else
          if nbspecial>0 and spawn==false then
            c_surface=math.floor(math.max(0,mountain-bottom_level)/trig)+1
            if c_surface<=nbspecial then
              if water_level~=0 and y<alt_water-1 then --sea
                data[index] = c_seagrd
              elseif y<alt_bottom then
                data[index] = espace.generat_sol(c_bottom,bsum,y,y_start)
              else
                data[index] = minetest.get_content_id(c_special[c_surface])
                heightmap[index2d]=alt_top+(31000*(c_surface))
              end
            else
              data[index] = espace.generat_sol(c_top,tsum,y,y_start)
            end
          else
            if y<alt_bottom-math.random(0,rnd_lvl) then --basse altitude
              if water_level~=0 and y<alt_water-1 then --sea
                data[index] = c_seagrd
              else
                data[index] = espace.generat_sol(c_bottom,bsum,y,y_start)
              end
            else
              data[index] = espace.generat_sol(c_top,tsum,y,y_start)
            end
          end
        end

      else --air / water

        if water_level>0 and y<alt_water then
            data[index] = c_water
        else
          if calc=="cloud" then
            if y>(alt_bottom+top_level) and y<alt_cloud then --option roche volante 3d
              if cave_dat>-0.05 and cave_dat<0.07 then
                data[index]=espace.generat_sol(ores,osum,y,y_start)
              else
                data[index]=c_air
              end
            else
              data[index]=c_air
            end
          else
          data[index] = c_air
          end
        end
                               
      end

    index3d=index3d+80

		end --y

xi=xi+1

xx=xx+pattern_zoom

if xx>(sizex+0.9) then
xx=1
end

index2d = index2d + 1

	end --x

    zi=zi+6400
xi=0

xx=patternx
zz=zz+pattern_zoom
if zz>(sizez-0.1) then
zz=0
end

	end --z
 
	vm:set_data(data)
	vm:write_to_map()

-- decoration
if maxp.y>alt_water and minp.y<(y_start+242+top_level) then

  if spawn==true then
    layer_spawn(minp,layer)
    return
  end

  if planet_layer[layer].deco~=nil then --si deco valide
    minp.y=y_start+242

    if extendpattern then --heightmap du bmp pour deco specifique
      espace.deco(planet_layer[layer].deco,planet_layer[layer].node,minp,maxp,deco_data,bottom_level)
    else
      espace.deco(planet_layer[layer].deco,planet_layer[layer].node,minp,maxp,heightmap,bottom_level)
    end
  end

end

end)
