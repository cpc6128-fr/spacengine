commerce={}

local mp_c=minetest.get_modpath("commerce")
dofile(mp_c .. "/data.lua")
dofile(mp_c .. "/commerce.lua")
dofile(mp_c .. "/bank.lua")
dofile(mp_c .. "/coffre.lua")
dofile(mp_c .. "/licence.lua")
dofile(mp_c .. "/civilisation.lua")

--_____________________________________________________
