--[[
SPACENGINE 2020 by CPC6128

sound : lasonotheque.org

channel=nom du vaisseaux
--]]

--protect en cas de dig si channel~="No channel"-->pas de destruction
spacengine.can_dig=function(pos,player)

  if player and player:is_player() and minetest.is_protected(pos, player:get_player_name()) then
		-- protected
		return false
	end

  if spacengine.owner_check(player,pos)~=2 then return true end

  local nod_met = minetest.get_meta(pos)
  local channel=nod_met:get_string("channel")
  local split=string.split(channel,":")
  if split[1]~="No channel" then return true end
  return true
end

--option = * tool / & MaJ disable / ~ screen / < param / > value / + submenu 1 accept upgrade, 2 accept repar
spacengine.rightclick=function(pos, node, player,option,maj)

  local tool = player:get_wielded_item():get_name()
  local meta = minetest.get_meta(pos)
  local vente=meta:get_string("vente")
  local check=spacengine.owner_check(player,pos,vente)

  if check==1 and tool=="spacengine:tool" then
    return spacengine.formspec_update(pos,player,option.."#+5",check)
  end

  if check<2 then return false end

  if tool == "spacengine:tool" then
    if minetest.get_item_group(node.name,"spacengine")==12 then
      return spacengine.formspec_update(pos,player,option.."#1#-",check) -- screen
    end
    --acces configuration
    if maj==nil then
      return spacengine.formspec_update(pos,player,option.."#1#*",check) -- tool
    else
      return spacengine.formspec_update(pos,player,option.."#1#*&",check) -- bloque maj
    end
  end

  if minetest.get_item_group(node.name,"spacengine")==12 then
    return spacengine.formspec_update(pos,player,option.."#1#<",check) -- param
  end
end

spacengine.construct_node=function(pos,module_name,data,group)
  local meta = minetest.get_meta(pos)
  if group==nil then group=0 end

  if group==1 then
    local inv = meta:get_inventory()
    inv:set_size("stock", 6)

local config={
{0,0,0,"x0y0z0v1331",{pos.x,pos.y,pos.z},{0,0,0}},
{0,0},
{0,0,0,{0},{0}},
{0,0,0,{0,0,0,0,0},0,0,0},
{0,0,0,0},
{0,0,0,0,0,0,0,0},
{0,0,0,"none:none",0,0},
{0,0},
{0,0,{0,0,0,0,0,0,0}},
{0,0,{0,0,0,0,0}},
{0,0,0,0},
{"n"},
{0,0,0,0,"none:none:0:none",1,"n",1,"ok",-1,0,0},
{0},
{33333,0,0,0}
}

    meta:set_string("config",spacengine.compact(config))
    meta:set_string("stock_pos","33333#0#0")
    meta:set_string("pos_cont",pos.x.."¨"..pos.y.."¨"..pos.z)
  else
    meta:set_string("pos_cont","33333¨0¨0")
  end

  meta:set_string("channel","No channel:noplayer")
  meta:set_string("spacengine",data)
  

  if group==12 then --screen stockage texte
    monitor.construct_sign(pos,nil,true)
  else
    meta:set_string("infotext",module_name)--name
  end

end

spacengine.placer_node=function(pos,placer)
  local meta = minetest.get_meta(pos)
  meta:set_string("channel","No channel:"..placer:get_player_name())
end

--controler
minetest.register_node("spacengine:controler", {
	description = "controler",
	tiles = {"spacengine_compass.png^[transformR90", "spacengine_side.png^[transformR90", "spacengine_side.png", "spacengine_side.png", "spacengine_cnt_front.png", {
			image = "spacengine_cnt_front_animated.png",
			backface_culling = false,
			animation = {
				type = "vertical_frames",
				aspect_w = 32,
				aspect_h = 32,
				length = 1
			},
		}},
  drawtype = "nodebox",
  node_box = {
		type = "fixed",
		fixed = {
			{-0.5, 0.4375, -0.5, 0.5, 0.5, 0.5}, -- NodeBox1
			{-0.5, -0.5, -0.5, 0.5, -0.4375, 0.5}, -- NodeBox2
			{-0.5, -0.5, -0.5, -0.4375, 0.5, 0.5}, -- NodeBox3
			{0.4375, -0.5, -0.5, 0.5, 0.5, 0.5}, -- NodeBox4
			{-0.4375, -0.4375, -0.4375, 0.4375, 0.4375, 0.4375}, -- NodeBox5
		}
	},
	groups = {cracky=4, spacengine=1},
	sounds = default.node_sound_stone_defaults(),
  on_construct=function(pos)
    spacengine.construct_node(pos,"CONTROLER beta5","^Aa¨250¨0¨^x0y0z0v1331¨6",1)
  end,
  after_place_node=function(pos,placer)
    spacengine.placer_node(pos,placer)
  end,
  on_rightclick = function(pos, node, player, itemstack, pointed_thing)
    spacengine.rightclick(pos,node,player,"controler")
	end,
  can_dig=spacengine.can_dig,
  on_timer=function(pos,elapsed)
    local timer=minetest.get_node_timer(pos)
    if timer:is_started() then return false end
    spacengine.controler(pos)
    timer:set(5,0)
  end,
  on_destruct=function(pos)
    minetest.get_node_timer(pos):stop()
  end
})


--battery
minetest.register_node("spacengine:battery", {
	description = "battery",
	tiles = {"spacengine_side.png^[transformR90", "spacengine_side.png^[transformR90", "spacengine_side.png", "spacengine_side.png", "spacengine_front.png", "spacengine_battery_front.png"},
  drawtype = "nodebox",
  node_box = {
		type = "fixed",
		fixed = {
			{-0.5, 0.4375, -0.5, 0.5, 0.5, 0.5}, -- NodeBox1
			{-0.5, -0.5, -0.5, 0.5, -0.4375, 0.5}, -- NodeBox2
			{-0.5, -0.5, -0.5, -0.4375, 0.5, 0.5}, -- NodeBox3
			{0.4375, -0.5, -0.5, 0.5, 0.5, 0.5}, -- NodeBox4
			{-0.4375, -0.4375, -0.4375, 0.4375, 0.4375, 0.4375}, -- NodeBox5
		}
	},
  paramtype2 = "facedir",
	groups = {cracky=4,spacengine=2},
	sounds = default.node_sound_stone_defaults(),
  on_construct=function(pos)
    spacengine.construct_node(pos,"BATTERY 50","^A¨50¨0¨5000",2)
  end,
  after_place_node=function(pos,placer)
    spacengine.placer_node(pos,placer)
  end,
  on_rightclick = function(pos, node, player, itemstack, pointed_thing)
    spacengine.rightclick(pos,node,player,"battery")
	end,
  can_dig=spacengine.can_dig,
  on_rotate = screwdriver.rotate_simple,
})

--power
minetest.register_node("spacengine:power", {
	description = "Power",
	tiles ={"spacengine_power_uv.png"},
  drawtype = "mesh",
  mesh = "power.obj",
  paramtype2 = "facedir",
  paramtype = "light",
	groups = {cracky=4,spacengine=3},
	sounds = default.node_sound_stone_defaults(),
  on_construct=function(pos)
    spacengine.construct_node(pos,"Generator Charcoal","1¨100¨0¨5¨^default:coal_lump¨^battery¨10¨0¨0¨0",3)
  end,
  after_place_node=function(pos,placer)
    spacengine.placer_node(pos,placer)
  end,
  on_rightclick = function(pos, node, player, itemstack, pointed_thing)
    spacengine.rightclick(pos,node,player,"power")
	end,
  can_dig=spacengine.can_dig,
})

--engine
minetest.register_node("spacengine:engine", {
	description = "engine",
	tiles ={"spacengine_side.png^[transformR90", "spacengine_side.png^[transformR90", "spacengine_side.png", "spacengine_side.png", "spacengine_engine_front.png", "spacengine_engine_front.png"},
  drawtype = "nodebox",
  node_box = {
		type = "fixed",
		fixed = {
			{-0.5, 0.4375, -0.5, 0.5, 0.5, 0.5}, -- NodeBox1
			{-0.5, -0.5, -0.5, 0.5, -0.4375, 0.5}, -- NodeBox2
			{-0.5, -0.5, -0.5, -0.4375, 0.5, 0.5}, -- NodeBox3
			{0.4375, -0.5, -0.5, 0.5, 0.5, 0.5}, -- NodeBox4
			{-0.4375, -0.4375, -0.4375, 0.4375, 0.4375, 0.4375}, -- NodeBox5
		}
	},
  paramtype2 = "facedir",
  light_source = 7,
	groups = {cracky=4,spacengine=4},
	sounds = default.node_sound_stone_defaults(),
  on_construct=function(pos)
    spacengine.construct_node(pos,"Rocket","^A¨75¨0¨10¨50¨50¨1000",4)
  end,
  after_place_node=function(pos,placer)
    spacengine.placer_node(pos,placer)
  end,
  on_rightclick = function(pos, node, player, itemstack, pointed_thing)
    spacengine.rightclick(pos,node,player,"engine")
	end,
  can_dig=spacengine.can_dig,
})

--shield
minetest.register_node("spacengine:shield", {
	description = "shield",
  inventory_image = "spacengine_shield_inv.png",
  tiles ={{
			image = "spacengine_shield_animated.png",
			backface_culling = false,
			animation = {
				type = "vertical_frames",
				aspect_w = 64,
				aspect_h = 64,
				length = 1
			},
		}},
  drawtype = "plantlike",
  use_texture_alpha = true,
  selection_box = { type = "fixed", fixed = { -0.4,-0.5,-0.4,0.4,0.5,0.4} },
  collision_box = { type = "fixed", fixed = { -0.4,-0.5,-0.4,0.4,0.5,0.4} },
  light_source = 7,
	groups = {cracky=4,spacengine=5},
	sounds = default.node_sound_stone_defaults(),
  on_construct=function(pos)
    spacengine.construct_node(pos,"Shield SB1","^A¨100¨0¨25¨1",5)
  end,
  after_place_node=function(pos,placer)
    spacengine.placer_node(pos,placer)
  end,
  on_rightclick = function(pos, node, player, itemstack, pointed_thing)
    spacengine.rightclick(pos,node,player,"shield")
	end,
  can_dig=spacengine.can_dig,
})

--weapons
minetest.register_node("spacengine:weapons", {
	description = "weapons",
	tiles ={"spacengine_radar_uv.png"},
  drawtype = "mesh",
  mesh = "weapons.obj",
  paramtype2 = "facedir",
  paramtype = "light",
	groups = {cracky=4,spacengine=6},
	sounds = default.node_sound_stone_defaults(),
  on_construct=function(pos)
    spacengine.construct_node(pos,"LASER","^A¨100¨0¨750¨20¨5¨2",6)
  end,
  after_place_node=function(pos,placer)
    spacengine.placer_node(pos,placer)
  end,
  on_rightclick = function(pos, node, player, itemstack, pointed_thing)
    spacengine.rightclick(pos,node,player,"weapons")
	end,
  can_dig=spacengine.can_dig,
})

--radar
minetest.register_node("spacengine:radar", {
	description = "Radar",
	tiles ={"spacengine_radar_uv.png"},
  drawtype = "mesh",
  mesh = "radar.obj",
  selection_box = { type = "fixed", fixed = { -0.3,-0.5,-0.3,0.3,0.5,0.3} },
  collision_box = { type = "fixed", fixed = { -0.3,-0.5,-0.3,0.3,0.5,0.3} },
  paramtype2 = "facedir",
  paramtype = "light",
	groups = {cracky=4,spacengine=7},
	sounds = default.node_sound_stone_defaults(),
  on_construct=function(pos)
    spacengine.construct_node(pos,"Stone","^A¨50¨0¨100¨10¨^group:stone",7)
  end,
  after_place_node=function(pos,placer)
    spacengine.placer_node(pos,placer)
  end,
  on_rightclick = function(pos, node, player, itemstack, pointed_thing)
    spacengine.rightclick(pos,node,player,"radar")
	end,
  can_dig=spacengine.can_dig,
})

--gravitation
minetest.register_node("spacengine:gravitation", {
	description = "gravitation",
	tiles ={"spacengine_side.png^[transformR90", "spacengine_side.png^[transformR90", "spacengine_side.png", "spacengine_side.png", "spacengine_front.png", "spacengine_gforce_front.png"},
  drawtype = "nodebox",
  node_box = {
		type = "fixed",
		fixed = {
			{-0.5, 0.4375, -0.5, 0.5, 0.5, 0.5}, -- NodeBox1
			{-0.5, -0.5, -0.5, 0.5, -0.4375, 0.5}, -- NodeBox2
			{-0.5, -0.5, -0.5, -0.4375, 0.5, 0.5}, -- NodeBox3
			{0.4375, -0.5, -0.5, 0.5, 0.5, 0.5}, -- NodeBox4
			{-0.4375, -0.4375, -0.4375, 0.4375, 0.4375, 0.4375}, -- NodeBox5
		}
	},
  paramtype2 = "facedir",
	groups = {cracky=4,spacengine=8},
	sounds = default.node_sound_stone_defaults(),
  on_construct=function(pos)
    spacengine.construct_node(pos,"GRAVITATION","^A¨100¨0¨0.4",8)
  end,
  after_place_node=function(pos,placer)
    spacengine.placer_node(pos,placer)
  end,
  on_rightclick = function(pos, node, player, itemstack, pointed_thing)
    spacengine.rightclick(pos,node,player,"gravitation")
	end,
  can_dig=spacengine.can_dig,
  on_rotate = screwdriver.rotate_simple,
})

--container
minetest.register_node("spacengine:container", {
	description = "container",
	tiles ={"spacengine_containera3.png", "spacengine_containera3.png", "spacengine_containera2.png", "spacengine_containera2.png", "spacengine_containera1.png", "spacengine_containera1.png"},
  paramtype2 = "facedir",
	groups = {cracky=4,spacengine=9},
	sounds = default.node_sound_stone_defaults(),
  on_construct=function(pos)
    spacengine.construct_node(pos,"Container 500Kg","^A¨100¨0¨500",9)
  end,
  after_place_node=function(pos,placer)
    spacengine.placer_node(pos,placer)
  end,
  on_rightclick = function(pos, node, player, itemstack, pointed_thing)
    spacengine.rightclick(pos,node,player,"container")
	end,
  can_dig=spacengine.can_dig,
  on_rotate = screwdriver.rotate_simple,
})

minetest.register_node("spacengine:container2", {
	description = "container2",
	tiles ={"spacengine_containerb3.png", "spacengine_containerb3.png", "spacengine_containerb2.png", "spacengine_containerb2.png", "spacengine_containerb1.png", "spacengine_containerb1.png"},
  paramtype2 = "facedir",
	groups = {cracky=4,spacengine=9},
	sounds = default.node_sound_stone_defaults(),
  on_construct=function(pos)
    spacengine.construct_node(pos,"Container 500Kg","^A¨100¨0¨500",9)
  end,
  after_place_node=function(pos,placer)
    spacengine.placer_node(pos,placer)
  end,
  on_rightclick = function(pos, node, player, itemstack, pointed_thing)
    spacengine.rightclick(pos,node,player,"container")
	end,
  can_dig=spacengine.can_dig,
  on_rotate = screwdriver.rotate_simple,
})

minetest.register_node("spacengine:container3", {
	description = "container3",
	tiles ={"spacengine_containerc3.png", "spacengine_containerc3.png", "spacengine_containerc2.png", "spacengine_containerc2.png", "spacengine_containerc1.png", "spacengine_containerc1.png"},
  paramtype2 = "facedir",
	groups = {cracky=4,spacengine=9},
	sounds = default.node_sound_stone_defaults(),
  on_construct=function(pos)
    spacengine.construct_node(pos,"Container 500Kg","^A¨100¨0¨500",9)
  end,
  after_place_node=function(pos,placer)
    spacengine.placer_node(pos,placer)
  end,
  on_rightclick = function(pos, node, player, itemstack, pointed_thing)
    spacengine.rightclick(pos,node,player,"container")
	end,
  can_dig=spacengine.can_dig,
  on_rotate = screwdriver.rotate_simple,
})

--passenger
minetest.register_node("spacengine:passenger", {
	description = "passenger",
	drawtype = "mesh",
  mesh = "passenger_seat.obj",
  tiles = {"spacengine_seat.png"},
  selection_box = { type = "fixed", fixed = { -0.4,-0.5,-0.4,0.4,-0.1,0.4} },
  collision_box = { type = "fixed", fixed = { -0.4,-0.5,-0.4,0.4,-0.1,0.4} },
  paramtype2 = "facedir",
  paramtype = "light",
	groups = {cracky=4,spacengine=10},
	sounds = default.node_sound_stone_defaults(),
  on_construct=function(pos)
    spacengine.construct_node(pos,"Crew","^A¨50¨0¨^c",10)
  end,
  after_place_node=function(pos,placer)
    spacengine.placer_node(pos,placer)
  end,
  on_rightclick = function(pos, node, player, itemstack, pointed_thing)
    if spacengine.sit(pos, node, player)==false then
      spacengine.rightclick(pos,node,player,"passenger")
    end
	end,
  can_dig=spacengine.can_dig,
  on_rotate = screwdriver.rotate_simple,
})

--manutention
minetest.register_node("spacengine:manutention", {
	description = "Manutention",
	tiles = {"spacengine_pupitre_warning.png", "spacengine_pupitre_warning.png", "spacengine_pupitre_side.png", "spacengine_pupitre_side.png", "spacengine_manu_rear.png", "spacengine_manu_front.png"},
  drawtype = "nodebox",
--
  node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.5, 0.5, 0, 0.5}, -- NodeBox1
			{-0.5, 0, -0.4375, 0.5, 0.5, 0.4375}, -- NodeBox2
      --{-0.5, -0.5, -0.5, -0.4375, 0.5, 0.5},
      --{0.4375, -0.5, -0.5, 0.5, 0.5, 0.5},
		}
	},--]]
  paramtype2 = "facedir",
	groups = {cracky=4,spacengine=13},
	sounds = default.node_sound_stone_defaults(),
  on_construct=function(pos)
    spacengine.construct_node(pos,"Crane","^B¨150¨0¨50¨2¨^default:stone:6:BD:50¨100",13)
  end,
  after_place_node=function(pos,placer)
    spacengine.placer_node(pos,placer)
  end,
  on_rightclick = function(pos, node, player, itemstack, pointed_thing)
    spacengine.rightclick(pos,node,player,"manutention")
	end,
  can_dig=spacengine.can_dig,
})

--radio
minetest.register_node("spacengine:radio", {
	description = "radio",
	tiles ={"spacengine_radio_side.png", "spacengine_radio_side.png", "spacengine_radio_side.png", "spacengine_radio_side.png", "spacengine_radio_side.png", "spacengine_radio.png"},
  paramtype2 = "facedir",
  light_source = 4,
	groups = {cracky=4,spacengine=17},
	sounds = default.node_sound_stone_defaults(),
  on_construct=function(pos)
    spacengine.construct_node(pos,"Radio","^A¨50¨0¨500",17)
  end,
  after_place_node=function(pos,placer)
    spacengine.placer_node(pos,placer)
  end,
  on_rightclick = function(pos, node, player, itemstack, pointed_thing)
    spacengine.rightclick(pos,node,player,"radio",true)
	end,
  can_dig=spacengine.can_dig,
  on_rotate = screwdriver.rotate_simple,
})
