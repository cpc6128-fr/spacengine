-- Do files
espace = {}
local mp=minetest.get_modpath("espace")
dofile( mp.. "/data.lua")
dofile(mp .. "/nodes.lua")
dofile(mp .. "/deco.lua")
dofile(mp .. "/functions.lua")
dofile(mp .. "/planete.lua")
dofile(mp .. "/spacemap.lua")
dofile(mp .. "/routine.lua")
dofile(mp .. "/fx.lua")
dofile(mp .. "/hurt.lua")
dofile(mp .. "/biome.lua")
dofile(mp .. "/gestion_layer.lua")
dofile(mp .. "/stargate_univers.lua")
dofile(mp .. "/weather.lua")

if not minetest.get_modpath("technic") then
  dofile(minetest.get_modpath("espace").."/technic.lua")
end
--dofile(minetest.get_modpath("espace").."/energy.lua") --petrole methane



