--[[
liste des nodes
## AIR ##
espace:vacuum = vacuum
espace:radiation = vacuum+radiation
espace:air = air / disapear near vacuum
espace:smog = brouillard épaix
espace:air_brume = brume colorée
espace:radioactive_air = air + radiation

## SUN ##
espace:sun_red
espace:sun_yellow
espace:sun_blue
espace:sun_white

## SOL ##
espace:invisible_bedrock
espace:bedrock = unbreakable bedrock
espace:star_material1 TODO radiation
espace:star_material2 TODO hot
espace:stone
espace:rock = RPGmaker
espace:stone_hot = proche lava RPGmaker
espace:gravel
espace:dust
espace:gallet = petit gallet de riviere RPGmaker
espace:desert = sol de desert sec et dur
espace:sand
espace:grass = style rpg RPGmaker
espace:grass_flowers = RPGmaker
espace:grass_cailloux = RPGmaker
espace:cailloux = RPGmaker
espace:cailloux_grass = RPGmaker
espace:dirt
espace:grass_2
espace:cailloux_2 = RPGmaker
espace:talcum = talc
espace:mur
espace:rock_2 = RPGmaker
espace:herbe
espace:fleur

## OBJET ##
espace:rocher
espace:rocher01
espace:buisson

## LIQUIDE ##
espace:water = bloc
espace:mud
espace:oil

espace:mud_source
espace:oil_source
espace:ocean_source


--]]

--****************
--** atmosphere **
--****************

if not minetest.get_modpath("vacuum") then

minetest.register_node(":vacuum:vacuum", {
	description = "Vacuum",

--original
	drawtype = "airlike",
	drowning = 1,
  groups = {not_in_creative_inventory=1, cools_lava=1},
--

--[[for creative mode
drawtype = "glasslike",
tiles = {"asteroid_atmos.png^[colorize:#DD00007F"},
post_effect_color = {a = 100, r = 150, g = 75, b = 125},
alpha = 100,
--]]

  paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	floodable = true,
  pointable = false,
diggable = true,
})
end

minetest.register_node("espace:radiation", {
	description = "radiation",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	drawtype = "glasslike",
	post_effect_color = {a = 100, r = 150, g = 75, b = 125},
	tiles = {"asteroid_atmos.png^[colorize:#964B7DAA"},
	alpha = 100,
	groups = {not_in_creative_inventory=1},
	paramtype = "light",
	sunlight_propagates =true,
	is_ground_content = false,
  floodable = true,
  drowning = 1,
})


minetest.register_node("espace:air", {
	description = "Air",
	drawtype = "airlike",
  paramtype = "light",
	is_ground_content = false,
	sunlight_propagates = true,
	walkable = false,
	pointable = false,--pointable = false,
	diggable = false,--diggable = false,
	buildable_to = true,--buildable_to = true,
	floodable = true,
  --groups = {not_in_creative_inventory=1},
})

minetest.register_node("espace:smog", {
	description = "smog",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	drawtype = "glasslike",
	post_effect_color = {a = 60, r = 50, g = 50, b = 50},
	tiles = {"asteroid_atmos.png^[colorize:#80808080"},--{"brume.png"},
	alpha = 25,
	groups = {not_in_creative_inventory=1},
	paramtype = "light",
	sunlight_propagates =true,
	is_ground_content = false,
})
--
minetest.register_node("espace:brume", {
	description = "brume",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	drawtype = "glasslike",
	post_effect_color = {a = 100, r = 180, g = 175, b = 190},
	tiles = {"brume.png"},
	--alpha = 50,
	groups = {not_in_creative_inventory=1},
	paramtype = "light",
	sunlight_propagates =true,
	is_ground_content = false,
  --floodable = true,
})
--]]
minetest.register_node("espace:radioactive_air", {
	description = "dust radioactive",
	drawtype = "glasslike",
	tiles = {"radioactive_dust.png"},
	paramtype = "light",
    light_source = 2,
	sunlight_propagates = true,
  post_effect_color = {a = 75, r = 150, g = 50, b = 250},
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	use_texture_alpha = true,
  --floodable = true,
	groups = { radioactive=1, not_in_creative_inventory = 1}
})


-- Items
--

minetest.register_craftitem("espace:helmet", {
	description = "Mesetint Helmet",
	inventory_image = "moonrealm_helmet.png",
	--groups = {not_in_creative_inventory = 1},
})
    
--***************
--** Spacesuit **
--***************

minetest.register_tool("espace:spacesuit", {
	description = "Spacesuit (wear slot 1)",
	inventory_image = "moonrealm_spacesuit.png",
})

minetest.register_craft({
	output = "espace:helmet",
	recipe = {
		{"default:mese_crystal"},
		{"default:glass"},
		{"default:gold_ingot"},
	}
})


minetest.register_craft({
	output = "espace:spacesuit",
	recipe = {
		{"wool:white", "espace:helmet", "wool:white"},
		{"", "espace:air_tank", ""},
		{"wool:white", "", "wool:white"},
	}
})

--toxic
minetest.register_tool("espace:toxic_suit", {
	description = "toxic suit(wear slot 1) protect toxic and poison",
	inventory_image = "toxic_suit.png",
})

minetest.register_craft({
	output = "espace:toxic_suit",
	recipe = {
		{"wool:red", "espace:helmet", "wool:red"},
		{"", "espace:air_tank", ""},
		{"wool:white", "", "wool:white"},
	}
})

--nuclear
minetest.register_tool("espace:nuclear_suit", {
	description = "nuclear (wear slot 1) protect radioactive",
	inventory_image = "nuclear_suit2.png",
})

minetest.register_craft({
	output = "espace:nuclear_suit",
	recipe = {
		{"wool:orange", "espace:helmet", "wool:orange"},
		{"", "espace:air_tank", ""},
		{"wool:white", "", "wool:white"},
	}
})

--**********
--** star **
--**********
minetest.register_node( "espace:star_material1", {
	description = "Star Material",
	tiles = { "sun_yellow.png"},
	groups = {cracky=2,not_in_creative_inventory = 1},
	light_source = LIGHT_MAX,
	sounds = default.node_sound_stone_defaults(),
	drop = "default:gold_lump",
	is_ground_content = false,
}) 

minetest.register_node( "espace:star_material2", {
	description = "Star Material 2",
	tiles = { "sun_white.png"},
	groups = {cracky=2,not_in_creative_inventory = 1},
	light_source = LIGHT_MAX,
	sounds = default.node_sound_stone_defaults(),
	drop = "default:mese_crystal",
	is_ground_content = false,
})

minetest.register_node( "espace:sun_red", {
	description = "Sun red",
  drawtype = "glasslike",
  paramtype = "light",
	tiles = { "sun_red_alpha.png"},
	groups = {cracky=2,not_in_creative_inventory = 1},
	light_source = LIGHT_MAX,
	sounds = default.node_sound_stone_defaults(),
	--drop = "default:gold_lump",
	is_ground_content = false,
}) 

minetest.register_node( "espace:sun_blue", {
	description = "Sun Blue",
  drawtype = "glasslike",
  paramtype = "light",
	tiles = { "sun_blue_alpha.png"},
	groups = {cracky=2,not_in_creative_inventory = 1},
	light_source = LIGHT_MAX,
	sounds = default.node_sound_stone_defaults(),
	--drop = "default:mese_crystal",
	is_ground_content = false,
}) 

minetest.register_node( "espace:nebul_red", {
	description = "nebuleuse red",
  paramtype = "light",
	tiles = {"nebuleuse2.png"},
	groups = {crumbly=3,not_in_creative_inventory = 1},
	walkable = false,
	climbable = true,
	sounds = default.node_sound_stone_defaults(),
	--drop = "default:mese_crystal",
	is_ground_content = false,
})

minetest.register_node( "espace:nebul_purple", {
	description = "nebuleuse purple",
  paramtype = "light",
	tiles = { "nebuleuse1.png"},
	groups = {crumbly=3,not_in_creative_inventory = 1},
	walkable = false,
	climbable = true,
	sounds = default.node_sound_stone_defaults(),
	--drop = "default:mese_crystal",
	is_ground_content = false,
})

minetest.register_node( "espace:nebul_blue", {
	description = "nebuleuse blue",
  paramtype = "light",
	tiles = { "nebuleuse4.png"},
	groups = {crumbly=3,not_in_creative_inventory = 1},
	walkable = false,
	climbable = true,
	sounds = default.node_sound_stone_defaults(),
	--drop = "default:mese_crystal",
	is_ground_content = false,
})

--***************
--** materiaux **
--***************

minetest.register_node("espace:bedrock", {
	description = "Bedrock",
	tile_images = {"bedrock.png"},
	drop = "",
  light_source = 3,
  is_ground_content = false,
	groups = {unbreakable = 1, not_in_creative_inventory = 1}, -- For Map Tools' admin pickaxe
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("espace:invisible_bedrock", {
	description = "invisible Bedrock",
  drawtype = "airlike",
  paramtype = "light",
	--tile_images = {"bedrock.png"},
	drop = "",
  is_ground_content = false,
	groups = {unbreakable = 1, not_in_creative_inventory = 1}, -- For Map Tools' admin pickaxe
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("espace:stone", {
	description = "Asteroid Stone",
	tiles = {"stone.png"},
	--is_ground_content = false,
	drop = 'default:cobble',
	groups = {cracky = 3},--, not_in_creative_inventory=1},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("espace:rock", {
	description = "Asteroid Rock",
	tiles = {"rock.png"},
	--is_ground_content = false,
	drop = 'default:cobble',
	groups = {cracky = 3},--, not_in_creative_inventory=1},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("espace:stone_hot", {
	description = "Asteroid stone hot",
	tiles = {"lava.png"},
	is_ground_content = false,
  paramtype = "light",
    light_source = 5,
	drop = 'default:cobble',
	groups = {cracky = 3},--, not_in_creative_inventory=1},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("espace:gravel", {
	description = "Asteroid Gravel",
	tiles = {"asteroid_gravel.png"},
	--is_ground_content = false,
	drop = 'default:gravel',
	groups = {crumbly = 2},
	sounds = default.node_sound_dirt_defaults({
		footstep = {name = "default_gravel_footstep", gain = 0.2},
	}),
})

minetest.register_node("espace:dust", {
	description = "Asteroid Dust",
	tiles = {"asteroid_dust.png"},
	--is_ground_content = false,
	groups = {crumbly = 3},
	sounds = default.node_sound_dirt_defaults({
		footstep = {name = "default_gravel_footstep", gain = 0.1},
	}),
})

minetest.register_node("espace:gallet", {
	description = "Gallet",
	tiles = {"gravel.png"},
	--is_ground_content = false,
	drop = 'default:gravel',
	groups = {crumbly = 2},
	sounds = default.node_sound_dirt_defaults({
		footstep = {name = "default_gravel_footstep", gain = 0.2},
	}),
})

minetest.register_node("espace:desert", {
	description = "desert ground",
	tiles = {"desert.png"},
	--is_ground_content = false,
	drop = 'espace:desert',
  sounds = default.node_sound_sand_defaults(),
	groups = {crumbly = 3},--, not_in_creative_inventory=1},
})

minetest.register_node("espace:sand", {
	description = "sand",
	tiles = {"sand.png"},
	--is_ground_content = false,
	drop = 'espace:sand',
  sounds = default.node_sound_sand_defaults(),
	groups = {crumbly = 3},--, not_in_creative_inventory=1},
})

--
minetest.register_node("espace:roche", {
	description = "roche",
	tiles ={"roche.png"},
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("espace:roche_mousse", {
	description = "roche_mousse",
	tiles ={"roche_mousse.png"},
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})
--]]

--fairyland

minetest.register_node("espace:grass", {
	description = "grass",
	tiles = {"grass.png"},
	--is_ground_content = false,
	drop = 'espace:grass',
  sounds = default.node_sound_leaves_defaults(),
	groups = {crumbly = 3, soil=1},--, not_in_creative_inventory=1},
})

minetest.register_node("espace:grass_flowers", {
	description = "grass flowers",
	tiles = {"grass_flowers.png","grass.png"},
	--is_ground_content = false,
	drop = 'espace:grass_flowers',
  sounds = default.node_sound_leaves_defaults(),
	groups = {crumbly = 3},--, not_in_creative_inventory=1},
})

minetest.register_node("espace:grass_cailloux", {
	description = "grass cailloux",
	tiles = {"grass_cailloux.png","grass.png"},
	--is_ground_content = false,
	drop = 'espace:grass_cailloux',
  sounds = default.node_sound_leaves_defaults(),
	groups = {crumbly = 3},--, not_in_creative_inventory=1},
})

minetest.register_node("espace:cailloux", {
	description = "cailloux",
	tiles = {"cailloux.png"},
	--is_ground_content = false,
	drop = 'espace:cailloux',
  sounds = default.node_sound_gravel_defaults(),
	groups = {cracky = 3},--, not_in_creative_inventory=1},
})

minetest.register_node("espace:cailloux_grass", {
	description = "cailloux grass",
	tiles = {"cailloux_grass.png"},
	--is_ground_content = false,
	drop = 'espace:cailloux_grass',
  sounds = default.node_sound_gravel_defaults(),
	groups = {cracky = 3},--, not_in_creative_inventory=1},
})

--

minetest.register_node("espace:dirt", {
	description = "Asteroid dirt",
	tiles = {"dirt.png"},
	--is_ground_content = false,
	groups = {crumbly = 3},--, not_in_creative_inventory=1},
	sounds = default.node_sound_dirt_defaults(),
})

minetest.register_node("espace:grass_2", {
	description = "Asteroid grass_2",
	tiles = {"grass_3.png"},
	--is_ground_content = false,
	groups = {crumbly = 3, soil=1},--, not_in_creative_inventory=1},
	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_node("espace:fleur", {
	description = "fleur",
	tiles ={"fleur.png","herbe.png"},
	groups = {crumbly=3},
	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_node("espace:herbe", {
	description = "herbe",
	tiles ={"herbe.png"},
	groups = {crumbly=3, soil=1},
	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_node("espace:cailloux_2", {
	description = "Asteroid cailloux_2",
	tiles = {"cailloux_2.png"},
	--is_ground_content = false,
	groups = {cracky = 3},--, not_in_creative_inventory=1},
	sounds = default.node_sound_gravel_defaults(),
})

minetest.register_node("espace:talcum", {
	description = "Asteroid talcum powder",
	tiles = {"asteroid_talcum.png"},
	--is_ground_content = false,
	groups = {crumbly = 2},--, not_in_creative_inventory=1},
	sounds = default.node_sound_sand_defaults(),
})

minetest.register_node("espace:mur", {
	description = "Asteroid mur",
	tiles = {"rock01.png"},
	is_ground_content = false,
	groups = {cracky = 3},--, not_in_creative_inventory=1},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("espace:rock_2", {
	description = "Asteroid rock 2",
	tiles = {"dirt02.png","rock02.png"},
	--is_ground_content = false,
	groups = {cracky = 3},--, not_in_creative_inventory=1},
	sounds = default.node_sound_stone_defaults(),
})

--** 3d plant objet **

--Rocks

minetest.register_node("espace:rocher", {
		description = "rocher",
		drawtype = "plantlike",
		tiles = {"rocher11.png"},
		inventory_image = "rocher11.png",
		wield_image = "rocher11.png",
		sunlight_propagates = false,
		paramtype = "light",
		walkable = true,
		buildable_to = true,
    is_ground_content = false,
    groups = {cracky = 3},
		selection_box = {
			type = "fixed",
			fixed = {-0.5,-0.5,-0.5,0.5,0.5,0.5}
		}
	})

minetest.register_node("espace:rocherbig", {
		description = "rocherbig",
		drawtype = "plantlike",
		tiles = {"rocherbig.png"},
--visual_scale=1.,
		inventory_image = "rocherbig.png",
		wield_image = "rocherbig.png",
		sunlight_propagates = false,
		paramtype = "light",
		walkable = true,
		buildable_to = true,
    is_ground_content = false,
    groups = {cracky = 3},
		selection_box = {
			type = "fixed",
			fixed = {-0.5,-0.5,-0.5,0.5,0.5,0.5}
		}
	})  

  minetest.register_node("espace:rocher01", {
		description = "rocher",
		drawtype = "plantlike",
		tiles = {"rocher01.png"},
		inventory_image = "rocher01.png",
		wield_image = "rocher01.png",
		sunlight_propagates = false,
		paramtype = "light",
		walkable = true,
		buildable_to = true,
    is_ground_content = false,
    groups = {cracky = 3},
		selection_box = {
			type = "fixed",
			fixed = {-0.5,-0.5,-0.5,0.5,0.5,0.5}
		}
	})

minetest.register_node("espace:buisson", {
		description = "buisson",
		drawtype = "plantlike",
		tiles = {"buisson.png"},
		inventory_image = "buisson.png",
		wield_image = "buisson.png",
		sunlight_propagates = true,
		paramtype = "light",
		walkable = false,
		buildable_to = true,
    is_ground_content = false,
    groups = {crumbly = 3},
		selection_box = {
			type = "fixed",
			fixed = {-0.4,-0.5,-0.4,0.4,0.5,0.4}
		}
	})
----------------------------------------------------------------------------------------------------------
--WATER
----------------------------------------------------------------------------------------------------------
minetest.register_node("espace:water", {
	description = "water",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	drawtype = "glasslike",
	post_effect_color = {a = 100, r = 0, g = 100, b = 200},
	tiles = {"asteroid_water.png"},
	alpha = 50,
	paramtype = "light",
	sunlight_propagates =true,
	is_ground_content = false,
  drowning = 1,
  climbable = true,
	groups = {water = 3, liquid = 3, puts_out_fire = 1},
})

minetest.register_node("espace:mud", {
	description = "mud",
	walkable = false,
	pointable = true,
	diggable = false,
	buildable_to = true,
	drawtype = "glasslike",
	post_effect_color = {a = 200, r = 81, g = 48, b = 5},
	tiles = {"lib_materials_fluid_mud_source.png"},
	alpha = 240,
	paramtype = "light",
	sunlight_propagates =true,
	is_ground_content = false,
  drowning = 1,
  climbable = true,
	groups = {water = 3, liquid = 3, puts_out_fire = 1},
})

minetest.register_node("espace:oil", {
	description = "oil",
	walkable = false,
	pointable = true,
	diggable = false,
	buildable_to = true,
	drawtype = "glasslike",
	post_effect_color = {a = 200, r = 20, g = 20, b = 20},
	tiles = {"lib_materials_fluid_oil_source.png"},
	alpha = 240,
	paramtype = "light",
	sunlight_propagates =true,
	is_ground_content = false,
	liquid_viscosity = 1,
  drowning = 1,
  climbable = true,
	groups = { liquid = 3},
})

minetest.register_node("espace:mud_source", {
	description = "mud source",
	drawtype = "liquid",
	tiles = {
		{
			name = "lib_materials_fluid_mud_source_animated.png",
			backface_culling = false,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 2.0,
			},
		},
		{
			name = "lib_materials_fluid_mud_source_animated.png",
			backface_culling = true,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 2.0,
			},
		},
	},
	alpha = 240,
	paramtype = "light",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	drowning = 1,
	liquidtype = "source",
	liquid_alternative_flowing = "espace:mud_flowing",
	liquid_alternative_source = "espace:mud_source",
	liquid_viscosity = 3,
	liquid_renewable = false,
	liquid_range = 1,
	post_effect_color = {a = 200, r = 81, g = 48, b = 5},
	groups = {liquid = 3},
	sounds = default.node_sound_water_defaults(),
})

minetest.register_node("espace:mud_flowing", {
	description = "Flowing Oil",
	drawtype = "flowingliquid",
	tiles = {"lib_materials_fluid_mud_source.png"},
	special_tiles = {
		{
			name = "lib_materials_fluid_mud_source_animated.png",
			backface_culling = false,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 0.8,
			},
		},
		{
			name = "lib_materials_fluid_mud_source_animated.png",
			backface_culling = true,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 0.8,
			},
		},
	},
	alpha = 240,
	paramtype = "light",
	paramtype2 = "flowingliquid",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	drowning = 1,
	liquidtype = "flowing",
	liquid_alternative_flowing = "espace:mud_flowing",
	liquid_alternative_source = "espace:mud_source",
	liquid_viscosity = 1,
	liquid_renewable = false,
	liquid_range = 1,
	post_effect_color = {a = 200, r = 81, g = 48, b = 5},
	groups = {liquid = 3, not_in_creative_inventory = 1},
	sounds = default.node_sound_water_defaults(),
})
--
minetest.register_node("espace:oil_source", {
	description = "Oil source",
	drawtype = "liquid",
	tiles = {
		{
			name = "lib_materials_fluid_oil_source_animated.png",
			backface_culling = false,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 2.0,
			},
		},
		{
			name = "lib_materials_fluid_oil_source_animated.png",
			backface_culling = true,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 2.0,
			},
		},
	},
	alpha = 240,
	paramtype = "light",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	drowning = 1,
	liquidtype = "source",
	liquid_alternative_flowing = "espace:oil_flowing",
	liquid_alternative_source = "espace:oil_source",
	liquid_viscosity = 3,
	liquid_renewable = false,
	liquid_range = 2,
	post_effect_color = {a = 200, r = 20, g = 20, b = 20},
	groups = {liquid = 3,toxic=1},
	sounds = default.node_sound_water_defaults(),
})

minetest.register_node("espace:oil_flowing", {
	description = "Flowing Oil",
	drawtype = "flowingliquid",
	tiles = {"lib_materials_fluid_oil_source.png"},
	special_tiles = {
		{
			name = "lib_materials_fluid_oil_source_animated.png",
			backface_culling = false,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 0.8,
			},
		},
		{
			name = "lib_materials_fluid_oil_source_animated.png",
			backface_culling = true,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 0.8,
			},
		},
	},
	alpha = 240,
	paramtype = "light",
	paramtype2 = "flowingliquid",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	drowning = 1,
	liquidtype = "flowing",
	liquid_alternative_flowing = "espace:oil_flowing",
	liquid_alternative_source = "espace:oil_source",
	liquid_viscosity = 1,
	liquid_renewable = false,
	liquid_range = 2,
	post_effect_color = {a = 200, r = 20, g = 20, b = 20},
	groups = {liquid = 3, not_in_creative_inventory = 1, toxic=1},
	sounds = default.node_sound_water_defaults(),
})

minetest.register_craft({
	type = "fuel",
	recipe = "espace:oil_source",
	burntime = 60,
})

minetest.register_node("espace:ocean_source", {
	description = "ocean source",
	drawtype = "liquid",
	tiles = {
		{
			name = "lib_materials_fluid_water_dirty_source_animated.png",
			backface_culling = false,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 2.0,
			},
		},
		{
			name = "lib_materials_fluid_water_dirty_source_animated.png",
			backface_culling = true,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 2.0,
			},
		},
	},
	alpha = 230,
	paramtype = "light",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	drowning = 1,
	liquidtype = "source",
	liquid_alternative_flowing = "espace:ocean_flowing",
	liquid_alternative_source = "espace:ocean_source",
	liquid_viscosity = 3,
	liquid_renewable = false,
	liquid_range = 0,
	post_effect_color = {a = 103, r = 30, g = 60, b = 90},
	groups = {liquid = 3},
	sounds = default.node_sound_water_defaults(),
})

minetest.register_node("espace:ocean_flowing", {
	description = "ocean flowing",
	drawtype = "flowingliquid",
	tiles = {"asteroid_water.png"},
	special_tiles = {
		{
			name = "lib_materials_fluid_water_dirty_source_animated.png",
			backface_culling = false,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 0.8,
			},
		},
		{
			name = "lib_materials_fluid_water_dirty_source_animated.png",
			backface_culling = true,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 0.8,
			},
		},
	},
	alpha = 230,
	paramtype = "light",
	paramtype2 = "flowingliquid",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	drowning = 1,
	liquidtype = "flowing",
	liquid_alternative_flowing = "espace:ocean_flowing",
	liquid_alternative_source = "espace:ocean_source",
	liquid_viscosity = 1,
	liquid_renewable = false,
	liquid_range = 0,
	post_effect_color = {a = 103, r = 30, g = 60, b = 90},
	groups = {liquid = 3, not_in_creative_inventory = 1},
	sounds = default.node_sound_water_defaults(),
})

bucket.register_liquid("espace:oil_source", "air", "espace:bucket_oil","bucket_oil.png","oil bucket","water_bucket = 1")
bucket.register_liquid("espace:mud_source", "air", "espace:bucket_mud","bucket_mud.png","mud bucket","water_bucket = 1")

--from MORETREES poplar

minetest.register_node(":moretrees:poplar_trunk", {
	description = "Poplar Tree",
	tiles = {"moretrees_poplar_trunk_top.png", "moretrees_poplar_trunk_top.png", "moretrees_poplar_trunk.png"},
	paramtype2 = "facedir",
	is_ground_content = false,
	groups = {tree = 1, choppy = 2, oddly_breakable_by_hand = 1, flammable = 2},
	sounds = default.node_sound_wood_defaults(),

	on_place = minetest.rotate_node
})

minetest.register_node(":moretrees:poplar_wood", {
	description = "Poplar Wood Planks",
	paramtype2 = "facedir",
	place_param2 = 0,
	tiles = {"moretrees_poplar_wood.png"},
	is_ground_content = false,
	groups = {choppy = 2, oddly_breakable_by_hand = 2, flammable = 2, wood = 1},
	sounds = default.node_sound_wood_defaults(),
})

minetest.register_node(":moretrees:poplar_sapling", {
	description = "Poplar Tree Sapling",
	drawtype = "plantlike",
	tiles = {"moretrees_poplar_sapling.png"},
	inventory_image = "moretrees_poplar_sapling.png",
	wield_image = "moretrees_poplar_sapling.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	on_timer = default.grow_sapling,
	selection_box = {
		type = "fixed",
		fixed = {-4 / 16, -0.5, -4 / 16, 4 / 16, 7 / 16, 4 / 16}
	},
	groups = {snappy = 2, dig_immediate = 3, flammable = 2,
		attached_node = 1, sapling = 1},
	sounds = default.node_sound_leaves_defaults(),

	on_construct = function(pos)
		minetest.get_node_timer(pos):start(math.random(10,20))--300, 1500))
	end,

	--[[on_place = function(itemstack, placer, pointed_thing)
		itemstack = default.sapling_on_place(itemstack, placer, pointed_thing,
			"moretrees:poplar_sapling",
			-- minp, maxp to be checked, relative to sapling pos
			-- minp_relative.y = 1 because sapling pos has been checked
			{x = -3, y = 1, z = -3},
			{x = 3, y = 6, z = 3},
			-- maximum interval of interior volume check
			4)

		return itemstack
	end,--]]
})

minetest.register_node(":moretrees:poplar_leaves", {
	description = "Poplar Tree Leaves",
	drawtype = "allfaces_optional",
	waving = 1,
	tiles = {"moretrees_poplar_leaves.png"},
	--special_tiles = {"default_leaves_simple.png"},
	paramtype = "light",
	is_ground_content = false,
	groups = {snappy = 3, leafdecay = 3, flammable = 2, leaves = 1, saison=1},
	drop = {
		max_items = 1,
		items = {
			{
				-- player will get sapling with 1/20 chance
				items = {'moretrees:poplar_sapling'},
				rarity = 20,
			},
			{
				-- player will get leaves only if he get no saplings,
				-- this is because max_items is 1
				items = {'moretrees:poplar_leaves'},
			}
		}
	},
	sounds = default.node_sound_leaves_defaults(),

	after_place_node = default.after_place_leaves,
})

minetest.register_node(":moretrees:poplar_leaves_autumn", {
	description = "Poplar autumn Leaves",
	drawtype = "allfaces_optional",
	waving = 1,
	tiles = {"moretrees_poplar_leaves_autumn.png"},
	--special_tiles = {"default_leaves_simple.png"},
	paramtype = "light",
	is_ground_content = false,
	groups = {snappy = 3, leafdecay = 3, flammable = 2, leaves = 1, saison=3},--,not_in_creative_inventory = 1},
	drop = {
		max_items = 1,
		items = {
			{
				-- player will get sapling with 1/20 chance
				items = {'moretrees:poplar_sapling'},
				rarity = 20,
			},
			{
				-- player will get leaves only if he get no saplings,
				-- this is because max_items is 1
				items = {'moretrees:poplar_leaves'},
			}
		}
	},
	sounds = default.node_sound_leaves_defaults(),

	after_place_node = default.after_place_leaves,
})

minetest.register_node(":moretrees:poplar_leaves_stick", {
	description = "Fruit Tree stick Leaves",
	drawtype = "allfaces_optional",
	tiles = {"espace_leaves_stick.png"},
	waving = 1,
	paramtype = "light",
	is_ground_content = false,
	groups = {snappy = 3, leafdecay = 3, flammable = 2, leaves = 1, saison=4},
	drop = {"default:stick"},
	sounds = default.node_sound_leaves_defaults(),
})

	minetest.register_decoration({
		name = "moretrees:poplar_tree",
		deco_type = "schematic",
		place_on = {"default:dirt_with_grass"},
		sidelen = 2,
    --fill_ratio=0.005,
    noise_params = {
			offset = 0.001,
			scale = 0.00001,
			spread = {x = 350, y = 350, z = 350},
			seed = 2,
			octaves = 2,
			persist = 0.008
		},
		biomes = {"deciduous_forest","coniferous_forest"},
		y_max = 50,
		y_min = 1,
		schematic = minetest.get_modpath("espace") .. "/schematics/poplar_tree_giant.mts",
		flags = "place_center_x, place_center_z",
		rotation = "random",
	})
