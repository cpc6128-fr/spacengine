-- Save table to file
function espace.save_table()

	local data = {day=espace.day, month=espace.month, year=espace.year, build_dt=espace.build_dt}
	local f, err = io.open(minetest.get_worldpath() .. "/espace_data", "w")

	if err then
		return err
	end

	f:write(minetest.serialize(data))
	f:close()
end

-- Reads saved file
function espace.read_startest()

	local f, err = io.open(minetest.get_worldpath() .. "/espace_data", "r")
	local data = minetest.deserialize(f:read("*a"))

	f:close()

	return data
end

minetest.register_on_shutdown(function()
		espace.save_table()
end)

-- Check to see if file exists and if not sets default values.
local f, err = io.open(minetest.get_worldpath().."/espace_data", "r")

if f == nil then

	espace.day = 1
	espace.month = 6
  espace.year = 2019
  espace.build_dt = 0

  espace.save_table()

else
  local filedata=espace.read_startest()
	espace.day = filedata.day
	espace.month = filedata.month
  espace.year = filedata.year
  espace.build_dt = filedata.build_dt
  if espace.build_dt==nil then startest.build_dt=0 end
  
end

--date de creation + delai
espace.set_dat=function(delaimin,delaimax,form)
local phr=""
local creat_dat=(espace.year*168)+((espace.month-1)*14)+(espace.day-1)+math.random(delaimin,delaimax)
if form~=nil then
  local year=creat_dat/168
  local month=(year-math.floor(year))*12
  local day=(month-math.floor(month))*14
  year=math.floor(year)
  month=math.floor(month)+1
  day=math.floor(day)+1
  phr=string.sub(tonumber(year+1000000),2) .."/".. string.sub(tonumber(month+100),2) .."/".. string.sub(tonumber(day+100),2)
end
return creat_dat,phr
end

espace.get_dat=function(dte,form)
local year,month,day
if form~=nil then
  local tmp=string.split(dte,"/")
  year=tonumber(tmp[1])
  month=tonumber(tmp[2])
  day=tonumber(tmp[3])
else
  year=dte/168
  month=(year-math.floor(year))*12
  day=(month-math.floor(month))*14
  year=math.floor(year)
  month=math.floor(month)+1
  day=math.floor(day)+1
end
return year,month,day
end

espace.postostring=function(pos)
  local tmp=tostring(math.floor(pos.x)+131000)
  local position=string.sub(tmp,2)
  tmp=tostring(math.floor(pos.y)+131000)
  position=position.."/"..string.sub(tmp,2)
  tmp=tostring(math.floor(pos.z)+131000)
  position=position.."/"..string.sub(tmp,2)
  return position
end

--position du magasin extraction
espace.postonumber=function(position)
  local pos={x=0,y=0,z=0}
  local list=string.split(position,"/")
  pos.x=tonumber(list[1])-31000
  pos.y=tonumber(list[2])-31000
  pos.z=tonumber(list[3])-31000
  return pos
end

espace.bloc_is_protect=function(pos,radius)--get_secteur_by_pos
  local err=false
  if radius==nil then radius=5 end

  local protect_list = minetest.find_nodes_in_area(
		{x = pos.x - radius, y = pos.y - radius, z = pos.z - radius},
		{x = pos.x + radius, y = pos.y + radius, z = pos.z + radius},
		{"protector:protect", "protector:protect2"})

  if #protect_list>0 then
    return true
  end

  if pos.y<1008 then

  elseif pos.y>1007 and pos.y<10268 then
    local matricex=math.floor((pos.x+30752)/80)
    local matricey=math.floor((pos.y-1008)/80)
    local matricez=math.floor((pos.z+30752)/80)
  
    local secteur={x=math.floor(matricex/8),y=math.floor(matricey/8),z=math.floor(matricez/8)}
    secteur.nb=secteur.x+(secteur.y*9216)+(secteur.z*96)
    secteur.seed=secteur.nb % 501

    --get_bloc
    local bloc={x=matricex % 8 , y=matricey % 8 , z=matricez % 8 } 
    local nb=bloc.x+(bloc.y*64)+(bloc.z*8)
    nb=nb+secteur.seed

    if nb>511 then nb=nb-512 end

    if nb==283 or nb==45 then err=true end

  elseif pos.y>10267 then

  end

return err
end

espace.secteur=function(pos)
  local matricex=math.floor((pos.x+30752)/80)
  local matricey=math.floor((pos.y-1008)/80)
  local matricez=math.floor((pos.z+30752)/80)
  
  local secteur={x=math.floor(matricex/8),y=math.floor(matricey/8),z=math.floor(matricez/8)}
  secteur.nb=secteur.x+(secteur.y*9216)+(secteur.z*96)
  secteur.seed=secteur.nb % 501

  local bloc={x=matricex % 8 , y=matricey % 8 , z=matricez % 8 } 
  local nb=bloc.x+(bloc.y*64)+(bloc.z*8)
  nb=nb+secteur.seed

  if nb>511 then nb=nb-512 end

  bloc.nb=nb
  --recherhe nom secteur
  local tmp=secteur.nb+1
  for i=1,#galaxie_map do
    if tmp==galaxie_map[i][2] then
      secteur.name=galaxie_map[i][1]
      break
    end
  end

return secteur,bloc
end

espace.secteur_by_matrice=function(matrice)
  local secteur={x=matrice.x,y=matrice.y,z=matrice.z}
  secteur.nb=matrice.x+(matrice.y*9216)+(matrice.z*96)
  secteur.seed=secteur.nb % 501
 --recherhe nom secteur
  local tmp=secteur.nb+1
  for i=1,#galaxie_map do
    if tmp==galaxie_map[i][2] then
      secteur.name=galaxie_map[i][1]
      break
    end
  end
  return secteur
end

espace.info_secteur=function(secteurnb) --get_info_secteur
  local matricey=secteurnb/9216+0.00001
  local matricez=(matricey-math.floor(matricey))*96+0.00001
  local matricex=(matricez-math.floor(matricez))*96+0.00001
  local secteur={nb=secteurnb,x=math.floor(matricex),y=math.floor(matricey),z=math.floor(matricez),seed=secteurnb % 501}

  local tmp=secteur.nb+1
  for i=1,#galaxie_map do
    if tmp==galaxie_map[i][2] then
      secteur.name=galaxie_map[i][1]
      break
    end
  end

  local astroport,stargate,jail=espace.astroport(secteur)

  local planete=espace.planete(secteur)

return secteur,astroport,stargate,jail,planete
end

espace.planete=function(secteur) --get_planet by secteur
local planete={nb=0,alt=1,name="-"}
local sectmp=secteur.nb+1
  if sectmp>9999 and sectmp<124236 then
    local layer=math.floor((sectmp-10000)/3685)
    if ((sectmp-10000)%3685)==0 then
      if layer==0 then
        planete={nb=0,alt=132,name="earth"}
      else
        if layer>(#planet_layer) then  --protection si depassement nb layer en data
          planete={nb=0,alt=1 , name="-"}
        else
          planete={nb=layer,alt=(10451+((layer-1)*640))+math.abs(planet_layer[layer].water) , name=planet_layer[layer].name}
        end
      end
    end
  end
return planete
end

espace.astroport=function(secteur) --get_astroport
  local nb=283-secteur.seed
  
  if nb<0 then nb=nb+512 end  --si depassement

  local ay=nb/64
  local az=(ay-math.floor(ay))*8
  local ax=(az-math.floor(az))*8

  ay=((math.floor(ay)*80)+(secteur.y*640))+1048
  az=((math.floor(az)*80)+(secteur.z*640))-30712
  ax=((math.floor(ax)*80)+(secteur.x*640))-30712
  local astroport={nb=nb,x=ax,y=ay,z=az}
  local stargate={x=ax,y=ay-28,z=az-20}

  nb=45-secteur.seed
  
  if nb<0 then nb=nb+512 end  --si depassement

  ay=nb/64
  az=(ay-math.floor(ay))*8
  ax=(az-math.floor(az))*8

  ay=((math.floor(ay)*80)+(secteur.y*640))+1050
  az=((math.floor(az)*80)+(secteur.z*640))-30712
  ax=((math.floor(ax)*80)+(secteur.x*640))-30712
  local jail={nb=nb,x=ax,y=ay,z=az}

return astroport,stargate,jail
end

espace.planete_by_name=function(planete_name)
  local nb_layer=#planet_layer
  if planete_name=="earth" then
    planete={nb=0,alt=1,name="earth"}
    secteur=10000
  else 
    for i=1,nb_layer do
      if planete_name==planet_layer[i].name then
        local calcul=10450+((i-1)*640)+math.abs(planet_layer[i]["water"])
        planete={nb=i,alt=calcul,name=planete_name}
        secteur=10000+(i*3685)
      end
    end
  end

  local matricey=secteur/9216+0.00001
  local matricez=(matricey-math.floor(matricey))*96+0.00001
  local matricex=(matricez-math.floor(matricez))*96+0.00001
  local secteurpos={nb=secteur,x=math.floor(matricex),y=math.floor(matricey),z=math.floor(matricez),seed=secteur % 512}

  local astroport,stargate,jail=espace.astroport(secteurpos)
  
  return planete,astroport,stargate,jail
end

--*****************************
--** test si peine de prison **
--*****************************
espace.is_jail=function(player)
  local jail
  local new_dat=((espace.year-1)*168)+((espace.month-1)*14)+espace.day

  if player:get_attribute("jail")~=nil then
    jail=player:get_attribute("jail")
  else
    player:set_attribute("jail","none")
    jail="none"
  end
  
  if string.find(jail,"none")==nil then
    if tonumber(jail)<new_dat then
      --sortie de prison
      player:set_attribute("jail","none/out")
    end 
  end

return jail
end

--** priv astroport **

espace.setpriv=function(plname)

  if espace.data[plname].priv==nil then return end

  local data=espace.data[plname].priv
  local phr=""

  for i=1,#data do
    phr=phr..data[i]
    if i<#data then phr=phr..":" end
  end

  local player=minetest.get_player_by_name(plname)
  player:set_attribute("priv_astroport",phr)

end

espace.getpriv=function(plname)
  local player=minetest.get_player_by_name(plname)
  local phr=player:get_attribute("priv_astroport")

  if phr==nil then return end

  local data=espace.split_string(phr,"%d+")
  espace.data[plname].priv=data
end

-- ++++++++++++++++++++++++++++++++++++++++++++++++++
-- ++ fonction pour determiner si dehors ou dedans ++
-- ++++++++++++++++++++++++++++++++++++++++++++++++++
--
espace.is_inside=function(pos)
	if minetest.get_node_light({x=pos.x,y=pos.y+1,z=pos.z},0.5) ~= 15 then
		return true
	end
	
	local temp_node = minetest.get_node_or_nil({x=pos.x,y=pos.y+1,z=pos.z})

	for i = 2,20 do
		if temp_node ~= nil and temp_node.name ~= "air" then
			return true
		end
		temp_node = minetest.get_node_or_nil({x=pos.x,y=pos.y+i,z=pos.z})
	end
	return false
end
