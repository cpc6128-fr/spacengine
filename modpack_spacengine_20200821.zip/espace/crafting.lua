
-- Spacesuit

minetest.register_craft({
	output = "espace:helmet",
	recipe = {
		{"default:mese_crystal"},
		{"default:glass"},
		{"default:gold_ingot"},
	}
})


minetest.register_craft({
	output = "espace:spacesuit",
	recipe = {
		{"wool:white", "espace:helmet", "wool:white"},
		{"", "espace:air_tank", ""},
		{"wool:white", "", "wool:white"},
	}
})

