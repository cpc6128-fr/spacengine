--biome: 0=underground 1=tempere 2=hot 3=jungle 4=cold 5=mars 6=solar  9=espace

-- ******************
-- ** set skylayer **
-- ******************
--<name>,<sky>,<cloud>,<physics>,<day>
-- name,altmin,altmax,dayratio,physics,sky,cloud,biome,secteur
-- layername = "earth"
-- meteolayer = "clear"
-- physicslayer
--"map_ "= {{skylayer},{physics},{meteo}}

	map_sky = {
    {name="map_underground",--sky 1
    day=0,
    physic={speed = 1, jump = 1, gravity = 1},
    sky={bgcolor = {r = 0, g = 0, b = 0}, type = "plain",textures=nil},
    clouds={},
    radiation=0,
    oxygene=true
    },

    {name="map_earth",--sky 2
    day=nil,
    physic={speed = 1, jump = 1, gravity = 1},
    sky={bgcolor = {r=0, g=100, b=255},type = "regular",textures=nil},
    clouds={
      density = 0.4,
      color = "#fff0f0e5",
      ambient = "#000000",
      height = 120,
      thickness = 16,
      speed = {z = -2, y = -2}},
    radiation=0,
    oxygene=true
    },

    {name="map_espace",--sky 3
    day=0.5,
    physic={speed = 1, jump = 1, gravity = 0.1},
    sky={bgcolor = {r = 0, g = 0, b = 0}, type = "skybox",textures = {
			"asteroid_invZ512.png^[transformR180",
			"asteroid_Z512.png",
			"asteroid_invY512.png",
			"asteroid_Y512.png",
			"asteroid_X512.png^[transformR90",
			"asteroid_invX512.png^[transformR270"
		}},
    clouds={},
    radiation=10,
    oxygen=false
    },

    {name="map_moon",--sky 4
    day=1,
    physic={speed = 0.9, jump = 1.1, gravity = 0.5},
    sky={bgcolor = {r = 25, g = 25, b = 25}, type = "skybox",textures = {
			"GalaxyTex1_bk.jpg",
			"GalaxyTex1_ft.jpg",
			"GalaxyTex1_dn.jpg^[transformR180",
			"GalaxyTex1_up.jpg^[transformR180",
			"GalaxyTex1_lf.jpg^[transformR180",
			"GalaxyTex1_rt.jpg^[transformR180"
		}},
    clouds={},
    radiation=5,
    oxygen=false
    },

    {name="map_mars",--sky 5
    day=nil,
    physic= {speed = 1, jump = 1, gravity = 1},
    sky={bgcolor = {r = 128, g = 64, b = 0}, type = "skybox",textures = {
			"mars_up.jpg^[transformR270",
			"mars_dn.jpg^[transformR90",
			"mars_ft.jpg",
			"mars_bk.jpg",
			"mars_lf.jpg",
			"mars_rt.jpg"
		}},
    clouds={thickness=64,
      color={r=172, g=103, b=13},
      thickness=64,
      height=30900,
      speed={z=-2,x=-2},
      density=0.4},
    radiation=2,
    oxygen=false
    },

    {name="map_dark",--sky 6
    day=nil,
    physic={speed = 1, jump = 1, gravity = 1},
    sky={bgcolor = {r = 128, g = 64, b = 128}, type = "skybox",textures = {
			"chaos_up.jpg^[transformR270",
			"chaos_dn.jpg^[transformR90",
			"chaos_ft.jpg",
			"chaos_bk.jpg",
			"chaos_lf.jpg",
			"chaos_rt.jpg"
		}},
    clouds={},
    radiation=0,
    oxygen=true
    },

    {name="map_exoplanet",--sky 7
    day=0.4,
    physic={speed = 0.8, jump = 1, gravity = 1.2},
    sky={bgcolor = {r=0, g=100, b=255},type = "regular",textures=nil},
    clouds={
      density = 0.4,
      color = "#fff0f0e5",
      ambient = "#000000",
      height = 30900,
      thickness = 16,
      speed = {z = 0, y = -2}
    },
    radiation=0,
    oxygen=true
    },

    {name="map_constellation",--sky 8
    day=0.4,
    physic={speed = 1, jump = 1, gravity = 1},
    sky={bgcolor = {r = 0, g = 0, b = 0}, type = "skybox",textures = {
			"minetestUP.png",
			"minetestDN.png",
			"minetestFT.png",
			"minetestBK.png",
			"minetestRT.png",
			"minetestLF.png"
		}},
    clouds={},
    radiation=0,
    oxygen=true
    },
    }

local timer=0
local mod_spacengine=minetest.get_modpath("spacengine")

  -- ooooooooooooooooooooo
  -- oo choix de la map oo
  -- oo     debut       oo
  -- ooooooooooooooooooooo
minetest.register_globalstep(function(dtime)

  timer = timer + dtime

  if timer<2 then return end
  timer=0      

  for nb, player in ipairs(minetest.get_connected_players()) do
    local ppos = player:getpos()
    local pname = player:get_player_name()
    local dataplayer=espace.data[pname]
    local skytype=0
    local nuage=0

    if ppos.y<-32 then

      if dataplayer.bloc~=513 then
        dataplayer.secteur=0
        dataplayer.biome="u"
        --dataplayer.old_biome="u"
        dataplayer.bloc_protect=false
        dataplayer.bloc=513
        skytype=1
      end

    elseif ppos.y<1008 then

      local matricex=math.floor((ppos.x+31000)/320)--local matricex=math.floor((ppos.x+31000)/320)
      local matricez=math.floor((ppos.z+31000)/320)--local matricez=math.floor((ppos.z+31000)/320)
      local secteur=matricex+matricez*194--local secteur=matricex+matricez*194

      if dataplayer.secteur~=secteur then --changement de secteur
        dataplayer.secteur=secteur
        espace.data[pname].secteur=secteur

        if espace.build=="on" then
          local new_dt=startest.set_dat(0,0,1)

          if espace.build_dt<new_dt then
            matricex=(matricex*320)-31000--matricex=(matricex*320)-31000
            matricez=(matricez*320)-31000--matricez=(matricez*320)-31000
            if ppos.y>-10 and ppos.y<100 then
              espace.building({x=math.floor(ppos.x),y=math.floor(ppos.y),z=math.floor(ppos.z)},0,"default:dirt")--,deco)
            end
          end
        end
      end

      --changement de layer ?
      if dataplayer.bloc~=514 then
        dataplayer.bloc=514
        dataplayer.biome="x"
        --dataplayer.old_biome="x"
        dataplayer.bloc_protect=false
        skytype=2
      end

    elseif ppos.y>1007 and ppos.y<10208 then
      local matricex=math.floor((ppos.x+30752)/80)
      local matricey=math.floor((ppos.y-1008)/80)
      local matricez=math.floor((ppos.z+30752)/80)
      local secteurpos={x=math.floor(matricex/8),y=math.floor(matricey/8),z=math.floor(matricez/8)}
      secteurpos.nb=secteurpos.x + ( secteurpos.y * 9216 ) + ( secteurpos.z * 96 )
      secteurpos.seed=secteurpos.nb % 501

      local bloc={x=matricex % 8 , y=matricey % 8 , z=matricez % 8 } 
      local nb=bloc.x+(bloc.y*64)+(bloc.z*8)
      nb=nb+secteurpos.seed

      if nb>511 then nb=nb-512 end
      --changement de bloc ou secteur ?
      if dataplayer.bloc~=nb or dataplayer.secteur~=secteurpos.nb then
        dataplayer.bloc_protect=false

        if nb==45 then
          dataplayer.bloc_protect=true

        elseif nb==283 then
          dataplayer.bloc_protect=true

          if dataplayer.priv~=nil then  --privilege pour l'astroport
            for i=1,#dataplayer.priv do
              if dataplayer.priv[i]==secteurpos.nb then
                dataplayer.bloc_protect=false
                break
              end
            end
          end

        end

        skytype=3
        dataplayer.bloc=nb
        dataplayer.secteur=secteurpos.nb

        dataplayer.biome="e"--espace
        --dataplayer.old_biome="e"
        tmp=secteur_dat[nb+1]

        if tmp==8 then --8=jail
          dataplayer.biome="n"
          --dataplayer.old_biome="n"
          skytype=8
        elseif tmp==4 then --4=earth
          dataplayer.biome="t"
          --dataplayer.old_biome="t"
          skytype=4
        elseif tmp==2 then --2=solar
          dataplayer.biome="S"
          --dataplayer.old_biome="S"
        elseif tmp==1 then --1=astroport
          dataplayer.biome="n"
          --dataplayer.old_biome="n"
          skytype=8
        end
      end

    elseif ppos.y>10207 then
      --calcul layer multimap 
      local layer=math.floor((ppos.y-10208)/640)+1
      local matricex=math.floor((ppos.x+30752)/640)
      local matricez=math.floor((ppos.z+30752)/640)
      local secteur=matricex+matricez*96
      local nb_layer=#planet_layer

      if layer>nb_layer then layer=nb_layer end  --en cas d'erreur de depassement

      --changement de bloc ou secteur ?
      if dataplayer.bloc~=(514+layer) then
        dataplayer.bloc=514+layer
        nuage=(layer*640)+9840+math.random(1,45)--hauteur relative sol 100
        dataplayer.secteur=matricex+matricez*96
        dataplayer.biome=planet_layer[layer].biome
        --dataplayer.old_biome=planet_layer[layer].biome
        dataplayer.bloc_protect=false
        skytype=planet_layer[layer].sky
      end
    end

    if skytype>0 then
      --set map layer player avec les nouveaux parametres
      if nuage>0 and map_sky[skytype].height~=nil then
        map_sky[skytype].height=nuage
      end

      --test meteo en cour
      if dataplayer.meteo~="clear" then
        espace.weather(ppos,player,"clear",espace.data[pname].meteo)
      end
      --set physic fx
      fxset(player,map_sky[skytype].name,map_sky[skytype].physic.speed,map_sky[skytype].physic.jump,map_sky[skytype].physic.gravity)
      
      player:set_sky(map_sky[skytype].sky.bgcolor,map_sky[skytype].sky.type,map_sky[skytype].sky.textures)
      
      player:set_clouds(map_sky[skytype].clouds)

      player:override_day_night_ratio(map_sky[skytype].day)
      dataplayer.skytype=skytype
      dataplayer.old_biome=dataplayer.biome
    end

    --test spacengine
    if mod_spacengine then
      spacengine.environnement(player)
    end
    --test damage
    hurt_test(player)
  
    --test fx
    fxtest(player)
  
    --horloge
    espace.horloge(player)

  end

end)
