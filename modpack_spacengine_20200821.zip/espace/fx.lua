--** FX system **
--[[
fxbase=stockage fx de base
fxlist=fx temporaire

fxlist[playername]={fxname,fxtime,fxspeed,fxjump,fxgravity,priority,fxdisable}

fxadd  (player,fxname,fxtime,fxspeed,fxjump,fxgravity) --> x = -9..0..9 speed+x
 > x>9 set fx x/100  ex:speed=-0.2 decremente de 0.2 le speed / si speed=550 set a 5.5 le speed

    fxtime =-2 permanent / =0 durer determiner de 1.5 seconde / =1-99 time constant / >99 add time

fxremove (player,fxname) --si remov_all enleve tout les effet (sauf armor)
fxdisable (player,fxname) --disable l'effet
fxenable (player,fxname) --le contraire de disable

TODO priority first in list, last
snow prioritaire
--]]

   fxbase={}
   fxlist={}
   
--*************
--** init fx **
minetest.register_on_joinplayer(function(player)

    local name=nil
    if not player or player.is_fake_player then
        return name
    end
   
	name = player:get_player_name()
   
	if fxbase[name] == nil then
		fxbase[name] = {"default",1,1,1,true,false}
        fxlist[name]={}
	end
end)

--**********

minetest.register_on_leaveplayer(function(player)
   local name = player:get_player_name()
   fxbase[name]=nil
   fxlist[name]=nil
end)

--************************
--** test fx and change **   
fxtest=function(player)  --test chaque fx temp
   
  local name=player:get_player_name()

  if name==nil then return end

  if default.player_attached[name] then return end

  local nbfx=#fxlist[name]
  local fxspeed=fxbase[name][2]
  local fxjump=fxbase[name][3]
  local fxgravity=fxbase[name][4]

  if nbfx>0 then   --fx present
    local nb=1

    repeat
      local fxtemp=fxlist[name][nb]
      local fxtime=fxtemp[2]

      if fxtemp[6]==false then --fx disable

        if fxtemp[3]<10 then
          fxspeed=fxspeed+fxtemp[3]
        else
          fxspeed=fxtemp[3]/100
        end

        if fxtemp[4]<10 then
          fxjump=fxjump+fxtemp[4]
        else
          fxjump=fxtemp[4]/100
        end

        if fxtemp[5]<10 then
          fxgravity=fxgravity+fxtemp[5]
        else
          fxgravity=fxtemp[5]/100
        end

        fxspeed=math.max(0.01,fxspeed)
        fxjump=math.max(0.01,fxjump)
        fxgravity=math.max(0.01,fxgravity)

        if fxtime>0 then
          fxtime=fxtime-1
        end

        fxlist[name][nb][2]=fxtime

        if fxtime==0 then --remove fx
          table.remove(fxlist[name],nb)
          nb=nb-1
        end
      end

      nb=nb+1
      nbfx=nbfx-1
    until nbfx<1

   end
  
   player:set_physics_override({
		speed = fxspeed,
		jump = fxjump,
		gravity = fxgravity
	})

end
   
--*****************
--** set fx base **   
fxset=function(player,fxname,fxspeed,fxjump,fxgravity)--,fxsneak,fxsneak_glitch)  --fx de base (terre, moon, espace...)
   local name=player:get_player_name()
   if name==nil then return end
                 
   fxbase[name]={fxname,fxspeed,fxjump,fxgravity}--,fxsneak,fxsneak_glitch}
   
   player:set_physics_override({speed=fxspeed,jump=fxjump,gravity=fxgravity})--,sneak=fxsneak,sneak_glitch=fxsneak_glitch})
   
end
   
--****************
--** add new fx **
fxadd=function(player,fxname,fxtime,fxspeed,fxjump,fxgravity,priority,disable)  --fx temporaire (potion, sprint...)
   
    local name=player:get_player_name()
   
    if name==nil then return end
   
    if fxspeed==nil then fxspeed=0 end
    if fxjump==nil then fxjump=0 end
    if fxgravity==nil then fxgravity=0 end
    if fxtime==nil then fxtime=0 end
    if disable==nil then disable=false end
    if priority==nil then priority=0 end

    local fxtemp
   
    local nb=1
    local nbfx=#fxlist[name]
   
    if nbfx>0 then
        
        repeat 
        
            if fxname==fxlist[name][nb][1] then
              fxtemp=fxlist[name][nb]
              nbfx=0
            else
              nb=nb+1
              nbfx=nbfx-1
            end
        until nbfx<1
    end
   
    if fxtemp==nil then
      if fxname=="snow" then
        table.insert(fxlist[name],1,{fxname,0,0,0,0,false})
        nb=1
      else
        if priority>0 then
          priority=math.max(#fxlist[name],priority+1)
          table.insert(fxlist[name],priority,{fxname,0,0,0,0,false})
        else
          table.insert(fxlist[name],{fxname,0,0,0,0,false})
        end
      end
      fxtemp={fxname,0,0,0,0,false}
    end
   
    if fxspeed<10 then
        fxspeed=fxspeed+fxtemp[3]
    end
   
    if fxjump<10 then
        fxjump=fxjump+fxtemp[4]
    end
    
    if fxgravity<10 then
        fxgravity=fxgravity+fxtemp[5]
    end
    
    if fxtime==0 then
      fxtime=3
    end

    if fxtime>99 then
      fxtime=(fxtime/100)+fxtemp[2]
    end

   fxlist[name][nb]={fxname,fxtime,fxspeed,fxjump,fxgravity,disable}
   
   fxtest(player)
end
   
--************
--** remove **
fxremove=function(player,fxname)  --remove fx temporaire
   
    local name=player:get_player_name()
   
    if name==nil then return end
   
    local nb=1
    local nbfx=#fxlist[name]
    
    if nbfx==0 then return end

    if fxname=="remov_all" then
      repeat 
        if fxlist[name][nb][1]~="armor" then --compatible 3d armor
            table.remove(fxlist[name],nb)
        end
        nb=nb+1
        nbfx=nbfx-1
      until nbfx<1
    else

    repeat 
        if fxname==fxlist[name][nb][1] then
            table.remove(fxlist[name],nb)
            nbfx=0
        end
        nb=nb+1
        nbfx=nbfx-1
    until nbfx<1

   end

    fxtest(player)
end

--** disable **
fxdisable=function(player,fxname)  --disable fx
   
    local name=player:get_player_name()
   
    if name==nil then return end
   
    local nb=1
    local nbfx=#fxlist[name]
    
    if nbfx==0 then return end

    repeat 
        if fxname==fxlist[name][nb][1] then
            fxlist[name][nb][6]=true
            nbfx=0
        end
        nb=nb+1
        nbfx=nbfx-1
    until nbfx<1


    fxtest(player)
end

--** enable **
fxenable=function(player,fxname)  --enable fx
   
    local name=player:get_player_name()
   
    if name==nil then return end
   
    local nb=1
    local nbfx=#fxlist[name]
    
    if nbfx==0 then return end

    repeat 
        if fxname==fxlist[name][nb][1] then
            fxlist[name][nb][6]=false
            nbfx=0
        end
        nb=nb+1
        nbfx=nbfx-1
    until nbfx<1


    fxtest(player)
end
