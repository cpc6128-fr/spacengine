
espace.data={}
local hurt_active=false
if minetest.setting_getbool("enable_damage") then
  hurt_active=true
end

--**********************
--** init data player **
--**********************
minetest.register_on_joinplayer(function(player)
    local playername=nil

    if not player or player.is_fake_player then
        return
    end
   
	playername = player:get_player_name()
   
	if espace.data[playername] == nil then
		espace.data[playername] = {}
	end

  if not player:get_attribute("fatigue") then player:set_attribute("fatigue","500") end

  atm.readaccounts()
  if not atm.balance[playername] then
    atm.balance[playername] = 300000 --test only
  end

    local sec = (86400*minetest.env:get_timeofday());
    local mn = math.floor(sec/60) % 60;
    local hr = math.floor(sec/3600) % 60;
    local nb=0x00FF00
    local h=(espace.day*2).."/"..espace.month.."/"..espace.year.."\n"..string.format("%02d",hr)..":"..string.format("%02d",mn).."\nT. 20°C"
    
    local affichage = player:hud_add({
    hud_elem_type = "text";
    position = {x=0.1, y=0.91};
    text = h;
    number = nb;
    scale = 20;
    });
    
    espace.data[playername] = {temp=20, meteo="clear", radiation=20, oxygen=true, biome="n",  hud=affichage,  bloc_protect=false, bloc=999, secteur=0,skytype=2,old_biome="n",new_meteo="clear"}
    espace.getpriv(playername)
    player:set_attribute("sound_meteo",nil) --reset sound

end)


minetest.register_on_leaveplayer(function(player)
  --stop sound et reset sound player
  local sound_nb=player:get_attribute("sound_meteo")
  if sound_nb then
    minetest.sound_stop(tonumber(sound_nb))
    player:set_attribute("sound_meteo",nil)
  end

  local name = player:get_player_name()
  espace.data[name]=nil
end)

minetest.register_on_respawnplayer(function(player)
  player:set_attribute("fatigue","500")
end)

--biome t=temperate h=hot c=cold
--***************
--** Hurt Test **
--***************
local hurt_timer=0

hurt_test=function(player)

  if hurt_active==false then return end

  hurt_timer=hurt_timer+1

  local playerpos=player:get_pos()
  local playername = player:get_player_name()
  local hurt = tonumber(player:get_attribute("fatigue"))

  -- marche dans la neige difficile fxspeed 0.3
  local snowpos=player:get_pos()
  local nodeup = minetest.get_node({x=snowpos.x,y=snowpos.y,z=snowpos.z})
  local nodedn = minetest.get_node({x=snowpos.x,y=snowpos.y-1,z=snowpos.z})

  if string.find(nodedn.name,"snow") or string.find(nodeup.name,"snow") then
    fxadd(player,"snow",2,60,0,0,1)
  end

  if hurt_timer<3 then return end
  hurt_timer=0

  --suit dans le slot 1 1:space:suit 2:nuclear_suit 3:toxic_suit
  local inv=player:get_inventory()
  local suit=0
  local w=0
  local x
            
  -- test si source de froid
  local ice_pos=minetest.find_node_near(playerpos, 6, {"group:cools_lava"})
  local ice=0
  if ice_pos~=nil then
    ice=5
  end

  -- test si source de chaleur
  local heat_pos=minetest.find_node_near(playerpos, 6, {"group:lava","group:igniter"})
  local heat=0
  if heat_pos~=nil then
    heat=5
  end

  local suit_tmp=inv:get_stack("main", 1):get_name()
  if suit_tmp=="espace:spacesuit" then --froid/chaud
    suit=1
  elseif suit_tmp=="espace:nuclear_suit" then --chaud
    suit=2
  elseif suit_tmp=="espace:toxic_suit" then --chaud
    suit=3
  end
            
  if suit>0 then
    w=inv:get_stack("main", 1):get_wear()
  end

  if espace.data[playername].temp<5 then -- teste si la temperature est inferieur a 5
    if suit>0 then 
      if heat==0 then
        w=math.min(65535,w+50)--usure de la combi
      end
    else
      if heat==0 then
        x=math.ceil((espace.data[playername].temp-5)*0.5)
        hurt=hurt+x --epuisement plus rapide en fonction de la temp.
      end
    end
  end

  if espace.data[playername].temp>38 then -- teste si la temperature est superieur a 38
    if suit>0 then
      if ice==0 then
        w=math.min(65535,w+50)
      end
    else
      if ice==0 then
        if espace.data[playername].temp>38 then
          x=math.floor((espace.data[playername].temp-38)*0.5)
          hurt=hurt-x --epuisement plus rapide quand forte chaleur                    
        else
          hurt=hurt-heat --epuisement plus rapide quand forte chaleur 
        end
      end
    end
  end

  --oxygene
  local o=player:get_breath()
  local node=minetest.get_node(playerpos)
  if espace.data[playername].oxygen==false then
    if node.name~="air" and suit~=1 then
      player:set_breath(math.max(0,o-1))
    end
  end

  if suit==1 then
    if o<10 then
      player:set_breath(10)
      w=math.min(65535,w+50)--(500*coef_use))
    
    elseif espace.data[playername].oxygen==false and node.name~="air" then
      player:set_breath(10)
      w=math.min(65535,w+50)--(500*coef_use))
    end
  end

  --radiation
  if espace.data[playername].radiation>0 then
    if suit==1 or suit==2 then
      w=math.min(65535,w+(50*espace.data[playername].radiation))
    else
      hurt=hurt-espace.data[playername].radiation
    end
  end

  --nuage toxique
  if minetest.find_node_near(playerpos, 1, {"group:toxic"})~=nil then
    if suit==3 then
      w=math.min(65535,w+50)
    else
      hurt=hurt-5
    end
  end

  --meteo
  if not espace.is_inside(playerpos) then
    --pluie et neige légère
    if espace.data[playername].meteo=="weather_snow" or espace.data[playername].meteo=="weather_rain" then
      if suit==3 or suit==4 then
        w=math.min(65535,w+50)
      else
        hurt=hurt-2 
      end
    end
    --orage et tempete de neige ou de sable
    if espace.data[playername].meteo=="weather_storm" or espace.data[playername].meteo=="weather_snow_storm" then
      if suit==3 or suit==4 then
        w=math.min(65535,w+50)
      else
        hurt=hurt-4 
      end
    end
  end

  if suit>0 then
    if w>65534 then
      inv:set_stack("main", 1,ItemStack({name=""}))
      suit=0
    end

    if suit==1 then
      inv:set_stack("main", 1,ItemStack({name="espace:spacesuit",wear=w}))
    elseif suit==2 then
      inv:set_stack("main", 1,ItemStack({name="espace:nuclear_suit",wear=w}))
    elseif suit==3 then
      inv:set_stack("main", 1,ItemStack({name="espace:toxic_suit",wear=w}))
    end
  end

  local hp_lvl=player:get_hp()
  if hp_lvl>17 and hurt<500 then
    hurt=hurt+1
  end

  hurt=math.ceil(hurt)


  if hurt<1 then 
    hurt=0
    local h=player:get_hp()-1
    player:set_hp(h)
  end

  player:set_attribute("fatigue",tostring(hurt))

end
