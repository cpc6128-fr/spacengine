minetest.override_item("default:lava_source", {
	groups = {lava = 3, liquid = 2, igniter = 1,fire_heat=1}
})

minetest.override_item("default:lava_flowing", {
	groups = {lava = 3, liquid = 2, igniter = 1,fire_heat=1}
})

minetest.override_item("default:ice", {
	groups = {cracky = 3, cools_lava = 1, slippery = 3, freezer=1}
})

minetest.override_item("fire:permanent_flame", {
groups = {igniter = 2, dig_immediate = 3,fire_heat=1}
})

minetest.override_item("fire:basic_flame", {
groups = {igniter = 2, dig_immediate = 3, not_in_creative_inventory = 1,fire_heat=1}
})

minetest.override_item("default:snow", {
groups = {crumbly = 3, falling_node = 1, snowy = 1,freezer=1}
})

minetest.override_item("default:snowblock", {
groups = {crumbly = 3, cools_lava = 1, snowy = 1,freezer=1}
})

-- Iron

minetest.register_ore({
		ore_type       = "scatter",
		ore            = "default:stone_with_iron",
		wherein        = "default:stone",
		clust_scarcity = 12 * 12 * 12,
		clust_num_ores = 6,
		clust_size     = 4,
		y_max          = -8,
		y_min          = -64,
	})

--[[
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "default:stone_with_iron",
		wherein        = "default:stone",
		clust_scarcity = 9 * 9 * 9,
		clust_num_ores = 12,
		clust_size     = 3,
		y_max          = 31000,
		y_min          = 1025,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "default:stone_with_iron",
		wherein        = "default:stone",
		clust_scarcity = 7 * 7 * 7,
		clust_num_ores = 5,
		clust_size     = 3,
		y_max          = 0,
		y_min          = -31000,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "default:stone_with_iron",
		wherein        = "default:stone",
		clust_scarcity = 24 * 24 * 24,
		clust_num_ores = 27,
		clust_size     = 6,
		y_max          = -64,
		y_min          = -31000,
	})
--]]
