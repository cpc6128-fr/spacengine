--saison 45°paralèle nord (VALENCE - FRANCE) climat tempéré

--**********
--** NODE **
--**********

minetest.register_node("farming:deadplant", {
	description = "Dead Plant",
	drawtype = "plantlike",
	tiles = {"startest_deadplant.png"},
	paramtype = "light",
	is_ground_content = false,
	buildable_to = true,
	sunlight_propagates = true,
	inventory_image = "startest_deadplant.png",
	visual_scale = 1.2,
	wield_scale = {x=0.5, y=0.5, z=0.5},
	groups = {snappy=3, flammable=1, attatched_node=1,},
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, -0.1, 0.2}
	},
	walkable = false,
})

minetest.register_node("farming:fall_grass", {
	description = "Dirt with Grass",
	tiles = {"default_grass.png^[colorize:brown:50", "default_dirt.png",
		{name = "default_dirt.png^(default_grass_side.png^[colorize:brown:50)",
			tileable_vertical = false}},
	groups = {crumbly = 3, soil = 1, not_in_creative_inventory=1},
	drop = 'default:dirt',
	sounds = default.node_sound_dirt_defaults({
		footstep = {name = "default_grass_footstep", gain = 0.25},
	}),
   soil = {
		base = "default:dirt_with_dry_grass",
		dry = "farming:soil",
		wet = "farming:soil_wet"
	}
})

minetest.register_node("farming:dirt_summer", {
	description = "dirt dry",
	tiles = {"default_dry_grass.png",
		"default_dirt.png",
		{name = "default_dirt.png^default_dry_grass_side.png",
			tileable_vertical = false}},
	is_ground_content = true,
	groups = {
		crumbly=3,
		soil=1,
		not_in_creative_inventory=1
	},
	drop = 'default:dirt',
	sounds = default.node_sound_dirt_defaults({
		footstep = {name="default_grass_footstep", gain=0.4},
	}),
})

for i = 1, 4 do
   minetest.register_node('farming:fall_leaves_'..i, {
      description = 'Fall Leaves',
      drawtype = 'mesh',
      mesh = 'mymonths_fall_leaves.obj',
      tiles = {'startest_fall_leaves_'..i..'.png'},
      inventory_image = 'startest_fall_leaves_'..i..'.png',
      groups = {oddly_breakable_by_hand = 1, flammable = 2, attached_node = 1, fallen_leaves = 1},
      paramtype = 'light',
      walkable = false,
      buildable_to = true,
	   drop = 'farming:fall_leaves_2',
      selection_box = {
         type = "fixed",
			fixed = {-0.5, -0.5, -0.5, 0.5, -5/16, 0.5},
      }
   })
end

--Snow Nodes
local snow = {
	{"farming:snow_cover_1","1", -0.4},
	{"farming:snow_cover_2","2", -0.2},
	{"farming:snow_cover_3","3", 0},
	{"farming:snow_cover_4","4", 0.2},
	{"farming:snow_cover_5","5", 0.5},
}
for i in ipairs(snow) do

	local itm = snow[i][1]
	local num = snow[i][2]
	local box = snow[i][3]

	minetest.register_node(itm, {
		tiles = {"weather_snow_cover.png"},
		drawtype = "nodebox",
		paramtype = "light",
		buildable_to = true,
		walkable = false,
		node_box = {
			type  = "fixed",
			fixed = {-0.5, -0.5, -0.5, 0.5, box, 0.5}
		},
		selection_box = {
			type  = "fixed",
			fixed = {-0.5, -0.5, -0.5, 0.5, box, 0.5}
		},
		groups = {not_in_creative_inventory = 0, crumbly = 3, attached_node = 0, falling_node = 1},
		drop = "default:snow " .. num,
	})
end

minetest.override_item("default:leaves", {
    groups = {snappy = 3, leafdecay = 3, flammable = 2, leaves = 1, saison=1}
})

--flowers tree
minetest.register_node(":default:leaves_flowers", {
	description = "Apple Tree Leaves",
	drawtype = "allfaces_optional",
	waving = 1,
	tiles = {"default_leaves.png^verger_flowers_1.png"},
	special_tiles = {"default_leaves_simple.png^verger_flowers_1.png"},
	paramtype = "light",
	is_ground_content = false,
	groups = {snappy = 3, leafdecay = 3, flammable = 2, leaves = 1, saison=2, not_in_creative_inventory = 1},
	drop = {
		max_items = 1,
		items = {
			{
				-- player will get sapling with 1/20 chance
				items = {'default:sapling'},
				rarity = 20,
			},
			{
				-- player will get leaves only if he get no saplings,
				-- this is because max_items is 1
				items = {'default:leaves'},
			}
		}
	},
	sounds = default.node_sound_leaves_defaults(),

	after_place_node = default.after_place_leaves,
})
--autumn leaves
minetest.register_node(":default:leaves_autumn", {
	description = "Apple Tree autumn Leaves",
	drawtype = "allfaces_optional",
	waving = 1,
	tiles = {"default_leaves_autumn.png"},
	special_tiles = {"default_leaves_simple_autumn.png"},
	paramtype = "light",
	is_ground_content = false,
	groups = {snappy = 3, leafdecay = 3, flammable = 2, leaves = 1, saison=3},
	drop = {
		max_items = 1,
		items = {
			{
				-- player will get sapling with 1/20 chance
				items = {'default:sapling'},
				rarity = 20,
			},
			{
				-- player will get leaves only if he get no saplings,
				-- this is because max_items is 1
				items = {'default:leaves_autumn'},
			}
		}
	},
	sounds = default.node_sound_leaves_defaults(),

	after_place_node = default.after_place_leaves,
})
--stick leaves
minetest.register_node(":default:leaves_stick", {
	description = "Apple Tree stick Leaves",
	drawtype = "allfaces_optional",
	waving = 1,
	tiles = {"default_leaves_stick.png"},
	special_tiles = {"default_leaves_simple_stick.png"},
	paramtype = "light",
	is_ground_content = false,
	groups = {snappy = 3, leafdecay = 3, flammable = 2, leaves = 1, saison=4},
	drop = {
		max_items = 1,
		items = {
			{
				-- player will get sapling with 1/20 chance
				items = {'default:sapling'},
				rarity = 20,
			},
			{
				-- player will get leaves only if he get no saplings,
				-- this is because max_items is 1
				items = {'default:stick'},
			}
		}
	},
	sounds = default.node_sound_leaves_defaults(),

	after_place_node = default.after_place_leaves,
})

minetest.override_item("default:aspen_leaves", {
    groups = {snappy = 3, leafdecay = 3, flammable = 2, leaves = 1, saison=1}
})

--aspen autumn leaves
minetest.register_node(":default:aspen_leaves_autumn", {
	description = "Aspen Tree autumn Leaves",
	drawtype = "allfaces_optional",
	tiles = {"default_aspen_leaves_autumn.png"},
	waving = 1,
	paramtype = "light",
	is_ground_content = false,
	groups = {snappy = 3, leafdecay = 3, flammable = 2, leaves = 1, saison=3},
	drop = {
		max_items = 1,
		items = {
			{items = {"default:aspen_sapling"}, rarity = 20},
			{items = {"default:aspen_leaves_autumn"}}
		}
	},
	sounds = default.node_sound_leaves_defaults(),

	after_place_node = default.after_place_leaves,
})
--stick leaves
minetest.register_node(":default:aspen_leaves_stick", {
	description = "Aspen Tree stick Leaves",
	drawtype = "allfaces_optional",
	tiles = {"default_aspen_leaves_stick.png"},
	waving = 1,
	paramtype = "light",
	is_ground_content = false,
	groups = {snappy = 3, leafdecay = 3, flammable = 2, leaves = 1, saison=4},
	drop = {
		max_items = 1,
		items = {
			{items = {"default:aspen_sapling"}, rarity = 20},
			{items = {"default:stick"}}
		}
	},
	sounds = default.node_sound_leaves_defaults(),

	after_place_node = default.after_place_leaves,
})


