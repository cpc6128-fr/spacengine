
-- tea
minetest.register_craftitem("farming:tea_seed", {
	description = "Tea seed",
	inventory_image = "farming_tea_seed.png",
	on_place = function(itemstack, placer, pointed_thing)
		return farming.place_seed(itemstack, placer, pointed_thing, "farming:tea_1")
	end,
})

minetest.register_craftitem("farming:tea", {
	description = "Tea",
	inventory_image = "farming_tea.png",
})

minetest.register_craftitem("farming:ice_tea", {
	description = "Ice Tea",
	inventory_image = "farming_ice_tea.png",
  on_use = minetest.item_eat(3),
})

minetest.register_craft({
	type = "shapeless",
	output = "farming:ice_tea",
	recipe = { "farming:tea", "farming:sugar", "bucket:bucket_water" },
  replacements = {{"bucket:bucket_water", "bucket:bucket_empty"}}
})

minetest.register_craft({
	type = "shapeless",
	output = "farming:tea_seed 1",
	recipe = { "farming:tea" }
})

-- tea definition
local crop_def = {
	drawtype = "plantlike",
	tiles = {"farming_tea_1.png"},
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	drop = "",
	selection_box = farming.select,
	groups = {
		snappy = 3, flammable = 2, plant = 1, attached_node = 1,
		not_in_creative_inventory = 1, growing = 8
	},
	sounds = default.node_sound_leaves_defaults()
}

-- stage 1
minetest.register_node("farming:tea_1", table.copy(crop_def))

-- stage2
crop_def.tiles = {"farming_tea_2.png"}
minetest.register_node("farming:tea_2", table.copy(crop_def))

-- stage 3
crop_def.tiles = {"farming_tea_3.png"}
minetest.register_node("farming:tea_3", table.copy(crop_def))

-- stage 4
crop_def.tiles = {"farming_tea_4.png"}
minetest.register_node("farming:tea_4", table.copy(crop_def))

-- stage 5
crop_def.tiles = {"farming_tea_5.png"}
minetest.register_node("farming:tea_5", table.copy(crop_def))

-- stage 6
crop_def.tiles = {"farming_tea_6.png"}
minetest.register_node("farming:tea_6", table.copy(crop_def))

-- stage 7
crop_def.tiles = {"farming_tea_7.png"}
crop_def.drop = {
	items = {
		{items = {'farming:tea'}, rarity = 1},
		{items = {'farming:tea'}, rarity = 3},
	}
}
minetest.register_node("farming:tea_7", table.copy(crop_def))

-- stage 8 (final)
crop_def.tiles = {"farming_tea_8.png"}
crop_def.groups.growing = 0
crop_def.drop = {
	items = {
		{items = {'farming:tea 5'}, rarity = 1},
    {items = {'farming:tea_seed 1'}, rarity = 1},
    {items = {'farming:tea 5'}, rarity = 2},
		{items = {'farming:tea_seed 2'}, rarity = 2},
	}
}
minetest.register_node("farming:tea_8", table.copy(crop_def))
