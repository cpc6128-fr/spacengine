commerce.item_type={"eat","ores","tools","material","furniture","machine","misc"}
commerce.passenger_type={"worker","tourist","scientist","military"}
--local mission_type={"marchandise","voyager","dig","build","spy"}
commerce.dig_node={{"STONE","default:stone:6:D:10:D"}, {"IRON","default:stone_with_iron:7:D:15:D"}, {"COPPER","default:stone_with_copper:7:D:15:D"}, {"TIN","default:stone_with_tin:7:D:16:D"}, {"URANIUM","technic:mineral_uranium:9:D:20:D"}, {"STAR","star:star:11:D:30"},{"Nebula","nebuleuse:star:12:D:35:D"}}
commerce.build_node={{"WOOD","default:wood:5:B:10:B"}, {"STONE","default:stone:6:B:10:B"}, {"ROCK","espace:rock:8:B:15:B"}, {"ROCK2","espace:rock_2:8:B:15:B"}, {"CONCRETE","bloc4builder:concrete_dir:10:B:20:B"}, {"STONEBRICK","default:stonebrick:10:B:20:B"}, {"Army","bloc4builder:army:15:B:25:B"}}
commerce.spy_type={{"URANIUM","technic:mineral_uranium"}, {"GOLD","default:stone_with_gold"}, {"MESE","default:stone_with_mese"}, {"AMETHYST","gems:amethyst_ore"}, {"MOB","mobs:all"}, {"SPACESHIP","group:spacengine"}}

--TODO depanneur : pour vaisseaux en panne hors des zones de relache

--*************
--** magasin **
--*************
local chg_form={}
--** fonction de base **

local function  commerce_can_dig(pos,player)
  if not minetest.check_player_privs(player:get_player_name(),{destruct_commerce=true}) then return false end
  return true
end

-- lecture de l'inventaire et renvoie l'index d'un item + tout ses metadata...
commerce.found_item_index=function(player,item)
  local index=0
  local inv=player:get_inventory()
  local stackname,stackcount,stackwear,stackmeta
  for i=1,32 do
    local stack=inv:get_stack("main",i)
    stackname=stack:get_name()
    if item==stackname then
      index=i
      stackcount=stack:get_count()
      stackwear=stack:get_wear()
      stackmeta=stack:get_metadata()
      break
    end
  end
  return index,stackcount,stackwear,stackmeta
end

--***************************
--** transaction with card **
--***************************
--stack=item / card=prix transaction
commerce.transaction=function(player,stack,card)
  local name=player:get_player_name()
  local inv = player:get_inventory()
  local havecard=commerce.found_item_index(player,"commerce:card")

  if havecard>0 then --si card presente
    if atm.balance[name]~= nil then
      if atm.balance[name]-card>0 then
        atm.balance[name] = atm.balance[name]-card
--TODO place pour add ?
        if stack~=nil then inv:add_item("main",stack) end
        atm.saveaccounts()
        minetest.sound_play("card2",{to_player=name,gain=1.5})
        minetest.chat_send_player(name,"Account : ".. atm.balance[name])
        return true
      end
    end
  end
  return false
end

--*******************************
--** transaction money or card **
--*******************************
--index = numero objet dans commerce.item / quantity = nb d'objet / money="nodename xx" / card = nil ou montant transaction
local magasin_transaction=function(player,objet,money,quantity,card)
  local err=0
  local name=player:get_player_name()

  --local objet=commerce.item[index]

    local inv = player:get_inventory()
    local stack=objet .." "..quantity
    local havecard=commerce.found_item_index(player,"commerce:card")

    if card~=nil and havecard>0 and havecard<9 then --si card presente dans le haut de l'inventaire (a l'ecran)
      if atm.balance[name]== nil then return end
      if atm.balance[name]-card>0 then
        atm.balance[name] = atm.balance[name]-card
        inv:add_item("main",stack)
        atm.saveaccounts()
        minetest.sound_play("card2",{to_player=name,gain=1.5})
        err=1
        minetest.chat_send_player(name,"Account : ".. atm.balance[name])
      end

    else --or with money
      if inv:contains_item("main",money) then
        inv:remove_item("main", money)
        inv:add_item("main",stack)
        minetest.sound_play("money",{to_player=name,gain=1.5})
        err=1
      end
    end
  
  if err==0 then
    minetest.sound_play("wrong",{to_player=name,gain=1.5})
  end
end

--********************
--** create magasin **
--********************
local function fill_shop(shop_pos,dealertype,item_type,size)
  if size==nil then size=16 end
  local meta = minetest.get_meta(shop_pos)
  local inv = meta:get_inventory()
  inv:set_size("pay",size)
  inv:set_size("objet",size)
  local trade_index = 1
  local trades_already_added = ""
  local price=0
  local money="currency:minegeld"
  local objet={}
  local list_item=""
  local quantity=0
  local trades = {}
  
  --par type ou aleatoire ?
  if item_type==nil then
      item_type=0
  end

  -- nb d'item enregistrer
  local nb_item = #commerce.item
  --choix premier objet
  local choix_item=nb_item
  
	for i=1,size do
    choix_item=math.random(1,nb_item)
    local rnd=math.random(1,100)
    repeat
      objet=commerce.item[choix_item]  --recuperation des données
      if string.find(objet[6],dealertype) then --type magasin/chest/xpchest/trader/distributeur
        -- objet deja selectionner ?
        if string.find(trades_already_added,objet[2])== nil then
              
          if item_type==0 or item_type==objet[1] then
            if objet[4]>rnd then
            list_item=list_item..choix_item.."/"
            inv:set_stack("objet",i,objet[2])
            trades_already_added=trades_already_added.." "..objet[2]
            choix_item=1
            end
          end
        end
      end
      rnd=rnd-1.5
      choix_item=choix_item-3
    until choix_item<1

  end

  --date de creation + delai
  local creat_dat=((espace.year-1)*168)+((espace.month-1)*14)+espace.day+math.random(40,80)
  meta:set_int("visit",creat_dat)
  --meta:set_int("inflation",math.random(10))--TODO suivant secteur civilisation
  meta:set_string("list_item",list_item)

end


local function price_shop(player,shop_pos,card)
  local meta = minetest.get_meta(shop_pos)
  local inv = meta:get_inventory()
  local plname=player:get_player_name()
  local trades
  local inflation=meta:get_int("inflation")
  if inflation==0 then inflation=1 end
  local tmp=meta:get_string("list_item")
  local list_item=string.split(tmp,"/")
  local xp=espace.xpgetlvl(player,"force")+1

  local formspec= "size[8,11]bgcolor[#080808BB;true]background[0,0;1,1;commerce_magasin1.png;true]listcolors[#00000069;#5A5A5A;#141318;#30434C;#FFF]"
  if card==true then
    formspec=formspec.."image[0,5.5;1.5,1.5;commerce_accept_cb.png]"
  end
  local x, y=0,0
	local newprice
  for i=1,#list_item do
    trades=inv:get_stack("objet",i):get_name()

    -- effacement stack
    inv:set_stack("pay",i,"")
    local objet=""
    local money="currency:minegeld"
    local quantity=1
    local index
    if trades then
      index=tonumber(list_item[i])
      local item_data=commerce.item[index]
      objet=item_data[2]
      local price=math.ceil(item_data[3]*inflation)
      newprice=math.ceil(price*((25+(xp*4))/100)) --taux différent suivant XP

      --currency calcul
    if newprice>2500 then
      quantity=math.ceil(newprice/100)
      money="currency:minegeld_100"
      newprice=quantity*100
    elseif newprice>500 then
      quantity=math.ceil(newprice/50)
      money="currency:minegeld_50"
      newprice=quantity*50
    elseif newprice>250 then
      quantity=math.ceil(newprice/10)
      money="currency:minegeld_10"
      newprice=quantity*10
    elseif newprice>50 then
      quantity=math.ceil(newprice/5)
      money="currency:minegeld_5"
      newprice=quantity*5
    elseif newprice>12.5 then
      quantity=math.ceil(newprice)
      money="currency:minegeld"
      newprice=quantity*1
    elseif newprice>2.5 then
      quantity=math.ceil(newprice/0.25)
      money="currency:minegeld_cent_25"
      newprice=quantity*0.25
    elseif newprice>0 then
      quantity=math.ceil(newprice/0.05)
      money="currency:minegeld_cent_5"
      newprice=quantity*0.05
    end

    chg_form[plname][i]={objet,money,quantity,newprice}
    formspec = formspec.."item_image_button["..x ..",".. y ..";1,1;".. objet ..";objet;".. i .."]item_image_button[".. x+1 ..",".. y ..";1,1;".. money .." ".. quantity ..";prices;]label[".. x+0.75 ..",".. y+0.9 ..";".. newprice .."]"

      x=x+2
      if x>6 then
        x = 0
        y = y+1.4
      end

    end
 
    inv:set_stack("pay",i,money)
  end
  formspec = formspec.."button_exit[3,6;2,1;exit;exit]list[current_player;main;0,7;8,4;]";

  if card==true then
    minetest.show_formspec(player:get_player_name(), "commerce#2", formspec)
  else
    minetest.show_formspec(player:get_player_name(), "commerce#1", formspec)
  end

end

--******************
--** node magasin **
--******************
minetest.register_node("commerce:magasin", {
	description = "stand de vente",
  tiles = {
		"commerce_borne_bottom.png",
		"commerce_borne_bottom.png",
		"commerce_etagere_vide.png",
		"commerce_etagere_vide.png",
		"commerce_nourriture1.png",
		"commerce_nourriture3.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
  paramtype2 = "facedir",
	groups = {cracky = 2, not_in_creative_inventory = 1},--cracky=2},
	legacy_facedir_simple = true,
	is_ground_content = false,
  on_construct = function(pos)
        fill_shop(pos,"m",0,16) --pos,type de magasin,type objet,size
  end,
  on_rightclick = function(pos,node,player,itemstack,_)
    local meta = minetest.get_meta(pos)
    local old_dat=meta:get_int("visit")
    local new_dat=((espace.year-1)*168)+((espace.month-1)*14)+espace.day

    if old_dat<new_dat then --si depasse la date, refill new item
      fill_shop(pos,"m",0,16)
    end

    chg_form[player:get_player_name()]={}
    price_shop(player,pos,true)
  end,
  can_dig=function(pos,player)
    return commerce_can_dig(pos,player)
  end
})

minetest.register_node("commerce:automatic_distributor", {
	description = "automatic distributor",
  tiles = {
		"commerce_distributor_e.png",
	},
	drawtype = "mesh",
  mesh = "homedecor_soda_machine.obj",
selection_box = {
	type = "fixed",
	fixed = {-0.5, -0.5, -0.5, 0.5, 1.5, 0.5}
},
	collision_box = {
	type = "fixed",
	fixed = {-0.5, -0.5, -0.5, 0.5, 1.5, 0.5}
},
	paramtype = "light",
  paramtype2 = "facedir",
	groups = {cracky = 2, not_in_creative_inventory = 1},--cracky=2},
	legacy_facedir_simple = true,
	is_ground_content = false,
  on_construct = function(pos)
        fill_shop(pos,"d",0,10)
  end,
  on_rightclick = function(pos,node,player,itemstack,_)
    local meta = minetest.get_meta(pos)
    local old_dat=meta:get_int("visit")
    local new_dat=((espace.year-1)*168)+((espace.month-1)*14)+espace.day

    if old_dat<new_dat then --si plus de 3 mois, refill new item
      fill_shop(pos,"d",0,10)
    end

    chg_form[player:get_player_name()]={}
    price_shop(player,pos,false)
  end,
  can_dig=function(pos,player)
    return commerce_can_dig(pos,player)
  end
})

--*********************************
--** commerce avec les vaisseaux **
--********************************

--calcul distance entre vaisseaux et commerce
local function distance(pos,channel,owner)
  local found,cpos=spacengine.test_area_ship(0,0,channel..":"..owner)
  if found then
    d={x=math.abs(cpos.x-pos.x),y=math.abs(cpos.y-pos.y),z=math.abs(cpos.z-pos.z)}
    d.max=math.max(d.x,d.y,d.z)
    if d.max<160 then
      return true
    end
  end
return false
end

--list tout les vaisseaux du player a proximiter du commerce 160 bloc max
local function list_vaisseaux(pos,player)
  local list=""
  local nb=1
  local plname=player:get_player_name()
  local vaisseaux=player:get_attribute("vaisseaux")
  
  if vaisseaux==nil then return "No channel","" end

  local split_vaisseaux=string.split(vaisseaux,":")
  vaisseaux=""

  for i=1,#split_vaisseaux do
    if split_vaisseaux[i]==nil then
      break
    else
      local found=distance(pos,split_vaisseaux[i],plname)
      if found then
        if nb==1 then vaisseaux=split_vaisseaux[i] end
        list=list..split_vaisseaux[i]..","
        nb=nb+1
      end
    end
  end

  return list.."No channel",vaisseaux
end

--initialise cargo
local function cargo(plname)
  chg_form[plname].marchandise=0
  chg_form[plname].poids_total=0
  chg_form[plname].poids=0
  chg_form[plname].passeng_nb=0
  chg_form[plname].passeng_max=0

  if chg_form[plname].vaisseaux~="" then
    local channel=chg_form[plname].vaisseaux ..":".. plname
    chg_form[plname].poids_total=spacengine.area[channel].config[9][1]
    chg_form[plname].poids=spacengine.area[channel].config[9][2]
    chg_form[plname].passeng_nb=spacengine.area[channel].config[10][2]
    chg_form[plname].passeng_max=spacengine.area[channel].config[10][1]

    if chg_form[plname].objet_type~=0 then
      chg_form[plname].marchandise=spacengine.area[channel].config[9][3][chg_form[plname].objet_type]
    end

    chg_form[plname].delivery_n=1
    -- recupere position controler
    local cpos=spacengine.area[channel].p0
    local cont_met=minetest.get_meta(cpos)
    --recupere meta delivery
    chg_form[plname].list_delivery=cont_met:get_string("delivery")

  end

end

local function cargaison_protect(plname,quantity,option)
  local err=false
  
  local channel=chg_form[plname].vaisseaux ..":".. plname
  mission=string.split(chg_form[plname].list_delivery,"/")
  if mission=="" then return false end

  local storage,passenger=0,0
  for ii=1,#mission do
    local destination=string.split(mission[ii],":")
    if destination[1]=="0" then
      if tonumber(destination[2])==chg_form[plname].objet_type then
        storage=storage+tonumber(destination[3])
      end
    elseif destination[1]=="1" then
      passenger=passenger+tonumber(destination[3])
    end
  end

  if option=="s" then
    if spacengine.area[channel].config[9][3][chg_form[plname].objet_type]-storage-quantity<0 then err=true end
  elseif option=="p" then
    if spacengine.area[channel].config[10][2]-passenger-quantity<0 then err=true end
  end

  return err
end

--**************************
--** ITEM -> MARCHANDISE  **
--**************************

--recherche item et type
local function objet_select(plname,inv)
  local stack=inv:get_stack("src",1)
  local nb_obj=#commerce.item
  local name=stack:get_name()
  chg_form[plname].price=0
  chg_form[plname].objet_type=0
  chg_form[plname].quantity=0

  repeat
    objet=commerce.item[nb_obj]

    if name==objet[2] then
      chg_form[plname].quantity=stack:get_count() -- nb objet
      chg_form[plname].price=math.ceil(objet[3]*chg_form[plname].quantity)--*chg_form[plname].inflation)
      chg_form[plname].objet_type=objet[1]
      nb_obj=0
    end

    nb_obj=nb_obj-1
  until nb_obj<1

end

--affichage formspec
local function affichage_item(plname)
  local valid=0
  local form="size[12,11]list[current_player;main;4,7;8,4;]button_exit[0,10;2,1;exit;exit]list[nodemeta:"..
  chg_form[plname].pos ..";src;5,0;1,1;]label[9,0;"..plname.."]textlist[0,0;4,1.3;spaceship;"..
  chg_form[plname].list ..";".. chg_form[plname].select .."]"

  if atm.balance[plname]~= nil then
    form=form.."label[9,0.5;Bank :]label[9,1;".. atm.balance[plname] .."]"
  end


  if chg_form[plname].vaisseaux~="" then
    form=form.."label[0,1.5;Cargo ".. chg_form[plname].poids .."/"..
    chg_form[plname].poids_total .."]"
    valid=valid+1
  end

  if chg_form[plname].objet_type~=0 then
    form=form.."label[9,1.5;price : ".. chg_form[plname].price .." Mg ]"
    valid=valid+1
  end
  
  if valid==2 then
    form=form.."label[4,1.5;Stock "..commerce.item_type[chg_form[plname].objet_type] .." "..
    chg_form[plname].marchandise .."]button[0,9;2,1;item;accept]"
  end

  return minetest.show_formspec(plname,"commerce#3", form)
end

--node commerce item
minetest.register_node("commerce:green_deal", {
  description = "magasin card",
  tiles = {"spacengine_batterie_left.png", "spacengine_batterie_left.png", "spacengine_batterie_left.png", "spacengine_batterie_left.png", "spacengine_batterie_front.png", "commerce_green.png"},
  paramtype = "light",
  paramtype2 = "facedir",
  groups = {cracky = 2, not_in_creative_inventory = 1},--cracky=2},
  on_rotate = screwdriver.rotate_simple,
  on_construct = function(pos)
    local meta = minetest.get_meta(pos)
    local inv = meta:get_inventory()
    inv:set_size('src', 1)
    --date de creation + delai et inflation
    local creat_dat=((espace.year-1)*168)+((espace.month-1)*14)+espace.day+math.random(40,80)
    meta:set_int("visit",creat_dat)
    --meta:set_int("inflation",math.random(10))
  end,

  on_rightclick = function(pos,node,player)
    local havelicence=commerce.found_item_index(player,"commerce:licence")
    if havelicence>0 then --si card presente
      local _,_,_,stackmeta=commerce.found_item_index(player,"commerce:licence")
      if string.find(stackmeta,"commerce")==nil then
        minetest.sound_play("wrong",{to_player=name,gain=1.5})
        return
      end
    else
      minetest.sound_play("wrong",{to_player=name,gain=1.5})
      return
    end

    local meta = minetest.get_meta(pos)
    local inv = meta:get_inventory()
    local plname=player:get_player_name()
    local old_dat=meta:get_int("visit")
    local new_dat=((espace.year-1)*168)+((espace.month-1)*14)+espace.day
    --local inflation=meta:get_int("inflation")
    --if inflation==0 then inflation=1 end

    if old_dat<new_dat then --si depasse la date, refill new item
      meta:set_int("visit",new_dat+math.random(40,80))
      --meta:set_int("inflation",math.random(10))
    end

    local list,vaisseaux=list_vaisseaux(pos,player)
    chg_form[plname]={}
    chg_form[plname].inflation=1
    chg_form[plname].list=list
    chg_form[plname].select=1
    chg_form[plname].vaisseaux=vaisseaux
    chg_form[plname].pos= pos.x ..",".. pos.y ..",".. pos.z
    objet_select(plname,inv)
    cargo(plname)
    affichage_item(plname)
  end,

  on_metadata_inventory_put = function(pos,listname, index, stack, player)
    local plname=player:get_player_name()
    local meta = minetest.get_meta(pos)
    local inv = meta:get_inventory()
    objet_select(plname,inv)
    cargo(plname)
    affichage_item(plname)
  end,

  on_metadata_inventory_take = function(pos, listname, index, stack, player)
    local plname=player:get_player_name()

    if listname=="src" then
      chg_form[plname].objet_type=0
      chg_form[plname].price=0
      affichage_item(plname)
    end

	end,
  can_dig=function(pos,player)
    return commerce_can_dig(pos,player)
  end
})

--**************************
--** MARCHANDISE --> ITEM **
--**************************

local function item_list(plname)
  local item_nb=#commerce.item
  local form=""

  repeat
    if commerce.item[item_nb][1]==chg_form[plname].objet_type then
      local calcul=math.ceil(commerce.item[item_nb][3])--*chg_form[plname].inflation)
      form=form..commerce.item[item_nb][2].." ".. calcul
      if item_nb>1 then
        form = form..","
      end
    end
    item_nb=item_nb-1
  until item_nb<1

  chg_form[plname].list_item=form
end

--affichage formspec
local function affichage_marchandise(plname)
  local form="size[12,11]list[current_player;main;4,7;8,4;]button_exit[0,10;2,1;exit;exit]label[9,0;"..
  plname.."]textlist[0,0;4,1.3;spaceship;".. chg_form[plname].list ..";".. chg_form[plname].select .."]textlist[4.5,0;4,1.3;marchandise;".. chg_form[plname].march_list ..";".. chg_form[plname].objet_type .."]"

  if atm.balance[plname]~= nil then
    form=form.."label[9,0.5;Bank :]label[9,1;".. atm.balance[plname] .."]"
  end


  if chg_form[plname].vaisseaux~="" then
    if chg_form[plname].list_item~="" then
    local split=string.split(chg_form[plname].list_item,",")
    local stack=string.split(split[chg_form[plname].objet_idx]," ")
    form=form.."label[0,1.5;Cargo ".. chg_form[plname].poids .."/"..
    chg_form[plname].poids_total .."]label[9,1.5;price : "..
--item_type[chg_form[plname].objet_type] ..
    stack[2] .." Mg]label[4,1.5;Stock ".. commerce.item_type[chg_form[plname].objet_type] .." "..
    chg_form[plname].marchandise .."]"
    form=form.."textlist[0,2;5,4;objet;"..chg_form[plname].list_item..";"..chg_form[plname].objet_idx.."]item_image_button[7,3;2,2;".. stack[1] ..";transfert;"..stack[2].."]"
    end
  end

  return minetest.show_formspec(plname,"commerce#4", form)
end

--node commerce marchandise
minetest.register_node("commerce:red_deal", {
  description = "magasin tonne",
  tiles = {"spacengine_batterie_left.png", "spacengine_batterie_left.png", "spacengine_batterie_left.png", "spacengine_batterie_left.png", "spacengine_batterie_front.png", "commerce_red.png"},
  paramtype = "light",
  paramtype2 = "facedir",
  groups = {cracky = 2, not_in_creative_inventory = 1},--{cracky=2},
  on_rotate = screwdriver.rotate_simple,
  on_construct = function(pos)
    --initialisation item
    local meta = minetest.get_meta(pos)
    --local inv = meta:get_inventory()
    --inv:set_size('dst', 60)
    --date de creation + delai et inflation
    local creat_dat=((espace.year-1)*168)+((espace.month-1)*14)+espace.day+math.random(40,80)
    meta:set_int("visit",creat_dat)
    --meta:set_int("inflation",math.random(10))
  end,

  on_rightclick = function(pos,node,player)
    local havelicence=commerce.found_item_index(player,"commerce:licence")
    if havelicence>0 then --si card presente
      local _,_,_,stackmeta=commerce.found_item_index(player,"commerce:licence")
      if string.find(stackmeta,"commerce")==nil then
        minetest.sound_play("wrong",{to_player=name,gain=1.5})
        return
      end
    else
      minetest.sound_play("wrong",{to_player=name,gain=1.5})
      return
    end

    --initialisation item
    local meta = minetest.get_meta(pos)
    local inv = meta:get_inventory()
    local plname=player:get_player_name()
    local old_dat=meta:get_int("visit")
    local new_dat=((espace.year-1)*168)+((espace.month-1)*14)+espace.day
    --local inflation=meta:get_int("inflation")
    --if inflation==0 then inflation=1 end

    if old_dat<new_dat then --si depasse la date, refill new item
      meta:set_int("visit",new_dat+math.random(40,80))
      --meta:set_int("inflation",math.random(10))
    end

    local list,vaisseaux=list_vaisseaux(pos,player)
    chg_form[plname]={}
    chg_form[plname].inflation=1
    chg_form[plname].list=list
    chg_form[plname].select=1
    chg_form[plname].vaisseaux=vaisseaux
    chg_form[plname].pos= pos.x ..",".. pos.y ..",".. pos.z
    chg_form[plname].objet_type=1
    chg_form[plname].objet_idx=1
    chg_form[plname].list_item=""
    chg_form[plname].march_list=""
    for ilist=1,#commerce.item_type do
      chg_form[plname].march_list=chg_form[plname].march_list .. commerce.item_type[ilist]
      if ilist<#commerce.item_type then chg_form[plname].march_list=chg_form[plname].march_list.."," end
    end
    cargo(plname)
    item_list(plname)
    affichage_marchandise(plname)
  end,
  can_dig=function(pos,player)
    return commerce_can_dig(pos,player)
  end
})

--******************
--** civilisation **
--******************

--affichage formspec
local function affichage_civilisation(plname)
  local nb=chg_form[plname].objet_type*2
  local form="size[12,11]list[current_player;main;4,7;8,4;]button_exit[0,10;2,1;exit;exit]label[9,0;"..
  plname.."]textlist[0,0;4,1.3;spaceship;".. chg_form[plname].list ..";".. chg_form[plname].select .."]textlist[4,3;4,1.3;marchandise;".. chg_form[plname].march_list ..";".. chg_form[plname].objet_type .."]"

  if atm.balance[plname]~= nil then
    form=form.."label[9,0.5;Bank :]label[9,1;".. atm.balance[plname] .."]"
  end

  if chg_form[plname].vaisseaux~="" then
    form=form.."label[0,1.5;Cargo ".. chg_form[plname].poids .."/"..
    chg_form[plname].poids_total .."]label[4,1.5;Stock ".. commerce.item_type[chg_form[plname].objet_type] .." "..
    chg_form[plname].marchandise .."]"
    form=form.."button[0,3;1,1;dec1;-1]button[0,4;1,1;dec10;-10]button[11,3;1,1;inc1;+1]button[11,4;1,1;inc10;+10]"
  end

  local trade_spl=string.split(chg_form[plname].trade,"/")
  form=form.."label[0,6;population ".. trade_spl[15] .."]label[8,6;Bank ".. trade_spl[16] .."]label[4,6;".. trade_spl[nb-1] .."]label[9,1.5;Price ".. tostring(trade_spl[nb]*chg_form[plname].inflation) .."]label[8,5.5;Name ".. trade_spl[17] .."]"

  return minetest.show_formspec(plname,"commerce#5", form)
end

minetest.register_node("commerce:info_astroport", {
	description = "astroport information",
	tiles = {
		"commerce_info_astroport2.png",
	},
	drawtype = "mesh",
  mesh = "info.obj",
selection_box = {
	type = "fixed",
	fixed = {-0.5, -0.5, -0.1, 0.5, 1.5, 0.1}
},
	collision_box = {
	type = "fixed",
	fixed = {-0.5, -0.5, -0.1, 0.5, 1.5, 0.1}
},
  on_construct=function(pos)
    commerce.civ_init(pos)
  end,
  on_rightclick = function(pos,node,player)
    local havelicence=commerce.found_item_index(player,"commerce:licence")
    if havelicence>0 then --si card presente
      local _,_,_,stackmeta=commerce.found_item_index(player,"commerce:licence")
      if string.find(stackmeta,"commerce")==nil then
        minetest.sound_play("wrong",{to_player=name,gain=1.5})
        return
      end
    else
      minetest.sound_play("wrong",{to_player=name,gain=1.5})
      return
    end

    --initialisation item
    local plname=player:get_player_name()
    chg_form[plname]={}
    local nod_met = minetest.get_meta(pos)
    chg_form[plname].trade=nod_met:get_string("trade")
    local inflation=nod_met:get_int("inflation")
    if inflation==0 then inflation=1 end
    chg_form[plname].inflation=inflation

    local list,vaisseaux=list_vaisseaux(pos,player)
    chg_form[plname].list=list
    chg_form[plname].select=1
    chg_form[plname].vaisseaux=vaisseaux
    chg_form[plname].pos= pos.x ..",".. pos.y ..",".. pos.z
    chg_form[plname].objet_type=1
    chg_form[plname].march_list=""
    for ilist=1,#commerce.item_type do
      chg_form[plname].march_list=chg_form[plname].march_list .. commerce.item_type[ilist]
      if ilist<#commerce.item_type then chg_form[plname].march_list=chg_form[plname].march_list.."," end
    end
    cargo(plname)
    affichage_civilisation(plname)
  end,
	paramtype = "light",
  paramtype2 = "facedir",
	groups = {unbreakable = 1, not_in_creative_inventory = 1},--{cracky = 3},
	sounds = default.node_sound_stone_defaults(),
})

--***********************
--** MISSION TRANSPORT **
--***********************

--**MISSION**
local function affichage_mission(plname)
  local err=0
  local formspec="size[12,11]background[0,0;1,1;commerce_mission.png;true]list[current_player;main;4,7;8,4;]button_exit[0,10;2,1;exit;exit]label[9,0;"..
  plname.."]textlist[0,0;4,1.3;spaceship;".. chg_form[plname].list ..";".. chg_form[plname].select .."]"..
  "button[0.5,6;2,1;mission;mission]button[8.5,6;2,1;delivery;delivery]"

  if chg_form[plname].data~="" then
    local mission=string.split(chg_form[plname].data,"/")
    formspec=formspec.."textlist[0,3;11.75,3;list_mission;"

    for ii=1,#mission do
      local destination=string.split(mission[ii],":")
      local nb=tonumber(destination[2])
      --marchandise
      if destination[1]=="1" then
        formspec= formspec.."TR ".. destination[3].." U of ".. commerce.item_type[nb] ..
        " to Sect.".. tonumber(destination[7])+1 .." in "..destination[5].." Days Price "..destination[4].." Mg"
      --voyager
      elseif destination[1]=="2" then
        formspec=formspec.."TR "..destination[3].." ".. commerce.passenger_type[nb].." to Sect.".. tonumber(destination[7])+1 .." in "..destination[5].." Days Price "..destination[4].." Mg"
      --dig
      elseif destination[1]=="3" then
        formspec=formspec.."DIG "..destination[3].." ".. commerce.dig_node[nb][1] .." to Sect.".. tonumber(destination[7])+1 .." in "..destination[5].." Days Price "..destination[4].." Mg"
      --build
      elseif destination[1]=="4" then
        formspec=formspec.."BLD "..destination[3].." ".. commerce.build_node[nb][1] .." to Sect.".. tonumber(destination[7])+1 .." in "..destination[5].." Days Price "..destination[4].." Mg"
      --radar
      elseif destination[1]=="5" then
        formspec=formspec.."SPY ".. commerce.spy_type[nb][1].." to Sect.".. tonumber(destination[7])+1 .." in "..destination[5].." Days Price "..destination[4].." Mg"
      end

      if ii<#mission then formspec=formspec.."," end
    end

    formspec=formspec..";".. chg_form[plname].mission_n ..";true]"
    err=err+1
  end

  if atm.balance[plname]~= nil then
    formspec=formspec.."label[9,0.5;Bank :]label[9,1;".. atm.balance[plname] .."]"
  end

  if chg_form[plname].vaisseaux~="" then
    formspec=formspec.."label[0,1.5;Cargo ".. chg_form[plname].poids .."/"..
    chg_form[plname].poids_total .."]label[4,1.5;Stock ".. commerce.item_type[chg_form[plname].objet_type] .." "..
    chg_form[plname].marchandise .."]textlist[4.5,0;4,1.3;marchandise;".. chg_form[plname].march_list ..";".. chg_form[plname].objet_type .."]"

    formspec=formspec.."label[9,1.5;Passenger ".. chg_form[plname].passeng_nb .."/"..
    chg_form[plname].passeng_max .."]"
    err=err+1
  end

  if err>1 then
    formspec=formspec.."button[0,9;2,1;accept;accept]"
  end

  return minetest.show_formspec(plname,"commerce#6", formspec)
end

--**DELIVERY**
local function affichage_delivery(plname)
  local formspec="size[12,11]background[0,0;1,1;commerce_delivery.png;true]list[current_player;main;4,7;8,4;]button_exit[0,10;2,1;exit;exit]label[9,0;"..
  plname.."]textlist[0,0;4,1.3;spaceship;".. chg_form[plname].list ..";".. chg_form[plname].select .."]"

  if atm.balance[plname]~= nil then
    formspec=formspec.."label[9,0.5;Bank :]label[9,1;".. atm.balance[plname] .."]"
  end

  if chg_form[plname].vaisseaux~="" then
    formspec=formspec.."label[0,1.5;Cargo ".. chg_form[plname].poids .."/"..
    chg_form[plname].poids_total .."]label[4,1.5;Stock ".. commerce.item_type[chg_form[plname].objet_type] .." "..
    chg_form[plname].marchandise .."]textlist[4.5,0;4,1.3;marchandise;".. chg_form[plname].march_list ..";".. chg_form[plname].objet_type .."]"

    formspec=formspec.."label[9,1.5;Passenger ".. chg_form[plname].passeng_nb .."/"..
    chg_form[plname].passeng_max .."]"

    --list_delivery
    if chg_form[plname].list_delivery~="" then
      local mission=string.split(chg_form[plname].list_delivery,"/")
      local creat_dat=((espace.year-1)*168)+((espace.month-1)*14)+espace.day
      local pos=minetest.string_to_pos("("..chg_form[plname].pos ..")")
      local this_secteur=espace.secteur(pos)

      formspec=formspec.."textlist[0,3;10.75,3;list_delivery;"
      for ii=1,#mission do
        local destination=string.split(mission[ii],":")
        local nb=tonumber(destination[2])
        local days=""
        local arrival=""
        local tmp=tonumber(destination[5])-creat_dat

        if tmp>0 then
          days=" in ".. tmp .." Days"
        else
          days=" Time Elapsed "..tmp
        end
        --test coordo destination
        if tonumber(destination[7])==this_secteur.nb then
          arrival=" to here "
        else
          arrival=" to sect.".. tonumber(destination[7])+1
        end

        if destination[1]=="1" then
          formspec= formspec.. destination[3].." U of ".. commerce.item_type[nb] ..arrival..days.." Price "..destination[4].." Mg"
        elseif destination[1]=="2" then
          formspec=formspec..destination[3].." ".. commerce.passenger_type[nb]..arrival..days.." Price "..destination[4].." Mg"
        end

        if ii<#mission then formspec=formspec.."," end
      end
      formspec=formspec..";".. chg_form[plname].delivery_n ..";true]button[0,9;2,1;accept;accept]"

    end
  end

  formspec=formspec.."button[0.5,6;2,1;mission;mission]button[8.5,6;2,1;delivery;delivery]"

  return minetest.show_formspec(plname,"commerce#6", formspec)
end

--1:marchandise 2:voyageur 3:special dig 4spec build 5:spec reco/ 1-7 marchandise type : quantiter 1-5 voyageur type : quantiter / prix / delai / secteur destination / manutention:radar
local function transport_init(pos)
  local meta=minetest.get_meta(pos)
  local data=meta:get_string("transport")
  local inflation=meta:get_int("inflation")
  if inflation==0 then inflation=1 end
  
  local creat_dat=((espace.year-1)*168)+((espace.month-1)*14)+espace.day
  local data=""
  local n_lig=math.random(3,10)

  for ii=1,n_lig do
    local tmp=math.random(1,50)
    local secteur,bloc=espace.secteur(pos)
    local x,y,z
    --après 1 an de jeu, secteur plus éloigné
    if (creat_dat-339262)>182 then
      x,y,z=math.random(1,11),math.random(1,7),math.random(1,11)
      secteur.x=secteur.x+(x-6)
      secteur.y=secteur.y+(y-4)
      secteur.z=secteur.z+(z-6)
    else
      x,y,z=math.random(1,7),math.random(1,5),math.random(1,7)
      secteur.x=secteur.x+(x-4)
      secteur.y=secteur.y+(y-3)
      secteur.z=secteur.z+(z-4)
    end

    local new_secteur=espace.secteur_by_matrice(secteur)

    --special dig
    if tmp>42 then
      local node=math.random(1,7)
      local quantity=math.random(10,120)
      local delai=math.ceil(math.max(x,y,z)*quantity*0.03)
      local prix=math.ceil(math.random(5,15)*node*delai)*inflation
      local price=quantity*prix
      data=data.."3:".. node ..":".. quantity ..":".. price ..":".. delai ..":".. prix ..":".. new_secteur.nb

    --special build
    elseif tmp>34 then
      local node=math.random(1,7)
      local quantity=math.random(10,120)
      local delai=math.ceil(math.max(x,y,z)*quantity*0.03)
      local prix=math.ceil(math.random(10,30)*node*delai)*inflation
      local price=quantity*prix
      data=data.."4:".. node ..":".. quantity ..":".. price ..":".. delai ..":".. prix ..":"..new_secteur.nb

    --special reconnaissance
    elseif tmp>28 then
      local style=math.random(1,6)
      local quantity=math.random(10,120)
      local delai=math.max(x,y,z)+1
      local prix=math.ceil(math.random(10,30)*style*delai)*inflation
      local price=quantity*prix
      data=data.."5:".. style ..":".. quantity ..":".. price ..":".. delai ..":".. prix ..":"..new_secteur.nb

    --transport marchandise
    elseif tmp>15 then
      local quantity=math.random(250,10000)
      local delai=math.max(x,y,z)
      local prix=math.ceil(math.random(1,25)*delai*0.25)*inflation
      local price=math.ceil(quantity*prix)
      data=data.."1:".. math.random(1,7) ..":".. quantity ..":".. price ..":".. delai ..":".. prix ..":"..new_secteur.nb

    --transport voyageur
    else      
      local passenger=math.random(1,4)
      local quantity=math.random(3,25)
      local delai=math.ceil(math.max(x,y,z)/2)
      local prix=passenger*delai*50*inflation
      local price=quantity*prix
      data=data.."2:".. passenger ..":".. quantity ..":".. price ..":".. delai ..":".. prix ..":"..new_secteur.nb
    end

    if ii<n_lig then data=data.."/" end
  end

  meta:set_int("visit",creat_dat+math.random(10,15))
  meta:set_string("transport",data)
end

minetest.register_node("commerce:guichet_b", {
description = "guichet B",
	tiles = {
		"commerce_guichetd.png",
		"commerce_guichetd.png",
		"commerce_guichetd.png^[transformR90",
		"commerce_guichetd.png^[transformR90",
		"commerce_guichetc.png",
		"commerce_guichetb.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
paramtype2 = "facedir",
use_texture_alpha = true,
groups = {unbreakable = 1, not_in_creative_inventory = 1},--{cracky=3},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.375, -0.0625, 0.5, 0.5, 0.0625}, -- NodeBox1
			{-0.5, -0.5, -0.5, 0.5, -0.375, 0.5}, -- NodeBox2
		}
	},
on_construct=function(pos)
  transport_init(pos)
end,
on_rightclick = function(pos,node,player)
    local havelicence=commerce.found_item_index(player,"commerce:licence")
    local licence=""
    if havelicence>0 then --si card presente
      local _,_,_,stackmeta=commerce.found_item_index(player,"commerce:licence")
      if string.find(stackmeta,"marchandise") then licence=licence.."m" end
      if string.find(stackmeta,"voyageur") then licence=licence.."v" end
      if string.find(stackmeta,"special") then licence=licence.."s" end
      if string.find(stackmeta,"commerce")==nil then
        minetest.sound_play("wrong",{to_player=name,gain=1.5})
        return
      end
    else
      minetest.sound_play("wrong",{to_player=name,gain=1.5})
      return
    end

    --initialisation item
    local new_dat=((espace.year-1)*168)+((espace.month-1)*14)+espace.day
    local meta = minetest.get_meta(pos)
    local old_dat=meta:get_int("visit")
    if new_dat>old_dat then
      transport_init(pos)
    end
    local inv = meta:get_inventory()
    local plname=player:get_player_name()
    local list,vaisseaux=list_vaisseaux(pos,player)
    chg_form[plname]={}
    chg_form[plname].list=list --list vaisseaux
    chg_form[plname].select=1 --selection list vaisseaux
    chg_form[plname].vaisseaux=vaisseaux --vaisseaux selectionner
    chg_form[plname].pos= pos.x ..",".. pos.y ..",".. pos.z
    chg_form[plname].objet_type=1 --index march_list
    chg_form[plname].mission_n=1 --index list_mission
    chg_form[plname].march_list="" --list type d'item
    chg_form[plname].page=1 --page 1=mission 2=delivery
    chg_form[plname].delivery_n=1 --index delivery
    chg_form[plname].list_delivery="" --list delivery
    chg_form[plname].licence=licence
    chg_form[plname].data=meta:get_string("transport")
    for ilist=1,#commerce.item_type do
      chg_form[plname].march_list=chg_form[plname].march_list .. commerce.item_type[ilist]
      if ilist<#commerce.item_type then chg_form[plname].march_list=chg_form[plname].march_list.."," end
    end
    cargo(plname)
    affichage_mission(plname)
  end,
})

--** garage fs **
local function list_player_ship(player)
  local plname=player:get_player_name()
  local vaisseaux=player:get_attribute("vaisseaux")

  if vaisseaux==nil then return 0,"" end

  local list_ship=""
  local nb=0
  local channel=""
  local vaiss_spl=string.split(vaisseaux,":")

  if type(vaiss_spl)=="string" then
    channel=vaiss_spl..":"..plname
    if spacengine.area[channel]==nil then return 0,"" end
    local secteur=espace.secteur(spacengine.area[channel].p0)
    list_ship=vaiss_spl
    nb=1
  else
    nb=#vaiss_spl
    for i=1,nb do
      channel=vaiss_spl[i]..":"..plname
      if spacengine.area[channel]==nil then return 0,"","" end
      local secteur=espace.secteur(spacengine.area[channel].p0)
      list_ship=list_ship.. vaiss_spl[i]
      if i<nb then
        list_ship=list_ship..","
      end
    end
  end

  return nb,list_ship
end

--affichage fs garage

local function affichage_garage(plname)
  local formspec

  if chg_form[plname].select==0 then 

  else
    local idx=chg_form[plname].select
    formspec="size[12,11]button_exit[0,10;2,1;exit;exit]label[9,0;".. plname.."]textlist[0,0;4,1.3;spaceship;".. chg_form[plname].list ..";".. idx .."]"
    
  end

  return minetest.show_formspec(plname,"commerce#8", formspec)
end

minetest.register_node("commerce:garage", {
description = "Garage",
	tiles = {
		"commerce_wrecker.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
  groups = {cracky = 2},
  
  on_place=function(itemstack,placer,pointed_thing)
    local under = pointed_thing.under
    local node = minetest.get_node(under)
    local node_def = minetest.registered_nodes[node.name]

    local pos
    if node_def and node_def.buildable_to then
      pos = under
    else
      pos = pointed_thing.above
    end

    local player_name = placer and placer:get_player_name() or ""

    if espace.bloc_is_protect(pos, placer,5)==true then
      return itemstack
    end

    node_def = minetest.registered_nodes[minetest.get_node(pos).name]
    if not node_def or not node_def.buildable_to then
      return itemstack
    end

    local secteur,bloc=espace.secteur(pos)
    bloc.nb=bloc.nb+1
    if secteur_dat[bloc.nb]==1 or secteur_dat[bloc.nb]==4 or secteur_dat[bloc.nb]==7 or secteur_dat[bloc.nb]==9 then

    minetest.set_node(pos, {name = "commerce:garage"})

    local meta = minetest.get_meta(pos)
    meta:set_string("owner",placer:get_player_name())
    meta:set_string("infotext",placer:get_player_name() .." GARAGE")

    if not (creative and creative.is_enabled_for
        and creative.is_enabled_for(player_name)) then
      itemstack:take_item()
    end

    end

    return itemstack
  end,

  on_rightclick = function(pos,node,player)
    --initialisation item
    local meta = minetest.get_meta(pos)
    if meta:get_string("owner")~=player:get_player_name() then return end
    local inv = meta:get_inventory()
    local plname=player:get_player_name()

    local nb,list=list_player_ship(player)
    chg_form[plname]={}
    chg_form[plname].list=list --list vaisseaux
    chg_form[plname].select=1 --selection list vaisseaux
    --chg_form[plname].vaisseaux=vaisseaux --vaisseaux selectionner
    chg_form[plname].pos= pos.x ..",".. pos.y ..",".. pos.z
    --chg_form[plname].objet_type=1 --index march_list
    --chg_form[plname].mission_n=1 --index list_mission
    --chg_form[plname].march_list="" --list type d'item
    --chg_form[plname].page=1 --page 1=mission 2=delivery
    --chg_form[plname].delivery_n=1 --index delivery
    --chg_form[plname].list_delivery="" --list delivery
    --chg_form[plname].licence=licence
    --chg_form[plname].data=meta:get_string("transport")
    affichage_garage(plname)
--]]    
  end,
  can_dig=function(pos,player)
    local meta = minetest.get_meta(pos)
    if meta:get_string("owner")==player:get_player_name() then return true end
    return false
  end
})

--************
--** FIELDS **
--************
minetest.register_on_player_receive_fields(function(player, formname, fields)
  if string.find(formname,"commerce") then
    commerce_n=string.split(formname,"#")
    local plname=player:get_player_name()

    if fields.spaceship then
      if string.find(fields.spaceship,"CHG:") then
        chg_form[plname].select=string.gsub(fields.spaceship,"CHG:","")
        
        local nb=tonumber(chg_form[plname].select)
        local split=string.split(chg_form[plname].list,",")

        if commerce_n[2]~="8" then
        if split[nb]~="No channel" then
          local channel=split[nb]..":"..plname
          chg_form[plname].vaisseaux=split[nb]
          chg_form[plname].poids_total=spacengine.area[channel].config[9][1]
          chg_form[plname].poids=spacengine.area[channel].config[9][2]
            cargo(plname)

        else
          chg_form[plname].vaisseaux=""
          chg_form[plname].poids_total=0
          chg_form[plname].poids=0
        end
        end
        
      end
    end

    if commerce_n[2]=="3" or commerce_n[2]=="4" then

      if fields.marchandise then
        if string.find(fields.marchandise,"CHG:") then
          local nb=string.gsub(fields.marchandise,"CHG:","")
          chg_form[plname].objet_type= tonumber(nb)
          chg_form[plname].objet_idx=1

          if chg_form[plname].vaisseaux~="" then
            cargo(plname)
            item_list(plname)
          end
        end
      end

      if fields.item then --transfert item to marchandise
        if chg_form[plname].vaisseaux=="" then
          return
        end

        if chg_form[plname].objet_type==0 then
          return
        end

        local havelicence=commerce.found_item_index(player,"commerce:licence")
        local _,_,_,stackmeta=commerce.found_item_index(player,"commerce:licence")
        if string.find(stackmeta,"commerce")==nil then return end

        local total=chg_form[plname].poids+chg_form[plname].quantity

        if chg_form[plname].poids_total > total then

          if commerce.transaction(player,nil, 0-chg_form[plname].price) then
            local channel=chg_form[plname].vaisseaux ..":".. plname
            local nb=chg_form[plname].objet_type
            spacengine.area[channel].config[9][2]=total
            spacengine.area[channel].config[9][3][nb]=spacengine.area[channel].config[9][3][nb]+chg_form[plname].quantity
            chg_form[plname].poids=spacengine.area[channel].config[9][2]
            chg_form[plname].price=0
            chg_form[plname].quantity=0
            chg_form[plname].objet_type=0
            local cpos=spacengine.area[channel].p0
            local cont_met = minetest.get_meta(spacengine.area[channel].p0)
            cont_met:set_string("config",spacengine.compact(spacengine.area[channel].config))

            local split=string.split(chg_form[plname].pos,",")
            local pos={x=split[1],y=split[2],z=split[3]}
            local meta = minetest.get_meta(pos)
            local inv = meta:get_inventory()
            inv:set_stack("src",1,"")
          end
        end
      end

      if fields.objet then --choix item
        if string.find(fields.objet,"CHG:") then
          local nb=string.gsub(fields.objet,"CHG:","")
          chg_form[plname].objet_idx=tonumber(nb)
        end
      end

      if fields.transfert then --transfert marchandise to item
        local nb=chg_form[plname].objet_idx
        local split=string.split(chg_form[plname].list_item,",")

        local stack=string.split(split[nb]," ")

        local inv = player:get_inventory()

        local total=chg_form[plname].marchandise-1

        if not cargaison_protect(plname,1,"s") then
        if total>-1 then
          if inv:room_for_item("main",stack[1]) then

            local havelicence=commerce.found_item_index(player,"commerce:licence")
            local _,_,_,stackmeta=commerce.found_item_index(player,"commerce:licence")
            if string.find(stackmeta,"commerce")==nil then return end

            if commerce.transaction(player,stack[1], stack[2]) then
            local channel=chg_form[plname].vaisseaux ..":".. plname
            nb=chg_form[plname].objet_type
            spacengine.area[channel].config[9][2]=spacengine.area[channel].config[9][2]-1
            spacengine.area[channel].config[9][3][nb]=total
            local cpos=spacengine.area[channel].p0
            local cont_met = minetest.get_meta(spacengine.area[channel].p0)
            cont_met:set_string("config",spacengine.compact(spacengine.area[channel].config))
            cargo(plname)
            end
          end
        end
        end
      end

    elseif commerce_n[2]=="1" or commerce_n[2]=="2" then

      if fields.objet then
        local index=tonumber(fields.objet)
        local money=chg_form[plname][index][2].." "..chg_form[plname][index][3]

        if commerce_n[2]=="2" then
          magasin_transaction(player,chg_form[plname][index][1],money,1,chg_form[plname][index][4])
        else
          magasin_transaction(player,chg_form[plname][index][1],money,1)
        end
      end

    elseif commerce_n[2]=="5" then

      if fields.marchandise then
        if string.find(fields.marchandise,"CHG:") then
          local nb=string.gsub(fields.marchandise,"CHG:","")
          chg_form[plname].objet_type= tonumber(nb)
          chg_form[plname].objet_idx=1

          if chg_form[plname].vaisseaux~="" then
            cargo(plname)
          end
        end
      end

      if chg_form[plname].vaisseaux~="" then
        --local xp=espace.xpgetlvl(player,"force")+1
        local trade_spl=string.split(chg_form[plname].trade,"/")
        local channel=chg_form[plname].vaisseaux ..":".. plname
        local nb=chg_form[plname].objet_type*2
        local total=0

        if fields.inc1 then
          if ((chg_form[plname].poids+1)<=spacengine.area[channel].config[9][1]) and (trade_spl[nb-1]-(1*chg_form[plname].inflation))>-1 then
            total=1
          end
        end

        if fields.inc10 then
          if (chg_form[plname].poids+10)<spacengine.area[channel].config[9][1] and (trade_spl[nb-1]-(10*chg_form[plname].inflation))>-1 then
            total=10
          end
        end

        if fields.dec1 then
          if not cargaison_protect(plname,1,"s") then
          if (spacengine.area[channel].config[9][3][chg_form[plname].objet_type]-1)>-1 and (trade_spl[16]-(trade_spl[nb]*chg_form[plname].inflation))>-1 then
            total=-1
          end
          end
        end

        if fields.dec10 then
          if not cargaison_protect(plname,10,"s") then
          if (spacengine.area[channel].config[9][3][chg_form[plname].objet_type]-10)>-1 and (trade_spl[16]-(trade_spl[nb]*10*chg_form[plname].inflation))>-1 then
            total=-10
          end
          end
        end

        if total~=0 then
          if commerce.transaction(player,nil, trade_spl[nb]*total*chg_form[plname].inflation) then
            spacengine.area[channel].config[9][2]=chg_form[plname].poids+total
            spacengine.area[channel].config[9][3][chg_form[plname].objet_type] = spacengine.area[channel].config[9][3][chg_form[plname].objet_type]+total
            trade_spl[nb-1]=trade_spl[nb-1]-total

            trade_spl[16]=trade_spl[16]+(trade_spl[nb]*total*chg_form[plname].inflation)
            --sauvegarde
            local cpos=spacengine.area[channel].p0
            local cont_met = minetest.get_meta(spacengine.area[channel].p0)
            cont_met:set_string("config",spacengine.compact(spacengine.area[channel].config))
            local split=string.split(chg_form[plname].pos,",")
            local pos={x=split[1],y=split[2],z=split[3]}
            local nod_met = minetest.get_meta(pos)
            chg_form[plname].trade=""
            for ii=1,#trade_spl do
              chg_form[plname].trade=chg_form[plname].trade ..trade_spl[ii]
              if ii<#trade_spl then chg_form[plname].trade=chg_form[plname].trade .."/" end
            end

            nod_met:set_string("trade",chg_form[plname].trade)
            cargo(plname)
          end
        end

      end

    --** MISSION **
    elseif commerce_n[2]=="6" then

      if fields.marchandise then
        if string.find(fields.marchandise,"CHG:") then
          local nb=string.gsub(fields.marchandise,"CHG:","")
          chg_form[plname].objet_type= tonumber(nb)

          if chg_form[plname].vaisseaux~="" then
            cargo(plname)
          end
        end
      end

      if fields.delivery then
        chg_form[plname].page=2
      end

      if fields.mission then
        chg_form[plname].page=1
      end

      if fields.list_mission then
        if string.find(fields.list_mission,"CHG:") then
          local nb=string.gsub(fields.list_mission,"CHG:","")
          chg_form[plname].mission_n= tonumber(nb)
        end
      end

      if fields.list_delivery then
        if string.find(fields.list_delivery,"CHG:") then
          local nb=string.gsub(fields.list_delivery,"CHG:","")
          chg_form[plname].delivery_n= tonumber(nb)
        end
      end

      if fields.accept then
        if chg_form[plname].page==1 then
          -- recupere position controler
          local channel=chg_form[plname].vaisseaux ..":".. plname
          local cpos=spacengine.area[channel].p0
          local cont_met=minetest.get_meta(cpos)
          --recupere meta delivery
          chg_form[plname].list_delivery=cont_met:get_string("delivery")
          local delivery={}

          if chg_form[plname].list_delivery~="" then
            delivery=string.split(chg_form[plname].list_delivery,"/")
          end

          if #delivery<7 then
            local mission=string.split(chg_form[plname].data,"/")
            local creat_dat=((espace.year-1)*168)+((espace.month-1)*14)+espace.day
            local err=false
            local destination=string.split(mission[chg_form[plname].mission_n],":")

            --marchandise
            if destination[1]=="1" then

              if string.find(chg_form[plname].licence,"m")==nil then err=true end

              local calcul=chg_form[plname].poids+tonumber(destination[3])

              if calcul>(chg_form[plname].poids_total+1) then
                err=true
              else
                if err==false then
                  spacengine.area[channel].config[9][3][tonumber(destination[2])]=spacengine.area[channel].config[9][3][tonumber(destination[2])]+tonumber(destination[3])
                  spacengine.area[channel].config[9][2]=calcul
                end
              end

            --voyager
            elseif destination[1]=="2" then

              if string.find(chg_form[plname].licence,"v")==nil then err=true end

              local calcul=chg_form[plname].passeng_nb+tonumber(destination[3])

              if calcul>(chg_form[plname].passeng_max+1) then
                err=true
              else
                if err==false then
                  local tmp=tonumber(destination[2])+1
                  spacengine.area[channel].config[10][3][tmp]=spacengine.area[channel].config[9][3][tmp]+tonumber(destination[3])
                  spacengine.area[channel].config[10][2]=calcul
                end
              end

            --dig or build
            elseif destination[1]=="3" or destination[1]=="4" then
                
              if string.find(chg_form[plname].licence,"s")==nil then err=true end

              if err==false then
                local idx_manut=1+#spacengine.area[channel].config[13][5]
                local idx=tonumber(destination[2])

                if destination[1]=="3" then
                  spacengine.area[channel].config[13][5][idx_manut]=commerce.dig_node[idx][2]..destination[2] ..destination[7]
                  destination[8]="D"..destination[2] ..destination[7]
                else
                  spacengine.area[channel].config[13][5][idx_manut]=commerce.build_node[idx][2]..destination[2] ..destination[7]
                  destination[8]="B"..destination[2] ..destination[7]
                end
              end

            --radar
            elseif destination[1]=="5" then
                
              if string.find(chg_form[plname].licence,"s")==nil then err=true end

              if err==false then
                local idx=tonumber(destination[2])
                local idx_radar=1+#spacengine.area[channel].config[7][4]
                spacengine.area[channel].config[7][4][idx_radar] = commerce.spy_type[idx][2] ..":none:".. destination[2] .. destination[7]
                destination[8]=destination[2] ..destination[7]
                spacengine.area[channel].config[7][5][idx_radar]=0
              end
            
          end

          if err==false then
            local nb=tonumber(destination[2])
            local new_dat=tonumber(destination[5])+creat_dat
            destination[5]=new_dat
            local phr=""

            for ii=1,#mission do
              if ii~=chg_form[plname].mission_n then
                phr=phr..mission[ii]
                if ii<#mission then phr=phr.."/" end
              end
            end

            local pos=minetest.string_to_pos("("..chg_form[plname].pos ..")")
            local nod_met=minetest.get_meta(pos)
            chg_form[plname].data=phr
            nod_met:set_string("transport",phr)

            phr=""
            for ii=1,#destination do
              phr=phr..destination[ii]
              if ii<#destination then phr=phr..":" end
            end

            if delivery==0 then
              cont_met:set_string("delivery",phr)
            else

              chg_form[plname].list_delivery=chg_form[plname].list_delivery.."/"..phr
              cont_met:set_string("delivery",chg_form[plname].list_delivery)
            end

            cont_met:set_string("config",spacengine.compact(spacengine.area[channel].config))
            chg_form[plname].mission_n=1
            cargo(plname)
          end

        else
            --sound error nb delivery>6
--minetest.chat_send_all("error")
        end
      

      elseif chg_form[plname].page==2 then
          --recupere data controler
          local mission=string.split(chg_form[plname].list_delivery,"/")
          local creat_dat=((espace.year-1)*168)+((espace.month-1)*14)+espace.day
          local pos=minetest.string_to_pos("("..chg_form[plname].pos ..")")
          local this_sector=espace.secteur(pos)
          local destination=string.split(mission[chg_form[plname].delivery_n],":")
          
          --teste si bon secteur
          if tonumber(destination[7])==this_sector.nb then  
            local new_dat=tonumber(destination[5])-creat_dat
            local bonus=0

            local channel=chg_form[plname].vaisseaux ..":".. plname
            local somme=0

            if destination[1]=="0" then
              spacengine.area[channel].config[9][3][tonumber(destination[2])]=math.max(0,spacengine.area[channel].config[9][3][tonumber(destination[2])]-tonumber(destination[3]))
              somme=spacengine.area[channel].config[9][2]-tonumber(destination[3])
              if somme>-1 then
                somme=tonumber(destination[3])
              else
                somme=tonumber(destination[3])+somme
              end
              spacengine.area[channel].config[9][2]=math.max(0,somme)
            else
              local tmp=tonumber(destination[2])+1
              spacengine.area[channel].config[10][3][tmp]=math.max(0,spacengine.area[channel].config[9][3][tmp]-tonumber(destination[3]))
              somme=spacengine.area[channel].config[10][2]-tonumber(destination[3])
              if somme>-1 then
                somme=tonumber(destination[3])
              else
                somme=tonumber(destination[3])+somme
              end
              spacengine.area[channel].config[10][2]=math.max(0,somme)
            end

            if new_dat>0 then
              if new_dat>math.ceil(tonumber(destination[5])*0.75) then
                --bonus
                bonus=(somme*tonumber(destination[6]))*0.25
              end
              bonus=bonus+(somme*tonumber(destination[6]))
            else
              --penaliter
              bonus=math.floor((somme*tonumber(destination[6])*0.5)-(math.abs(new_dat)*(somme*tonumber(destination[6])*0.25)))
            end

            atm.balance[plname]=math.max(0,atm.balance[plname]+bonus)
            atm.saveaccounts()

            local phr=""
            for ii=1,#mission do
              if ii~=chg_form[plname].delivery_n then
                phr=phr..mission[ii]
                if ii<#mission then phr=phr.."/" end
              end
            end

            local channel=chg_form[plname].vaisseaux ..":".. plname
            local cpos=spacengine.area[channel].p0
            local cont_met=minetest.get_meta(cpos)
            cont_met:set_string("delivery",phr)
            cont_met:set_string("config",spacengine.compact(spacengine.area[channel].config))
            chg_form[plname].list_delivery=phr
            chg_form[plname].delivery_n=1
            cargo(plname)
          end
        end
      end
    elseif commerce_n[2]=="8" then
      if fields.spaceship then
        local field_spl=string.split(fields.spaceship,":")
        if string.find(field_spl[1],"DCL") then
        end
      end
    end

    if fields.quit then
      chg_form[plname]=nil
    end

    if not fields.quit then
      if commerce_n[2]=="3" then
        return affichage_item(plname)
      elseif commerce_n[2]=="4" then
        return affichage_marchandise(plname)
      elseif commerce_n[2]=="5" then
        return affichage_civilisation(plname)
      elseif commerce_n[2]=="6" then
        if chg_form[plname].page==1 then
          return affichage_mission(plname)
        else
          return affichage_delivery(plname)
        end
      elseif commerce_n[2]=="8" then
        return affichage_garage(plname)
      end
    end
  end
end)
