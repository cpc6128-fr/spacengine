
-- mob spawner
--chance name lightmin lightmax nbmax air
--air:(0)all (1)air (2)vacuum (3)water  choix multiple possible 13 or 12...
espace.spawner = "50 mobs_npc:npc 1 15 2 1/15 mobs_animal:kitten 1 10 1 1/5 scifi_mobs:r2 0 15 1 12"

minetest.register_node(":mobs:spawner2", {
	tiles = {"mobs_spawn.png"},
	drawtype = "nodebox",
  node_box = {
		type = "fixed",
    fixed = {-0.5,-0.5,-0.5,0.5,-0.45,0.5},
		},
  use_texture_alpha = true,
	paramtype = "light",
  light_source = 4,
	walkable = true,
	description = "Mob Spawner",
	groups = {dig_immediate = 2, not_in_creative_inventory=1, unbreakable = 1},

})

if minetest.get_modpath("mobs") then

local max_per_block = tonumber(minetest.setting_get("max_objects_per_block") or 99)

-- spawner abm
minetest.register_abm({
	label = "Mob spawner node2",
	nodenames = {"mobs:spawner2"},
	interval = 60,--30
	chance = 1,--4
	catch_up = false,

	action = function(pos, node, active_object_count, active_object_count_wider)

		-- return if too many entities already
		if active_object_count_wider >= max_per_block then
			return
		end
  
    local moblist = string.split(espace.spawner,"/")

    for i=1,#moblist do
      local err=0
      local comm=string.split(moblist[i]," ")
      -- get settings from command
      local rnd=tonumber(comm[1])
      local mob = comm[2]
      local mlig = tonumber(comm[3])
      local xlig = tonumber(comm[4])
      local num = tonumber(comm[5])
      local air = comm[6]

      -- if amount is 0 then do nothing
      if num == 0 then
        err=1
      end

      --   are we spawning a registered mob?
      if not mobs.spawning_mobs[mob] then
        --print ("--- mob doesn't exist", mob)
        err=1
      end

      if math.random(1,1000)>rnd then
        err=1
      end

      if err==0 then
      -- check objects inside 9x9 area around spawner
      local objs = minetest.get_objects_inside_radius(pos, 9)
      local count = 0
      local ent = nil

      -- count mob objects of same type in area
      for k, obj in ipairs(objs) do

        ent = obj:get_luaentity()

        if ent and ent.name and ent.name == mob then
          count = count + 1
        end
      end

      -- is there too many of same type?
      if count >= num then
        return
      end


      -- find air blocks

      local pos2 = {x = pos.x , y = pos.y + 1, z = pos.z }
			local lig = minetest.get_node_light(pos2) or 0
  
      local  nodair = minetest.get_node(pos2)

			if nodair.name=="ignore" then break end

      if air~="0" then
        err=1
        if string.find(air,"1") and (nodair.name=="air" or nodair.name=="espace:air") then err=0 end
        if string.find(air,"2") and nodair.name=="vacuum:vacuum" then err=err+1 end
        if string.find(air,"3") and minetest.get_item_group(nodair.name,"water")~=0 then err=err+1 end
      end
			-- only if light levels are within range
			if lig >= mlig and lig <= xlig and minetest.registered_entities[mob] and err==0 then
				minetest.add_entity(pos2, mob)
        break
			end
		--end

    end
  end
  end
})

end
