--** FX system **
--[[
fxbase=stockage fx de base
fxlist=fx temporaire

fxlist[playername]={fxname,fxtime,fxspeed,fxjump,fxgravity,priority,fxdisable}

fxadd  (player,fxname,fxtime,fxspeed,fxjump,fxgravity) --> x = -9..0..9 speed+x
 > x>9 set fx x/100  ex:speed=-0.2 decremente de 0.2 le speed / si speed=5500 set a 5.5 le speed

    fxtime =-2 permanent / =0 durer determiner de 1.5 seconde / =1-99 time constant / >99 add time

fxremove (player,fxname) --si remov_all enleve tout les effet (sauf armor)
fxdisable (player,fxname) --disable l'effet
fxenable (player,fxname) --le contraire de disable

TODO priority first in list, last
snow prioritaire
--]]

espace.fx={}

--** magic sound **
local function fxsound()
  minetest.sound_play("magic", {to_player = name})
end

--*************
--** init fx **
--*************
minetest.register_on_joinplayer(function(player)

    local name=nil
    if not player or player.is_fake_player then
        return name
    end
   
	name = player:get_player_name()
   
	if espace.fx[name] == nil then
		espace.fx[name] = {base={1,1,1},snow={0,0,0},armor={1,1,1},list={}}
	end
end)

--**********

minetest.register_on_leaveplayer(function(player)
   local name = player:get_player_name()
   espace.fx[name]=nil  
end)

--************************
--** test fx and change **   
fxtest=function(player)  --test chaque fx temp
   
  local name=player:get_player_name()

  if name==nil then return end

  if default.player_attached[name] then return end

  local nbfx=#espace.fx[name].list
  local fxspeed=espace.fx[name].base[1]
  local fxjump=espace.fx[name].base[2]
  local fxgravity=espace.fx[name].base[3]

  fxspeed=fxspeed + espace.fx[name].snow[1] + espace.fx[name].armor[1]
  fxjump=fxjump+espace.fx[name].armor[2]
  fxgravity=fxgravity+espace.fx[name].armor[3]

  if nbfx>0 then   --fx present
    local nb=1

    repeat
      local fxtemp=fxlist[name][nb]
      local fxtime=fxtemp[2]

      if fxtemp[6]==false then --fx disable

        if fxtemp[3]<10 then
          fxspeed=fxspeed+fxtemp[3]
        else
          fxspeed=fxtemp[3]/1000
        end

        if fxtemp[4]<10 then
          fxjump=fxjump+fxtemp[4]
        else
          fxjump=fxtemp[4]/1000
        end

        if fxtemp[5]<10 then
          fxgravity=fxgravity+fxtemp[5]
        else
          fxgravity=fxtemp[5]/1000
        end

        fxspeed=math.max(0,fxspeed)
        fxjump=math.max(0,fxjump)
        fxgravity=math.max(0,fxgravity)

        if fxtime>0 then
          fxtime=fxtime-1
        end

        fxlist[name][nb][2]=fxtime

        if fxtime==0 then --remove fx
          if fxlist[name][nb][1]=="fly" then
            local privs = minetest.get_player_privs(name)
            privs.fly = nil			-- revoke priv
            minetest.set_player_privs(name, privs)
          end
          table.remove(fxlist[name],nb)
          nb=nb-1
        end
      end

      nb=nb+1
      nbfx=nbfx-1
    until nbfx<1

   end
  
   player:set_physics_override({
		speed = fxspeed,
		jump = fxjump,
		gravity = fxgravity
	})

end
   
--*****************
--** set fx base **   
fxset=function(player,fxname,fxspeed,fxjump,fxgravity)--,fxsneak,fxsneak_glitch)  --fx de base (terre, moon, espace...)
   local name=player:get_player_name()
   if name==nil then return end
                 
   fxbase[name]={fxname,fxspeed,fxjump,fxgravity}--,fxsneak,fxsneak_glitch}
   
   player:set_physics_override({speed=fxspeed,jump=fxjump,gravity=fxgravity})--,sneak=fxsneak,sneak_glitch=fxsneak_glitch})
   
end
   
--****************
--** add new fx **
fxadd=function(player,fxname,fxtime,fxspeed,fxjump,fxgravity,priority,disable)  --fx temporaire (potion, sprint...)
   
    local name=player:get_player_name()
   
    if name==nil then return end
   
    if fxspeed==nil then fxspeed=0 end
    if fxjump==nil then fxjump=0 end
    if fxgravity==nil then fxgravity=0 end
    if fxtime==nil then fxtime=0 end
    if disable==nil then disable=false end
    if priority==nil then priority=0 end

    local special=false

    if priority>9 then
      priority=priority-10
      special=true
    end

    local fxtemp
   
    local nb=1
    local nbfx=#fxlist[name]
   
    if nbfx>0 then
        
        repeat 
        
            if fxname==fxlist[name][nb][1] then
              fxtemp=fxlist[name][nb]
              nbfx=0
            else
              nb=nb+1
              nbfx=nbfx-1
            end
        until nbfx<1
    end
   
    if fxtemp==nil then
      if fxname=="snow" then
        table.insert(fxlist[name],1,{fxname,0,0,0,0,false})
        nb=1
      else
        if priority>0 then
          priority=math.max(#fxlist[name],priority+1)
          table.insert(fxlist[name],priority,{fxname,0,0,0,0,false})
        else
          table.insert(fxlist[name],{fxname,0,0,0,0,false})
        end
      end
      fxtemp={fxname,0,0,0,0,false}
    end
   
    if special==false then
    if fxspeed<10 then
        fxspeed=fxspeed+fxtemp[3]
    end
   
    if fxjump<10 then
        fxjump=fxjump+fxtemp[4]
    end
    
    if fxgravity<10 then
        fxgravity=fxgravity+fxtemp[5]
    end
    
    if fxtime==0 then
      fxtime=3
    end

    end

    if fxtime>99 then
      fxtime=(fxtime/100)+fxtemp[2]
    end

   fxlist[name][nb]={fxname,fxtime,fxspeed,fxjump,fxgravity,disable}

   fxtest(player)
end
   
--************
--** remove **
fxremove=function(player,fxname)  --remove fx temporaire
   
    local name=player:get_player_name()
   
    if name==nil then return end
   
    local nb=1
    local nbfx=#fxlist[name]
    
    if nbfx==0 then return end

    if fxname=="remov_all" then
      repeat 
        if fxlist[name][nb][1]~="armor" then --compatible 3d armor
            table.remove(fxlist[name],nb)
        end
        nb=nb+1
        nbfx=nbfx-1
      until nbfx<1
    else

    repeat 
        if fxname==fxlist[name][nb][1] then
            table.remove(fxlist[name],nb)
            nbfx=0
        end
        nb=nb+1
        nbfx=nbfx-1
    until nbfx<1

   end

    fxtest(player)
end

--** disable **
fxdisable=function(player,fxname)  --disable fx
   
    local name=player:get_player_name()
   
    if name==nil then return end
   
    local nb=1
    local nbfx=#fxlist[name]
    
    if nbfx==0 then return end

    repeat 
        if fxname==fxlist[name][nb][1] then
            fxlist[name][nb][6]=true
            nbfx=0
        end
        nb=nb+1
        nbfx=nbfx-1
    until nbfx<1


    fxtest(player)
end

--** enable **
fxenable=function(player,fxname)  --enable fx
   
    local name=player:get_player_name()
   
    if name==nil then return end
   
    local nb=1
    local nbfx=#fxlist[name]
    
    if nbfx==0 then return end

    repeat 
        if fxname==fxlist[name][nb][1] then
            fxlist[name][nb][6]=false
            nbfx=0
        end
        nb=nb+1
        nbfx=nbfx-1
    until nbfx<1


    fxtest(player)
end

--************
--** potion **
--************
minetest.register_node("espace:mushroom_pot", {
	description = "champignon secher",
	drawtype = "plantlike",
	tiles = {"witchcraft_mud_bottle.png"},
	inventory_image = "witchcraft_mud_bottle.png",
	wield_image = "witchcraft_mud_bottle.png",
	paramtype = "light",
	is_ground_content = false,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.25, -0.5, -0.25, 0.25, 0.4, 0.25}
	},
	groups = {vessel=1,dig_immediate=3,attached_node=1, flammable = 1},
	sounds = default.node_sound_glass_defaults(),
})

minetest.register_craft({
	type = "cooking",
	cooktime = 15,
	output = "espace:mushroom_pot",
	recipe = "flowers:mushroom_brown"
})

minetest.register_craft({
	type = "cooking",
	cooktime = 15,
	output = "espace:mushroom_pot 2",
	recipe = "flowers:mushroom_red"
})

minetest.register_craftitem("espace:hp1", {
	description = "HP +1",
	inventory_image = "espace_hp1.png",
	on_use = function(itemstack, player)
  local nb = itemstack:get_count()
	local health = player:get_hp();
  fxsound()
	player:set_hp(health+2)
  nb=nb-1
  if nb>0 then
    itemstack:set_count(nb)
  else
    itemstack:replace("")
  end
  return itemstack
	end,
	groups = {flammable = 2},
})

minetest.register_craft({
	type = "shapeless",
	output = "espace:hp1",
	recipe = {"espace:mushroom_pot", "espace:mushroom_pot", "farming:wheat"}
})

minetest.register_craftitem("espace:hp5", {
	description = "HP +5",
	inventory_image = "espace_hp5.png",
	on_use = function(itemstack, player)
  local nb = itemstack:get_count()
	local health = player:get_hp();
  fxsound()
	player:set_hp(health+10)
  nb=nb-1
  if nb>0 then
    itemstack:set_count(nb)
  else
    itemstack:replace("")
  end
  return itemstack
	end,
	groups = {flammable = 2},
})

minetest.register_craft({
	type = "shapeless",
	output = "espace:hp5",
	recipe = {"espace:mushroom_pot", "espace:coral_dust", "farming:wheat"}
})

minetest.register_node("espace:coral_dust", {
	description = "coral dust",
	drawtype = "plantlike",
	tiles = {"espace_bocal_coral.png"},
	inventory_image = "espace_bocal_coral.png",
	wield_image = "espace_bocal_coral.png",
	paramtype = "light",
	is_ground_content = false,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.25, -0.5, -0.25, 0.25, 0.4, 0.25}
	},
	groups = {vessel=1,dig_immediate=3,attached_node=1, flammable = 1},
	sounds = default.node_sound_glass_defaults(),
})

minetest.register_craftitem("espace:speed", {
	description = "speed ++",
	inventory_image = "witchcraft_potion_brown.png",
	on_use = function(itemstack, player)
    minetest.chat_send_player(player:get_player_name(),"FX Speed+")
    local nb = itemstack:get_count()
    fxsound()
    fxadd(player,"speed",500,2000,0,0) --speed constant *1.5 / rajoute du temps 5s au decompte initial a chaque utilisation
  nb=nb-1
  if nb>0 then
    itemstack:set_count(nb)
  else
    itemstack:replace("")
  end
  return itemstack
	end,
	groups = {flammable = 2},
})

minetest.register_craft({
	type = "shapeless",
	output = "espace:speed",
	recipe = {"", "espace:mushroom_pot", ""}
})

minetest.register_craftitem("espace:jump", {
	description = "jump ++",
	inventory_image = "witchcraft_potion_darkpurple.png",
	on_use = function(itemstack, player)
    minetest.chat_send_player(player:get_player_name(),"FX Jump+")
    local nb = itemstack:get_count()
    fxsound()
    fxadd(player,"jump",300,0,2000,0)
  nb=nb-1
  if nb>0 then
    itemstack:set_count(nb)
  else
    itemstack:replace("")
  end
  return itemstack
	end,
	groups = {flammable = 2},
})
--
minetest.register_craftitem("espace:panic", {
	description = "panic",
	inventory_image = "witchcraft_potion_gred.png",
	on_use = function(itemstack, player)
    minetest.chat_send_player(player:get_player_name(),"FX Panic")
    local nb = itemstack:get_count()
    fxsound()
    fxadd(player,"panic",5,0.2,0.2,500)
  nb=nb-1
  if nb>0 then
    itemstack:set_count(nb)
  else
    itemstack:replace("")
  end
  return itemstack
	end,
	groups = {flammable = 2},
})
--[[
minetest.register_craftitem("espace:slow_off", {
	description = "stop slow",
	inventory_image = "witchcraft_potion_green2.png",
	on_use = function(itemstack, player)
    minetest.chat_send_player(player:get_player_name(),"Stop FX Slow")
    local nb = itemstack:get_count()
    fxremove(player,"slow")
  nb=nb-1
  if nb>0 then
    itemstack:set_count(nb)
  else
    itemstack:replace("")
  end
  return itemstack
	end,
	groups = {flammable = 2},
})
--]]
minetest.register_craftitem("espace:gravity", {
	description = "anti-gravity",
	inventory_image = "witchcraft_potion_blue2.png",
	on_use = function(itemstack, player)
    minetest.chat_send_player(player:get_player_name(),"FX Gravity-")
    local nb = itemstack:get_count()
    fxsound()
    fxadd(player,"gravity",12,0,0,-0.2) --temps constant 20s / diminution gravity -0.2 a chaque utilisation
  nb=nb-1
  if nb>0 then
    itemstack:set_count(nb)
  else
    itemstack:replace("")
  end
  return itemstack
	end,
	groups = {flammable = 2},
})

minetest.register_craftitem("espace:fly", {
	description = "Fly Privs",
	inventory_image = "witchcraft_potion_green2.png",
	on_use = function(itemstack, player)
    local name=player:get_player_name()
    minetest.chat_send_player(name,"Grant Fly")
    local nb = itemstack:get_count()
    fxsound()
    fxadd(player,"fly",20,0,0,0)
    local privs = minetest.get_player_privs(name)
    privs.fly = true
    minetest.set_player_privs(name, privs)
  nb=nb-1
  if nb>0 then
    itemstack:set_count(nb)
  else
    itemstack:replace("")
  end
  return itemstack
	end,
	groups = {flammable = 2},
})
