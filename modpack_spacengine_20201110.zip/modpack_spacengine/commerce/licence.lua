--
-- ** GUICHET FEDERATION GALACTIQUE **
--** LICENCE **

local licence_formspec="size[8,9]background[0,0;1,1;commerce_licence_bg.png;true]"..
        "button[0,0;1,1;exploitation;250]label[1,0.25;EXPLOITATION]"..
        "button[0,1;1,1;commerce;500]label[1,1.25;COMMERCE]"..
        "button[0,2;1,1;marchandise;1500]label[1,2.25;MARCHANDISE]"..
        "button[0,3;1,1;voyageur;10000]label[1,3.25;VOYAGEUR]"..
        "button[0,4;1,1;special;20000]label[1,4.25;SPECIAL]"..
        "item_image_button[4.5,2;1,1;commerce:licence;card;500]"..
        "button_exit[6.4,3.5;1.5,1;exit;exit]"..
        "list[current_player;main;0,5;8,4;]"

minetest.register_node("commerce:guichet_a", {
description = "guichet A",
	tiles = {
		"commerce_guichetd.png",
		"commerce_guichetd.png",
		"commerce_guichetd.png^[transformR90",
		"commerce_guichetd.png^[transformR90",
		"commerce_guichetc.png",
		"commerce_guicheta.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
paramtype2 = "facedir",
use_texture_alpha = true,
groups = {unbreakable = 1, not_in_creative_inventory = 1},--{cracky=3},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.375, -0.0625, 0.5, 0.5, 0.0625}, -- NodeBox1
			{-0.5, -0.5, -0.5, 0.5, -0.375, 0.5}, -- NodeBox2
		}
	},
on_construct = function(pos)
    local meta = minetest.get_meta(pos)
    local inv = meta:get_inventory()
    meta:set_string("formspec", licence_formspec )
  end,

--TODO "License : 2019/02/15 : commerce : exploitation" insertion date

on_receive_fields=function(pos,formname,fields,sender)
  local err=0
  local name = sender:get_player_name()
  local inv = sender:get_inventory()
  local meta = minetest.get_meta(pos)
  local stack={name="commerce:card",count=1}
  local index=0
  local price=0
  local licence=""
  local account=0
  local stackmeta
  local formspec_tmp=""
  if inv:contains_item("main",stack) then
    if fields.exploitation~=nil then
      price=250
      licence="exploitation"
    elseif fields.marchandise~=nil then
      price=1500
      licence="marchandise"
    elseif fields.commerce~=nil then
      price=500
      licence="commerce"
    elseif fields.voyageur~=nil then
      price=10000
      licence="voyageur"
    elseif fields.special~=nil then
      price=20000
      licence="special"
    elseif fields.card~=nil then
      price=500
      licence="card"
    end
    if licence~="" then
      
      if not (atm.balance[name] == nil) then
        account=atm.balance[name]
      end
      if account-price>0 then
        index,_,_,stackmeta=commerce.found_item_index(sender,"commerce:licence")
        if licence~="card" then
          --test licence
          stack={name="commerce:licence",count=1}
          if inv:contains_item("main",stack) then
            if stackmeta=="" then
              stackmeta="licence:00"
            end
            if string.find(stackmeta,licence)==nil then
              local tmp=string.split(stackmeta,":")
              local dat_new=espace.set_dat(42,42)
              tmp[2]=dat_new
              stackmeta=tmp[1]
              for j=2,#tmp do
                stackmeta=stackmeta..":"..tmp[j]
              end
              stackmeta=stackmeta..":"..licence
              --debit account
              atm.balance[name] = account-price
              minetest.sound_play("accept",{to_player=name,gain=2})
              minetest.chat_send_player(name,stackmeta)
              formspec_tmp="label[4.75,0;account : "..atm.balance[name].."  ]"
              atm.saveaccounts ()
              err=1
            end
            inv:remove_item("main", "commerce:licence")
            inv:add_item("main", {name="commerce:licence", count=1, wear=0, metadata=stackmeta})
          end
        else
          --debit account
            atm.balance[name] = account-price
            minetest.sound_play("accept",{to_player=name,gain=2})
            formspec_tmp="label[4.75,0;account : "..atm.balance[name].."  ]"
            atm.saveaccounts ()
            err=1
          if index==0 then  --new card
            licence="Licence:00"
            minetest.chat_send_player(name,"LICENCE")
          else  --MaJ licence
            local tmp=string.split(stackmeta,":")
            local dat_new=espace.set_dat(42,42)
            tmp[2]=dat_new
            licence="Licence"
            for j=2,#tmp do
              licence=licence..":"..tmp[j]
            end
            inv:remove_item("main", "commerce:licence")
            minetest.chat_send_player(name,"MaJ LICENCE")
          end
          inv:add_item("main", {name="commerce:licence", count=1, wear=0, metadata=licence})
        end
      end
    end
  else
    minetest.chat_send_player(name,"NO CREDIT CARD PRESENT IN INVENTORY")
  end

  if err==0 and fields.quit==nil then
    minetest.sound_play("wrong",{to_player=name,gain=2})
  end
meta:set_string("formspec", licence_formspec..formspec_tmp )   
end,
})

-- neutre

minetest.register_node("commerce:guichet", {
description = "guichet",
	tiles = {
		"commerce_guichetd.png",
		"commerce_guichetd.png",
		"commerce_guichetd.png^[transformR90",
		"commerce_guichetd.png^[transformR90",
		"commerce_guichet.png",
		"commerce_guichet.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
paramtype2 = "facedir",
use_texture_alpha = true,
groups = {unbreakable = 1, not_in_creative_inventory = 1},--{cracky=3},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.375, -0.0625, 0.5, 0.5, 0.0625}, -- NodeBox1
			{-0.5, -0.5, -0.5, 0.5, -0.375, 0.5}, -- NodeBox2
		}
	}
})

minetest.register_craftitem("commerce:licence", {
	description = "licence",
	inventory_image = "commerce_licence.png",
	groups = {flammable = 3,not_in_creative_inventory = 1},
  stack_max = 1,
  on_use = function(itemstack, user, pointed_thing)
		local nplayer = user:get_player_name()
		local stackmeta = itemstack:get_metadata()
		if stackmeta~=nil then
      local tmp=string.split(stackmeta,":")
      local year,month,day=espace.get_dat(tmp[2])
      tmp[2]=year.."/"..month.."/"..day
      stackmeta=tmp[1]
      for j=2,#tmp do
        stackmeta=stackmeta.." : "..tmp[j]
      end
    else
      stackmeta="empty"
    end
    minetest.chat_send_player(nplayer, stackmeta)
	end,
})

minetest.register_craftitem("commerce:card", {
	description = "Bank card",
	inventory_image = "commerce_credit_card.png",
	groups = {flammable = 3},--,not_in_creative_inventory = 1},
stack_max = 1,
on_use = function(itemstack, user, pointed_thing)
		local name = user:get_player_name()
		atm.readaccounts ()
    if atm.balance[name] == nil then
      atm.ensure_init(name)
    end
    minetest.chat_send_player(name, atm.balance[name])
	end,
})

minetest.register_craft({
  output = 'commerce:card',
  recipe = {
    {'currency:minegeld_10','','currency:minegeld_10'},
    {'','currency:minegeld_10',''},
    {'currency:minegeld_10','','currency:minegeld_10'},
  }
})
