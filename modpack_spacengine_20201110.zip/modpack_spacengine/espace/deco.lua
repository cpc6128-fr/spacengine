--**************
--** load_bmp **
--**************
--from REALTERRAIN
-- Original file is part of Allegro 4.4.
-- BMP loader by Seymour Shlien.
-- Translated to Lua by Diego Martínez <lkaezadl3@gmail.com>
local function read_bytes(f, c, d)

	local s = (d < 0) and c or 1
	local e = (d < 0) and 1 or c

	local buf = f:read(c)
	if (not buf) or (buf:len() ~= c) then return nil end

	local r = 0

	for x = s, e, d do
		r = r * 256
		r = r + buf:byte(x)
	end

	return r

end

local function fgetc(f) return (f:read(1) or " "):byte() end

espace.load_bmp=function(filename,pattern_swap)
  local decodata={}
  local bmpdata={}
  local surfacedata={}
  local f= io.open(minetest.get_modpath("espace").."/heightmap/"..filename..".bmp", "r")
  local sizex,sizez
  if f then
    --header
    local tmphead=f:read(10)
    local offset=read_bytes(f, 4, -1)-26
    tmphead=f:read(4)
    sizex=math.abs(read_bytes(f, 4, -1))
    sizez=math.abs(read_bytes(f, 4, -1))
    tmphead=f:read(offset)
    --image
    if pattern_swap>2 then
      local index=1
        for line=1,sizez do
          local ii = 0

          for i = 1, sizex do
            --tmphead=f:read(2) --bleu et vert
            tmphead=f:read(1) --bleu
            surfacedata[index]=fgetc(f) --vert
            bmpdata[index] = fgetc(f)/50 --*0.234 --recupere composante rouge mise a echelle layer 0-->60 au lieu de 0 a 255
            ii = ii + 1
            index=index+1
          end

          -- padding
          ii =ii % 4
          if ii ~= 0 then
            while ii < 4 do
              fgetc(f)
              ii = ii + 1
            end
          end
        end
      else
        local index=1
        for line=1,sizez do
          local ii = 0

          for i = 1, sizex do
            tmphead=f:read(2) --bleu et vert
            --tmphead=f:read(1) --bleu
            --surfacedata[index]=f:read(1) --vert
            bmpdata[index] = fgetc(f)/50--*0.234 --recupere composante rouge mise a echelle layer 0-->60 au lieu de 0 a 255
            ii = ii + 1
            index=index+1
          end

          -- padding
          ii =ii % 4
          if ii ~= 0 then
            while ii < 4 do
              fgetc(f)
              ii = ii + 1
            end
          end
        end
      end
    end

  f:close()
return bmpdata,sizex,sizez,surfacedata,decodata
end

--
--******************
--** string split **
--******************
--patt="%d+" recherche nombre "%a+" recherche lettre
espace.split_string=function(phrase,patt)
local index=1
local result={}
for w in string.gmatch(phrase, patt) do
if patt=="%d+" then
    result[index]=tonumber(w)
  else
    result[index]=w
  end
  index=index+1
end 
return result
end

--****************
--** choix node **
--****************
espace.generat_sol=function(list,sum,alt_ore,alt_start)
  local demisum=math.ceil(sum/2)
  local rnd = math.random(1,sum)-math.random(1,demisum)
  if rnd<1 then rnd=rnd+sum end

  local nb=#list
  local c1=0
  local c2=list[nb][2]

  repeat
    if rnd>c1 and rnd<c2 then
      
      if list[nb][3]==nil then
        return minetest.get_content_id(list[nb][1])
      else
        local tmp=list[nb][3]+alt_start
        if list[nb][4]~=nil then
          if alt_ore>tmp and alt_ore<tmp+list[nb][4] then
            return minetest.get_content_id(list[nb][1])
          end
        else
          if alt_ore<tmp then
            return minetest.get_content_id(list[nb][1])
          end
        end
      end
    end
  c1=c2
  nb=nb-1
  if nb>0 then c2=c2+list[nb][2] end
  until nb<1
  
	return minetest.get_content_id(list[1][1])
end

--**************
--** Ores sum **
--**************
espace.sum_ores=function(list)
  local nb=#list
  local sum=0
  repeat
    sum=sum+list[nb][2]
    nb=nb-1
  until nb<1
  return sum
end

-- *****************************
-- ** remplissage des coffres **
-- *****************************
espace.fill_chest=function(chest_pos,size,locker)
  local meta = minetest.get_meta(chest_pos)
  local inv = meta:get_inventory()
  local w=math.floor(size/10)
  local h=size-(w*10)
  local x=math.floor(4-(w/2))
  local y=math.floor(2-(h/2))
  size=w*h
  local form="invsize[8,9;]".."list[context;main;".. x ..",".. y ..";"..w..","..h..";]".."list[current_player;main;0,5;8,4;]"
  inv:set_size("main",size)

  if locker~="-" then
  local boucle=0
  local objet={}
  local quantity=0
  -- nb d'item enregistrer
  local nb_item = #commerce.item
  --choix premier objet
  local choix_item=math.random(1,nb_item)

	for i=1,size do
    boucle=3
    choix_item=math.random(1,nb_item)
    local rnd=math.random(1,100)

    repeat
      objet=commerce.item[choix_item]  --recuperation des données
              
        if objet[4]<rnd then
          if string.find(objet[6],locker) then --fill si autorisation
            local tmp=math.ceil(objet[5]/2)--quantite mini
            quantity=math.random(tmp,objet[5])--quantite maxi
            inv:set_stack("main",i,objet[2] .." ".. tostring(quantity))
            boucle=0
          end
        end
    
      choix_item=choix_item+10
      if choix_item>nb_item then choix_item=choix_item-nb_item end
      boucle=boucle-1
    until boucle<1
    
  end
  --local creat_dat=((startest.year-1)*168)+((startest.month-1)*14)+startest.day+math.random(40,80)
  --meta:set_int("visit",creat_dat)
  --meta:set_int("visit",25)
  end
  meta:set_string("formspec",form)

end

--********************************
--** remplacement portes/autres **
--********************************
espace.replace_objet=function(pos1,pos2,a)
  local objet_pos={}
  local testnode=""
  local p2=0

  --** group chest **
  local chest_item=0
  local group=0
  local list_coordo=minetest.find_nodes_in_area(pos1,pos2, {"default:chest","commerce:xpchest"})
  local count=table.getn(list_coordo)

  if count>0 then
    for i=1,count do
      objet_pos=list_coordo[i]
      testnode=minetest.get_node(objet_pos)
      minetest.set_node(objet_pos, {name = testnode.name , param2=testnode.param2})
      --quel sorte de stockage ?
      --group=minetest.get_item_group(testnode.name,"chest")
      local size,locker=82,"c"

      --if group==1 then
        --size=82
        --locker="c"
      if testnode.name=="commerce:xpchest" then
        size=22
        locker="c"
      end
      --elseif group==3 then
      --  size=33
      --  locker="c"
      --elseif group==4 then
      --  size=math.random(2,8)*10+math.random(2,4)
      --  locker="x"
      --end
      espace.fill_chest(objet_pos,size,locker)
    end
  end

  --recherche objet
  list_coordo=minetest.find_nodes_in_area(pos1,pos2, {"default:furnace", "commerce:magasin", "commerce:automatic_distributor", "commerce:bank", "commerce:master_bank", "commerce:guichet_a", "commerce:guichet_b","protector:protect","protector:protect2","default:bookshelf","doors:trapdoor","vessels:shelf" ,"commerce:green_deal" ,"commerce:red_deal","spacengine:builder","commerce:info_astroport"})
  count=table.getn(list_coordo)
  
  if count>0 then
    for i=1,count do
      objet_pos=list_coordo[i]
      testnode=minetest.get_node(objet_pos)
      minetest.set_node(objet_pos, {name = testnode.name , param2=testnode.param2})
      if testnode.name=="protector:protect2" or testnode.name=="protector:protect" then
        local meta = minetest.get_meta(objet_pos)
        meta:set_string("owner", "")
        meta:set_string("infotext", "Admin Protection")
        meta:set_string("members", "")
      end

      if a~=nil then
        if testnode.name=="commerce:info_astroport"
          or testnode.name=="commerce:magasin"
          or testnode.name=="commerce:automatic_distributor"
          or testnode.name=="commerce:master_bank"
          or testnode.name=="commerce:guichet_b" then
        
          local meta = minetest.get_meta(objet_pos)
          meta:set_int("inflation",a)
        end
      end

      --TODO magasin compatible astroport
    end
  end


end

--
--****************
--** decoration **
--****************
espace.deco_search=function(decoration,decox,decoz,pmin,pmax,heightmap,bottom_level)
local tmpnb=#decoration--math.random(1,#decoration)
local alt_layer=pmin.y
local longx=pmax.x-pmin.x+1
local longz=pmax.z-pmin.z+1

local pos1,pos2,xx,zz,alt,alt_abs,indextmp
local rot=math.random(1,4)  --rotation
local h_moy=0
local h_min=31000
local h_max=-31000
local surface

repeat
--better random in
local prob=math.max(1,5000-(decoration[tmpnb][3]*5))
local demiprob=math.ceil(prob/2)
local rnd=math.random(1,5000)-math.random(1,demiprob)
--better random out

if rnd<1 then rnd=rnd+5000 end

    if rnd>prob then --probabiliter
      local typ_spawn=decoration[tmpnb][1]
      surface=string.split(typ_spawn," ")

      if decoration[tmpnb][7]~=nil then --si dimension x/z présente
        pos1={x=decox,z=decoz}
        if rot==2 or rot==4 then --rotation box

          local size=espace.split_string(decoration[tmpnb][7],"%d+")
          zz=math.floor(size[1]/2)
          xx=math.floor(size[3]/2)
          pos2={x=decox+size[3]-1,z=decoz+size[1]-1}
        else
          local size=espace.split_string(decoration[tmpnb][7],"%d+")
          pos2={x=decox+size[1]-1,z=decoz+size[3]-1}
          xx=math.floor(size[1]/2)
          zz=math.floor(size[3]/2)
        end
        
      else  --sinon node
        pos1={x=decox,z=decoz}
        pos2={x=decox,z=decoz}
        xx=0
        zz=0
      end
      
      indextmp=(decox+xx)+((zz+decoz-1)*longz)
      
      --recherche emplacement
      if pos1.x>0 and pos2.x<longx+1 then --interieur minp
        if pos1.z>0 and pos2.z<longz+1 then
        alt=heightmap[indextmp] --hauteur a l'index
        alt_abs=math.abs(alt) --attention water est neg
        local testspawn=0

        for i=1,#surface do
          if surface[i]=="o" or surface[i]=="O" then
            --option objet influence pas
          else
            if alt>372000 then --deco specifique top
              if surface[i]=="g" then
                if decoration[tmpnb][4]>bottom_level-1 then
                  testspawn=1
                  break
                end
              end
            elseif alt>341000 then --deco specifique bottom
              if surface[i]=="g" then
                if decoration[tmpnb][4]<bottom_level then
                  testspawn=1
                  break
                end
              end
            elseif alt>31000 then --deco specifique layer
              local nb_lay=tostring(math.floor(alt/31000)-1)
              if surface[i]==nb_lay then
                testspawn=1
                break
              end
            elseif (alt_abs>alt_layer+decoration[tmpnb][4] and alt_abs<alt_layer+decoration[tmpnb][5]) then --deco normal mode
              testspawn=1
            end
          end
        end

        if testspawn>0 then
            local zero=0
            local cpt=0
            h_moy=0

            --recherche zone libre
            for z=pos1.z, pos2.z do
              for x=pos1.x , pos2.x do
                local pos=x+((z-1)*longz)
                local tmpalt=heightmap[pos]

                if tmpalt==0 then --quand un objet present valeur est a 0
                  zero=zero+1
                end

                if string.find(typ_spawn,"w") then --objet sur l'eau
                  if tmpalt>-1 then
                    zero=zero+1
                  end
                end

                if tmpalt>372000 then --surface specifique
                  tmpalt=tmpalt-372000
                  if string.find(typ_spawn,"g") and decoration[tmpnb][4]>bottom_level-1 then
                  else
                    zero=zero+1
                  end
                elseif tmpalt>341000 then
                  tmpalt=tmpalt-341000
                  if string.find(typ_spawn,"g") and decoration[tmpnb][4]<bottom_level then
                  else
                    zero=zero+1
                  end
                elseif tmpalt>31000 then
                  local nb_lay=tostring(math.floor(tmpalt/31000)-1)
                  tmpalt=tmpalt % 31000
                  if string.find(typ_spawn,nb_lay) then
                  else
                    zero=zero+1
                  end
                elseif tmpalt>0 then
                  if string.find(typ_spawn,"g") then
                  else
                    zero=zero+1
                  end
                end

                h_moy=h_moy+tmpalt
                
                cpt=cpt+1

                if string.find(typ_spawn,"o") or string.find(typ_spawn,"O") then
                  h_min=math.min(h_min,tmpalt)
                  h_max=math.max(h_max,tmpalt)
                end

                

              end--x
            end--z

            if cpt>0 then
              h_moy=math.floor(h_moy/cpt) --calcul hauteur moyenne pour house et socle
            end

            if string.find(typ_spawn,"o") then -- zone plane ?
              if (h_max-h_min)>0 then h_moy=31000 end
            end
            if string.find(typ_spawn,"O") then --trop grand ecart ?
              if (h_max-h_min)>9 then h_moy=31000 end
            end

            if zero==0 and h_moy<31000 then -- si de la place pour poser un objet
              --remplacement par 0 de l'altitude quand un objet est présent
              for z=pos1.z, pos2.z do
                for x=pos1.x , pos2.x do
                  local pos=x+((z-1)*longz)
                  heightmap[pos]=0
                end--x
              end--z

              if alt>372000 then
                h_moy=alt-372000
                alt_abs=h_moy
              elseif alt>341000 then
                h_moy=alt-341000
                alt_abs=h_moy
              elseif alt>31000 then
                h_moy=alt % 31000
                alt_abs=h_moy
              end

              local pos={x=pmin.x+decox+xx-1,y=alt_abs,z=pmin.z+decoz+zz-1}
              if alt<0 then --choix surface water ou ground
                return pos,decoration[tmpnb][1],"water",tmpnb,rot,h_moy
              else
                return pos,decoration[tmpnb][1],"ground",tmpnb,rot,h_moy
              end
            end

          end
        end

      end

  end

  tmpnb=tmpnb-1
until tmpnb<1

return nil
end

--*************************
--** schematic placement **
--*************************
espace.deco_place=function(mtspos,decoration,typ_spawn,typ_surface,nodename,rot,h_moy)

if typ_surface=="water" then
  if string.find(typ_spawn,"w") then
--nothing
  else
    return
  end
else
  if string.find(typ_spawn,"w") then return end
end

local file=decoration[2]
local typ_file="none"
if string.find(file,":") then typ_file="node" end
if string.find(file,"%.mts") then typ_file="mts" end
if string.find(file,"%.we") then typ_file="we" end

local decaly=0
if decoration[6]~= nil then
decaly=math.min(9,decoration[6])
end

local sizx=0
local sizy=0
local sizz=0

if decoration[7]~=nil then
local size=espace.split_string(decoration[7],"%d+")
  sizx=math.floor(size[1]/2)
  sizy=size[2]
  sizz=math.floor(size[3]/2)
end

local tmp1={}
if string.find(typ_spawn,"O") then
  tmp1={x=mtspos.x-sizx,y=h_moy+decaly,z=mtspos.z-sizz}  --hauteur moyenne
else
  tmp1={x=mtspos.x-sizx,y=mtspos.y+decaly,z=mtspos.z-sizz}
end

local tmp2={x=0,y=0,z=0}
local tmp3={x=0,y=0,z=0}
local rota="0"
--rotation box
if rot==1 then --rot -1
rota="0"
tmp1.x=mtspos.x-sizx
tmp1.z=mtspos.z-sizz
tmp2.x=mtspos.x-sizx
tmp2.z=mtspos.z-sizz
tmp3.x=mtspos.x+sizx
tmp3.z=mtspos.z+sizz

elseif rot==2 then
rota="90"--(yaw270)
tmp1.x=mtspos.x-sizz
tmp1.z=mtspos.z-sizx
tmp2.x=mtspos.x-sizz
tmp2.z=mtspos.z-sizx
tmp3.x=mtspos.x+sizz
tmp3.z=mtspos.z+sizx

elseif rot==3 then
rota="180"--tostring(90*rot)
tmp1.x=mtspos.x-sizx
tmp1.z=mtspos.z-sizz
tmp2.x=mtspos.x-sizx
tmp2.z=mtspos.z-sizz
tmp3.x=mtspos.x+sizx
tmp3.z=mtspos.z+sizz

elseif rot==4 then
rota="270"--(yaw90) tostring(90*rot)
tmp1.x=mtspos.x-sizz
tmp1.z=mtspos.z-sizx
tmp2.x=mtspos.x-sizz
tmp2.z=mtspos.z-sizx
tmp3.x=mtspos.x+sizz
tmp3.z=mtspos.z+sizx
end

if typ_file=="node" then
    minetest.set_node(tmp1,{name=decoration[2]})
  return
elseif typ_file=="mts" then
  local filename=minetest.get_modpath("espace").."/schematics/"..file
  minetest.place_schematic(tmp1, filename, rota, nil, true)
elseif typ_file=="we" then
  tmp3.y=math.abs(h_moy)+sizy+decaly
  worldedit.set(tmp2, tmp3, "air")
  local file = io.open(minetest.get_modpath("espace").."/schematics/"..file)
  local value = file:read("*a")
  file:close()
  worldedit.deserialize(tmp1, value)
end

--creation sol du mts
 if string.find(typ_spawn,"O") then
  tmp2.y=h_moy-10
  tmp3.y=(h_moy-1)+decaly
  worldedit.set(tmp2, tmp3, nodename)
 end

if string.find(typ_spawn,"o") or string.find(typ_spawn,"O") then
  tmp2.y=math.abs(h_moy)+decaly
  tmp3.y=math.abs(h_moy)+sizy+decaly
  --recherche coffre et objet
  espace.replace_objet(tmp2,tmp3)
end

return
end

espace.deco=function(decoration,surface,pmin,pmax,heightmap,bottom_level)
local longx=(pmax.x-pmin.x)-3 --longueur x et z
local longz=(pmax.z-pmin.z)-3

  local decox=math.random(3,6) --position x et z
  local decoz=math.random(3,6)

  local c_water
  if surface.water~=nil then
    c_water = minetest.get_content_id(surface.water)
  else
    c_water = minetest.get_content_id("default:water_source")
  end

    repeat
    local pos,typ_spawn,typ_surface,tmpnb,rot,h_moy=espace.deco_search(decoration,decox,decoz,pmin,pmax,heightmap,bottom_level)

    if pos~=nil then

      if string.find(typ_spawn,"w") then
        espace.deco_place(pos,decoration[tmpnb],typ_spawn,typ_surface,c_water,rot,h_moy)
      else
        espace.deco_place(pos,decoration[tmpnb],typ_spawn,typ_surface,surface.bottom[1][1],rot,h_moy)
      end

    end

    decox=decox+math.random(3,6)

    if decox>longx then
      decox=math.random(3,6)
      decoz=decoz+3
    end

    until decoz>longz
end

--*******************************
--** modification map realtime **
--*******************************
espace.building=function(bpos,alt,node,deco)

  if deco==nil then
    deco={
    {"g","chalet_02_protect.mts","9/6/9/0",15},
    {"g","house_vercors_protect.mts","9/11/9/0",15},
    {"g","building_01.mts","15/22/15/0",2},
    {"g","building_02.mts","15/22/15/0",3},
    {"w","pirate_ship_protect.mts","7/15/20/1",25},
    {"g","magasin_protect.mts","5/4/7/0",15},
    {"g","epicerie.mts","7/4/5/0",10},
    {"g","bank_protect.mts","9/8/7/1",15}
    }
  end

  local tmpnb=math.random(1,#deco)
  local out=0

  for j=1,tmpnb do
    if math.random(1,100)<deco[j][4] then
      out=1
      tmpnb=j
      break
    end
  end
--minetest.chat_send_all("out "..out.." "..tmpnb)
  if out==0 then return end

  local rot=math.random(1,4)-- -1
  local decox=math.random(1,10)+20
  local decoz=math.random(1,10)+20
  local pos1={}
  local pos2={}
  local size=espace.split_string(deco[tmpnb][3],"%d+")
  local sizx=math.floor(size[1]/2)
  local sizy=size[2]
  local sizz=math.floor(size[3]/2)
  local decalage=size[4]

  if string.find(deco[tmpnb][2],"%.mts") then

    if rot==1 then --rot -1
      rota="0"
      pos1.x=bpos.x-decox-sizx
      pos1.z=bpos.z-decoz-sizz
      pos2.x=bpos.x-decox+sizx
      pos2.z=bpos.z-decoz+sizz

    elseif rot==2 then
      rota="90"--(yaw270)
      pos1.x=bpos.x-decox-sizz
      pos1.z=bpos.z+decoz-sizx
      pos2.x=bpos.x-decox+sizz
      pos2.z=bpos.z+decoz+sizx

    elseif rot==3 then
      rota="180"
      pos1.x=bpos.x+decox-sizx
      pos1.z=bpos.z+decoz-sizz
      pos2.x=bpos.x+decox+sizx
      pos2.z=bpos.z+decoz+sizz

    elseif rot==4 then
      rota="270"--(yaw90)
      pos1.x=bpos.x+decox-sizz
      pos1.z=bpos.z-decoz-sizx
      pos2.x=bpos.x+decox+sizz
      pos2.z=bpos.z-decoz+sizx
    end

  else
    pos1.x=bpos.x-decox-sizx
    pos1.z=bpos.z-decoz-sizz
    pos2.x=bpos.x-decox+sizx
    pos2.z=bpos.z-decoz+sizz
  end

  --recherche emplacement pour building
  local node_list={}

  if deco[tmpnb][1]=="w" then --water
    pos1.y=alt-2
    pos2.y=alt+2
    node_list=minetest.find_nodes_in_area_under_air(pos1,pos2,{"group:water"})
--minetest.chat_send_all(deco[tmpnb][2] .." ".. #node_list.." w "..(sizx*sizz))
    if #node_list<(sizx*sizz) then return end
  else --ground
    pos1.y=alt-2
    pos2.y=alt+78
    node_list=minetest.find_nodes_in_area_under_air(pos1,pos2,{"group:soil"})
--minetest.chat_send_all(deco[tmpnb][2] .." ".. #node_list.." g "..(sizx*sizz))
    if #node_list<(sizx*sizz) then return end
  end

  local ht_min=31000
  local ht_max=-31000
  local ht_moy=0
  local tmp

  for i=1,#node_list do 
    tmp=node_list[i]
    if tmp.y<ht_min then
      ht_min=tmp.y
    end
    if tmp.y>ht_max then
      ht_max=tmp.y
    end
    ht_moy=ht_moy+tmp.y
  end

  local delta=ht_max-ht_min
--minetest.chat_send_all("delta "..delta)
  if delta>9 then return end

  ht_moy=math.floor(ht_moy/#node_list)

  --recherche protection
  node_list=minetest.find_nodes_in_area({x=pos1.x-5,y=ht_moy-delta-5-decalage,z=pos1.z-5},{x=pos2.x+5,y=ht_moy+sizy+5,z=pos2.z+5},{"protector:protect", "protector:protect2"})
--minetest.chat_send_all("protect "..#node_list)
  if #node_list>0 then return end
  
  local filename=minetest.get_modpath("espace").."/schematics/"..deco[tmpnb][2]

  --if deco[tmpnb][1]=="ground" then
    --effacement des blocs avant construction
    pos1.y=ht_moy+1-decalage
    pos2.y=ht_moy+sizy+1
    worldedit.set(pos1, pos2, "air")
  --end

  if string.find(deco[tmpnb][2],"%.mts") then
    pos1.y=ht_moy+1-decalage
    minetest.place_schematic(pos1, filename, rota, nil, true)

  else
    pos1.y=ht_moy+1-decalage
    local file = io.open(filename)
    local value = file:read("*a")
    file:close()
    worldedit.deserialize(pos1, value)
  end

  minetest.chat_send_all("build "..pos1.x .." / ".. pos1.z)

  if deco[tmpnb][1]=="g" then
    --creation sol du mts
    pos1.y=ht_moy-delta-1
    pos2.y=ht_moy-decalage
    worldedit.set(pos1, pos2, node)
  end

  --recherche coffre et objet
  pos1.y=ht_moy
  pos2.y=ht_moy+sizy+1
  espace.replace_objet(pos1,pos2)
  --creation date
  espace.build_dt=espace.set_dat(5,10,1)--(5,10,1)
end
