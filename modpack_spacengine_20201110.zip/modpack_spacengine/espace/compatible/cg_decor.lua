minetest.register_node(":cg_decor:tree_trunk", {
	drawtype = "mesh",
	mesh = "cg_decor_small_tree.obj",
	tiles = {"cg_decor_tree_trunk.png"},
	paramtype = "light",
	is_ground_content = true,
	climbable = true,
    selection_box = {
            type = "fixed",
            fixed = { -0.125, -0.5, -0.125, 0.125, 0.5, 0.125 },
    },
    collision_box = {
            type = "fixed",
            fixed = { -0.125, -0.5, -0.125, 0.125, 0.5, 0.125 },
    },
    drop = {
		max_items = 1,
		items = {{items = {'default:stick 2'},}}
	},
	groups = {snappy=3,flammable=2,leafdecay=2},
	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_node(":cg_decor:tree_trunk_base", {
	drawtype = "mesh",
	mesh = "cg_decor_small_tree.obj",
	tiles = {"cg_decor_tree_trunk.png"},
	paramtype = "light",
	is_ground_content = true,
	climbable = true,
    selection_box = {
            type = "fixed",
            fixed = { -0.125, -0.5, -0.125, 0.125, 0.5, 0.125 },
    },
    collision_box = {
            type = "fixed",
            fixed = { -0.125, -0.5, -0.125, 0.125, 0.5, 0.125 },
    },
    drop = {
		max_items = 1,
		items = {{items = {'default:stick 2'},}}
	},
	groups = {snappy=3,flammable=2,tree=1},
	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_node(":cg_decor:cherry_leaves_large", {
		drawtype = "mesh",
		mesh = "cg_decor_tree_leaves.obj",
		waving = 1,
		visual_scale = 2.5,
		tiles = {"cg_decor_cherry_leaves.png"},
		paramtype = "light",
		walkable = false,
		climbable = true,
		is_ground_content = false,
		groups = {snappy=3, leafdecay=3, flammable=2, leaves=1},
    drop = {
			max_items = 2,
			items = {
                    {items = {"cg_decor:cherry 2"},},
                    {items = {"cg_decor:cherry_tree_extralarge"},}
                    }
		},
		drop = "cg_decor:cherry",
		collision_box = {
			type = "fixed",
			fixed = {-0.2, -0.2, -0.2, 0.2, 1.2, 0.2}
		},
		selection_box = {
			type = "fixed",
			fixed = {-0.5, -0.5, -0.5, 0.5, 1.5, 0.5}
		},
		sounds = default.node_sound_leaves_defaults(),
	})

minetest.register_node(":cg_decor:cherry", {
			description = "cherry",
			drawtype = "plantlike",
			visual_scale = 0.8,
			tiles = {"cg_decor_cherry.png"},
			inventory_image = "cg_decor_cherry.png",
			paramtype = "light",
			sunlight_propagates = true,
			walkable = false,
			is_ground_content = true,
			groups = {fleshy=3,dig_immediate=3,flammable=2,attached_node=1,not_in_creative_inventory=1},
			on_use = minetest.item_eat(1),
			selection_box = {
				type = "fixed",
				fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
			},
			sounds = default.node_sound_leaves_defaults()
		})

minetest.register_node(":cg_decor:cherry_tree_extralarge", {
		description = "Extra large Cherry tree",
		drawtype = "plantlike",
		visual_scale = 1.9,
		tiles = {"cg_decor_cherry_tree.png"},
		inventory_image = "cg_decor_cherry_tree.png",
		wield_image = "cg_decor_cherry_tree.png",
		paramtype = "light",
		walkable = false,
		is_ground_content = true,
		selection_box = {
			type = "fixed",
			fixed = {-0.3, -0.5, -0.3, 0.3, 0.35, 0.3}
		},
		groups = {snappy=2,dig_immediate=3,flammable=2,attached_node=1},
on_construct=function(pos)
local nu =  minetest.get_node({x=pos.x, y=pos.y-1, z=pos.z}).name
local is_soil = minetest.get_item_group(nu, "soil")
if is_soil == 0 then
minetest.remove_node(pos)
minetest.spawn_item(pos, "cg_decor:cherry_tree_extralarge")
return
end
minetest.get_node_timer(pos):start(math.random(60,120))
end,
on_timer=function(pos)
  espace.grow_tree(pos,"cherry_tree")
end,
		sounds = default.node_sound_leaves_defaults(),
	})
