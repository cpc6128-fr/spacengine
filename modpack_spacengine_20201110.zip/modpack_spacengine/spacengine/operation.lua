spacengine.central_msg=function(msg,config)
  local msg_hr=math.ceil(minetest.get_timeofday()*24000)
  local msg_mn=math.floor((msg_hr % 1000)*0.06)
  msg_hr=math.floor(msg_hr/1000)
  msg=string.sub(msg,1,42)
  local lng=string.len(msg)
  local s1,s2,s3="","",""

  if lng>26 then
    s3=string.sub(msg,27,42) 
  end
  if lng>10 then
    s2=string.sub(msg,11,26)
  end
  s1=string.sub(msg,1,10)

  local nb_msg=string.split(config[13][9],";")

  config[13][9]=string.sub((msg_hr+100),2)..":"..string.sub((msg_mn+100),2).." "..s1..s2..s3

  for i=1,#nb_msg do
    if i<6 then
      config[13][9]=config[13][9]..";"..nb_msg[i]
    end
  end

end



local function manutention_idx(config)
  local zone=math.floor((config[13][3]*config[4][4][4])/100)*2+1

  if config[13][11]<0 then
    config[13][11]=(zone^3)-1
  end

  config[13][11]=config[13][11]-1
  if config[13][11]<0 then
    config[13][10]=-1
    return false
  end

  local index=config[13][11]

  local id_y=index/(zone^2)
  local id_z=( (id_y-math.floor(id_y) ) * (zone^2) )/zone
  local id_x=math.floor( (id_z-math.floor(id_z)) * zone )+1
  id_y=math.floor(id_y)+1
  id_z=math.floor(id_z)+1

  return true,id_x,id_y,id_z
end

--*****************
--*** controler ***
--*****************
spacengine.controler=function(pos,scr)
  --local tt0 = minetest.get_us_time()
  local cont_met = minetest.get_meta(pos)
  local pos_cont=spacengine.decompact(cont_met:get_string("pos_cont"))
  local channel=cont_met:get_string("channel")

  if pos_cont[2]>31000 then return end

  local cha_spl=string.split(channel,":")
  channel=cha_spl[1]..":"..cha_spl[2] --channel+owner only

  if spacengine.config[channel]==nil then return end --erreur config absent

  local config=spacengine.config[channel]

  if config[1][1]==0 and config[12]=="n" then return end

  --temps ecouler entre 2 appels
  local t0=config[14]
  local t1 = minetest.get_us_time()-t0
  if t1<0 then t1=5000000 end
  local new_screen="m"
  config[3][2]=0
  local new_pos

  local id_stock_pos=0
  local stock_pos=spacengine.decompact(cont_met:get_string("stock_pos"))

  if stock_pos then id_stock_pos=#stock_pos end

  if id_stock_pos>1 then
    
    for idx=2,id_stock_pos do
      new_pos={x=stock_pos[idx][1]+pos.x,y=stock_pos[idx][2]+pos.y,z=stock_pos[idx][3]+pos.z}
      dst=minetest.get_node(new_pos) 
      nod_met=minetest.get_meta(new_pos)
      local cha_dst=nod_met:get_string("channel")
      local spl_cha=string.split(channel,":")
      cha_dst=spl_cha[1]..":"..spl_cha[2] --recuperation du premier nom

      if cha_dst==channel then --ifchannel ok
        local dst_group=minetest.get_item_group(dst.name,"spacengine")

        if dst_group==3 and t1>4500000 and scr==nil then
          local rs=spacengine.power(new_pos,nod_met,cont_met,config)
          if rs==true then new_screen=new_screen.."e" end

        elseif dst_group==12 then
          if config[12]~="n" then
            spacengine.screen_display(new_pos,nod_met,pos,cont_met,config)
          end
        end

      end
    end
  end

  if t1>4500000 and config[1][1]==1 and scr==nil then --minimum 5 sec.

    --** temperature moteur **
    if config[4][6]>0 then
      config[4][6]=math.max(0,config[4][6]-config[4][5])
      new_screen=new_screen.."E"
    end

    --** regeneration shield **
    if config[5][4]>0 then
      config[5][4]=math.max(0,config[5][4]-config[5][3])
      new_screen=new_screen.."S"
    end

    if config[5][2]>0 then
      local sh=math.ceil(config[5][1]*config[5][2]*0.5)
      config[3][2]=config[3][2]-sh
      config[2][2]=math.max(0,config[2][2]-sh)
      if config[2][2]==0 then
        config[5][2]=0
        spacengine.central_msg("SHIELD OFF LOW BAT",config)
        spacengine.make_sound("alert",config[15])
      end
    end

    --** reload weapons **
    if config[6][6]>0 then
      config[6][6]=math.max(0,config[6][6]-1)
      new_screen=new_screen.."W"
    end

    --** gravitation **
    if config[8][2]>0 then
      local g=math.max(10,config[8][2]*config[8][1]*3)
      config[3][2]=config[3][2]-g
      config[2][2]=math.max(0,math.floor(config[2][2]-g))
      config[3][2]=config[3][2]-math.ceil(g)

      if config[2][2]==0 then
        config[8][2]=0
        spacengine.central_msg("MODULE GRAVITON STOP LOW BAT",config)
        spacengine.make_sound("alarm2",config[15])
      end
        
      new_screen=new_screen.."G"

    end

    --** oxygene **
    if config[11][2]>0 or config[11][4]>0 then
      config[11][4]=config[11][4]-1
      new_screen=new_screen.."O"

      if config[11][4]<2 then
        if config[11][2]==0 then
          config[11][4]=0
        else
          config[11][4]=1
        end
        spacengine.oxygene(pos,config)
      end
    end

    --** manutention **
    if config[13][10]>-1 then
      config[13][10]=math.max(0,config[13][10]-1)
      if config[13][10]==0 then
        local msg=spacengine.manutention(pos,cont_met,config)
        if msg then
          spacengine.make_sound("notification",config[15])
          spacengine.central_msg(msg,config)
          new_screen=new_screen.."M"
        end
      end
    end

    -- consommation vaisseaux base
    local volume=tonumber(string.sub(config[1][4],8,9))+config[1][3]
    config[3][2]=config[3][2]-volume
    config[2][2]=math.max(0,math.floor(config[2][2]-volume))
    if config[2][2]<(config[2][1]*0.1) then
      if not string.find(config[13][9],"LOW BAT.") then
        spacengine.central_msg("LOW BAT.",config)
        spacengine.make_sound("alarm",config[15])
      end
    end
    -- puissance moyenne
    config[3][3]=config[3][2]

    -- timer
    config[14]=minetest.get_us_time()
  end

  if new_screen=="" then
    config[12]="n"
  else
    config[12]=new_screen
  end

  --sauvegarde reguliere
  cont_met:set_string("config",spacengine.compact(config))
--local tt1 = minetest.get_us_time()
--local time_micros = (tt1 - tt0)/1000
--minetest.chat_send_all(" time " .. time_micros .. " ms")
end

--*************
--*** power ***
--*************
spacengine.power=function(pos,nod_met,cont_met,config)
  local spac_eng=spacengine.decompact(nod_met:get_string("spacengine"))
  local pos_cont=spacengine.decompact(nod_met:get_string("pos_cont"))
  local refresh_screen=false

  if pos_cont[1]==33333 then return end --controler invalid

  if spac_eng[8]==1 and config[1][1]==1 then --power activer

    local time_release=spac_eng[9] --timer

    local cont_inv = cont_met:get_inventory()
    local capa,charg=config[2][1],config[2][2]

    --mode safe state
    if time_release<0 then
      if charg<capa*0.75 and spac_eng[4]>0 then
        time_release=-time_release
          spacengine.make_sound("sonnerie_porte",config[15])
      else
        return
      end
    end

    local src=spac_eng[5]

    if time_release>0 then --timer on
      local p,coef=spac_eng[4],0
      refresh_screen=true

      if src=="solar" then
        local light=minetest.get_node_light({x=pos.x,y=pos.y+1,z=pos.z})
        if light==nil then light=0 end
        if light>10 then coef=(light-10)*0.14 end

      elseif src=="water" then
        local water=minetest.find_nodes_in_area({x=pos.x-1,y=pos.y-1,z=pos.z-1},{x=pos.x+1,y=pos.y+1,z=pos.z+1},{"default:water_flowing","default:river_water_flowing"})
        if #water > 7 then coef=(#water-7)*0.05 end

      elseif src=="battery" then
        if charg-p>0 then
          charg=math.max(0,charg-p)
        end
        if charg==0 then --stop si battery decharger
          time_release=0
          spac_eng[9]=0
          spacengine.central_msg("POWER OFF - LOW "..src,config)
          spacengine.make_sound("detector",config[15])
        end

      else --node
        coef=1
      end

      local dst=spac_eng[6]
      if dst=="battery" then --destination
        charg=math.min(capa,charg+(p*coef))
        config[2][2]=math.floor(charg)
        if charg==capa and spac_eng[4]>0 then
          --spacengine.central_msg("enable safe power state",config)
          spacengine.make_sound("sonnerie_porte",config[15])
          time_release=-time_release
        end
      end

      if p<0 then --utilisation de la battery
        coef=1
        charg=math.max(0,charg+p)
        config[2][2]=math.floor(charg)
        if charg==0 then --stop si battery decharger
          time_release=0
          spac_eng[8]=0
          refresh_screen=false
          spacengine.central_msg("POWER OFF LOW BATT",config)
          spacengine.make_sound("notification",config[15])
        end
      end

      if time_release==1 and dst~="battery" and coef>0 then --quand transformation terminer add to l'inventaire
        if cont_inv:room_for_item("stock",spac_eng[6]) then
          cont_inv:add_item("stock",spac_eng[6])
        else
          time_release=0
          spac_eng[8]=0
          spacengine.central_msg("POWER STOCK FULL",config)
          spacengine.make_sound("notification",config[15])
        end
      end

      spac_eng[10]=math.ceil(p*coef)
      config[3][2]=config[3][2]+spac_eng[10]

      if coef>0 and time_release>0 then  --bloque timer si pas d'energy sinon decompte
        time_release=time_release-1
      else
        refresh_screen=false
      end
      
    else
      if src=="solar" or src=="water" or src=="battery" then
        time_release=spac_eng[7]
      else
        if cont_inv:contains_item("stock",src) then
          cont_inv:remove_item("stock",src)
          time_release=spac_eng[7]
        else
          spacengine.central_msg("POWER STOCK EMPTY "..src,config)
          spacengine.make_sound("notification",config[15])
        end
      end

    end

    spac_eng[9]=time_release
    
    nod_met:set_string("spacengine",spacengine.compact(spac_eng))
  end

  return refresh_screen
end

--***************
--*** Weapons ***
--***************

spacengine.weapons=function(cpos,channel,cont_met,config,puncher)
  local toucher=false
  if config[6][6]>0 then return "WAIT HOT" end

  local damage=(100-config[1][3])*0.01
  local puissance=math.floor(config[6][1]*config[6][2]*0.01)
  local range=math.floor(config[6][3]*config[6][4]*0.01)
  local zone=math.ceil(config[6][8]*config[4][4][4]*0.01)
  local xrng=math.ceil((-1+(0.02*config[4][4][1]))*range)
  local yrng=math.ceil((-1+(0.02*config[4][4][2]))*range)
  local zrng=math.ceil((-1+(0.02*config[4][4][3]))*range)
  local rmax=math.max(math.abs(xrng),math.abs(yrng),math.abs(zrng))
  local conso=puissance+rmax+(zone*zone*zone)

  if config[2][2]-conso<0 then return "BATTERY TOO LOW" end

  local nb_weapons=math.ceil(config[6][7]*damage)
  local chance=rmax*zone*zone*zone
  local trigger=math.ceil(chance*0.1)
  chance=math.ceil(chance/nb_weapons)
  local degat=math.ceil(puissance*damage*0.01)
  --taille du vaisseaux
  local rangex=5+tonumber(string.sub(config[1][4],2,2))*2
  local rangey=5+tonumber(string.sub(config[1][4],4,4))*2
  local rangez=5+tonumber(string.sub(config[1][4],6,6))*2
--direction
  local aleax=math.floor((math.random(100)*zone*0.02)-(zone/2))
  local aleay=math.floor((math.random(100)*zone*0.02)-(zone/2))
  local aleaz=math.floor((math.random(100)*zone*0.02)-(zone/2))

  if xrng<0 then
    rangex=-rangex
  elseif xrng==0 then
    rangex=0
  end
  if yrng<0 then
    rangey=-rangey
  elseif yrng==0 then
    rangey=0
  end
  if zrng<0 then
    rangez=-rangez
  elseif zrng==0 then
    rangez=0
  end

  if rangex==0 and rangey==0 and rangez==0 then return "SUICIDE" end --prevent suicide >8-b

  local impact=math.random(1,chance)
  local pos3={x=cpos.x+rangex+xrng,y=cpos.y+rangey+yrng,z=cpos.z+rangez+zrng}
  local cible_destroy={x=pos3.x+aleax,y=pos3.y+aleay,z=pos3.z+aleaz}

  if cible_destroy.y<1008 or cible_destroy.y>10207 then return "OUT SPACE" end
  if cible_destroy.x<-30500 or cible_destroy.x>30500 then return "OUT SPACE" end
  if cible_destroy.z<-30500 or cible_destroy.z>30500 then return "OUT SPACE" end

  spacengine.make_sound("laser",config[15])
  config[6][6]=config[6][5] --timer on
  config[2][2]=config[2][2]-conso --consommation
  --search and destroy entity mob
  if puissance>2500 then
    local list=minetest.get_objects_inside_radius(cible_destroy,zone)

    if #list>0 then

      local obj_pos, dist
      
      for _,obj in ipairs(list) do
        obj_pos = obj:get_pos()
        local ent = obj:get_luaentity()

        if obj:is_player() or string.find(ent.name,"mobs") and impact<trigger then
          -- protect area shield
          local found,pos_shield=spacengine.test_area_ship(obj_pos,0)

          if found then
            local target,new_degat=spacengine.check_shield(pos_shield,degat)
            if target then
              new_degat=math.ceil(new_degat/10)
--minetest.chat_send_all("entity")
              toucher=true
              spacengine.explosion(obj_pos)
              obj:punch(list[1], 1.0, {
                full_punch_interval = 1.0,
                damage_groups = {fleshy = new_degat},
              })
              degat=0
              break
            end
          end
        end
      end
    end
  end

  if toucher==false then
    local node,group

      for i=1,nb_weapons do

        impact=math.random(1,chance)
        aleax=math.floor((math.random(100)*zone*0.02)-(zone/2))
        aleay=math.floor((math.random(100)*zone*0.02)-(zone/2))
        aleaz=math.floor((math.random(100)*zone*0.02)-(zone/2))

        cible_destroy={x=pos3.x+aleax,y=pos3.y+aleay,z=pos3.z+aleaz}
        node=minetest.get_node(cible_destroy)

        if minetest.get_item_group(node.name,"spacengine")>0 and impact<trigger then
          if spacengine.destroy_target(cpos,cible_destroy,node,degat) then
            --spacengine.explosion(cible_destroy)
            toucher=true
          end
        end

        -- protection
        if not minetest.is_protected(cible_destroy,"") then

          group=0

          if minetest.get_item_group(node.name,"crumbly")==3 then
            group=10
          elseif minetest.get_item_group(node.name,"cracky")==3 and puissance>2000 then
            group=20
          elseif minetest.get_item_group(node.name,"cracky")==2 and puissance>4000 then
            group=40
          elseif minetest.get_item_group(node.name,"cracky")==1 and puissance>6000 then
            group=50
          elseif minetest.get_item_group(node.name,"wall")>0 then
            group=60
          end

          if group>0 and impact<trigger then
            local found,pos_shield=spacengine.test_area_ship(cible_destroy,0)
            if found then
              if spacengine.check_shield(pos_shield,degat) then
                minetest.remove_node(cible_destroy)
                --spacengine.explosion(cible_destroy)
                toucher=true
              end
            else
              minetest.remove_node(cible_destroy)
              --spacengine.explosion(cible_destroy)
              toucher=true
            end
          end

        end

        spacengine.explosion(cible_destroy)
      end
  end

  if toucher then
    spacengine.make_sound("bip",config[15])
  end

  return
end

--*************
--*** RADAR ***
--*************
spacengine.radar=function(cpos,channel,cont_met,config)
  local puissance=math.ceil(config[7][1]*config[7][2]/100)
  if config[2][2]-puissance<0 then return end
  
  local pos1,pos2
  local id=math.max(1,config[7][6])

  if type(config[7][4])~="table" then return end

  local cible=config[7][4][id]

  if cible=="none:none" then return end

  --direction
  local rangex=5+tonumber(string.sub(config[1][4],2,2))*2
  local rangey=5+tonumber(string.sub(config[1][4],4,4))*2
  local rangez=5+tonumber(string.sub(config[1][4],6,6))*2  
  local pos1,pos2
  local zone=math.ceil(config[7][3]*config[4][4][4]/100)
  local xrng=math.ceil((-1+(0.02*config[4][4][1]))*config[7][3])
  local yrng=math.ceil((-1+(0.02*config[4][4][2]))*config[7][3])
  local zrng=math.ceil((-1+(0.02*config[4][4][3]))*config[7][3])
  
  if xrng<0 then
    rangex=-rangex
  elseif xrng==0 then
    rangex=0
  end
  if yrng<0 then
    rangey=-rangey
  elseif yrng==0 then
    rangey=0
  end
  if zrng<0 then
    rangez=-rangez
  elseif zrng==0 then
    rangez=0
  end

  if rangex==0 and rangey==0 and rangez==0 then return end --prevent narcissisme ;-D

  if cpos.y<1008 or cpos.y>10207 then return end
  if cpos.x<-30500 or cpos.x>30500 then return end
  if cpos.z<-30500 or cpos.z>30500 then return end

  spacengine.make_sound("sonar",config[15])
  config[2][2]=config[2][2]-puissance

  pos1={x=cpos.x+rangex+xrng-zone,y=cpos.y+rangey+yrng-zone,z=cpos.z+rangez+zrng-zone}
  pos2={x=cpos.x+rangex+xrng+zone,y=cpos.y+rangey+yrng+zone,z=cpos.z+rangez+zrng+zone}


  local list=minetest.find_nodes_in_area(pos1,pos2,cible)
  local tmp
  if list==nil then
    config[7][5][id]=0
  else
    config[7][5][id]=math.floor(#list*config[7][2]/100)
  end
  
end

--*******************
--*** MANUTENTION ***
--*******************
spacengine.manutention=function(pos,cont_met,config)

  if config[13][10]>0 then return end
  local manutention=config[13]
  local tmp1=math.floor((manutention[1]*manutention[2])/100)
  local tmp2
  local tmp3
  local zone=math.floor((manutention[3]*config[4][4][4])/100)
  local xrng=math.ceil((-1+(0.02*config[4][4][1]))*tmp1)
  local yrng=math.ceil((-1+(0.02*config[4][4][2]))*tmp1)
  local zrng=math.ceil((-1+(0.02*config[4][4][3]))*tmp1)
  local rangex=5+tonumber(string.sub(config[1][4],2,2))*2
  local rangey=5+tonumber(string.sub(config[1][4],4,4))*2
  local rangez=5+tonumber(string.sub(config[1][4],6,6))*2  
  local pos1

  if pos.y<1008 or pos.y>10207 then return "OUT SPACE" end
  if pos.x<-30500 or pos.x>30500 then return "OUT SPACE" end
  if pos.z<-30500 or pos.z>30500 then return "OUT SPACE" end

  if xrng<0 then
    rangex=-rangex
  elseif xrng==0 then
    rangex=0
  end
  if yrng<0 then
    rangey=-rangey
  elseif yrng==0 then
    rangey=0
  end
  if zrng<0 then
    rangez=-rangez
  elseif zrng==0 then
    rangez=0
  end

  if rangex==0 and rangey==0 and rangez==0 then return "ON SHIP" end --prevent dig your ship

  if config[13][11]==nil then config[13][11]=0 end

  local active,id_x,id_y,id_z=manutention_idx(config)

  if not active then
    return "TERMINATED"
  end

  pos1={x=pos.x+rangex+xrng-zone+id_x,y=pos.y+rangey+yrng-zone+id_y,z=pos.z+rangez+zrng-zone+id_z}

  if type(manutention[5])=="table" then
    tmp3=string.split(manutention[5][manutention[6]],":")
  else
    tmp3=string.split(manutention[5],":")
  end

  local cible=tmp3[1]..":"..tmp3[2]

  if config[2][2]-tonumber(tmp3[5])<0 then
    config[13][10]=-1
    return "LOW BATTERY"
  end

  local sav_conf=false
  local cont_inv = cont_met:get_inventory()
  --***********
  --** BUILD **
  --***********
  if string.find(manutention[7],"B") and string.find(tmp3[4],"B") then
    if manutention[8]==1 then
      --protect
      if minetest.is_protected(pos1,"") then
        config[13][10]=-1
        return "! PROTECTED !"
      end

      local node=minetest.get_node(pos1)

      if node.name=="ignore" then
        config[13][10]=-1
        return "MAP ERROR"
      end

      if node.name=="air" or node.name=="vacuum:vacuum" then --build only if place

        if not cont_inv:contains_item("stock",cible) then
          config[13][10]=-1
          return "STOCK EMPTY"
        end

        cont_inv:remove_item("stock",cible)

        minetest.set_node(pos1,{name=cible})

        config[13][10]=math.ceil(tonumber(tmp3[3])*config[13][12]*0.01)
        config[2][2]=config[2][2]-tonumber(tmp3[5])
      end
      sav_conf=true
    end
  end

  --*********
  --** DIG **
  --*********
  if string.find(manutention[7],"D") and string.find(tmp3[4],"D") then
    if manutention[8]==2 then
      local node=minetest.get_node(pos1)
      if node.name==cible then
        --protect
        if minetest.is_protected(pos1,"") then
          config[13][10]=-1
          return "! PROTECTED !"
        end

        if minetest.get_item_group(node.name,"unbreakable")~=0 then
          config[13][10]=-1
          return "! PROTECTED !"
        end

        local group_cracky=minetest.get_item_group(node.name,"cracky")
        if group_cracky==334 then cible="espace:star_dust" end
        if group_cracky==335 then cible="default:mese_crystal_fragment" end
        --add to controler
        if cont_inv:room_for_item("stock",cible) then
          cont_inv:add_item("stock",cible)
        else
          config[13][10]=-1
          return "STOCK FULL"
        end

        config[13][10]=tonumber(tmp3[3])
        --digg 1 by 1
        minetest.remove_node(pos1)
        config[2][2]=config[2][2]-tonumber(tmp3[5])
      end
      sav_conf=true
    end
  end

  --**********
  --** PUMP **
  --**********
  if string.find(manutention[7],"P") and string.find(tmp3[4],"P") then
    if manutention[8]==3 then
      local node=minetest.get_node(pos1)
      if node.name==cible then
        --protect
        if minetest.is_protected(pos1,"") then
          config[13][10]=-1
          return "! PROTECTED !"
        end
        --add to controler
        local cont_inv = cont_met:get_inventory()
        if cont_inv:room_for_item("stock",cible) then
          cont_inv:add_item("stock",cible)
        else
          config[13][10]=-1
          return "STOCK FULL"
        end

        config[13][10]=tonumber(tmp3[3])
        --pump not remove node ?
        minetest.remove_node(pos1)
        config[2][2]=config[2][2]-tonumber(tmp3[5])
      end
      sav_conf=true
    end
  end

  if sav_conf then
    return
  end

  config[13][10]=-1
  return "BAD COMMAND"
end

--************
--*** jump ***
--************
-- from spacejump to execute jump with my conditions
spacengine.jump = function(cpos, player,channel)
	local cont_met = minetest.get_meta(cpos)
  local cha_cnt=cont_met:get_string("channel")

  local cha_spl=string.split(channel,":")
  channel=cha_spl[1]..":"..cha_spl[2] --recuperation du premier nom

  local cnt_spl=string.split(cha_cnt,":")
  cha_cnt=cnt_spl[1]..":"..cnt_spl[2] --recuperation du premier nom


  if channel==cha_cnt then --valid channel

    if player:get_player_name()~=cnt_spl[2] then return false,"PLAYER NOT CAPTAIN" end

    if spacengine.test_area_ship(cpos,0,channel)==false then return false end

    local config=spacengine.config[channel]
    local pos_cont=spacengine.decompact(cont_met:get_string("pos_cont"))

  if config[4][6]>999 then return false,"WAIT ENGINE TOO HOT" end

  if cpos.y<1028 or cpos.y>10188 then return false,"OUT SPACE" end
  if cpos.x<-30500 or cpos.x>30500 then return false,"OUT SPACE" end
  if cpos.z<-30500 or cpos.z>30500 then return false,"OUT SPACE" end

  if config[1][2]>config[4][7] then return false,"WEIGHT OVERLOAD" end

  local conso,rmax,temperature,check=spacengine.conso_engine(cpos,config)

  if not check then return false,"! OUT of RANGE !" end --destination trop loin

  if config[2][2]-conso<0 then return false,"LOW BAT" end

--recherche jumpdrive
  local rangex=5+tonumber(string.sub(config[1][4],2,2))*2
  local rangey=5+tonumber(string.sub(config[1][4],4,4))*2
  local rangez=5+tonumber(string.sub(config[1][4],6,6))*2

  --SWITCH OFF all
  local list=minetest.find_nodes_in_area({x=cpos.x-rangex,y=cpos.y-rangey,z=cpos.z-rangez},{x=cpos.x+rangex,y=cpos.y+rangey,z=cpos.z+rangez},"bloc4builder:switch_on")
  for i=1,#list do
    dst=minetest.get_node(list[i]) 
    dst_met=minetest.get_meta(list[i])
    local cha_dst=dst_met:get_string("channel")
    local cha_spl=string.split(cha_dst,":")
          
    if cnt_spl[1]==cha_spl[1] then
        bloc4builder.switch_off(list[i],"bloc4builder:switch_off",10)
    end
  end

  local jumpdrive_pos=minetest.find_nodes_in_area({x=cpos.x-rangex,y=cpos.y-rangey,z=cpos.z-rangez},{x=cpos.x+rangex,y=cpos.y+rangey,z=cpos.z+rangez},"jumpdrive:engine")

  if #jumpdrive_pos~=1 then return false,"JumpDrive Error" end

	local radius = math.max(rangex,rangey,rangez)
	local targetPos = {x=config[1][6][1],y=config[1][6][2],z=config[1][6][3]}

  if jumpdrive.check_mapgen(cpos) then
		return false, "Error: mapgen was active in this area, please try again later for your own safety!"
	end

	--local distance = vector.distance(cpos, targetPos)

	local radius_vector = {x=rangex, y=rangey, z=rangez}
	local source_pos1 = {x=cpos.x-rangex,y=cpos.y-rangey,z=cpos.z-rangez}
	local source_pos2 = {x=cpos.x+rangex,y=cpos.y+rangey,z=cpos.z+rangez}
	local target_pos1 = {x=targetPos.x-rangex,y=targetPos.y-rangey,z=targetPos.z-rangez}
	local target_pos2 = {x=targetPos.x+rangex,y=targetPos.y+rangey,z=targetPos.z+rangez}

  local x_overlap = (target_pos1.x <= source_pos2.x and target_pos1.x >= source_pos1.x) or
		(target_pos2.x <= source_pos2.x and target_pos2.x >= source_pos1.x)
	local y_overlap = (target_pos1.y <= source_pos2.y and target_pos1.y >= source_pos1.y) or
		(target_pos2.y <= source_pos2.y and target_pos2.y >= source_pos1.y)
	local z_overlap = (target_pos1.z <= source_pos2.z and target_pos1.z >= source_pos1.z) or
		(target_pos2.z <= source_pos2.z and target_pos2.z >= source_pos1.z)

	if x_overlap and y_overlap and z_overlap then
		return false, "Error: jump into itself! extend your jump target"
	end

	-- load chunk
	minetest.get_voxel_manip():read_from_map(target_pos1, target_pos2)

local blacklisted_pos_list = minetest.find_nodes_in_area(source_pos1, source_pos2, jumpdrive.blacklist)
	for _, nodepos in ipairs(blacklisted_pos_list) do
		return false, "Can't jump node @ " .. minetest.pos_to_string(nodepos)
	end
  local air_found=false
	if minetest.find_nodes_in_area(target_pos1, target_pos2, "air") then
		air_found=true
	end

  local ignore_nb=minetest.find_nodes_in_area(target_pos1, target_pos2, "ignore")
  if #ignore_nb>20 then
    return false, "Warning: Jump-target is in uncharted area "..#ignore_nb
  end

	if jumpdrive.is_area_protected(source_pos1, source_pos2, playername) then
		return false, "Jump-source is protected!"
	end

	if jumpdrive.is_area_protected(target_pos1, target_pos2, playername) then
		return false, "Jump-target is protected!"
	end

	local is_empty, empty_msg = jumpdrive.is_area_empty(target_pos1, target_pos2)

	if not is_empty then
		return false,"Jump-target is obstructed " .. empty_msg
	end

--  temperature=temperature+config[4][6]
  --modif consommation, température
  config[2][2]=config[2][2]-conso
  config[4][6]=temperature+config[4][6]
  --sauvegarde old pos controler
  config[1][5][1]=cpos.x
  config[1][5][2]=cpos.y
  config[1][5][3]=cpos.z
  --sauvegarde new pos controler
  pos_cont[1]=targetPos.x
  pos_cont[2]=targetPos.y
  pos_cont[3]=targetPos.z

  config[12]="y"
  --config[1][7]=0
  --sauvegarde data
  cont_met:set_string("pos_cont",spacengine.compact(pos_cont))
  cont_met:set_string("config",spacengine.compact(config))
  --spacengine.test_area_ship(cpos,1,channel)

minetest.sound_play("spacengine_jump", {
		to_player = pl_name,
		gain = 1,
    max_hear_distance = 50
	})

	local t0 = minetest.get_us_time()

  --before jump change gravity to prevent falling
  fxadd(player,"jumpdrive",4,0,0,10)

	-- actual move
	jumpdrive.move(source_pos1, source_pos2, target_pos1, target_pos2)

  --replace vacuum --> air (si saut dans un atelier ou hangar)
  if air_found then
    worldedit.replace(target_pos1, target_pos2, "vacuum:vacuum", "air", false)
  end

-- show animation in source
	minetest.add_particlespawner({
		amount = 200,
		time = 2,
		minpos = source_pos1,
		maxpos = source_pos2,
		minvel = {x = -2, y = -2, z = -2},
		maxvel = {x = 2, y = 2, z = 2},
		minacc = {x = -3, y = -3, z = -3},
		maxacc = {x = 3, y = 3, z = 3},
		minexptime = 0.1,
		maxexptime = 5,
		minsize = 1,
		maxsize = 1,
		texture = "spark.png",
		glow = 5,
	})


	-- show animation in target
	minetest.add_particlespawner({
		amount = 200,
		time = 2,
		minpos = target_pos1,
		maxpos = target_pos2,
		minvel = {x = -2, y = -2, z = -2},
		maxvel = {x = 2, y = 2, z = 2},
		minacc = {x = -3, y = -3, z = -3},
		maxacc = {x = 3, y = 3, z = 3},
		minexptime = 0.1,
		maxexptime = 5,
		minsize = 1,
		maxsize = 1,
		texture = "spark.png",
		glow = 5,
	})

--maj nouvelle position dans la liste
spacengine.test_area_ship(targetPos,1,channel)

spacengine.maj_channel(targetPos,channel,0)

spacengine.save_area()

	local t1 = minetest.get_us_time()
	local time_micros = t1 - t0

	return true
end
return false
end
