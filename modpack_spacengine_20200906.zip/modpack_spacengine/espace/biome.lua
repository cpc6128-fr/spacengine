local param_perlin_heat={
        offset=50,
        scale=50,
        spread={x=1000,y=1000,z=1000},
        seed=5349,
        octaves=3,persist=0.5,
        lacunarity=2,
        flags="default"}

--*** determine temperature biome ***
espace.biome=function(biome_n,p)
    
  local month,day
  local coef=espace.coef
  if coef==nil then coef=1 end
  local hygro=espace.hygro
  if hygro==nil then hygro=0 end
  local hour = math.floor(minetest.get_timeofday() * 24)
  local biome_temp,x
  local meteo="clear"

  if biome_n=="x" or biome_n=="X" then --earth

    if biome_n=="x" then
      biome_temp=math.floor(minetest.get_perlin(param_perlin_heat):get2d({x=p.x,y=p.z}))
    else
      biome_temp=50
    end

    local biome_t
        
    if biome_temp<41 then    --froid
      biome_temp=-13
      biome_t=0
      month=(coef*17)
      day=-math.cos(hour*0.26-1)*((coef*0.5+0.5)+3)
      x=hygro*0.5*((coef*0.5+0.5)+3)
    end
        
    if biome_temp>40 and biome_temp<81 then   --tempere
      biome_temp=12.5
      biome_t=1
      month=(coef*13)
      day=-math.cos(hour*0.26)*((coef*0.5+0.5)*3.75+2.5) --delta 3.75 min 2.5
      x=hygro*0.5*((coef*0.5+0.5)*4+4)
    end
        
    if biome_temp>80 and biome_temp<101 then    --tropical savanne
      biome_temp=30
      biome_t=2
      month=(coef*5)
      day=-math.cos(hour*0.26)*((coef*0.5+0.5)*5+1.5)
      x=hygro*0.5*((coef*0.5+0.5)*2.5+2.5)
    end
        
    if biome_temp>100 then    --desert
      biome_temp=40
      biome_t=3
      month=coef
      day=-math.cos(hour*0.26)*((coef*0.5+0.5)*2.5+7.5)
      x=hygro*0.5*((coef*0.5+0.5)+1)
    end

    biome_temp=biome_temp + month + day - x

    if hygro>0.5 then
            meteo="weather_cloud"
            --blizzard
            if biome_temp>-30 and biome_temp<-25 then
                meteo="weather_snow_storm"
            end
            
            if biome_temp>-9 and biome_temp<-5 then
                meteo="weather_snow_storm"
            end
            --snow
            if biome_temp>-3 and biome_temp<4 then
                meteo="weather_snow"
            end
            
            --pluie
            if biome_temp>5 and biome_temp<10 and espace.month==3 then
                meteo="weather_rain"
            end
            
            if biome_temp>9 and biome_temp<15 then
                meteo="weather_rain"
            end
            
            if biome_temp>17 and biome_temp<20 then
                meteo="weather_rain"
            end
          
            --orage
            if biome_temp>29 and biome_temp<36 and biome_t==1 then
                meteo="weather_storm"
            end
            
            if biome_temp>36 and biome_temp<39 and biome_t==2 then
                meteo="weather_storm"
            end
        end
        -- temps couvert sans pluie
        if hygro<0.51 then
            meteo="weather_cloud"
        end
        -- temps dégagé
        if hygro<0.26 then
            meteo="clear"
        end

  elseif biome_n=="u" or biome_n=="U" then -- underground
    biome_temp=7
    month=coef
    day=-math.cos(hour*0.26)*((coef*0.5+0.5)*2.5+7.5)
    x=hygro*0.5*((coef*0.5+0.5)+1)
    biome_temp=biome_temp + month + day - x

  elseif biome_n=="e" or biome_n=="E" then -- espace
    biome_temp=-180
    month=coef
    day=-math.cos(hour*0.26)*((coef*0.5+0.5)*2.5+7.5)
    x=hygro*0.5*((coef*0.5+0.5)+1)
    biome_temp=biome_temp + month + day - x

  elseif biome_n=="c" or biome_n=="C" then -- cold
    biome_temp=-13
    -- month = temp. maxi et mini du biome (13-> -13 en hiver a +13 en ete)
    month=(coef*17)
    -- day = delta et mini  ((coef*0.5+0.5)*delta+mini) mini=temp min en hiver delta+mini=temp max en ete
    day=-math.cos(hour*0.26-1)*((coef*0.5+0.5)+3)
    -- x = temp. suivant hygrometrie delta+mini
    x=hygro*0.5*((coef*0.5+0.5)+3)
    biome_temp=biome_temp + month + day - x

    if biome_n=="C" then
    if hygro>0.5 then
      meteo="weather_cloud"
      --blizzard
      if biome_temp>-35 and biome_temp<-25 then
        meteo="weather_snow_storm"

      elseif biome_temp>-15 and biome_temp<-10 then
        meteo="weather_snow_storm"
      
      --snow
      elseif biome_temp>-5 and biome_temp<4 then
        meteo="weather_snow"
            
      --pluie
      elseif biome_temp>9 and biome_temp<15 then
        meteo="weather_rain"
      end
    end
    -- temps couvert sans pluie
    if hygro<0.51 then
      meteo="weather_cloud"
    end
    -- temps dégagé
    if hygro<0.26 then
      meteo="clear"
    end
    end

  elseif biome_n=="t" or biome_n=="T" then -- temperate
    biome_temp=12.5
    month=(coef*13)
    day=-math.cos(hour*0.26)*((coef*0.5+0.5)*3.75+2.5) --delta 3.75 min 2.5
    x=hygro*0.5*((coef*0.5+0.5)*4+4)
    biome_temp=biome_temp + month + day - x

    if biome_n=="T" then
    if hygro>0.5 then
      meteo="weather_cloud"
      --blizzard
      if biome_temp>-30 and biome_temp<-25 then
        meteo="weather_snow_storm"

      elseif biome_temp>-9 and biome_temp<-5 then
        meteo="weather_snow_storm"
      
      --snow
      elseif biome_temp>-3 and biome_temp<4 then
        meteo="weather_snow"
            
      --pluie
      elseif biome_temp>5 and biome_temp<10 and espace.month==3 then
        meteo="weather_rain"

      elseif biome_temp>9 and biome_temp<15 then
        meteo="weather_rain"

      elseif biome_temp>17 and biome_temp<20 then
        meteo="weather_rain"

      --orage
      elseif biome_temp>29 and biome_temp<36 and biome_n==1 then
        meteo="weather_storm"

      elseif biome_temp>36 and biome_temp<39 and biome_n==2 then
        meteo="weather_storm"
      end
    end
    -- temps couvert sans pluie
    if hygro<0.51 then
      meteo="weather_cloud"
    end
    -- temps dégagé
    if hygro<0.26 then
      meteo="clear"
    end
    end

  elseif biome_n=="j" or biome_n=="J" then -- jungle
    biome_temp=30
    month=(coef*5)
    day=-math.cos(hour*0.26)*((coef*0.5+0.5)*5+1.5)
    x=hygro*0.5*((coef*0.5+0.5)*2.5+2.5)
    biome_temp=biome_temp + month + day - x

    if biome_n=="J" then
    if hygro>0.5 then
      meteo="weather_cloud"
      --blizzard
      if biome_temp>20 and biome_temp<25 then
        meteo="weather_storm"

      elseif biome_temp>35 and biome_temp<40 then
        meteo="weather_storm"

      --pluie
      elseif biome_temp>9 and biome_temp<15 then
        meteo="weather_rain"
      end
    end
    -- temps couvert sans pluie
    if hygro<0.51 then
      meteo="weather_cloud"
    end
    -- temps dégagé
    if hygro<0.26 then
      meteo="clear"
    end
    end

  elseif biome_n=="s" or biome_n=="S" then -- solar
    biome_temp=180
    month=coef
    day=-math.cos(hour*0.26)*((coef*0.5+0.5)*10.5+7.5)
    x=hygro*0.5*((coef*0.5+0.5)+1)
    biome_temp=biome_temp + month + day - x

    if biome_n=="D"  then
      if hygro>0.9 then
        meteo="weather_meteor"
      else
        meteo="clear"
      end
    end

  elseif biome_n=="d" or biome_n=="D" then -- desert
    biome_temp=25
    month=coef
    day=-math.cos(hour*0.26)*((coef*0.5+0.5)*25)
    x=hygro*0.5*((coef*0.5+0.5)+1)
    biome_temp=biome_temp + month + day - x

    if biome_n=="D"  then
      if hygro>0.9 then
        meteo="weather_dust"
      else
        meteo="clear"
      end
    end

  elseif biome_n=="n" or biome_n=="N" then --neutral
    biome_temp=18
    month=coef
    day=-math.cos(hour*0.26)*((coef*0.5+0.5)*2+2)
    x=hygro*0.5*((coef*0.5+0.5)*4+4)
    biome_temp=biome_temp + month + day - x

    if biome_n=="N" then
      if hygro>0.9 then
        meteo="weather_dust"
      else
        meteo="clear"
      end
    end

  elseif biome_n=="m" or biome_n=="M" then --style mars
    biome_temp=15
    month=(coef*15)
    day=-math.cos(hour*0.26)*((coef*0.5+0.5)*3.75+2.5)
    x=hygro*0.5*((coef*0.5+0.5)*4+4)
    biome_temp=biome_temp + month + day - x

    if biome_n=="M" then
      if hygro>0.9 then
        meteo="weather_dust"
      else
        meteo="clear"
      end
    end

  elseif biome_n=="r" or biome_n=="R" then --rain
    biome_temp=10
    month=(coef*15)
    day=-math.cos(hour*0.26)*((coef*0.5+0.5)*3.75+2.5)
    x=hygro*0.5*((coef*0.5+0.5)*4+4)
    biome_temp=biome_temp + month + day - x

    if biome_n=="R" then
      if hygro>0.8 then
        meteo="weather_rain"
      elseif hygro>0.5 then
        meteo="weather_cloud"
      else
        meteo="clear"
      end
    end

  end

  return biome_temp,meteo
end

--** fonction pour l'heure **
local function floormod(x,y)
    return (math.floor(x) % y)
end

--*****************************
-- Sets Month and length of day
--*****************************
                            
local timescale = 140 -- vitesse du defilement du temps
       
-- Set days
local jour = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"}

-- Set months
local mois = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"}

local startest_meteo="on" --active meteo

--Day Night Speeds (Thanks to sofar for this)
local dc = tonumber(espace.day)      --date day
local mc = tonumber(espace.month)    --date month
local x = ((mc-1)*14)+dc                       --calcul nb jour
espace.coef=math.sin(((x/168)-0.34)*6.28)
--
-- sinus  petit ratio en hiver et grand ratio en ete (jour long en ete)
local ratio=math.sin((x/168)*3.14) ^ 2
--
-- nuit plus rapide
local nightratio = math.floor(timescale*(0.5+ratio))
-- jour plus long
local dayratio =  math.floor(timescale*(1.5-ratio))
local leversoleil=4000+((1-ratio)*4000)
local couchsoleil=16000+(ratio*4000)
--vitesse en journée
local vitesse_horloge=12000/(couchsoleil-leversoleil)


local decal1=math.random(1,9) -- quand changement d'année ou arriver dans le jeu, valeur de decalage de la
local decal2=math.random(1,9)
local decal3=math.random(1,9) -- depression pour ne pas avoir la meme meteo chaque année

local timer1 = 0
local timer2 = 0

local startest_daystate = 3  --determine matin ou apres midi 0 soir 1 matin 2 jour 3 arriver dans le jeu
-- _______________________________________________________________________________

-- +++++++++++++++++++++++++++++++++++++++++
-- ++ fonction principale meteo and month ++
-- +++++++++++++++++++++++++++++++++++++++++

minetest.register_globalstep(function(dtime)    --horloge month

  timer1 = timer1 + dtime -- date & civilisation
  timer2 = timer2 + dtime -- meteo

  if timer1 > 5 then --5 sec ** test heure du jour
  timer1=0
--[[
  if espace.epidemic~="off" then
    espace.epidemic_time=espace.epidemic_time-1
    if espace.epidemic_time<1 then
      espace.epidemic="off"
    end
  end
--]]
  -- +++++++++++++++++++++++++++++++
  -- ++ calcul du jour de l'année ++
  -- +++++++++++++++++++++++++++++++
  local time_in_seconds = minetest.get_timeofday() * 24000

  -- si reprise du jeu
  if startest_daystate>2 then
            
    if time_in_seconds>17999 then
      startest_daystate=2    --soir
    end
            
    if time_in_seconds>5999 and time_in_seconds<18000 then
      startest_daystate=1    --journée
    end
            
    if espace.day>7 then -- nom du jour
      espace.day_name = jour[espace.day-7]
    else
      espace.day_name = jour[espace.day]
    end

    espace.month_name = mois[espace.month]
  end
  
  -- journée
  if time_in_seconds > 5999 and time_in_seconds<18000 then  --test si l'horloge compris entre 6h et 18h
    if startest_daystate == 1 then                                   -- test si journée
      --citymap.civ_found()
      minetest.settings:set("time_speed", dayratio)         -- et changement timer
      if espace.day>7 then
        espace.day_name = jour[espace.day-7]
      else
        espace.day_name = jour[espace.day]       -- nom du jour
      end
      vitesse_horloge=12000/(couchsoleil-leversoleil)
      espace.month_name = mois[espace.month]
      minetest.chat_send_all("Good Morning! It is "..espace.day_name .." ".. (espace.day*2) .." ".. espace.month_name .." ".. espace.year)
      startest_daystate=2    --prochain etat soir
      espace.save_table()
    end
  end
  
  -- soir
  if time_in_seconds>17999 and time_in_seconds<24001 then
    if startest_daystate == 2 then --si soir
      --citymap.civ_found()
      minetest.settings:set("time_speed", nightratio)       --changement timer pour soir
      startest_daystate=0 --passage en etat matin
      vitesse_horloge=12000/((24000-couchsoleil)+leversoleil)
    end
  end
  
  -- matin
  if time_in_seconds>0 and time_in_seconds<6001 then
    if startest_daystate==0 then --si matin
      --citymap.civ_found()
      espace.day = espace.day + 1      --incrementation jour 
      if espace.day > 14 then --si jour superieur a 14
        espace.month = espace.month + 1 --incrementation des mois
        espace.day = 1 -- reset jour
      end
      -- reset compteur mois si superieur a 12
      if espace.month > 12 then -- si fin d'année
        espace.month=1 -- reset mois
        espace.year=espace.year+1
        minetest.chat_send_all("Happy new year ".. espace.year .." !!!")
      end
    end

    --Day Night Speeds
    if startest_daystate==0 or startest_daystate==3 then -- si arriver dans le jeu ou matin
      startest_daystate=1 --passage en etat journée
      dc = tonumber(espace.day)      --date day
      mc = tonumber(espace.month)    --date month
      x = ((mc-1)*14)+dc               --calcul nb jour
      ratio=math.sin((x/168)*3.14) ^ 2
      -- nuit plus rapide
      nightratio = math.floor(timescale*(0.5+ratio))
      -- jour plus long
      dayratio =  math.floor(timescale*(1.5-ratio))
      leversoleil=4000+((1-ratio)*4000)
      couchsoleil=16000+(ratio*4000)
      minetest.settings:set("time_speed", nightratio)       --changement timer pour matin
      vitesse_horloge=12000/((24000-couchsoleil)+leversoleil)
--[[
      if espace.epidemic=="off" then
        local tmp=math.random(1,500)
        if tmp<5 then
          espace.epidemic="crazy"
          espace.epidemic_time=math.random(50,300)
          minetest.chat_send_all("!! EPIDEMIC !! [CRAZY MOBS]")
        elseif tmp>100 and tmp<105 then
          espace.epidemic="peste"
          espace.epidemic_time=math.random(50,300)
          minetest.chat_send_all("!! EPIDEMIC !! [PESTE]")
        elseif tmp>200 and tmp<205 then
          espace.epidemic="peacefull"
          espace.epidemic_time=math.random(50,300)
          minetest.chat_send_all("!! EPIDEMIC !! [PEACEFULL]")
        elseif tmp>300 and tmp<305 then
          espace.epidemic="h1n1"
          espace.epidemic_time=math.random(50,300)
          minetest.chat_send_all("!! EPIDEMIC !! [H1N1]")
        elseif tmp>400 and tmp<405 then
          espace.epidemic="madcow"
          espace.epidemic_time=math.random(50,300)
          minetest.chat_send_all("!! EPIDEMIC !! [MADCOW]")
        elseif tmp>495 then
          espace.epidemic="zombiland"
          espace.epidemic_time=math.random(50,300)
          minetest.chat_send_all("!! EPIDEMIC !! [ZOMBILAND]")
        end
      end
--]]
    end
  end

  end

  --meteo
  if timer2>5 then
    timer2=0
    -- meteo commun au serveur
    local day = tonumber(espace.day)-1
    local month = tonumber(espace.month)-1
    local hour = math.floor(minetest.get_timeofday() * 24)
    --calcul nb heure
    local x = ((month*14)+day)*24+hour
    -- coeficient entre hiver et ete
    espace.coef=math.sin(((x/4032)-0.3)*6.28)
    espace.hygro=math.cos(decal1+x*0.26)*1.25+math.sin(decal2+x*0.085)*0.50+math.cos(decal3+x*0.035)*0.25

    for nb, player in ipairs(minetest.get_connected_players()) do
      local ppos = player:getpos()
      local playername = player:get_player_name()

      -- ****************************
      -- ** determination du biome **
      -- ****************************
      local temp,new_weather=espace.biome(espace.data[playername].biome,ppos)
      espace.data[playername].temp=temp
      espace.data[playername].new_meteo=new_weather
    end
  end

end)


-- ***********************************
-- ** affichage temperature et time **
-- ***********************************
espace.horloge=function(player)
  local sec = (86400*minetest.env:get_timeofday());
  --calcul heure et minute pour afichage time
  if sec<21600 then
    sec=sec/vitesse_horloge  --si matin
  elseif sec>21599 and sec<64800 then
    sec=((sec-21600)/vitesse_horloge)+(leversoleil*3.6)  --si jour
  elseif sec>63799 then
    sec=((sec-64800)/vitesse_horloge)+(couchsoleil*3.6) --si soir
  end
  local mn = floormod(sec/60, 60);
  local hr = floormod(sec/3600, 60);
  local playername = player:get_player_name()
      
  if espace.data[playername].hud ~= nil then
    -- couleur du texte suivant temperature froid=blue chaud=red normal=green
    local nb=0x00FF00
    if espace.data[playername].temp>38 then
      nb=0xFF0000
    elseif espace.data[playername].temp<5 then
      nb=0x0000FF
    end
    local hurt = math.ceil(0.2*tonumber(player:get_attribute("fatigue")))
    local h=(espace.day*2) .."/".. espace.month .."/".. espace.year .."\n".. string.format("%02d",hr) ..":".. string.format("%02d",mn) .."\nT.".. math.ceil(espace.data[playername].temp) .."°C\n".. hurt .."%"
    player:hud_change(espace.data[playername].hud,"text",h)
    player:hud_change(espace.data[playername].hud,"number",nb)
  end
end


minetest.register_chatcommand("priv", {
	params = "",
	description = "priv atroport number",

	func = function(name, param)

    if espace.data[name].priv==nil then
      espace.data[name].priv={}
    end
    table.insert(espace.data[name].priv,param)

minetest.chat_send_player(name,"privilege astroport n.secteur : ".. param)
espace.setpriv(name)
end
})
