-- Do files
espace = {}
espace.data={}
local mp=minetest.get_modpath("espace")
dofile( mp.. "/data.lua")
dofile(mp .. "/nodes.lua")
dofile(mp .. "/deco.lua")
dofile(mp .. "/vacuum.lua")
dofile(mp .. "/planete.lua")
dofile(mp .. "/spacemap.lua")
dofile(mp .. "/routine.lua")
dofile(mp .. "/fx.lua")
dofile(mp .. "/hurt.lua")

if not minetest.get_modpath("moreores") then
  dofile(minetest.get_modpath("espace").."/compatible/moreores.lua")
end

if not minetest.get_modpath("moretrees") then
  dofile(minetest.get_modpath("espace").."/compatible/moretrees.lua")
end

if not minetest.get_modpath("moreplants") then
  dofile(minetest.get_modpath("espace").."/compatible/moreplants.lua")
end

if not minetest.get_modpath("verger") then
  dofile(minetest.get_modpath("espace").."/compatible/verger.lua")
end

if not minetest.get_modpath("technic") then
  dofile(minetest.get_modpath("espace").."/compatible/technic.lua")
end

if not minetest.get_modpath("gems") then
  dofile(minetest.get_modpath("espace").."/compatible/gems.lua")
end

if not minetest.get_modpath("cg_decor") then
  dofile(minetest.get_modpath("espace").."/compatible/cg_decor.lua")
end

if not minetest.get_modpath("protector") then
  dofile(minetest.get_modpath("espace").."/compatible/protector.lua")
end

if minetest.get_modpath("mobs") then
  dofile(minetest.get_modpath("espace").."/compatible/spawner.lua")
end

--dofile(minetest.get_modpath("espace").."/energy.lua") --petrole methane

--**********************
--** init data player **
--**********************
-- Save table to file
function espace.save_table()

	local data = {day=espace.day, month=espace.month, year=espace.year, build_dt=espace.build_dt, epidemic=espace.epidemic, epidemic_time=espace.epidemic_time}
	local f, err = io.open(minetest.get_worldpath() .. "/espace_data", "w")

	if err then
		return err
	end

	f:write(minetest.serialize(data))
	f:close()
end

-- Reads saved file
function espace.read_startest()

	local f, err = io.open(minetest.get_worldpath() .. "/espace_data", "r")
	local data = minetest.deserialize(f:read("*a"))

	f:close()

	return data
end

minetest.register_on_shutdown(function()
		espace.save_table()
end)

-- Check to see if file exists and if not sets default values.
local f, err = io.open(minetest.get_worldpath().."/espace_data", "r")

if f == nil then

	espace.day = 1
	espace.month = 6
  espace.year = 2019
  espace.build_dt = 0
  espace.epidemic="off"
	espace.epidemic_time=0
  espace.save_table()

else
  local filedata=espace.read_startest()
	espace.day = filedata.day
	espace.month = filedata.month
  espace.year = filedata.year
  espace.build_dt = filedata.build_dt or 0
  --if espace.build_dt==nil then startest.build_dt=0 end
  if filedata.epidemic==nil then
    espace.epidemic="off"
    espace.epidemic_time=0
  else
    espace.epidemic=filedata.epidemic
    espace.epidemic_time=filedata.epidemic_time
  end

end

minetest.register_on_joinplayer(function(player)
    local playername=nil

    if not player or player.is_fake_player then
        return
    end
   
	playername = player:get_player_name()
   
	if espace.data[playername] == nil then
		espace.data[playername] = {}
	end

  if not player:get_attribute("fatigue") then player:set_attribute("fatigue","500") end

  atm.readaccounts()
  if not atm.balance[playername] then
    atm.balance[playername] = 30--300000 --test only
  end

    local sec = (86400*minetest.env:get_timeofday());
    local mn = math.floor(sec/60) % 60;
    local hr = math.floor(sec/3600) % 60;
    local nb=0x00FF00
    local h=(espace.day*2).."/"..espace.month.."/"..espace.year.."\n"..string.format("%02d",hr)..":"..string.format("%02d",mn).."\nT. 20°C"
    
    local affichage = player:hud_add({
    hud_elem_type = "text";
    position = {x=0.1, y=0.91};
    text = h;
    number = nb;
    scale = 20;
    });

    espace.data[playername] = {temp=20, meteo="clear", radiation=20, oxygen=true, biome="n",  hud=affichage,  bloc_protect=false, bloc=999, secteur=0,skytype=2,old_biome="n",new_meteo="clear"}
    espace.getpriv(playername)
    player:set_attribute("sound_meteo",nil) --reset sound

end)


minetest.register_on_leaveplayer(function(player)
  --stop sound et reset sound player
  local sound_nb=player:get_attribute("sound_meteo")
  if sound_nb then
    minetest.sound_stop(tonumber(sound_nb))
    player:set_attribute("sound_meteo",nil)
  end

  local name = player:get_player_name()
  espace.data[name]=nil
end)

minetest.register_on_respawnplayer(function(player)
  player:set_attribute("fatigue","500")
end)

dofile(mp .. "/biome.lua")
dofile(mp .. "/gestion_layer.lua")
dofile(mp .. "/stargate_univers.lua")
dofile(mp .. "/weather.lua")
