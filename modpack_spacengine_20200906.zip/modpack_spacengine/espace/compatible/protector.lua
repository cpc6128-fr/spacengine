-- Infolevel:
-- 0 for no info
-- 1 for "This area is owned by <owner> !" if you can't dig
-- 2 for "This area is owned by <owner>.
-- 3 for checking protector overlaps

espace.can_dig = function(pos, digger, onlyowner)

	if not digger or not pos then
		return false
	end

	-- protector_bypass privileged users can override protection
	if minetest.check_player_privs(digger, {protection_bypass = true}) then
		return true
	end

	-- find the protector nodes
	local pos = minetest.find_nodes_in_area(
		{x = pos.x - 5, y = pos.y - 5, z = pos.z - 5},
		{x = pos.x + 5, y = pos.y + 5, z = pos.z + 5},
		{"protector:protect", "protector:protect2"})

	local meta, owner, members

	for n = 1, #pos do

		meta = minetest.get_meta(pos[n])
		owner = meta:get_string("owner") or ""
		members = meta:get_string("members") or ""
    
    if owner=="" then
      owner="admin"
      meta:set_string("owner","admin")
    end

		-- node change and digger isn't owner
		if owner ~= digger then

			-- and you aren't on the member list
			if onlyowner then

				minetest.chat_send_player(digger,"This area is owned by "..owner.. "!")

				return false
			end
		end
	end

	return true
end


local old_is_protected = minetest.is_protected

-- check for protected area, return true if protected and digger isn't on list
function minetest.is_protected(pos, digger)

	digger = digger or "" -- nil check
  if (creative and creative.is_enabled_for and creative.is_enabled_for(digger)) then return old_is_protected(pos, digger) end

	-- is area protected against digger?
	if not espace.can_dig(pos, digger, false) then

		if player and player:is_player() then

			-- flip player when protection violated

				-- yaw + 180°
				local yaw = player:get_look_horizontal() + math.pi

				if yaw > 2 * math.pi then
					yaw = yaw - 2 * math.pi
				end

				player:set_look_horizontal(yaw)

				-- invert pitch
				player:set_look_vertical(-player:get_look_vertical())

				-- if digging below player, move up to avoid falling through hole
				local pla_pos = player:get_pos()

				if pos.y < pla_pos.y then

					player:set_pos({
						x = pla_pos.x,
						y = pla_pos.y + 0.8,
						z = pla_pos.z
					})
				end
		end

		return true
	end

	-- otherwise can dig or place
	return old_is_protected(pos, digger)
end

-- protection node
minetest.register_node(":protector:protect", {
	description = "Protection Block (USE for area check)",
	drawtype = "nodebox",
	tiles = {
		"default_stone.png^protector_overlay.png",
		"default_stone.png^protector_overlay.png",
		"default_stone.png^protector_overlay.png^protector_logo.png"
	},
	sounds = default.node_sound_stone_defaults(),
	groups = {dig_immediate = 2, unbreakable = 1, not_in_creative_inventory=1},
	is_ground_content = false,
	paramtype = "light",
	light_source = 4,

	node_box = {
		type = "fixed",
		fixed = {
			{-0.5 ,-0.5, -0.5, 0.5, 0.5, 0.5},
		}
	},

	after_place_node = function(pos, placer)

		local meta = minetest.get_meta(pos)

		meta:set_string("owner", "admin")
		meta:set_string("infotext", "Admin Protection")
		meta:set_string("members", "")
	end,

	on_blast = function() end,
})



-- protection logo
minetest.register_node(":protector:protect2", {
	description = "Protection Logo (USE for area check)",
	tiles = {"protector_logo.png"},
	wield_image = "protector_logo.png",
	inventory_image = "protector_logo.png",
	sounds = default.node_sound_stone_defaults(),
	groups = {dig_immediate = 2, unbreakable = 1, not_in_creative_inventory=1},
	paramtype = "light",
	paramtype2 = "wallmounted",
	legacy_wallmounted = true,
	light_source = 4,
	drawtype = "nodebox",
	sunlight_propagates = true,
	walkable = true,
	node_box = {
		type = "wallmounted",
		wall_top    = {-0.375, 0.4375, -0.5, 0.375, 0.5, 0.5},
		wall_bottom = {-0.375, -0.5, -0.5, 0.375, -0.4375, 0.5},
		wall_side   = {-0.5, -0.5, -0.375, -0.4375, 0.5, 0.375},
	},
	selection_box = {type = "wallmounted"},

	after_place_node = function(pos, placer)

		local meta = minetest.get_meta(pos)
    
		meta:set_string("owner", "admin")
		meta:set_string("infotext", "Admin Protection")
		meta:set_string("members", "")
	end,

  on_blast = function() end,
})
