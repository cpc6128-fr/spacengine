--*****************
--** node coffre **
--*****************

minetest.register_node("commerce:xpchest", {
	description = "coffre",
    tiles = {
		"caisse_top.png",
        "caisse_top.png",
        "caisse.png",
        "caisse.png",
        "caisse_xp.png",
        "caisse_xp.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
  paramtype2 = "facedir",
	groups = {cracky=2, chest=4},
	is_ground_content = false,
  on_construct = function(pos)
    local size=math.random(2,8)*10+math.random(2,4)
    espace.fill_chest(pos,size,"x")
  end,

  allow_metadata_inventory_take=function(pos,listname,index,stack,player)
    local name=player:get_player_name()
    local xp=xpgetlvl(player,"xp_lvl")+1
    local item_name=stack:get_name()

    --recherche objet
    local nb_obj = #commerce.item
    local out=2
    local obj_recherche
   
    repeat
      obj_recherche=commerce.item[nb_obj]  --recuperation des données
   
      if item_name==obj_recherche[2] then
        nb_obj=1
        if xp>obj_recherche[6] then
          out=1
        else
          out=2
        end
      end
   
      nb_obj=nb_obj-1
    until nb_obj<1
   
    if out==2 then
      minetest.chat_send_player(name,"sorry, not enought XP")
      return 0
    end
   
    return stack:get_count()
  end,
  on_rotate = screwdriver.rotate_simple,
--[[
  can_dig = function(pos,player)
    local meta = minetest.get_meta(pos);
		local inv = meta:get_inventory()
		return inv:is_empty("main")
  end,--]]
  drop = 'default:dirt'
})
