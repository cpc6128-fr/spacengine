--******************
--*** test owner ***
--******************
--pos=coordo du controler / 0 false(inconu) 1 acheteur 2 owner(capitaine) 3 guest(equipage)
spacengine.owner_check=function(player,pos,vente)

  if vente==nil then vente="" end

  local nod_met = minetest.get_meta(pos)
  local node=minetest.get_node(pos)
  local name=player:get_player_name()
  local channel=nod_met:get_string("channel")

  if channel=="" then --channel error
    channel="No channel:"..name
    nod_met:set_string("channel",channel)
  end

  local split_ch=string.split(channel,":")

  local nb_owner=#split_ch
  local out=0

  if split_ch[2]==name then
    out=2

  else

    if nb_owner>2 then
      for i=3,nb_owner do
        if split_ch[i]==name then
          out=3
          break
        end
      end
    end

  end

  if out>1 then return out end

  if vente~="" or split_ch[2]=="noplayer" then return 1 end

  return 0
end

--transforme pos {x,y,z} --> position "xxxxx:yyyyy:zzzzz"
spacengine.pts=function(pos)
  local position=tostring(math.floor(pos.x))..":"..tostring(math.floor(pos.y))..":"..tostring(math.floor(pos.z))
  return position
end
--transforme position "xxxxx:yyyyy:zzzzz" --> pos {x,y,z}
spacengine.ptn=function(position)
  local pos={x=0,y=0,z=0}
  local list=string.split(position,":")
  pos.x=tonumber(list[1])
  pos.y=tonumber(list[2])
  pos.z=tonumber(list[3])
  return pos
end

spacengine.conso_engine=function(cpos,config,option)
  if option==nil then option=0 end
  local coef_r=0
  if config[4][7]>0 then coef_r=config[4][3]/config[4][7] end
  local rmax=math.ceil((((config[4][7]-config[1][2])*coef_r)+config[4][3])*config[4][2]*0.01)  

  if rmax<0 then rmax=0 end

  if option==1 then return rmax end

  local distance={x=math.abs(cpos.x-config[1][6][1]),y=math.abs(cpos.y-config[1][6][2]),z=math.abs(cpos.z-config[1][6][3])}
  distance.max=math.max(distance.x,distance.y,distance.z)

  local puissance=math.ceil(config[4][1]*config[4][2]*0.01)
  local coef_p=config[4][7]*config[4][1]
  if coef_p>0 then coef_p=1/coef_p  end
  local volume=tonumber(string.sub(config[1][4],8,11))
  local conso=math.ceil((coef_p*(config[1][2]*puissance))*(distance.max*volume*0.1))
  conso=conso+config[4][1]--*config[4][8])

  if option==2 then return conso,rmax,distance.max end

  local coef_t=config[4][1]*config[4][3]*config[4][7]

  if coef_t>0 then coef_t=8000/coef_t end
  local temperature=math.ceil(coef_t*(puissance*distance.max*math.min(config[4][7],config[1][2])))+2000
--minetest.chat_send_all(temperature.." "..distance.max)  
  if distance.max>rmax then return conso,rmax,temperature,false end

  return conso,rmax,temperature,true
end

spacengine.transaction=function(player,stack,card)
  local name=player:get_player_name()
  local inv = player:get_inventory()
  --local havecard=citymap.found_item_index(player,"citymap:card")

  --if havecard>0 then --si card presente
    if atm.balance[name]~= nil then
      if atm.balance[name]-card>0 then
        atm.balance[name] = atm.balance[name]-card
        if stack~=nil then inv:add_item("main",stack) end
        atm.saveaccounts()
        --minetest.sound_play("card2",{to_player=name,gain=2})
        minetest.chat_send_player(name,"Account : ".. atm.balance[name])
        return true
      end
    end
  --end
  return false
end

--********************
--** PLace SpaceShip **
--********************
spacengine.place_ship=function(cpos,filename,player,channel,option)
--channel="goldo:singleplayer:papi:jooj"

  filename = minetest.get_modpath("spacengine").."/schems/"..filename ..".mts"
  --lecture du MTS
  local file_dat = io.open(filename)
  local value = file_dat:read(12)--("*a")
  file_dat:close()

  local rangex = string.byte(string.sub(value, 8, 8)) + (string.byte(string.sub(value, 7, 7)) * 256)
  local rangey = string.byte(string.sub(value, 10, 10)) + (string.byte(string.sub(value, 9, 9)) * 256)
  local rangez = string.byte(string.sub(value, 12, 12)) + (string.byte(string.sub(value, 11, 11)) * 256)
  local volume=rangex*rangey*rangez
  rangex=math.floor(rangex/2)
  rangey=math.floor(rangey/2)
  rangez=math.floor(rangez/2)
  local rx=(rangex-5)/2
  local ry=(rangey-5)/2
  local rz=(rangez-5)/2
  

  --controler center
  local pos1={x=cpos.x-rangex,y=cpos.y-rangey,z=cpos.z-rangez}
  local pos2={x=cpos.x+rangex,y=cpos.y+rangey,z=cpos.z+rangez}
  
  minetest.place_schematic(pos1, filename, "0", nil, true)

  --recherche module, switch
  list=minetest.find_nodes_in_area(pos1,pos2,{"group:spacengine", "bloc4builder:switch_off", "bloc4builder:switch_on"})
  nb=#list
  local node
  local group
  local prelativ

--minetest.log("channel "..channel)
  for i=1,nb do
    node=minetest.get_node(list[i])
    group=minetest.get_item_group(node.name,"spacengine")
    if group~=0 then
      minetest.set_node(list[i],{name=node.name, param2=node.param2})
      nod_met=minetest.get_meta(list[i])
      nod_met:set_string("channel",channel)
      if group~=1 then
        prelativ={list[i].x-cpos.x,list[i].y-cpos.y,list[i].z-cpos.z}
      else
        prelativ={cpos.x,cpos.y,cpos.z}
        --taille du vaisseaux
        local config=spacengine.decompact(nod_met:get_string("config"))
        local spac_eng=spacengine.decompact(nod_met:get_string("spacengine"))
        local coordo="x"..rx.."y"..ry.."z"..rz.."v"..volume
        config[1][4]=coordo
        spac_eng[4]=coordo
        spac_eng[1]=option
        nod_met:set_string("config",spacengine.compact(config))
        nod_met:set_string("spacengine",spacengine.compact(spac_eng))
      end
      nod_met:set_string("pos_cont",spacengine.compact(prelativ))
    end

    if node.name=="bloc4builder:switch_off" or node.name=="bloc4builder:switch_on" then
      minetest.set_node(list[i],{name=node.name, param2=node.param2})
      nod_met=minetest.get_meta(list[i])
      nod_met:set_string("channel",channel)
    end

  end

  local cha_spl=string.split(channel,":")
  channel=cha_spl[1]..":"..cha_spl[2]
  spacengine.test_area_ship(cpos,1,channel)

  local trouver,npos=spacengine.search_controler(cpos,player,channel)
  if trouver==true then
    spacengine.maj_channel(npos,channel,0) --maj nouveau channel
  end

  --node=minetest.get_node(cpos)
  --nod_met:set_string("vente","500")
end

--******************************
--** sell ship change channel **
--******************************
spacengine.sell_ship=function(cpos,channel)
  local controler=minetest.get_meta(cpos)

  local config=spacengine.decompact(controler:get_string("config"))

  local rangex=5+tonumber(string.sub(config[1][4],2,2))*2
  local rangey=5+tonumber(string.sub(config[1][4],4,4))*2
  local rangez=5+tonumber(string.sub(config[1][4],6,6))*2

  --controler center
  pos1={x=cpos.x-rangex,y=cpos.y-rangey,z=cpos.z-rangez}
  pos2={x=cpos.x+rangex,y=cpos.y+rangey,z=cpos.z+rangez}

  list=minetest.find_nodes_in_area(pos1,pos2,{"group:spacengine", "bloc4builder:switch_off", "bloc4builder:switch_on"})
  nb=#list
  local node
  local group

  for i=1,nb do
    node=minetest.get_node(list[i])
    group=minetest.get_item_group(node.name,"spacengine")
    if group~=0 then
      nod_met=minetest.get_meta(list[i])
      nod_met:set_string("channel",channel)
    end

    if node.name=="bloc4builder:switch_off" or node.name=="bloc4builder:switch_on" then
      nod_met=minetest.get_meta(list[i])
      nod_met:set_string("channel",channel)
    end

  end

  spacengine.test_area_ship(cpos,1,channel)

  local trouver,npos,crew=spacengine.search_controler(cpos,player,channel)
  if trouver==true then
    if spacengine.maj_pos_node(npos,player,channel,cpos,crew) then
      spacengine.maj_channel(npos,channel,0) --maj nouveau channel
    end
  end
end


--*** sit ***
--from mod : xdecor

function spacengine.sit(pos, node, clicker)
	local tool = clicker:get_wielded_item():get_name()
  if tool == "spacengine:tool" then return false end
	local player_name = clicker:get_player_name()
	local objs = minetest.get_objects_inside_radius(pos, 0.1)
	local vel = clicker:get_player_velocity()
	local ctrl = clicker:get_player_control()
  local physics=clicker:get_physics_override() --TODO compatible potion ici

	for _, obj in pairs(objs) do
		if obj:is_player() and obj:get_player_name() ~= player_name then
			return
		end
	end

	if default.player_attached[player_name] then
    physics=minetest.deserialize(clicker:get_attribute("sit"))
		pos.y = pos.y - 0.5
		clicker:setpos(pos)
		clicker:set_eye_offset({x=0, y=0, z=0}, {x=0, y=0, z=0})
		clicker:set_physics_override(physics)
    --fxadd(clicker,"sit",-2,)
		default.player_attached[player_name] = false
		default.player_set_animation(clicker, "stand", 30)

	elseif not default.player_attached[player_name] and node.param2 <= 3 and
			not ctrl.sneak and vector.equals(vel, {x=0,y=0,z=0}) then
    physics=clicker:set_attribute("sit",minetest.serialize(physics))
		clicker:set_eye_offset({x=0, y=-7, z=2}, {x=0, y=0, z=0})
		clicker:set_physics_override(0, 0, 0)
		clicker:setpos(pos)
		default.player_attached[player_name] = true
		default.player_set_animation(clicker, "sit", 30)

		if     node.param2 == 2 then clicker:set_look_yaw(3.15)
		elseif node.param2 == 3 then clicker:set_look_yaw(7.9)
		elseif node.param2 == 0 then clicker:set_look_yaw(6.28)
		elseif node.param2 == 1 then clicker:set_look_yaw(4.75) end
	end
  return true
end

function spacengine.sit_dig(pos, digger)
	for _, player in pairs(minetest.get_objects_inside_radius(pos, 0.1)) do
		if player:is_player() and
			    default.player_attached[player:get_player_name()] then
			return false
		end
	end
	return true
end

--################################
local function str(val_in)
  local val_out
  if val_in==nil then val_in="" end
  if type(val_in)=="string" then
   val_out="^".. val_in
  else
    val_out=val_in
  end
  return val_out
end

local function tab(val_in)
  local val_out
if val_in=="*" then val_in="^*" end
if string.sub(val_in,1,1)=="^" then
   val_out=string.sub(val_in,2)
  else
    val_out=tonumber(val_in)
  end
  return val_out
end

--transform src {0},{{0,{0,"none"}} } --> compact "0¨0#0/^none"
spacengine.compact=function(src)
  local dst=""
if type(src)=="table" then
  for idx1=1,#src do
    local cont1=src[idx1]
  
    if type(cont1)=="table" then

      for idx2=1,#cont1 do
        local cont2=cont1[idx2]

        if type(cont2)=="table" then

          for idx3=1,#cont2 do
            dst=dst .. str(cont2[idx3])
            if idx3<#cont2 then dst=dst .."/" end
          end

        else
          dst=dst .. str(cont2)
        end

        if idx2<#cont1 then dst=dst .."#" end
      end
    else
      dst=dst .. str(cont1)
    end

    if idx1<#src then dst=dst .."¨" end

  end
else
  dst=str(src)
end

  return dst
end

--transform src "0¨0#0/^none" --> decompact {{0},{0,{0,"none"}} }
spacengine.decompact=function(src)
local dst={}
local data

if string.find(src,"¨") then
  local family=string.split(src,"¨")
  local idx=1

  for idx1=1,#family do
    local val1={}

    if string.find(family[idx1],"#") then
      local machine=string.split(family[idx1],"#")
      local val2={}

      for idx2=1,#machine do
        if string.find(machine[idx2],"/") then
          data=string.split(machine[idx2],"/")
          val2={}

          for idx3=1,#data do
            val2[idx3]=tab(data[idx3])
          end

          val1[idx2]=val2
        else
          val1[idx2]=tab(machine[idx2])
        end
      end
      dst[idx1]=val1
    else
      dst[idx1]=tab(family[idx1])
    end
  end
else
  dst=tab(src)
end

  return dst
end

--########################################

--****************************
--** weapons destroy target **
--****************************
spacengine.destroy_target=function(cpos,cible_destroy,node,degat)
  --recuperation node ennemie
  local nod_met=minetest.get_meta(cible_destroy)
  local nod_spac=spacengine.decompact(nod_met:get_string("spacengine"))
  --recuperation controleur ennemie
  local pos_cont=spacengine.decompact(nod_met:get_string("pos_cont"))
  local group=minetest.get_item_group(node.name,"spacengine")
  local cpos

  if group==1 then
    cpos={x=pos_cont[1],y=pos_cont[2],z=pos_cont[3]}
  else
    cpos={x=cible_destroy.x-pos_cont[1],y=cible_destroy.y-pos_cont[2],z=cible_destroy.z-pos_cont[3]}
  end

  local cont_dst=minetest.get_meta(cpos)
  local tmp=cont_dst:get_string("config")

  if tmp=="" then return false end --controleur ennemi invalid

  local config_dst=spacengine.decompact(tmp)
  --recuperation bouclier ennemie
  local sh_damage=config_dst[5][4]*0.01
  local shield=math.floor((config_dst[5][1]*config_dst[5][2]*0.01)*(1-sh_damage))
  --appliquer les degats
  if nod_spac[3]==100 then
    return false
  end

  spacengine.make_sound("warning",config_dst) --warning attack  
  nod_spac[3]=math.min(100,nod_spac[3]+math.max(0,degat-shield))
  nod_met:set_string("spacengine",spacengine.compact(nod_spac))
  config_dst[5][4]=math.min(100,math.ceil(degat*math.max(0.01,sh_damage))+config_dst[5][4])
  cont_dst:set_string("config",spacengine.compact(config_dst))
  return true
end

--************
--** shield **
--************
spacengine.check_shield=function(pos_shield,degat)
  local cont_dst=minetest.get_meta(pos_shield)
  local tmp=cont_dst:get_string("config")

  if tmp=="" then return false,0 end --controleur ennemi invalid

  local config_dst=spacengine.decompact(tmp)
  --recuperation bouclier ennemie
  local sh_damage=config_dst[5][4]*0.01
  local shield=math.floor((config_dst[5][1]*config_dst[5][2]*0.01)*(1-sh_damage))
  config_dst[5][4]=math.min(100,math.ceil(degat*math.max(0.01,sh_damage))+config_dst[5][4])
  cont_dst:set_string("config",spacengine.compact(config_dst))

  if degat-shield<1 then return false,0 end

  return true,(degat-shield)
end

--** explosion **
spacengine.explosion=function(cible_destroy)
local delay=math.random(100)*0.01
local text_choice=math.random(20)
if text_choice<10 then
minetest.after(delay,function(cible_destroy)
minetest.sound_play("explosion", {pos = cible_destroy, gain = 1.5,
			max_hear_distance = 25})

minetest.add_particle({
		pos = cible_destroy,
		velocity = vector.new(),
		acceleration = vector.new(),
		expirationtime = 1.5,
		size = 20,
		collisiondetection = false,
		vertical = false,
		texture = "spacengine_blast02.png",
    animation = {
				type = "vertical_frames",
				aspect_w = 32,
				aspect_h = 32,
				length = 0.8
			},
		glow = 15,
	})
	minetest.add_particlespawner({
		amount = 32,
		time = 0.5,
		minpos = vector.subtract(cible_destroy, 1),
		maxpos = vector.add(cible_destroy, 1),
		minvel = {x = -10, y = -10, z = -10},
		maxvel = {x = 10, y = 10, z = 10},
		minacc = vector.new(),
		maxacc = vector.new(),
		minexptime = 1,
		maxexptime = 2.5,
		minsize = 3,
		maxsize = 5,
		texture = "spacengine_nuage.png",
	})
end,cible_destroy)

else
minetest.after(delay,function(cible_destroy)
minetest.sound_play("explosion", {pos = cible_destroy, gain = 1.5,
			max_hear_distance = 25})

minetest.add_particle({
		pos = cible_destroy,
		velocity = vector.new(),
		acceleration = vector.new(),
		expirationtime = 0.6,
		size = 20,
		collisiondetection = false,
		vertical = false,
		texture = "spacengine_blast01.png",
    animation = {
				type = "vertical_frames",
				aspect_w = 32,
				aspect_h = 32,
				length = 0.3
			},
		glow = 15,
	})
	minetest.add_particlespawner({
		amount = 32,
		time = 0.5,
		minpos = vector.subtract(cible_destroy, 1),
		maxpos = vector.add(cible_destroy, 1),
		minvel = {x = -10, y = -10, z = -10},
		maxvel = {x = 10, y = 10, z = 10},
		minacc = vector.new(),
		maxacc = vector.new(),
		minexptime = 1,
		maxexptime = 2.5,
		minsize = 4,
		maxsize = 6,
		texture = "spacengine_nuage.png",
	})
end,cible_destroy)

end

end

spacengine.make_sound=function(soundname,radio_pos)
  if radio_pos[1]~=33333 then
    minetest.sound_play(soundname, {pos = {x=radio_pos[1],y=radio_pos[2],z=radio_pos[3]}, gain = 1, max_hear_distance=32})
  end
end

--*****************
--*** AREA SHIP ***
--*****************

--*** test area ship ***
--action -1 dec 1=maj 0 neutre 2 maj si nil
spacengine.test_area_ship=function(pos,action,channel)

  if channel then

    if string.find(channel,"No channel") then return false end

    if spacengine.area[channel]==nil then
      if action>0 then
        local cont_met=minetest.get_meta(pos)
        local tmp=cont_met:get_string("config")
        if tmp=="" then return false end
        local cont_config=spacengine.decompact(tmp)
        local cont_dat=spacengine.decompact(cont_met:get_string("spacengine"))

        local rangex=5+tonumber(string.sub(cont_dat[4],2,2))*2
        local rangey=5+tonumber(string.sub(cont_dat[4],4,4))*2
        local rangez=5+tonumber(string.sub(cont_dat[4],6,6))*2

        spacengine.area[channel]={p0={x=pos.x,y=pos.y,z=pos.z}, p1={x=pos.x-rangex,y=pos.y-rangey,z=pos.z-rangez}, p2={x=pos.x+rangex,y=pos.y+rangey,z=pos.z+rangez},config=cont_config}
        return true
      end
      return false

    else

      if action==-1 then
        spacengine.area[channel]=nil
        return true

      elseif action==1 then
        local cont_met=minetest.get_meta(pos)
        local tmp=cont_met:get_string("config")
        if tmp=="" then return false end
        local cont_config=spacengine.decompact(tmp)
        local cont_dat=spacengine.decompact(cont_met:get_string("spacengine"))

        local rangex=5+tonumber(string.sub(cont_dat[4],2,2))*2
        local rangey=5+tonumber(string.sub(cont_dat[4],4,4))*2
        local rangez=5+tonumber(string.sub(cont_dat[4],6,6))*2

        spacengine.area[channel]={p0={x=pos.x,y=pos.y,z=pos.z}, p1={x=pos.x-rangex,y=pos.y-rangey,z=pos.z-rangez}, p2={x=pos.x+rangex,y=pos.y+rangey,z=pos.z+rangez},config=cont_config}
        return true
      end

      return true,spacengine.area[channel].p0
    end
  end

  --recherche position
  local p0={}
  local name=""

  for k, v in pairs (spacengine.area) do
    local p1,p2=v.p1,v.p2
    if (pos.x>p1.x and pos.x<p2.x) and (pos.y>p1.y and pos.y<p2.y) and (pos.z>p1.z and pos.z<p2.z) then
      p0={x=v.p0.x,y=v.p0.y,z=v.p0.z}
      name=k
      break
    end
  end

  if name~="" then
    return true,p0,name
  end

  return false
end
