
local S = farming.intllib

--= Sugar

minetest.register_craftitem("farming:sugar", {
	description = S("Sugar"),
	inventory_image = "farming_sugar.png",
})

minetest.register_craft({
	type = "cooking",
	cooktime = 3,
	output = "farming:sugar 2",
	recipe = "default:papyrus",
})

minetest.register_craft({
	type = "cooking",
	cooktime = 3,
	output = "farming:sugar 3",
	recipe = "farming:sugarbeet_seed",
})

--= Salt

minetest.register_node("farming:salt", {
	description = ("Salt"),
	inventory_image = "farming_salt.png",
	wield_image = "farming_salt.png",
	drawtype = "plantlike",
	paramtype = "light",
	tiles = {"farming_salt.png"},
	groups = {vessel = 1, salt = 1, dig_immediate = 3, attached_node = 1},
	sounds = default.node_sound_glass_defaults(),
	selection_box = {
		type = "fixed",
		fixed = {-0.25, -0.5, -0.25, 0.25, 0.3, 0.25}
	},
})

minetest.register_craft({
	type = "cooking",
	cooktime = 15,
	output = "farming:salt",
	recipe = "bucket:bucket_water",
	replacements = {{"bucket:bucket_water", "bucket:bucket_empty"}}
})

--sugarbeet
minetest.register_craftitem("farming:sugarbeet_seed", {
	description = S("SugarBeet seed"),
	inventory_image = "farming_sugarbeet_seed.png",
	on_place = function(itemstack, placer, pointed_thing)
		return farming.place_seed(itemstack, placer, pointed_thing, "farming:sugarbeet_1")
	end,
  on_use = minetest.item_eat(1),
})


-- crop definition
local crop_def = {
	drawtype = "plantlike",
	tiles = {"farming_sugarbeet_1.png"},
	paramtype = "light",
	paramtype2 = "meshoptions",
	place_param2 = 3,
	sunlight_propagates = true,
	waving = 1,
	walkable = false,
	buildable_to = true,
	drop = "",
	selection_box = farming.select,
	groups = {
		snappy = 3, flammable = 3, plant=1, attached_node = 1,
		not_in_creative_inventory = 1, growing = 6
	},
	sounds = default.node_sound_leaves_defaults()
}

-- stage 1
minetest.register_node("farming:sugarbeet_1", table.copy(crop_def))

-- stage 2
crop_def.tiles = {"farming_sugarbeet_2.png"}
minetest.register_node("farming:sugarbeet_2", table.copy(crop_def))

-- stage 3
crop_def.tiles = {"farming_sugarbeet_3.png"}
minetest.register_node("farming:sugarbeet_3", table.copy(crop_def))

-- stage 4
crop_def.tiles = {"farming_sugarbeet_4.png"}
minetest.register_node("farming:sugarbeet_4", table.copy(crop_def))

-- stage 5
crop_def.tiles = {"farming_sugarbeet_5.png"}
crop_def.groups.growing = 0
crop_def.drop = {
	max_items = 5, items = {
		{items = {'farming:sugarbeet_seed'}, rarity = 1},
		{items = {'farming:sugarbeet_seed'}, rarity = 1},
		{items = {'farming:sugarbeet_seed'}, rarity = 1},
		{items = {'farming:sugarbeet_seed'}, rarity = 2},
		{items = {'farming:sugarbeet_seed'}, rarity = 5},
	}
}
minetest.register_node("farming:sugarbeet_5", table.copy(crop_def))
