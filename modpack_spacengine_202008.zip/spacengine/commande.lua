local function switch_analog(dst,value)
  local calcul=0
  if value<1 then
    dst=math.abs(value)
  else
    calcul=math.ceil(dst/(100/value))+1
    if calcul>value then calcul=0 end
    dst=math.floor(calcul*(100/value))
  end
  return dst
end

--*****************
--*** controler ***
--*****************
spacengine.controler=function(pos)
  --local tt0 = minetest.get_us_time()
  local cont_met = minetest.get_meta(pos)
  local pos_cont=spacengine.decompact(cont_met:get_string("pos_cont"))
  local channel=cont_met:get_string("channel")

  if pos_cont[2]>31000 then return end

  local config=spacengine.decompact(cont_met:get_string("config"))

  if config[1][1]==0 and config[12]=="n" then return end

  local split=string.split(channel,":")
  channel=split[1]..":"..split[2]

  --temps ecouler entre 2 appels
  local t0=config[14]
  local t1 = minetest.get_us_time()-t0
  local new_screen=""
  config[3][2]=0
  local new_pos

  local id_stock_pos=0
  local stock_pos=spacengine.decompact(cont_met:get_string("stock_pos"))

  if stock_pos then id_stock_pos=#stock_pos end

  if id_stock_pos>1 then
    
    for idx=2,id_stock_pos do
      new_pos={x=stock_pos[idx][1]+pos.x,y=stock_pos[idx][2]+pos.y,z=stock_pos[idx][3]+pos.z}
      dst=minetest.get_node(new_pos) 
      nod_met=minetest.get_meta(new_pos)
    
      if nod_met:get_string("channel")==channel then --ifchannel ok
        local dst_group=minetest.get_item_group(dst.name,"spacengine")

        if dst_group==3 and t1>9000000 then
          local rs=spacengine.power(new_pos,nod_met,cont_met,config,t0)
          if rs==true then new_screen=new_screen.."e" end

        elseif dst_group==12 then
          if config[12]~="n" then
            spacengine.screen_display(new_pos,nod_met,pos,cont_met,config)
          end
        end

      end
    end
  end

  if t1>9000000 then --minimum 10 sec.

    --** temperature moteur **
    if config[4][6]>0 then
      config[4][6]=math.max(0,config[4][6]-config[4][5])
      new_screen=new_screen.."E"
    end

    --** regeneration shield **
    if config[5][4]>0 then
      config[5][4]=math.max(0,config[5][4]-config[5][3])
      new_screen=new_screen.."S"
    end

    --** reload weapons **
    if config[6][6]>0 then
      config[6][6]=math.max(0,config[6][6]-1)
      new_screen=new_screen.."W"
    end

    --** gravitation **
    if config[8][2]>0 then
      local g=math.max(10,config[8][2]*config[8][1])

      if g>10 then
        config[2][2]=math.max(0,math.floor(config[2][2]-g))
        config[3][2]=config[3][2]-math.ceil(g)

        if config[2][2]==0 then
          config[8][2]=0
          g=10
        end
--TODO sauvegarde
--[[
        if spacengine.graviton[channel].g~=g then --sauvegarde area vaisseaux par nom
          local rangex=5+tonumber(string.sub(config[1][4],2,2))*2
          local rangey=5+tonumber(string.sub(config[1][4],4,4))*2
          local rangez=5+tonumber(string.sub(config[1][4],6,6))*2
          spacengine.graviton[channel]={g=g,pos1={x=pos.x-rangex,y=pos.y-rangey,z=pos.z-rangey} , pos2={x=pos.x+rangex,y=pos.y+rangey,z=pos.z+rangez}}
        end
      --]]
        new_screen=new_screen.."G"
      end

    end

    --** oxygene **
    if config[11][2]>0 then
      if config[11][4]>1 then
        config[11][4]=config[11][4]-1
      else
        spacengine.oxygene(pos,cont_met,config,t1)
      end
    end

    --** manutention **
    if config[13]>-1 then
      config[13]=math.max(0,config[13]-1)
      if config[13]==0 then
        local msg=spacengine.manutention(pos,cont_met,config)
        if msg then
          local manutention=spacengine.decompact(cont_met:get_string("manutention"))
          manutention[9]=msg
          cont_met:set_string("manutention",spacengine.compact(manutention))
          new_screen=new_screen.."M"
        end
      end
    end

    -- consommation vaisseaux base
    local volume=tonumber(string.sub(config[1][4],8,9))+config[1][3]
    config[2][2]=math.max(0,math.floor(config[2][2]-volume))
    -- puissance moyenne
    config[3][3]=config[3][2]
  end
  
  -- timer
  config[14]=minetest.get_us_time()

  if new_screen=="" then
    config[12]="n"
  else
    config[12]=new_screen
  end
  cont_met:set_string("config",spacengine.compact(config))
--local tt1 = minetest.get_us_time()
--local time_micros = (tt1 - tt0)/1000
--minetest.chat_send_all(" time " .. time_micros .. " ms")
end

--*************
--*** power ***
--*************
spacengine.power=function(pos,nod_met,cont_met,config,t0)
  local spac_eng=spacengine.decompact(nod_met:get_string("spacengine"))
  local pos_cont=spacengine.decompact(nod_met:get_string("pos_cont"))
  local refresh_screen=false

  if pos_cont[2]>31000 then return end --controler invalid

  if spac_eng[8]==1 then --power activer
    local time_release=spac_eng[9] --timer

    local cont_inv = cont_met:get_inventory()
    local capa,charg=config[2][1],config[2][2]
    local src=spac_eng[5]
    

    if time_release>0 then --timer on
      local p,coef=spac_eng[4],0
      refresh_screen=true

      if src=="solar" then
        local light=minetest.get_node_light({x=pos.x,y=pos.y+1,z=pos.z})
        if light==nil then light=0 end
        if light>10 then coef=(light-10)*0.14 end

      elseif src=="water" then
        local water=minetest.find_nodes_in_area({x=pos.x-1,y=pos.y-1,z=pos.z-1},{x=pos.x+1,y=pos.y+1,z=pos.z+1},{"default:water_flowing","default:river_water_flowing"})
        if #water > 7 then coef=(#water-7)*0.05 end

      elseif src=="battery" then
        if charg-p>0 then
          charg=math.max(0,charg-p)
        end
        if charg==0 then --stop si battery decharger
          time_release=0
          spac_eng[9]=0
        end

      else --node
        coef=1
      end

      local dst=spac_eng[6]
      if dst=="battery" then --destination
        charg=math.min(capa,charg+(p*coef))
        config[2][2]=math.floor(charg)
      end

      if p<0 then --utilisation de la battery
        coef=1
        charg=math.max(0,charg+p)
        config[2][2]=math.floor(charg)
        if charg==0 then --stop si battery decharger
          time_release=0
          spac_eng[8]=0
          refresh_screen=false
        end
      end

      if time_release==1 and dst~="battery" and coef>0 then --quand transformation terminer add to l'inventaire
        if cont_inv:room_for_item("stock",spac_eng[6]) then
          cont_inv:add_item("stock",spac_eng[6])
        else
          time_release=0
          spac_eng[8]=0
        end
      end

      spac_eng[10]=math.ceil(p*coef)
      config[3][2]=config[3][2]+spac_eng[10]

      if coef>0 then  --bloque timer si pas d'energy sinon decompte
        time_release=math.max(0,time_release-1)
      else
        refresh_screen=false
      end
      
    else
      if src=="solar" or src=="water" or src=="battery" then
        time_release=spac_eng[7]
      else
        if cont_inv:contains_item("stock",src) then
          cont_inv:remove_item("stock",src)
          time_release=spac_eng[7]
        end
      end

    end

    spac_eng[9]=time_release
    
    nod_met:set_string("spacengine",spacengine.compact(spac_eng))

  end
  return refresh_screen
end

--***************
--*** Weapons ***
--***************

spacengine.weapons=function(cpos,channel,cont_met,config)
  local toucher=false
  if config[6][6]>0 then return end

  local puissance=math.floor(config[6][1]*config[6][2]/100)
  local range=math.floor(config[6][3]*config[6][4]/100)
  local zone=math.ceil(config[6][8]*config[4][4][4]/100)
  local xrng=math.ceil((-1+(0.02*config[4][4][1]))*range)
  local yrng=math.ceil((-1+(0.02*config[4][4][2]))*range)
  local zrng=math.ceil((-1+(0.02*config[4][4][3]))*range)
  local rmax=math.max(math.abs(xrng),math.abs(yrng),math.abs(zrng))
  local conso=puissance+(rmax*(puissance/100))+(zone*zone*zone)

  if config[2][2]-conso<0 then return end

  --suivant puissance, detruit different type
  local src={"group:wood"}
  
  if puissance>5000 then
    src={"group:wall","group:stone","group:wood","group:spacengine"}
  elseif puissance>1250 then
    src={"group:wall","group:stone","group:wood"}
  elseif puissance>625 then
    src={"group:stone","group:wood"}
  end

  config[6][6]=config[6][5] --timer on
  config[2][2]=config[2][2]-conso --consommation
  local nb_weapons=config[6][7]
  local chance=math.ceil(((rmax*zone*zone*zone))/nb_weapons)
  local trigger=math.ceil(chance*0.1)
  local degat=math.ceil(puissance*(100-config[1][3])*0.0001)
  --taille du vaisseaux
  local rangex=5+tonumber(string.sub(config[1][4],2,2))*2
  local rangey=5+tonumber(string.sub(config[1][4],4,4))*2
  local rangez=5+tonumber(string.sub(config[1][4],6,6))*2
--TODO direction
  local aleax=math.floor((math.random(100)*zone*0.02)-(zone/2))
  local aleay=math.floor((math.random(100)*zone*0.02)-(zone/2))
  local aleaz=math.floor((math.random(100)*zone*0.02)-(zone/2))

  if xrng<0 then
    rangex=-rangex
  elseif xrng==0 then
    rangex=0
  end
  if yrng<0 then
    rangey=-rangey
  elseif yrng==0 then
    rangey=0
  end
  if zrng<0 then
    rangez=-rangez
  elseif zrng==0 then
    rangez=0
  end

  local impact=math.random(1,chance)
  local pos3={x=cpos.x+rangex+xrng,y=cpos.y+rangey+yrng,z=cpos.z+rangez+zrng}
  local cible_destroy={x=pos3.x+aleax,y=pos3.y+aleay,z=pos3.z+aleaz}
  --search and destroy entity mob
  if puissance>2500 then
    local list=minetest.get_objects_inside_radius(cible_destroy,zone)

    if #list>0 then

      local obj_pos, dist
      
      for _,obj in ipairs(list) do
        obj_pos = obj:get_pos()
        local ent = obj:get_luaentity()

        if obj:is_player() or string.find(ent.name,"mobs") and impact<trigger then
--TODO protect area shield
--minetest.chat_send_all("entity")
          toucher=true
          spacengine.explosion(obj_pos)
          obj:punch(list[1], 1.0, {
            full_punch_interval = 1.0,
            damage_groups = {fleshy = degat},
          })
          degat=0
          break
        end
      end
    end
  end

  if toucher==false then
    local node,group

      for i=1,nb_weapons do
        impact=math.random(1,chance)
        aleax=math.floor((math.random(100)*zone*0.02)-(zone/2))
        aleay=math.floor((math.random(100)*zone*0.02)-(zone/2))
        aleaz=math.floor((math.random(100)*zone*0.02)-(zone/2))

        cible_destroy={x=pos3.x+aleax,y=pos3.y+aleay,z=pos3.z+aleaz}
        node=minetest.get_node(cible_destroy)

        -- protection
        if not minetest.is_protected(cible_destroy,"") then

          if minetest.get_item_group(node.name,"wood")>0 and impact<trigger then
            minetest.remove_node(cible_destroy)
            spacengine.explosion(cible_destroy)
            degat=degat-10
            toucher=true
--minetest.chat_send_all("wood")
          elseif minetest.get_item_group(node.name,"stone")>0 and impact<trigger then
            minetest.remove_node(cible_destroy)
            spacengine.explosion(cible_destroy)
            degat=degat-20
            toucher=true
--minetest.chat_send_all("stone")
          elseif minetest.get_item_group(node.name,"wall")>0 and impact<trigger then
            local pos_shield=minetest.find_node_near(cible_destroy,5,"group:spacengine")
--minetest.chat_send_all("wall")
            if spacengine.check_shield(pos_shield,node,degat) then
              minetest.remove_node(cible_destroy)
              spacengine.explosion(cible_destroy)
              degat=degat-40
              toucher=true

            end
          end

          if degat<1 then
            break
          end
        end

        if minetest.get_item_group(node.name,"spacengine")>0 and impact<trigger then
--minetest.chat_send_all("spacengine")
          if spacengine.destroy_target(cpos,cible_destroy,node,degat) then
            spacengine.explosion(cible_destroy)
            toucher=true

            break
          end
        end
        spacengine.explosion(cible_destroy)
      end
  end
  if toucher then
    minetest.sound_play("bip", {pos = cpos, gain = 1.5,
			max_hear_distance = 15})
  else
    spacengine.explosion(cible_destroy)
  end
  return
end

--*************
--*** RADAR ***
--*************
spacengine.radar=function(cpos,channel,cont_met,config)
  local puissance=math.ceil(config[7][1]*config[7][2]/100)
  if config[2][2]-puissance<0 then return end
  
  local pos1,pos2
  local id=math.max(1,config[7][6])

  if type(config[7][4])~="table" then return end

  local cible=config[7][4][id]

  if cible=="none:none" then return end

  minetest.sound_play("sonar", {pos = cpos, gain = 1,max_hear_distance = 15})
  config[2][2]=config[2][2]-puissance
  --direction
  local rangex=5+tonumber(string.sub(config[1][4],2,2))*2
  local rangey=5+tonumber(string.sub(config[1][4],4,4))*2
  local rangez=5+tonumber(string.sub(config[1][4],6,6))*2  
  local pos1,pos2
  local zone=math.ceil(config[7][3]*config[4][4][4]/100)
  local xrng=math.ceil((-1+(0.02*config[4][4][1]))*config[7][3])
  local yrng=math.ceil((-1+(0.02*config[4][4][2]))*config[7][3])
  local zrng=math.ceil((-1+(0.02*config[4][4][3]))*config[7][3])
  
  if xrng<0 then rangex=-rangex end
  if yrng<0 then rangey=-rangey end
  if zrng<0 then rangez=-rangez end
    
  pos1={x=cpos.x+rangex+xrng-zone,y=cpos.y+rangey+yrng-zone,z=cpos.z+rangez+zrng-zone}
  pos2={x=cpos.x+rangex+xrng+zone,y=cpos.y+rangey+yrng+zone,z=cpos.z+rangez+zrng+zone}


  local list=minetest.find_nodes_in_area(pos1,pos2,cible)
  local tmp
  if list==nil then
    config[7][5][id]=0
  else
    config[7][5][id]=math.floor(#list*config[7][2]/100)
  end
  
end

--*******************
--*** MANUTENTION ***
--*******************
spacengine.manutention=function(pos,cont_met,config)

  if config[13]>0 then return end
  local manutention=spacengine.decompact(cont_met:get_string("manutention"))
  local tmp1=math.floor((manutention[1]*manutention[2])/100)
  local tmp2
  local tmp3
  local zone=math.floor((manutention[3]*config[4][4][4])/100)
  local xrng=math.ceil((-1+(0.02*config[4][4][1]))*tmp1)
  local yrng=math.ceil((-1+(0.02*config[4][4][2]))*tmp1)
  local zrng=math.ceil((-1+(0.02*config[4][4][3]))*tmp1)
  local rangex=5+tonumber(string.sub(config[1][4],2,2))*2
  local rangey=5+tonumber(string.sub(config[1][4],4,4))*2
  local rangez=5+tonumber(string.sub(config[1][4],6,6))*2  
  local pos1,pos2

  if xrng<0 then rangex=-rangex end
  if yrng<0 then rangey=-rangey end
  if zrng<0 then rangez=-rangez end
    
  pos1={x=pos.x+rangex+xrng-zone,y=pos.y+rangey+yrng-zone,z=pos.z+rangez+zrng-zone}
  pos2={x=pos.x+rangex+xrng+zone,y=pos.y+rangey+yrng+zone,z=pos.z+rangez+zrng+zone}

  if type(manutention[5])=="table" then
    tmp3=string.split(manutention[5][manutention[6]],":")
  else
    tmp3=string.split(manutention[5],":")
  end

  local cible=tmp3[1]..":"..tmp3[2]

  if config[2][2]-tonumber(tmp3[5])<0 then
    config[13]=-1
    return "BATTERY DOWN"
  end

  local sav_conf=false
  local cont_inv = cont_met:get_inventory()
  --***********
  --** BUILD **
  --***********
  if string.find(manutention[7],"B") and string.find(tmp3[4],"B") then
    if manutention[8]==1 then

      local zonex=math.random(0,zone)
      local zoney=math.random(0,zone)
      local zonez=math.random(0,zone)
      pos1={x=pos.x+rangex+xrng-zonex,y=pos.y+rangey+yrng-zoney,z=pos.z+rangez+zrng-zonez}
      --protect
      if minetest.is_protected(pos1,"") then
        config[13]=-1
        return "! PROTECTED !"
      end

      local node=minetest.get_node(pos1)

      if node.name=="ignore" then
        config[13]=-1
        return "MAP ERROR"
      end

      if node.name=="air" or node.name=="vacuum:vacuum" then

        if not cont_inv:contains_item("stock",cible) then
          config[13]=-1
          return "STOCK EMPTY"
        end

        cont_inv:remove_item("stock",cible)

        minetest.set_node(pos1,{name=cible})

        config[13]=tonumber(tmp3[3])
        config[2][2]=config[2][2]-tonumber(tmp3[5])
        sav_conf=true

      else
        config[13]=-1
        return "BUILD OK"
      end
    end
  end

  --*********
  --** DIG **
  --*********
  if string.find(manutention[7],"D") and string.find(tmp3[4],"D") then
    if manutention[8]==2 then
      local list=minetest.find_nodes_in_area(pos1,pos2,cible)
      if #list<1 then
        config[13]=-1
        return "TERMINATED"
      end

      --protect
      if minetest.is_protected(list[1],"") then
        config[13]=-1
        return "! PROTECTED !"
      end

      --add to controler
      if cont_inv:room_for_item("stock",cible) then
          cont_inv:add_item("stock",cible)
        else
          config[13]=-1
          return "STOCK FULL"
        end

      config[13]=tonumber(tmp3[3])
      --digg 1 by 1
      minetest.remove_node(list[1])
      config[2][2]=config[2][2]-tonumber(tmp3[5])
      sav_conf=true
    end
  end

  --**********
  --** PUMP **
  --**********
  if string.find(manutention[7],"P") and string.find(tmp3[4],"P") then
    if manutention[8]==3 then
      local list=minetest.find_nodes_in_area(pos1,pos2,cible)
      if #list<1 then
        config[13]=-1
        return "TERMINATED"
      end

      --protect
      if minetest.is_protected(list[1],"") then
        config[13]=-1
        return "! PROTECTED !"
      end
      --add to controler
      local cont_inv = cont_met:get_inventory()
      if cont_inv:room_for_item("stock",cible) then
          cont_inv:add_item("stock",cible)
        else
          config[13]=-1
          return "STOCK FULL"
        end

      config[13]=tonumber(tmp3[3])
      --pump not remove node ?
      minetest.remove_node(list[1])
      config[2][2]=config[2][2]-tonumber(tmp3[5])
      sav_conf=true
    end
  end

  if sav_conf then
    return
  end

  config[13]=-1
  return "BAD COMMAND"
end

--***************************
--*** recherche controler ***
--***************************
spacengine.search_controler=function(pos,player,channel,range)

  if range==nil then range="x5y5z5" end

  local rangex=10+tonumber(string.sub(range,2,2))*4
  local rangey=10+tonumber(string.sub(range,4,4))*4
  local rangez=10+tonumber(string.sub(range,6,6))*4

  local pos1={x=pos.x-rangex,y=pos.y-rangey,z=pos.z-rangez}
  local pos2={x=pos.x+rangex,y=pos.y+rangey,z=pos.z+rangez}

  local list=minetest.find_nodes_in_area(pos1,pos2,"spacengine:controler")
  local nb=#list
  local idx=0
  local cpos

  for i=1,nb do -- recherche controler = channel:owner
    nm=minetest.get_meta(list[i])    

    if nm:get_string("channel")==channel then
      cpos=list[i]
      idx=idx+1
    end

  end

  if idx==0 then --pas de channel
    return false
  elseif idx>1 then --plusieurs channel identique
    minetest.chat_send_player(player:get_player_name(),"Same Channel Found")
    return false
  end

  return true,cpos
end

--*************************
--*** MaJ position node ***
--*************************
spacengine.maj_pos_node=function(pos,player,channel,cpos)
  --recuperation data node
  local nod_met = minetest.get_meta(pos)
  local nod_spl=spacengine.decompact(nod_met:get_string("spacengine"))
  local pos_cont=spacengine.decompact(nod_met:get_string("pos_cont"))
  local node=minetest.get_node(pos)
  local group=minetest.get_item_group(node.name,"spacengine")

--position controler
  local err=0
  if group==1 then
    pos_cont[1]=cpos.x
    pos_cont[2]=cpos.y
    pos_cont[3]=cpos.z

  else
    pos_cont[1]=pos.x-cpos.x
    pos_cont[2]=pos.y-cpos.y
    pos_cont[3]=pos.z-cpos.z

    local cont_met=minetest.get_meta(cpos)
    local cont_dat=spacengine.decompact(cont_met:get_string("spacengine"))

    local rangex=5+tonumber(string.sub(cont_dat[4],2,2))*2
    local rangey=5+tonumber(string.sub(cont_dat[4],4,4))*2
    local rangez=5+tonumber(string.sub(cont_dat[4],6,6))*2

    local tmp1=pos_cont[1]+rangex
    if tmp1<0 or tmp1>(rangex*2) then
      err=err+1
      minetest.chat_send_player(player:get_player_name(),"Out of range X coordo")
    end

    tmp1=pos_cont[2]+rangey
    if tmp1<0 or tmp1>(rangey*2) then
      err=err+1
      minetest.chat_send_player(player:get_player_name(),"Out of range Y coordo")
    end

    tmp1=pos_cont[3]+rangez
    if tmp1<0 or tmp1>(rangez*2) then
      err=err+1
      minetest.chat_send_player(player:get_player_name(),"Out of range Z coordo")
    end
  end

  if err>0 then
    nod_met:set_string("pos_cont","62000¨62000¨62000")
    return false
  end

  nod_met:set_string("pos_cont",spacengine.compact(pos_cont))
  return true
end

--***************************
--*** Mise A Jour channel ***
--***************************

local function stockmax(src,calcul,smax)
if calcul+src>smax then
  src=smax-calcul
else
  calcul=calcul+src
end
return src,calcul
end

spacengine.maj_channel=function(cpos,player,channel,repar)
  local controler=minetest.get_meta(cpos)
  local tmp=controler:get_string("channel")

  if channel~=tmp then --invalid controler or channel
    return
  end

  local config=spacengine.decompact(controler:get_string("config"))

  local rangex=5+tonumber(string.sub(config[1][4],2,2))*2
  local rangey=5+tonumber(string.sub(config[1][4],4,4))*2
  local rangez=5+tonumber(string.sub(config[1][4],6,6))*2

  --controler center
  pos1={x=cpos.x-rangex,y=cpos.y-rangey,z=cpos.z-rangez}
  pos2={x=cpos.x+rangex,y=cpos.y+rangey,z=cpos.z+rangez}

  list=minetest.find_nodes_in_area(pos1,pos2,"group:spacengine")
  nb=#list

  local storage=spacengine.decompact(controler:get_string("storage"))
  local passenger=spacengine.decompact(controler:get_string("passenger"))
  local manutention=spacengine.decompact(controler:get_string("manutention"))

  --reset compteur
  local idx4,idx5,idx6=0,0,0
  local idx7,idx8,idx11,idx13=0,0,0,0
  --controler
  config[1][2]=math.floor(((rangex*2+1)*(rangey*2+1)*(rangez*2+1))/10) --poids
  config[1][3]=0 --damage
  local stock_pos={{0,0,0}}
  local id_stock_pos=1
  --battery
  config[2][1]=0
  --power
  config[3][2]=0
  local cont1,cont2
  if type(config[3][4])=="table" then
    cont1=config[3][4]
    cont2=config[3][5]
    if cont2[1]==1 then --reset list
      cont1={0}
      cont2={0}
    end
  else
    cont1={0}
    cont2={0}
  end

  --engine
  config[4][1]=0
  config[4][3]=0
  config[4][5]=0
  config[4][7]=0
  --shield
  config[5][1]=0
  config[5][3]=0
  --weapons
  config[6][1]=0
  config[6][3]=0
  config[6][5]=0
  config[6][8]=0
  --radar
  config[7][1]=0
  config[7][3]=0
  local cont7={"none:none"}
  local cont77={0}
  --gravitation
  config[8][1]=0
  --storage
  storage[1]=0
  --passenger
  passenger[1]=0
  --oxygene
  config[11][1]=0
  config[11][3]=0
  --screen

  --manutention
  local cont11={"none:none:0:none:0"}
  manutention[7]=""
  manutention[1]=0
  manutention[3]=0

  for i=1,nb do
    dst=minetest.get_node(list[i]) 
    dst_met=minetest.get_meta(list[i])    
    local dst_channel=dst_met:get_string("channel")
    if dst_channel==channel then --ifchannel ok
      local sauvegarde=false
      local dst_group=minetest.get_item_group(dst.name,"spacengine")
      local dst_space=spacengine.decompact(dst_met:get_string("spacengine"))

      config[1][2]=config[1][2]+dst_space[2] --weight
      if repar then
        dst_space[3]=0 --reparation
        sauvegarde=true
      else
        config[1][3]=config[1][3]+dst_space[3] --damage
      end

    --controler
    if dst_group==1 then
      config[1][4]=dst_space[4] --volume
      config[1][7]=dst_space[5] --stock

    --battery
    elseif dst_group==2 then
      config[2][1]=config[2][1]+dst_space[4]

    --power      
    elseif dst_group==3 then
      id_stock_pos=id_stock_pos+1
      stock_pos[id_stock_pos]={list[i].x-cpos.x,list[i].y-cpos.y,list[i].z-cpos.z}
      local err=false
      for j=1,#cont1 do
        if dst_space[1]==cont1[j] then --present ?
          dst_space[8]=cont2[j]
          err=true
        end
      end

      if err==false then
        local j=#cont1+1 
        cont1[j]=dst_space[1]
        cont2[j]=dst_space[8] --on/off
      end

      config[3][2]=config[3][2]+dst_space[10]
      sauvegarde=true

    --engine
    elseif dst_group==4 then
      idx4=idx4+1
      config[4][1]=config[4][1]+dst_space[4]
      config[4][3]=config[4][3]+dst_space[5]
      config[4][5]=config[4][5]+dst_space[6]
      config[4][7]=config[4][7]+dst_space[7]
    
    --shield
    elseif dst_group==5 then
      idx5=idx5+1
      config[5][1]=config[5][1]+dst_space[4]
      config[5][3]=config[5][3]+dst_space[5]

    --weapons
    elseif dst_group==6 then
      idx6=idx6+1
      config[6][1]=math.max(10000,config[6][1]+dst_space[4])
      config[6][3]=math.max(100,config[6][3]+dst_space[5])
      config[6][5]=config[6][5]+dst_space[6]
      config[6][8]=config[6][8]+dst_space[7]

    --radar
    elseif dst_group==7 then
      idx7=idx7+1
      config[7][1]=config[7][1]+dst_space[4]
      config[7][3]=config[7][3]+dst_space[5]
      local err=false
      if type(dst_space[6])=="table" then

        for chk=1,#dst_space[6] do
          err=false
          for j=1,#cont7 do
            if dst_space[6][chk]==cont7[j] then --present ?
            err=true
            end
          end
          if err==false then
            local j=#cont7+1 
            cont7[j]=dst_space[6][chk]
            cont77[j]=0
          end
        end

      else
        for j=1,#cont7 do
          if dst_space[6]==cont7[j] then --present ?
            err=true
          end
        end
        if err==false then
          local j=#cont7+1 
          cont7[j]=dst_space[6]
          cont77[j]=0
        end
      end

    --gravitation
    elseif dst_group==8 then
      idx8=idx8+1
      config[8][1]=config[8][1]+dst_space[4]

    --storage
    elseif dst_group==9 then
      storage[1]=storage[1]+dst_space[4]

    --passenger
    elseif dst_group==10 then
      passenger[1]=passenger[1]+1

    --oxygene
    elseif dst_group==11 then
      idx11=idx11+1
      config[11][1]=config[11][1]+dst_space[4]
      config[11][3]=config[11][3]+dst_space[5]
    --screen
    elseif dst_group==12 then
      id_stock_pos=id_stock_pos+1
      stock_pos[id_stock_pos]={list[i].x-cpos.x,list[i].y-cpos.y,list[i].z-cpos.z}
    --manutention
    elseif dst_group==13 then
      idx13=idx13+1
      manutention[1]=manutention[1]+dst_space[4]
      manutention[3]=manutention[3]+dst_space[5]

      local err=false
      if type(dst_space[6])=="table" then

        for chk=1,#dst_space[6] do
          err=false
          for j=1,#cont11 do
            if dst_space[6][chk]==cont11[j] then --present ?
            err=true
            end
          end
          if err==false then
            local j=#cont11+1 
            cont11[j]=dst_space[6][chk]
          end
        end

      else
        for j=1,#cont11 do
          if dst_space[6]==cont11[j] then --present ?
            err=true
          end
        end
        if err==false then
          local j=#cont11+1 
          cont11[j]=dst_space[6]
        end
      end

      if string.find(manutention[7],string.sub(dst_space[1],1,1)) then --present ?
      else
        manutention[7]=manutention[7] .. string.sub(dst_space[1],1,1)
      end
    end

    local prelativ
    --calcul position relative
    if dst_group~=1 then
      prelativ={list[i].x-cpos.x,list[i].y-cpos.y,list[i].z-cpos.z}
    else
      prelativ={cpos.x,cpos.y,cpos.z}
    end
    
    dst_met:set_string("pos_cont",spacengine.compact(prelativ))
    
    if sauvegarde then --sauvegarde nouvelle donnée du module
      dst_met:set_string("spacengine",spacengine.compact(dst_space))
    end

    end --ifchannel

  end --for

  config[1][3]=math.ceil(config[1][3]/nb) --damage

    if config[2][2]>config[2][1] then config[2][2]=config[2][1] end --limitation battery

    if idx4>1 then --engine
      config[4][1]=math.floor(config[4][1]/idx4)+idx4
      config[4][3]=math.floor(config[4][3]/idx4)
      config[4][5]=math.floor(config[4][5]/idx4)
    end

    if idx5>1 then --shield
      config[5][3]=math.floor(config[5][3]/idx5)
      config[5][1]=math.min(150,math.floor((config[5][1]/idx5)+(idx5*2)))
    end

    if idx6>1 then --weapons
      config[6][1]=math.floor(config[6][1]/idx6)
      config[6][3]=math.min(160,math.floor(config[6][3]/idx6))
      config[6][5]=math.floor(config[6][5]/idx6)
      config[6][8]=math.floor(config[6][8]/idx6)
    end

    if idx7>1 then --radar
      config[7][1]=math.floor(config[7][1]/idx7)+(idx7*2)
      config[7][3]=math.min(200,math.floor(config[7][3]/idx7)+idx7)
    end

    if idx8>1 then --gravitation
      config[8][1]=math.floor(config[8][1]/idx8)
    end

    if idx11>1 then --oxygene
      config[11][1]=math.min(100,math.floor(config[11][1]/idx11))
      config[11][3]=math.floor(config[11][3]/idx11)
    end

    if idx13>1 then --manutention
      manutention[1]=math.floor(manutention[1]/idx13)
      manutention[3]=math.floor(manutention[3]/idx13)
    end

    config[3][4]=cont1
    config[3][5]=cont2
    config[4][8]=idx4
    config[6][7]=idx6
    config[7][4]=cont7
    config[7][5]=cont77
    config[9][1]=storage[1]
    config[10][1]=passenger[1]
    manutention[5]=cont11

    if manutention[7]=="" then manutention[7]="n" end

    local calcul=0
    storage[3][7],calcul=stockmax(storage[3][7],calcul,config[9][1])
    storage[3][6],calcul=stockmax(storage[3][6],calcul,config[9][1])
    storage[3][5],calcul=stockmax(storage[3][5],calcul,config[9][1])
    storage[3][4],calcul=stockmax(storage[3][4],calcul,config[9][1])
    storage[3][3],calcul=stockmax(storage[3][3],calcul,config[9][1])
    storage[3][2],calcul=stockmax(storage[3][2],calcul,config[9][1])
    storage[3][1],calcul=stockmax(storage[3][1],calcul,config[9][1])
    config[1][2]=config[1][2]+calcul
    storage[2]=calcul
    config[9][2]=storage[2]

    calcul=0
    passenger[3][1],calcul=stockmax(passenger[3][1],calcul,config[10][1])
    passenger[3][2],calcul=stockmax(passenger[3][2],calcul,config[10][1])
    passenger[3][3],calcul=stockmax(passenger[3][3],calcul,config[10][1])
    passenger[3][4],calcul=stockmax(passenger[3][4],calcul,config[10][1])
    passenger[3][5],calcul=stockmax(passenger[3][5],calcul,config[10][1])
    config[1][2]=config[1][2]+calcul
    passenger[2]=calcul
    config[10][2]=passenger[2]
    
    if id_stock_pos>1 then
      controler:set_string("stock_pos",spacengine.compact(stock_pos))
    else
      controler:set_string("stock_pos","")
    end
    
    controler:set_string("manutention",spacengine.compact(manutention))
    controler:set_string("passenger",spacengine.compact(passenger))
    controler:set_string("storage",spacengine.compact(storage))
    controler:set_string("config",spacengine.compact(config))

end

--********************
--*** PUNCH MODULE ***
--********************
local function refscr(cpos,cont_met,config)
  cont_met:set_string("config",spacengine.compact(config))
  spacengine.controler(cpos)
end

--***
spacengine.punch_module=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  local nb_param=spac_eng[5]*3
  local switch=string.sub(spac_eng[4],nb_param-2,nb_param-2)
  local command=string.sub(spac_eng[4],nb_param-1,nb_param-1)

  if config[1][1]==0 and group==12 then
    --spacengine.sound_on(cpos)
    local timer=minetest.get_node_timer(cpos)
    timer:set(10,0)
    config[1][1]=1
    config[12]="y"
    refscr(cpos,cont_met,config)
    return
  end

  --switch BP
  if switch=="b" then

    if command=="C" then --on off controler
      local timer=minetest.get_node_timer(cpos)
      if timer:is_started() then
        --spacengine.sound_off(cpos)
        timer:stop()
        config[1][1]=0
        config[12]="y"
        cont_met:set_string("config",spacengine.compact(config))
        spacengine.controler(cpos)
      else
        --spacengine.sound_on(cpos)
        timer:set(10,0)
        config[1][1]=1
        config[12]="y"
        refscr(cpos,cont_met,config)
      end

    elseif command=="J" then --engine jump
      return "menu#1#+3-"

    elseif command=="M" then --menu
      return "menu#1#-"

    elseif command=="P" then --power change src

      if type(config[3][4])=="table" then
        if config[3][1]<2 then config[3][1]=2 end
        config[3][1]=config[3][1]+1
        if config[3][1]>#config[3][4] then config[3][1]=2 end
      end
      config[12]="e"
      refscr(cpos,cont_met,config)

    elseif command=="F" then --weapons fire
      spacengine.weapons(cpos,channel,cont_met,config)
      
      config[12]="We"
      refscr(cpos,cont_met,config)

    elseif command=="r" then --radar cible
      local n=1
      if config[7][6]<1 then config[7][6]=1 end
      config[7][6]=config[7][6]+1
      if type(config[7][4])=="table" then
        n=#config[7][4]
      end
      if config[7][6]>n then config[7][6]=1 end
      config[12]="R"
      refscr(cpos,cont_met,config)

    elseif command=="S" then --radar scan
      spacengine.radar(cpos,channel,cont_met,config)
      config[12]="R"
      refscr(cpos,cont_met,config)

    elseif command=="s" then --manutention source
      local n=1
      local manutention=spacengine.decompact(cont_met:get_string("manutention"))
      manutention[6]=manutention[6]+1
      if type(manutention[5])=="table" then
        n=#manutention[5]
      end
      if manutention[6]>n then manutention[6]=1 end
      cont_met:set_string("manutention",spacengine.compact(manutention))
      config[12]="M"
      refscr(cpos,cont_met,config)

    elseif command=="c" then --manutention command
      local manutention=spacengine.decompact(cont_met:get_string("manutention"))
      manutention[8]=manutention[8]+1
      if manutention[8]>3 then manutention[8]=1 end
      cont_met:set_string("manutention",spacengine.compact(manutention))
      config[12]="M"
      refscr(cpos,cont_met,config)

    elseif command=="E" then --manutention execute

      if config[13]>-1 then return end

      config[13]=1 --active manutention
      config[12]="M"
      refscr(cpos,cont_met,config)


    elseif command=="D" then --on off power screen
      if type(config[3][4])=="table" then
        id=config[3][1]
        if id<2 then id=2 end
          if config[3][5][id]==0 then
            config[3][5][id]=1
          else
            config[3][5][id]=0
          end
      end
      config[12]="e"
      cont_met:set_string("config",spacengine.compact(config))
      spacengine.maj_channel(cpos,puncher,channel)
      spacengine.controler(cpos)

    elseif command=="H" then --cheat mod
      config[2][2]=config[2][1]
      config[5][4]=0
      config[12]="e"
      refscr(cpos,cont_met,config)

    end

  --switch Inter
  elseif switch=="i" then

    if command=="A" then --on off power
      --code=cible
      code=spac_eng[6]

      if type(config[3][4])=="table" then
        for i=2,#config[3][4] do
          idx=config[3][4][i]
          if code==spacengine.upgrade[3][idx][3] then
            config[3][5][i]=value
          end
        end
      end

      config[12]="e"
      cont_met:set_string("config",spacengine.compact(config))
      spacengine.maj_channel(cpos,puncher,channel)
      spacengine.controler(cpos)

    elseif command=="B" then --active switch
      local rangex=5+tonumber(string.sub(config[1][4],2,2))*2
      local rangey=5+tonumber(string.sub(config[1][4],4,4))*2
      local rangez=5+tonumber(string.sub(config[1][4],6,6))*2
      local pos1={x=cpos.x-rangex,y=cpos.y-rangey,z=cpos.z-rangez}
      local pos2={x=cpos.x+rangex,y=cpos.y+rangey,z=cpos.z+rangez}

      if not code then
        code=spac_eng[6]
      end

      if value>0 then
        local list=minetest.find_nodes_in_area(pos1,pos2,"bloc4builder:switch_off")
        for i=1,#list do
          dst=minetest.get_node(list[i]) 
          dst_met=minetest.get_meta(list[i])
          if channel==dst_met:get_string("channel") then
            if dst_met:get_string("code")==code then
              bloc4builder.switch_on(list[i],"bloc4builder:switch_on",10)
            end
          end
        end

      else
        local list=minetest.find_nodes_in_area(pos1,pos2,"bloc4builder:switch_on")
        for i=1,#list do
          dst=minetest.get_node(list[i]) 
          dst_met=minetest.get_meta(list[i])
          if channel==dst_met:get_string("channel") then
            if dst_met:get_string("code")==code then
              bloc4builder.switch_off(list[i],"bloc4builder:switch_off",10)
            end
          end
        end

      end

      config[12]="A"
      refscr(cpos,cont_met,config)

    elseif command=="C" then --light on/off
      local rangex=5+tonumber(string.sub(config[1][4],2,2))*2
      local rangey=5+tonumber(string.sub(config[1][4],4,4))*2
      local rangez=5+tonumber(string.sub(config[1][4],6,6))*2
      local pos1={x=cpos.x-rangex,y=cpos.y-rangey,z=cpos.z-rangez}
      local pos2={x=cpos.x+rangex,y=cpos.y+rangey,z=cpos.z+rangez}
      
      if value>0 then
        local list=minetest.find_nodes_in_area(pos1,pos2,"bloc4builder:light_off")
        for i=1,#list do
          dst=minetest.get_node(list[i]) 
          minetest.swap_node(list[i],{name="bloc4builder:light_up",param2=dst.param2})
        end

      else
        local list=minetest.find_nodes_in_area(pos1,pos2,"bloc4builder:light_up")
        for i=1,#list do
          dst=minetest.get_node(list[i]) 
          minetest.swap_node(list[i],{name="bloc4builder:light_off",param2=dst.param2})
        end

      end

      config[12]="A"
      refscr(cpos,cont_met,config)

    elseif command=="D" then --manutention on off

      if value==1 then
        if config[13]<0 then
          config[13]=-config[13]
        end
      else
        if config[13]>0 then
          config[13]=-config[13]
        elseif config[13]==0 then
          config[13]=-1
        end
      end

      config[12]="M"
      refscr(cpos,cont_met,config)
    end

  --switch Analog
  elseif switch=="a" then

    if command=="A" then --engine
      if group==14 then return config[4][2] end
      config[4][2]=switch_analog(config[4][2],value)
      config[12]="eD"
      refscr(cpos,cont_met,config)

    elseif command=="B" then --shield
      if group==14 then return config[5][2] end
      config[5][2]=switch_analog(config[5][2],value)
      config[12]="SCD"
      refscr(cpos,cont_met,config)

    elseif command=="C" then --weapons puissance
      if group==14 then return config[6][2] end
      config[6][2]=switch_analog(config[6][2],value)
      config[12]="WCD"
      refscr(cpos,cont_met,config)

    elseif command=="D" then --weapons range
      if group==14 then return config[6][4] end
      config[6][4]=switch_analog(config[6][4],value)
      config[12]="W"
      refscr(cpos,cont_met,config)

    elseif command=="F" then --gravitation
      if group==14 then return config[8][2] end
      config[8][2]=switch_analog(config[8][2],value)
      config[12]="GD"
      refscr(cpos,cont_met,config)

    elseif command=="G" then --oxygene
      if group==14 then return config[11][2] end
      config[11][2]=switch_analog(config[11][2],value)
      config[12]="OD"
      refscr(cpos,cont_met,config)

    elseif command=="E" then --radar
      if group==14 then return config[7][2] end
      config[7][2]=switch_analog(config[7][2],value)
      config[12]="RD"
      refscr(cpos,cont_met,config)

    elseif command=="H" then --manutention
      local manutention=spacengine.decompact(cont_met:get_string("manutention"))
      if group==14 then return manutention[2] end
      manutention[2]=switch_analog(manutention[2],value)
      cont_met:set_string("manutention",spacengine.compact(manutention))
      config[12]="M"
      refscr(cpos,cont_met,config)

    elseif command=="J" then --manutention
      local manutention=spacengine.decompact(cont_met:get_string("manutention"))
      if group==14 then return manutention[4] end
      manutention[4]=switch_analog(manutention[4],value)
      cont_met:set_string("manutention",spacengine.compact(manutention))
      config[12]="M"
      refscr(cpos,cont_met,config)

    elseif command=="x" then --xpos
      if group==14 then return config[4][4][1] end
      config[4][4][1]=switch_analog(config[4][4][1],value)
      config[12]="WRMc"
      refscr(cpos,cont_met,config)

    elseif command=="y" then --ypos
      if group==14 then return config[4][4][2] end
      config[4][4][2]=switch_analog(config[4][4][2],value)
      config[12]="WRMc"
      refscr(cpos,cont_met,config)

    elseif command=="z" then --zpos
      if group==14 then return config[4][4][3] end
      config[4][4][3]=switch_analog(config[4][4][3],value)
      config[12]="WRMc"
      refscr(cpos,cont_met,config)

    elseif command=="I" then --zone
      if group==14 then return config[4][4][3] end
      config[4][4][4]=switch_analog(config[4][4][4],value)
      config[12]="WRMc"
      refscr(cpos,cont_met,config)

    elseif command=="a" then --zone
      config[12]="sp"
      refscr(cpos,cont_met,config)

    end

  end


end

--************
--*** jump ***
--************
-- from spacejump to execute jump with my conditions
spacengine.jump = function(cpos, player,channel)
	local cont_met = minetest.get_meta(cpos)

  if channel==cont_met:get_string("channel") then
    local tmp=cont_met:get_string("config")

    if tmp=="" then return false end

    local config=spacengine.decompact(tmp)
    local pos_cont=spacengine.decompact(cont_met:get_string("pos_cont"))

  if config[4][6]>250 then return false,"WAIT ENGINE TOO HOT" end

  local conso,rmax,temperature,check=spacengine.conso_engine(cpos,config)

  temperature=temperature+config[4][6]

  if not check then return false,"! OVERLOAD !" end --destination trop loin

--recherche jumpdrive
  local rangex=5+tonumber(string.sub(config[1][4],2,2))*2
  local rangey=5+tonumber(string.sub(config[1][4],4,4))*2
  local rangez=5+tonumber(string.sub(config[1][4],6,6))*2
  local jumpdrive_pos=minetest.find_nodes_in_area({x=cpos.x-rangex,y=cpos.y-rangey,z=cpos.z-rangez},{x=cpos.x+rangex,y=cpos.y+rangey,z=cpos.z+rangez},"jumpdrive:engine")

  if #node~=1 then return false,"JumpDrive Error" end

	local radius = math.max(rangex,rangey,rangez)
	local targetPos = {x=config[1][6][1],y=config[1][6][2],z=config[1][6][3]}

  if jumpdrive.check_mapgen(cpos) then
		return false, "Error: mapgen was active in this area, please try again later for your own safety!"
	end

	local distance = vector.distance(cpos, targetPos)

	local radius_vector = {x=rangex, y=rangey, z=rangez}
	local source_pos1 = vector.subtract(cpos, radius_vector)
	local source_pos2 = vector.add(cpos, radius_vector)
	local target_pos1 = vector.subtract(targetPos, radius_vector)
	local target_pos2 = vector.add(targetPos, radius_vector)

  local x_overlap = (target_pos1.x <= source_pos2.x and target_pos1.x >= source_pos1.x) or
		(target_pos2.x <= source_pos2.x and target_pos2.x >= source_pos1.x)
	local y_overlap = (target_pos1.y <= source_pos2.y and target_pos1.y >= source_pos1.y) or
		(target_pos2.y <= source_pos2.y and target_pos2.y >= source_pos1.y)
	local z_overlap = (target_pos1.z <= source_pos2.z and target_pos1.z >= source_pos1.z) or
		(target_pos2.z <= source_pos2.z and target_pos2.z >= source_pos1.z)

	if x_overlap and y_overlap and z_overlap then
		return false, "Error: jump into itself! extend your jump target"
	end

	-- load chunk
	minetest.get_voxel_manip():read_from_map(target_pos1, target_pos2)

local blacklisted_pos_list = minetest.find_nodes_in_area(source_pos1, source_pos2, jumpdrive.blacklist)
	for _, nodepos in ipairs(blacklisted_pos_list) do
		return false, "Can't jump node @ " .. minetest.pos_to_string(nodepos)
	end

	if minetest.find_node_near(targetPos, radius, "vacuum:vacuum", true) then
		msg = "Warning: Jump-target is in vacuum!"
	end

	if minetest.find_node_near(targetPos, radius, "ignore", true) then
		return false, "Warning: Jump-target is in uncharted area"
	end

	if jumpdrive.is_area_protected(source_pos1, source_pos2, playername) then
		return false, "Jump-source is protected!"
	end

	if jumpdrive.is_area_protected(target_pos1, target_pos2, playername) then
		return false, "Jump-target is protected!"
	end

	local is_empty, empty_msg = jumpdrive.is_area_empty(target_pos1, target_pos2)

	if not is_empty then
		msg = "Jump-target is obstructed (" .. empty_msg .. ")"
		success = false
	end

	-- check preflight conditions
	local preflight_result = jumpdrive.preflight_check(cpos, targetPos, radius, playername)
	if not preflight_result.success then
		-- check failed in customization
		msg = "Preflight check failed!"
		if preflight_result.message then
			msg = preflight_result.message
		end
		success = false
	end

  --modif consommation, température
  config[2][2]=config[2][2]-conso
  config[4][6]=temperature
  --sauvegarde old pos controler
  config[1][5][1]=cpos.x
  config[1][5][2]=cpos.y
  config[1][5][3]=cpos.z
  --sauvegarde new pos controler
  pos_cont[1]=targetPos.x
  pos_cont[2]=targetPos.y
  pos_cont[3]=targetPos.z
  --sauvegarde data
  cont_met:set_string("pos_cont",spacengine.compact(pos_cont))
  cont_met:set_string("config",spacengine.compact(config))

	local t0 = minetest.get_us_time()

	minetest.sound_play("jumpdrive_engine", {
		pos = cpos,
		max_hear_distance = 50,
		gain = 0.7,
	})

	-- actual move
	jumpdrive.move(source_pos1, source_pos2, target_pos1, target_pos2)

	local t1 = minetest.get_us_time()
	local time_micros = t1 - t0

	minetest.log("action", "[jumpdrive] jump took " .. time_micros .. " us")

	-- show animation in source
	minetest.add_particlespawner({
		amount = 200,
		time = 2,
		minpos = source_pos1,
		maxpos = source_pos2,
		minvel = {x = -2, y = -2, z = -2},
		maxvel = {x = 2, y = 2, z = 2},
		minacc = {x = -3, y = -3, z = -3},
		maxacc = {x = 3, y = 3, z = 3},
		minexptime = 0.1,
		maxexptime = 5,
		minsize = 1,
		maxsize = 1,
		texture = "spark.png",
		glow = 5,
	})


	-- show animation in target
	minetest.add_particlespawner({
		amount = 200,
		time = 2,
		minpos = target_pos1,
		maxpos = target_pos2,
		minvel = {x = -2, y = -2, z = -2},
		maxvel = {x = 2, y = 2, z = 2},
		minacc = {x = -3, y = -3, z = -3},
		maxacc = {x = 3, y = 3, z = 3},
		minexptime = 0.1,
		maxexptime = 5,
		minsize = 1,
		maxsize = 1,
		texture = "spark.png",
		glow = 5,
	})

	return true, time_micros
end
return false
end
