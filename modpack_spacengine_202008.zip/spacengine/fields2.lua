--*** spacengine 202007 by CPC6128

--**function local**

local function refresh_screen(cpos,scr_value,channel)
  local cont_met = minetest.get_meta(cpos)
  if channel~=cont_met:get_string("channel") then return end
  local tmp=cont_met:get_string("config")
  if tmp=="" then return end
  local config=spacengine.decompact(tmp)
  config[12]=scr_value
  cont_met:set_string("config",spacengine.compact(config))
  spacengine.controler(cpos)
end

local function accept_upgrade(nod_met,spac_eng,group,form_spl)
  local idx2=tonumber(form_spl[3]) --ligne choisi
  local msg=false
    --si remplacement de l'upgrade
    if string.sub(spacengine.upgrade[group][idx2][1],1,1)=="1" then
      if group==3 then
        spac_eng[1]=idx2
      else
        local upg=string.sub(spac_eng[1],2)
        spac_eng[1]=string.sub(spacengine.upgrade[group][idx2][1],2)..upg
      end

      if group~=12 then --screen stockage texte
        nod_met:set_string("infotext",spacengine.upgrade[group][idx2][3])--name
      end

    else --ou rajout d'une option
      if group==3 then
        spac_eng[1]=idx2
      else
        if string.find(spac_eng[1],string.sub(spacengine.upgrade[group][idx2][1],2))==nil then
          spac_eng[1]=spac_eng[1].. string.sub(spacengine.upgrade[group][idx2][1],2)
        end
      end
    end

    local upgrad_spl={}
    --group POWER
    if group==3 then
      upgrad_spl=spacengine.decompact(spacengine.upgrade[group][idx2][4])

      for u=1,#spac_eng do
        if upgrad_spl[u]~="*" then --si "*" ne remplace pas
          if type(upgrad_spl[u])=="number" then --number
            spac_eng[u]=upgrad_spl[u]
          else
            local tmp=string.sub(upgrad_spl[u],1,1)
            if tmp==">" then --option add si >
              spac_eng[u]=spac_eng[u]+tonumber(string.sub(upgrad_spl[u],2))
            elseif tmp=="<" then --option dec si <
              spac_eng[u]=spac_eng[u]-tonumber(string.sub(upgrad_spl[u],2))
            elseif tmp=="$" then --option creation et add table
              local id=#spac_eng[u]
              local out=0
              local name_dst=string.sub(upgrad_spl[u],2)
              if type(spac_eng[u])=="table" then
                    local id=#spac_eng[u]
                    for chk=1,id do
                      if spac_eng[u][chk]==name_dst then out=1 end
                    end
                  
                    if out==0 then
                      id=id+1
                      spac_eng[u][id]=name_dst
                    end

                  else
                    local new_dat={spac_eng[u],name_dst}
                    spac_eng[u]=new_dat
                end

                else
                  spac_eng[u]=upgrad_spl[u]
                end
          end
        end
      end

    --Autre group
    else
      for i=1,#spacengine.upgrade[group] do
        local j=string.sub(spacengine.upgrade[group][i][1],2) --recupere numero d'option
        if string.find(spac_eng[1],j) and spacengine.upgrade[group][i][4]~="" then
          upgrad_spl=spacengine.decompact(spacengine.upgrade[group][i][4])
            
          for u=1,#spac_eng do
            if upgrad_spl[u]~="*" then --si "*" ne remplace pas
              if type(upgrad_spl[u])=="number" then --number
                spac_eng[u]=upgrad_spl[u]
              else
                local tmp=string.sub(upgrad_spl[u],1,1)
                if tmp==">" then --option add si >
                  spac_eng[u]=spac_eng[u]+tonumber(string.sub(upgrad_spl[u],2))

                elseif tmp=="<" then --option dec si <
                  spac_eng[u]=spac_eng[u]-tonumber(string.sub(upgrad_spl[u],2))

                elseif tmp=="$" then --option creation et add table
                  local out=0
                  local name_dst=string.sub(upgrad_spl[u],2)
                  if type(spac_eng[u])=="table" then
                    local id=#spac_eng[u]
                    for chk=1,id do
                      if spac_eng[u][chk]==name_dst then out=1 end
                    end
                  
                    if out==0 then
                      id=id+1
                      spac_eng[u][id]=name_dst
                    end

                  else
                    if spac_eng[u]~=name_dst then
                      local new_dat={spac_eng[u],name_dst}
                      spac_eng[u]=new_dat
                    end
                  end

                else
                  spac_eng[u]=upgrad_spl[u]
                end
              end
            end
          end

        end
      end
    end
      
    local inv = nod_met:get_inventory()
    if group==1 and spac_eng[2]~=inv:get_size("stock") then
      inv:set_size("stock",spac_eng[2])
    end
    nod_met:set_string("spacengine",spacengine.compact(spac_eng))
    msg=true
  return msg
end

--##########################################################################

--************
--*** MENU ***
--************
minetest.register_on_player_receive_fields(function(player, formname, fields)

  if string.find(formname,"spacengine")==nil then
    return
  end

  local new_form=false

  --recupere coordo du node, channel et group
  local form_spl=string.split(formname,"#")
  local npos=spacengine.ptn(form_spl[5])
  local nod_met = minetest.get_meta(npos)
  local channel=nod_met:get_string("channel")
  local node=minetest.get_node(npos)
  local group=minetest.get_item_group(node.name,"spacengine")

  local pos_cont=spacengine.decompact(nod_met:get_string("pos_cont"))
  local spac_eng=spacengine.decompact(nod_met:get_string("spacengine"))

  --recupere coordo controler
  local cpos
  if group==1 then
    cpos={x=pos_cont[1], y=pos_cont[2], z=pos_cont[3]}
  else
    cpos={x=npos.x-pos_cont[1], y=npos.y-pos_cont[2], z=npos.z-pos_cont[3]}
  end

  --**********************
  --** list menu accept **
  --**********************
  if fields.accept then
    if string.find(form_spl[4],"+1") then --upgrade module
      local price=spacengine.upgrade[group][tonumber(form_spl[3])][2]
      if spacengine.transaction(player,nil,price) then

        accept_upgrade(nod_met,spac_eng,group,form_spl)

        if group==12 then --screen modifie l'affichage
          refresh_screen(cpos,"y",channel)
        end

        local trouver,cpos=spacengine.search_controler(npos,player,channel)

        if trouver==true then
          if spacengine.maj_pos_node(npos,player,channel,cpos) then
            spacengine.maj_channel(cpos,player,channel) --maj nouveau channel
          end
        end
      end

      if string.find(form_spl[4],"~") then
        famille=form_spl[2].."#"..form_spl[3].."#-"
      else
        famille=form_spl[2].."#"..form_spl[3].."#".. string.sub(form_spl[4],3)
      end
      new_form=true

    elseif string.find(form_spl[4],"+2") then --reparation
      local lng=string.len(form_spl[4])
      local damage=tonumber(string.sub(form_spl[4],lng-6,lng-4))
      local volume=tonumber(string.sub(form_spl[4],lng-3))
      local price=math.ceil(damage*damage*volume*0.0002)
      
      if spacengine.transaction(player,nil,price) then
        local trouver,cpos=spacengine.search_controler(npos,player,channel)
        if trouver==true then
          if spacengine.maj_pos_node(npos,player,channel,cpos) then
            spacengine.maj_channel(cpos,player,channel,true) --maj nouveau channel
          end
        end
      end

    elseif string.find(form_spl[4],"+3") then --jumpdrive
      local jump,msg=spacengine.jump(cpos,player,channel)
      if msg then minetest.chat_send_player(player:get_player_name(),msg) end

    elseif string.find(form_spl[4],"+4") then --buy/sell
        --TODO stop controleur
        if fields.data1=="" then
          nod_met:set_string("vente","") --change le channel du node
        else
          nod_met:set_string("vente",fields.data1) -- ! vente en cour
        end
      return

    elseif string.find(form_spl[4],"+5") then --buy by other player
      local pl_name=player:get_player_name()
      local vente=nod_met:get_string("vente")

      if spacengine.transaction(player,nil,tonumber(vente)) then
        local new_name
        if fields.newname=="" then
          new_name="new_ship"
          --error
        else
          new_name=fields.newname
        end
        spacengine.sell_ship(cpos,new_name..":"..pl_name)
      end

      return
    end

  end

  --** changement gui pour selection option screen **
  if fields.screen then
    return spacengine.formspec_update(npos,player,form_spl[2].."#"..form_spl[3].."#~")
  end

  --** MaJ en quittant **
  if fields.maj then
    local split=string.split(channel,":")

    if fields.channel=="" then fields.channel="No channel" end

    local range="x5y5z5"
    pos_cont={62000,62000,62000} --reset position

    if group==1 then
      range=spac_eng[4]
    end

    nod_met:set_string("channel",fields.channel ..":".. split[2]) --change le channel du node
    nod_met:set_string("pos_cont",spacengine.compact(pos_cont))

    if split[1]~="No channel" then
      local trouver,cpos=spacengine.search_controler(npos,player,channel)
      if trouver==true then
        spacengine.maj_channel(cpos,player,channel) --maj ancien channel
      end
    end        

    channel=fields.channel ..":".. split[2]
    local trouver,cpos=spacengine.search_controler(npos,player,channel)

    if trouver==true then
      if spacengine.maj_pos_node(npos,player,channel,cpos) then
        spacengine.maj_channel(cpos,player,channel) --maj nouveau channel
      end
    end
    return
  end
 
  --** achat nouveau vaisseaux **
  if fields.achat then
    if string.find(fields.achat,"DCL:") then
      local dcl=string.gsub(fields.achat,"DCL:","")--ligne choisi
      local choice=dcl*1
      if spacengine.transaction(player,nil,spacengine.vaisseaux[choice][1]) then
        spacengine.place_ship(cpos,spacengine.vaisseaux[choice][3],player,channel,spacengine.vaisseaux[choice][4])
      end
    end
    return
  end

  --** reparation **
  if fields.repar then
    famille=form_spl[2].."#"..form_spl[3].."#+2"..form_spl[4]
    return spacengine.formspec_update(npos,player,famille)
  end

  if fields.vente then
    famille=form_spl[2].."#"..form_spl[3].."#+4"..form_spl[4]
    return spacengine.formspec_update(npos,player,famille)
  end

  if fields.commerce then
    famille=form_spl[2].."#"..form_spl[3].."#+6"..form_spl[4]
    return spacengine.formspec_update(npos,player,famille)
  end

  --** installation Upgrade **
  if fields.upgrade then
    if string.find(fields.upgrade,"DCL:") then
    local dcl=string.gsub(fields.upgrade,"DCL:","")--ligne choisi
    famille=form_spl[2].."#"..dcl.."#+1"..form_spl[4]

    return spacengine.formspec_update(npos,player,famille)
    end
  end

  --** bouton JUMP **
  if fields.jump then
    local scr_opt=tostring(group)
    if group==12 then
      scr_opt=string.sub(spac_eng[1],1,1) --option screen
    end
    
    if scr_opt=="E" or scr_opt=="4" then
      famille=form_spl[2].."#"..form_spl[3].."#+3"..form_spl[4]
      return spacengine.formspec_update(npos,player,famille)

    --weapons fire
    elseif scr_opt=="W" or scr_opt=="6" then
      local cont_met=minetest.get_meta(cpos)
      local config=spacengine.decompact(cont_met:get_string("config"))
      spacengine.weapons(cpos,channel,cont_met,config)
    end

  end

  --KEY ENTER

  --** changement channel **
  if fields.key_enter_field then
    if fields.key_enter_field=="channel" then
      local split=string.split(channel,":")

      if fields.channel=="" then fields.channel="No channel" end

      local range="x5y5z5"
      if group==1 then
        range=spac_eng[4]
      end

      pos_cont={62000,62000,62000} --reset position
      nod_met:set_string("channel",fields.channel ..":".. split[2]) --change le channel du node
      nod_met:set_string("pos_cont",spacengine.compact(pos_cont))

      if split[1]~="No channel" then
        local trouver,cpos=spacengine.search_controler(npos,player,channel)
        if trouver==true then
          spacengine.maj_channel(cpos,player,channel) --maj ancien channel
        end
      end        

      channel=fields.channel ..":".. split[2]

      if fields.channel~="No channel" then
        local trouver,cpos=spacengine.search_controler(npos,player,channel,range)
        if trouver==true then
          if spacengine.maj_pos_node(npos,player,channel,cpos) then
            spacengine.maj_channel(cpos,player,channel) --maj nouveau channel
          end
        end
      end

    --DATA1
    elseif fields.key_enter_field=="data1" then
      local scr_opt=tostring(group)
      if group==12 then
        scr_opt=string.sub(spac_eng[1],1,1) --option screen
      end
      local cont_met = minetest.get_meta(cpos)
      if channel~=cont_met:get_string("channel") then return end
      local tmp=cont_met:get_string("config")
      if tmp=="" then return end
      local config=spacengine.decompact(tmp)
      local reglage=math.abs(tonumber(fields.data1))

      if scr_opt=="S" or scr_opt=="5" then
        config[5][2]=math.min(100,reglage)
      elseif scr_opt=="E" or scr_opt=="4" then
        config[4][2]=math.min(100,reglage)
      elseif scr_opt=="W" or scr_opt=="6" then
        config[6][2]=math.min(100,reglage)
      elseif scr_opt=="R" or scr_opt=="7" then
        config[7][3]=math.min(100,reglage)
      elseif scr_opt=="G" or scr_opt=="8" then
        config[8][2]=math.min(100,puissance)
      elseif scr_opt=="O" or scr_opt=="11" then
        config[11][2]=math.min(100,reglage)
      end

      cont_met:set_string("config",spacengine.compact(config))

    --DATA2
    elseif fields.key_enter_field=="data2" then
      local scr_opt=tostring(group)
      if group==12 then
        scr_opt=string.sub(spac_eng[1],1,1) --option screen
      end
      local cont_met = minetest.get_meta(cpos)
      if channel~=cont_met:get_string("channel") then return end
      local tmp=cont_met:get_string("config")
      if tmp=="" then return end
      local config=spacengine.decompact(tmp)
      local reglage=math.abs(tonumber(fields.data1))

      if scr_opt=="W" or scr_opt=="6" then
        config[6][4]=math.min(100,reglage)
      end

      cont_met:set_string("config",spacengine.compact(config))

    --COORDO
    elseif fields.key_enter_field=="pos_dst" then
      local tmp_spl=string.split(fields.pos_dst," ")
      if not tmp_spl[2] or not tmp_spl[3] then return end
      local cont_met = minetest.get_meta(cpos)
      if channel==cont_met:get_string("channel") then
        local tmp=cont_met:get_string("config")
        if tmp=="" then return end
        local config=spacengine.decompact(tmp)
        local puissance=math.ceil(config[4][1]*(config[4][2]/100))
        local _,rmax=spacengine.conso_engine(cpos,config)

        local tmp1=math.min(cpos.x+rmax,tonumber(tmp_spl[1]))
        tmp1=math.max(cpos.x-rmax+1,tmp1)
        config[1][6][1]=tmp1
        tmp1=math.min(cpos.y+rmax,tonumber(tmp_spl[2]))
        tmp1=math.max(cpos.y-rmax,tmp1)
        config[1][6][2]=tmp1
        tmp1=math.min(cpos.z+rmax,tonumber(tmp_spl[3]))
        tmp1=math.max(cpos.z-rmax,tmp1)
        config[1][6][3]=tmp1
        cont_met:set_string("config",spacengine.compact(config))
      end
    end

  end

  local field_name,field_dat="-","-"
  for k, v in pairs(fields) do
    if string.find(k,"upgrade") then
    field_name = tostring(k)
    field_dat = v
    end

  if string.find(k,"power") then
    field_name = tostring(k)
    field_dat = v
    end
  end

  if string.find(field_name,"upgrade") then
    local field_spl=string.split(field_dat,":")
    famille=form_spl[2].."#"..field_spl[2].."#"..form_spl[4]
    new_form=true
  end

  if string.find(field_name,"power") then
    local field_spl=string.split(field_dat,":")
    if string.find(field_spl[1],"DCL") then
      local tmp=string.split(field_name,"#")
      local tmp1=tonumber(field_spl[2])
      local cont_pos=spacengine.ptn(tmp[2])
      local cont_met=minetest.get_meta(cont_pos)
      local config=spacengine.decompact(cont_met:get_string("config"))
      if config[3][5][tmp1]>0 then
        config[3][5][tmp1]=0
      else
        config[3][5][tmp1]=1
      end
      famille=form_spl[2].."#"..form_spl[3].."#"..form_spl[4]
      cont_met:set_string("config",spacengine.compact(config))
      local trouver,cpos=spacengine.search_controler(npos,player,channel)
      if trouver==true then
        if spacengine.maj_pos_node(npos,player,channel,cpos) then
          spacengine.maj_channel(cpos,player,channel) --maj nouveau channel
        end
      end
      new_form=true
    end
  end

if new_form then
return spacengine.formspec_update(npos,player,famille)
end
end)
