--
local function p_dis(p,nz)
if nz==nil then nz=5 end
local a=""
if p<0 then
a="-"..string.sub(tostring(math.abs(p)+10^nz),2)
else
a="+"..string.sub(tostring(p+10^nz),2)
end
return a
end

local function battery(config)
  local b1
  local b2="k"
  if config[2][1]==0 then --% battery
    b1=0
  else
    b1=math.ceil(((config[2][2])/config[2][1])*100)
  end
  if b1>74 then --couleur pile
    b2="f"
  elseif b1<26 then
    b2="h"
  end

  return "(1#".. b2 ..string.char(math.floor(b1/25)+112) ..")#q".. string.sub(tostring(b1+1000),2) .."%"
end

local function chargement(config)
  local poid1=config[1][2]
  local poid2=config[4][7]
  local poid=""
if poid1<poid2 then
          if poid2==0 then
            poid1=0
          else
            poid1=math.ceil((poid1/poid2)*100)
          end
          poid=poid.."#l(2`)"..string.sub(tostring(poid1+1000),2).."%"
        else
          poid=poid.."#h(2`)OVER"
        end
  return poid
end

local function energy_total(config)
  local u_t=config[2][2]
  local unit=" U"

  if u_t>100000 then
    u_t=math.floor(u_t/1000)
    unit="KU"
  end
return "#q(1*)"..string.sub(tostring(math.floor(u_t)+100000),2)..unit
end
--**********************
--*** screen display ***
--**********************
spacengine.screen_display=function(npos,nod_met,cpos,cont_met,config)
  local channel=nod_met:get_string("channel")

  local pos_cont=spacengine.decompact(nod_met:get_string("pos_cont"))
  local split=string.split(channel,":")
  local owner=split[2]
  channel=split[1]

  if channel=="No channel" or pos_cont[2]>31000 then
    nod_met:set_string("text","ERROR")
    monitor.update_sign(npos,nil,nil,nil)
    return false
  end

  local nod_space=spacengine.decompact(nod_met:get_string("spacengine"))
  local scr_opt=string.sub(nod_space[1],1,1)
  local phr=""
  local page=""
  --spacengine off
  if config[1][1]==0 then
    phr="#u".. string.sub(owner,1,16) .." | #s(2CBBBBBBBBBBBBBBD) | #s(2A)#hSPACENGINE OFF(2#sA) | #s(2EBBBBBBBBBBBBBBF) | #u".. string.sub(channel,1,16)

  else
    local bymodule=config[12]
    local by_all=false

    if string.find(config[12],"y") then
      by_all=true
    end

    --multipage
  if bymodule~="n" then
    local lng=string.len(nod_space[4])/3
    page="(2#b"
    for i=1,lng do
      if i==nod_space[5] then
        page=page.."#c"..i.."#b"
      else
        page=page..i
      end
    end
    page=page.. string.rep("_",9-lng)..")#c"
  end

  --*****************
  --*** controler ***
  --*****************
  if string.find(bymodule,"C") or string.find(bymodule,"e") or by_all then
    if scr_opt=="C" then
      if nod_space[5]==1 then
        page=page.."(1;)ON(1:)OFF"
      elseif nod_space[5]==2 then
        page=page.."#h(1!)JUMP "
        if config[4][6]<250 then
        page=page.."#f(1u)"
      else
        page=page.."#h(1!)"
      end
      elseif nod_space[5]==3 then
        page=page.."(3?MENU=@)"
      end

      phr=page.." | #p(3?CONTROLER@)".. battery(config) .." | "
      
      if config[3][3]<0 then
        phr=phr.."(2#df#h".. string.char(math.min(7,math.ceil(config[3][3]/-100))+110) .."#df"
      else
        phr=phr.."(2#df#t".. string.char(math.min(7,math.ceil(config[3][3]/100))+110) .."#df"
      end

      if config[4][2]>0 then
        phr=phr.."#f(1_'"..string.char(math.floor(config[4][2]/15)+97).."_)"
      else
        phr=phr.."#h(1_'a_)"
      end

      if config[6][2]>0 then
        phr=phr.."#f(1%"..string.char(math.floor(config[6][2]/15)+97).."_)"
      else
        phr=phr.."#h(1%a_)"
      end

      if config[5][2]>0 then
        phr=phr.."#f(1`"..string.char(math.floor(config[5][2]/15)+97).."_)"
      else
        phr=phr.."#h(1`a_)"
      end

      if config[11][2]>0 then 
        phr=phr.."#f (2:(1"..string.char(math.floor(config[11][2]/15)+97)..")"
      else
        phr=phr.."#h (2:(1a)"
      end

      local rmax=spacengine.conso_engine(cpos,config,1)
      
      if nod_space[5]==1 then
        local rangex=11+tonumber(string.sub(config[1][4],2,2))*4
        local rangey=11+tonumber(string.sub(config[1][4],4,4))*4
        local rangez=11+tonumber(string.sub(config[1][4],6,6))*4
        phr=phr.." | #r(1x)"
        if config[1][3]>75 then
          phr=phr.."#h"
        elseif config[1][3]>50 then
          phr=phr.."#j"
        else
          phr=phr.."#f"
        end
        phr=phr .. string.sub(tostring(config[1][3]+1000),2) .."%"
        phr=phr .. "#c(1_v)X".. rangex .."Y"..rangey.."Z"..rangez.." | "
        phr=phr.. "(1#kV)"..chargement(config) .."#l(10[)"..string.sub(tostring(config[1][2]+10000000),2)

      elseif nod_space[5]==2 then
        phr=phr.." | #jX"..p_dis(config[1][6][1]) .."(1__)Z"..p_dis(config[1][6][3]) .." | #jY"..p_dis(config[1][6][2]) .."(1__#m+w)".. string.sub(tostring(rmax+100000),2)

      elseif nod_space[5]==3 then
        phr=phr.." | #fX"..p_dis(cpos.x) .."(1__)Z"..p_dis(cpos.z) .." | #fY"..p_dis(cpos.y) .."(1__#m+w)".. string.sub(tostring(rmax+100000),2)
      end

    end
  end

  if string.find(bymodule,"B") or string.find(bymodule,"e") or by_all then
    --***************
    --*** battery ***
    --***************
    if scr_opt=="B" then
      local tmp1=config[2][1]
      local tmp2=config[2][2]
      local tmp3="U"
      phr="#p(3?BATTERY@) "..battery(config)
      
      if tmp1>100000 then
        tmp1=math.floor(tmp1/1000)
        tmp2=math.floor(tmp2/1000)
        tmp3="KU"
      end
      phr= phr.." | #qlvl "..string.sub(tostring(math.floor(tmp2)+10000000),2).." #p"..tmp3.." | #emax "..string.sub(tostring(math.floor(tmp1)+10000000),2).." #p"..tmp3
    end
  end
  --*************
  --*** power ***
  --*************
  if string.find(bymodule,"P") or string.find(bymodule,"e") or by_all then
    if scr_opt=="P" then

      if nod_space[5]==1 then
        page=page.." ON/OFF"
      elseif nod_space[5]==2 then
        page=page.."- SRC -"
      elseif nod_space[5]==3 then
        page=page.."(3?MENU=@)"
      end

      phr=page.." | #p(3?POWER@)"

        local tmp1=config[3][1]
        
        if type(config[3][4])=="table" then
          if tmp1<2 or tmp1>#config[3][4] then tmp1=2 end
          local id=config[3][4][tmp1]
          if config[3][5][tmp1]==0 then
            phr=phr.."#h(3?OFF@) | #g"
          else
            phr=phr.."#f(3?ON=@) | #g"
          end
          phr=phr.. string.sub(spacengine.upgrade[3][id][3],1,16) .." | "
          
        else
          phr=phr.."#jNONE | #h(3?OFF@) | "
        end

      if config[3][3]<0 then
        phr=phr.."(2#df#h".. string.char(math.min(7,math.ceil(config[3][3]/-100))+110) .."#df)#h".. string.sub(tostring(math.floor(config[3][3])+100000),2)
      else
        phr=phr.."(2#df#t".. string.char(math.min(7,math.ceil(config[3][3]/100))+110) .."#df)#f".. string.sub(tostring(math.floor(config[3][3])+100000),2)
      end

      local tmp1=config[2][1]
      local tmp2=config[2][2]
      local tmp3="U"
      if tmp1>100000 then
        tmp1=math.floor(tmp1/1000)
        tmp2=math.floor(tmp2/1000)
        tmp3="KU"
      end
      phr=phr.." | (1#qt)"..string.sub(tostring(math.floor(tmp2)+100000),2).."#o/#e".. string.sub(tostring(math.floor(tmp1)+100000),2) ..tmp3
    end
  end
  --**************
  --*** engine ***
  --**************
  if string.find(bymodule,"E") or string.find(bymodule,"e") or by_all then
    if scr_opt=="E" then
      if nod_space[5]==1 then
        phr=page.."#h(1!)JUMP (1!)"
      elseif nod_space[5]==2 then
        phr=page.."PUISSAN"
      elseif nod_space[5]==3 then
        phr=page.."(3?MENU=@)"
      end

      phr=phr.." | #p(3?ENGINE@)"
      if config[4][6]<250 then
        phr=phr.."#f(1u)"
      else
        phr=phr.."#h(1!)"
      end
      
      if config[4][6]>5000 then
        phr=phr.." (2#h"
      elseif config[4][6]>250 then
        phr=phr.." (2#k"
      else
        phr=phr.." (2#f"
      end

      phr=phr.."m)".. string.sub(tostring(config[4][6]+100000),2).." | "
      local conso,rmax,distance=spacengine.conso_engine(cpos,config,2)

      if nod_space[5]==1 then
        phr=phr.."#jX"..p_dis(config[1][6][1]).."(1____)".. battery(config).." | #jY".. p_dis(config[1][6][2]) .."(1____#rx)"..string.sub(tostring(config[1][3]+1000),2) .."% | #jZ".. p_dis(config[1][6][3]) .."(1___#du)".. string.sub(tostring(distance+100000),2)

      elseif nod_space[5]==2 then
        local conso_2
        if config[2][2]>0 then
          conso_2=math.min(200,math.ceil((conso/config[2][2])*100))
        else
          conso_2=200
        end
        local tmp1="f"
        if conso_2>75 then
          tmp1="h"
        elseif conso_2>50 then
          tmp1="k"
        end

        local tmp3=math.floor(config[4][2]/16)+65
        tmp2=math.ceil((config[4][1]*config[4][2])/100)
        phr=phr.."(1#n3)".. string.sub(tostring(rmax+100000),2) .."#k(1R*)".. string.sub(tostring(conso+100000000),2) .." | (1#mw)".. string.sub(tostring(config[4][3]+100000),2) .."#q(1Rt)".. string.sub(tostring(config[2][2]+100000000),2) .." | #g(1".. string.char(tmp3) .."')".. string.sub(tostring(tmp2+1000),2).."T#j(1R)#"..tmp1.. string.sub(tostring(conso_2+1000),2) .."%".. chargement(config)

      elseif nod_space[5]==3 then
        phr=phr.."#fX"..p_dis(cpos.x).."(2#l`(1V)".. string.sub(tostring(config[1][2]+10000000),2) .." | #fY"..p_dis(cpos.y).. "(1#k$V)".. string.sub(tostring(config[4][7]+10000000),2) .." | #fZ".. p_dis(cpos.z).."(1___#du)".. string.sub(tostring(distance+100000),2)
      end
      
    end
  end

--************
--** shield **
--************
if string.find(bymodule,"S") or by_all then
  if scr_opt=="S" then

    if nod_space[5]==1 then
      page=page.."PUISSAN"
    elseif nod_space[5]==2 then
        page=page.."(3?MENU=@)"
    end

    phr=page.." | #p(3?SHIELD@)"
    if config[5][2]>0 then
      phr=phr.."#f (3?ON=@)"
    else
      phr=phr.."#h (3?OFF@)"
    end
    local tmp1=math.floor((config[5][1]*config[5][2])/100)
    local tmp2=math.floor(config[5][2]/15)+65
    phr=phr.." | (1#k"..string.char(tmp2)..")"..string.sub(tostring(tmp1+1000),2).." "..string.sub(tostring(config[5][2]+1000),2).." % | #n(1`)"..string.sub(tostring(config[5][1]+1000),2).." #r(1x)"
    if config[1][3]>75 then
        phr=phr.."#h"
      elseif config[1][3]>50 then
        phr=phr.."#j"
      else
        phr=phr.."#f"
      end
    phr=phr.. string.sub(tostring(config[5][4]+1000),2).."%"
  end
end

--*************
--** weapons **
--*************
if string.find(bymodule,"W") or by_all then
  if scr_opt=="W" then

    phr=" | #p (3?WEAPONS@) "
    if config[6][6]==0 then
      phr=phr.."#fREADY!"
    else
      phr=phr.."#hRELOAD"
    end
    
    if nod_space[5]==1 then
      page=page.."#h(1!)FIRE (1!)"
    elseif nod_space[5]==2 then
      page=page.."PUISSAN"
    elseif nod_space[5]==3 then
      page=page.."-RANG -"
    elseif nod_space[5]==4 then
      page=page.."-ZONE -"
    elseif nod_space[5]==5 then
      page=page.."(3?MENU=@)"
    end
    local tmp1=math.floor((config[6][1]*config[6][2])/100)
    local tmp2=math.floor(config[6][2]/15)+65

    
    phr=page..phr.." | ".. battery(config) .."#l(1_%)".. string.sub(tostring(config[6][7]+1000),2) .." #d(1v)".. string.sub(tostring(config[6][8]+1000),2) .." | (1#g*".. string.char(tmp2) ..")".. string.sub(tostring(tmp1+100000),2).."U(1_#mw"
    tmp1=math.floor((config[6][3]*config[6][4])/100)
    tmp2=math.floor(config[6][4]/15)+65
    phr=phr..string.char(tmp2)..")"..string.sub(tostring(tmp1+1000),2)
    if nod_space[5]<4 then
      phr=phr.." | #e(2_Q)"..string.sub(tostring(config[6][6]+10000),2) .."/".. string.sub(tostring(config[6][5]+10000),2)
    elseif nod_space[5]==4 then
      tmp1=math.ceil(config[6][8]*config[4][4][4]/100)
      tmp2=math.floor(config[4][4][4]/15)+72
      phr=phr.." | #kZONE (1".. string.char(tmp2) .."_)"..tmp1
    else
      tmp1=math.floor((config[6][3]*config[6][4])/100)
      local xrng=math.ceil((-1+(0.02*config[4][4][1]))*tmp1)
      local yrng=math.ceil((-1+(0.02*config[4][4][2]))*tmp1)
      local zrng=math.ceil((-1+(0.02*config[4][4][3]))*tmp1)
      phr=phr.." | #pX"..xrng.." Y"..yrng.." Z"..zrng
    end

  end
end

--*****************
--** gravitation **
--*****************
if string.find(bymodule,"G") or by_all then
  if scr_opt=="G" then

    if nod_space[5]==1 then
      page=page.."PUISSAN"
    elseif nod_space[5]==2 then
        page=page.."(3?MENU=@)"
    end

    phr=page.." | #p(3?GRAVITON@)"
    if config[8][2]>0 then
      phr=phr.."#f(3?ON=@)"
    else
      phr=phr.."#h(3?OFF@)"
    end
    local tmp1=math.max(10,(config[8][1]*config[8][2]))/100
    local tmp2=math.floor(config[8][2]/14.4)+65
    phr=phr.." | (1#l"..string.char(tmp2)..") | #l"..tmp1.."G"
  end
end

--*************
--** oxygene **
--*************
if string.find(bymodule,"O") or by_all then
  if scr_opt=="O" then --oxygene

    if nod_space[5]==1 then
      page=page.."PUISSAN"
    elseif nod_space[5]==2 then
        page=page.."(3?MENU=@)"
    end

    phr=page.." | #p(3?OXYGENE@)"
    if config[11][2]>0 then
      phr=phr.."#f(3?ON=@)"
    else
      phr=phr.."#h(3?OFF@)"
    end
    local tmp1=math.floor((config[11][1]*config[11][2])/100)
    local tmp2=math.floor(config[11][2]/15)+65
    phr=phr.." | (1#i"..string.char(tmp2)..") | #gmax "..tmp1.." %"

  end
end

--***********
--** radar **
--***********
if string.find(bymodule,"R") or by_all then
  if scr_opt=="R" then --radar

    if nod_space[5]==1 then
      page=page.."#j-SCAN -"
    elseif nod_space[5]==2 then
      page=page.."PUISSAN"
    elseif nod_space[5]==3 then
      page=page.."-CIBLE-"
    elseif nod_space[5]==4 then
      page=page.."-ZONE -"
    elseif nod_space[5]==5 then
      page=page.."(3?MENU=@)"
    end

    phr=page.." | #p(3?RADAR@(1#rU_#lw)"..config[7][3]
    local tmp1=math.floor((config[7][1]*config[7][2])/100)
    local tmp2=math.floor(config[7][2]/15)+65
    local tmp3=math.floor((config[7][3]*config[4][4][4])/100)
    phr=phr.." | "..battery(config).."(1#d__"..string.char(tmp2).."*)"..string.sub(tostring(tmp1+1000),2).."U #p(1v)"..tmp3
    if nod_space[5]<4 then
      local id=math.max(1,config[7][6])
      if type(config[7][4])=="table" then
        id=math.min(#config[7][4],id)
        tmp3=string.split(config[7][4][id],":")
        phr=phr.." | #p".. string.sub(tmp3[2],1,16).." | #p"..config[7][5][id]
      else
        tmp3=string.split(config[7][4],":")
        phr=phr.." | #p".. string.sub(tmp3[2],1,16).." | #p"..config[7][5]
      end

    else
      local xrng=math.ceil((-1+(0.02*config[4][4][1]))*config[7][3])
      local yrng=math.ceil((-1+(0.02*config[4][4][2]))*config[7][3])
      local zrng=math.ceil((-1+(0.02*config[4][4][3]))*config[7][3])
      phr=phr.." | #pX"..xrng.." Y"..yrng.." Z"..zrng
    end
  end
end

--*****************
--** manutention **
--*****************
if string.find(bymodule,"M") or by_all then
  if scr_opt=="M" then
    local manutention=spacengine.decompact(cont_met:get_string("manutention"))

    if nod_space[5]==1 then
      page=page.."!EXEC !"
    elseif nod_space[5]==2 then
      page=page.."COMMAND"
    elseif nod_space[5]==3 then
      page=page.."-SRCE -"
    elseif nod_space[5]==4 then
      page=page.."-RANGE-"
    elseif nod_space[5]==5 then
      page=page.."-ZONE -"
    elseif nod_space[5]==6 then
      page=page.."(3?MENU=@)"
    end

    local tmp1=math.floor((manutention[1]*manutention[2])/100)
    local tmp2=math.floor(manutention[2]/15)+65
    local tmp3
    local tmp4=math.floor((manutention[3]*config[4][4][4])/100)

    if type(manutention[5])=="table" then
      if manutention[6]>#manutention[5] then manutention[6]=1 end
      tmp3=string.split(manutention[5][manutention[6]],":")
    else
      tmp3=string.split(manutention[5],":")
    end

    if config[13]<0 then
      phr=page.." | (3#h?MANUTENTION@)"
    else
      phr=page.." | (3#f?MANUTENTION@)"
    end

    phr=phr.."#j(2R)".. string.sub(tostring(tmp3[3]+100),2) .." | (1#mw".. string.char(tmp2) ..")".. string.sub(tostring(tmp1+1000),2)
    
    tmp2=math.floor(config[4][4][4]/15)+65

    phr=phr.."(1#d_v"..string.char(tmp2)..")".. string.sub(tostring(tmp4+1000),2).."#i(1_*)".. string.sub(tostring(tmp3[5]+1000),2)

  if nod_space[5]<4 then
    phr=phr.." | #f".. string.sub(tmp3[2],1,16).." | "

    if string.find(manutention[7],"B") and string.find(tmp3[4],"B") then
      if manutention[8]==1 then
        phr=phr.."(1#kT)"
      else
        phr=phr.."(1#wT)"
      end
    else
      phr=phr.."(1#w/)"
    end
    if string.find(manutention[7],"D") and string.find(tmp3[4],"D") then
      if manutention[8]==2 then
        phr=phr.."(2#k*)"
      else
        phr=phr.."(2#w*)"
      end
    else
      phr=phr.."(1#w/)"
    end
    if string.find(manutention[7],"P") and string.find(tmp3[4],"P") then
      if manutention[8]==3 then
        phr=phr.."(2#k+)"
      else
        phr=phr.."(2#w+)"
      end
    else
      phr=phr.."(1#w/)"
    end
  else
    local xrng=math.ceil((-1+(0.02*config[4][4][1]))*tmp1)
    local yrng=math.ceil((-1+(0.02*config[4][4][2]))*tmp1)
    local zrng=math.ceil((-1+(0.02*config[4][4][3]))*tmp1)
    phr=phr.." | #pX"..xrng.." Y"..yrng.." Z"..zrng .." | #v".. manutention[9]

end

  end
end

--*************
--** storage **
--*************
if string.find(bymodule,"s") or by_all then
  if scr_opt=="s" then
    local storage=spacengine.decompact(cont_met:get_string("storage"))

    if nod_space[5]==1 then
      page=page.."PAGE (162)"
    elseif nod_space[5]==2 then
        page=page.."(3?MENU=@)"
    end

    local nb_param=nod_space[5]
    if nb_param>math.floor(string.len(nod_space[4])/3) then
      nb_param=1
    end

    local vl=string.sub(nod_space[4],nb_param*3,nb_param*3)
    phr=page.." | #p(3?STORAGE@(2_#w`) | #o".. string.sub(tostring(storage[2]+1000000),2) .."/".. string.sub(tostring(storage[1]+1000000),2)
    if vl=="0" then
      phr=phr.." | #pEat "..storage[3][1].." | #pOres"..storage[3][2]
    elseif vl=="1" then
      phr=phr.." | #pTools "..storage[3][3].." | #pFurniture"..storage[3][4]
    elseif vl=="2" then
      phr=phr.." | #pWeapons "..storage[3][5].." | #pHightech"..storage[3][6]
    elseif vl=="3" then
      phr=phr.." | #pMachine "..storage[3][3]
    elseif vl=="4" then
      phr=phr.." | #pWeight "..config[1][2]
    end
  end
end

--***************
--** passenger **
--***************
if string.find(bymodule,"p") or by_all then
  if scr_opt=="p" then
    local passenger=spacengine.decompact(cont_met:get_string("passenger"))

    if nod_space[5]==1 then
      page=page.."PAGE (162)"
    elseif nod_space[5]==2 then
        page=page.."(3?MENU=@)"
    end

    phr=page.." | #p(3?PASSENGER@(2_#n@) | #o".. string.sub(tostring(passenger[2]+1000000),2) .."/".. string.sub(tostring(passenger[1]+1000000),2) .." | #pCrew"..passenger[3][1]
    local nb_param=nod_space[5]
    if nb_param>math.floor(string.len(nod_space[4])/3) then
      nb_param=1
    end

    local vl=string.sub(nod_space[4],nb_param*3,nb_param*3)
    phr=page.." | #p(3?PASSENGER@(2_#n@) | #o".. string.sub(tostring(passenger[2]+1000000),2) .."/".. string.sub(tostring(passenger[1]+1000000),2)
    if vl=="0" then
      phr=phr.." | #pCrew "..passenger[3][1]
    elseif vl=="1" then
      phr=phr.." | #pWorker "..passenger[3][2]
    elseif vl=="2" then
      phr=phr.." | #pTourist "..passenger[3][3]
    elseif vl=="3" then
      phr=phr.." | #pScientist "..passenger[3][4]
    elseif vl=="4" then
      phr=phr.." | #pMilitary "..passenger[3][5]
    elseif vl=="5" then
      phr=phr.." | #pWeight "..config[1][2]
    end

  end
end

if string.find(bymodule,"A") or by_all then
--** SWITCH **
  if scr_opt=="A" then
    
    if nod_space[5]==1 then
      page=page.."HANGAR(1_)"
    elseif nod_space[5]==2 then
      page=page.."SAS_OUT"
    elseif nod_space[5]==3 then
      page=page.."DOOR_IN"
    elseif nod_space[5]==4 then
      page=page.."STORAGE"
    elseif nod_space[5]==5 then
      page=page.."AUX_1(1__)"
    elseif nod_space[5]==6 then
      page=page.."AUX_2(1__)"
    elseif nod_space[5]==7 then
      page=page.."-LIGHT-"
    end

    phr=page.." | #p(3?SWITCH@) | (1"
    local lign_up,lign_down="",""
    local value
    for nb_param=1, 7 do
      value=tonumber(string.sub(nod_space[4],nb_param*3,nb_param*3))
      if value==0 then
        lign_up=lign_up.."#h_Y"
        lign_down=lign_down.." "..nb_param
      else
        lign_up=lign_up.."#f_Z"
        lign_down=lign_down.." "..nb_param
      end
    end
    phr=phr..lign_up.."_) | #p"..lign_down .."(1_) | (2#sBBBBBBBBBBBBBBBB)"
  end
end

if string.find(bymodule,"D") or by_all then
--** analog **
  if scr_opt=="D" then
    
    if nod_space[5]==1 then
      page=page.."-ENGINE"
    elseif nod_space[5]==2 then
      page=page.."WEAPONS"
    elseif nod_space[5]==3 then
      page=page.."-SHIELD"
    elseif nod_space[5]==4 then
      page=page.."-RADAR-"
    elseif nod_space[5]==5 then
      page=page.."GRAVITO"
    elseif nod_space[5]==6 then
      page=page.."OXYGENE"
    end

    phr=page.." | #p(3?ANALOG@) | "
    local lign_up=""
    local lign_down=""

    if config[4][2]>0 then
      lign_up=lign_up.."#f(1"..string.char(math.floor(config[4][2]/15)+65)
      --lign_down=lign_down.."#f(1'"
    else
      lign_up=lign_up.."#h(1A"
      --lign_down=lign_down.."#h(1'"
    end

    if config[6][2]>0 then
      lign_up=lign_up.."#f_"..string.char(math.floor(config[6][2]/15)+65)
      --lign_down=lign_down.."#f_%"
    else
      lign_up=lign_up.."#h_A"
      --lign_down=lign_down.."#h_%"
    end

    if config[5][2]>0 then
      lign_up=lign_up.."#f_"..string.char(math.floor(config[5][2]/15)+65)
      --lign_down=lign_down.."#f_`"
    else
      lign_up=lign_up.."#h_A"
      --lign_down=lign_down.."#h_`"
    end

    if config[7][2]>0 then
      lign_up=lign_up.."#f_"..string.char(math.floor(config[7][2]/15)+65)
      --lign_down=lign_down.."#f_U"
    else
      lign_up=lign_up.."#h_A"
      --lign_down=lign_down.."#h_U"
    end

    if config[8][2]>0 then 
      lign_up=lign_up.."#f_"..string.char(math.floor(config[8][2]/15)+65)
      --lign_down=lign_down.."#f_)G"
    else
      lign_up=lign_up.."#h_A"
      --lign_down=lign_down.."#h_)G"
    end

    if config[11][2]>0 then 
      lign_up=lign_up.."#f_"..string.char(math.floor(config[11][2]/15)+65)
      --lign_down=lign_down.."#f(2_:)"
    else
      lign_up=lign_up.."#h_A)"
      --lign_down=lign_down.."#h(2_:)"
    end

    phr=phr..lign_up.." | (1#p'_%_`_U_)G(2_:)"
  end
end

if string.find(bymodule,"c") or by_all then
--** coordo **
  if scr_opt=="c" then
    local manutention=spacengine.decompact(cont_met:get_string("manutention"))
    if nod_space[5]==1 then
      page=page.."-SET X-"
    elseif nod_space[5]==2 then
      page=page.."-SET Y-"
    elseif nod_space[5]==3 then
      page=page.."-SET Z-"
    elseif nod_space[5]==4 then
      page=page.."-ZONE -"
    elseif nod_space[5]==5 then
      page=page.."(3?MENU=@)"
    end

    local zone=math.floor(config[4][4][4]/15)+65
    phr=page.." | (1#m".. string.char(math.floor(config[4][4][1]/15)+65) .."#e".. string.char(math.floor(config[4][4][2]/15)+65) .."#j".. string.char(math.floor(config[4][4][3]/15)+65) .."#p(3?COORDO@#k(1_"..string.char(zone) ..") | "
    local wpns=math.floor((config[6][3]*config[6][4])/100)
    local radar=config[7][3]
    local manut=math.floor((manutention[1]*manutention[2])/100)
    local xrng=(-1+(0.02*config[4][4][1]))
    local yrng=(-1+(0.02*config[4][4][2]))
    local zrng=(-1+(0.02*config[4][4][3]))
    phr=phr.."(1#h%)#mX".. p_dis(math.floor(xrng*wpns),2).." #eY"..p_dis(math.floor(yrng*wpns),2).." #jZ"..p_dis(math.floor(zrng*wpns),2).." | " --.."(1#d"..string.char(zone)..")"
    phr=phr.."(1#dU)#mX"..p_dis(math.floor(xrng*radar),2).." #eY"..p_dis(math.floor(yrng*radar),2).." #jZ"..p_dis(math.floor(zrng*radar),2).." | "
    phr=phr.."(1#kT)#mX"..p_dis(math.floor(xrng*manut),2).." #eY"..p_dis(math.floor(yrng*manut),2).." #jZ"..p_dis(math.floor(zrng*manut),2)
  end
end

end

if phr=="" then return end
nod_met:set_string("text",phr)
monitor.update_sign(npos,nil,nil,nil)
end
