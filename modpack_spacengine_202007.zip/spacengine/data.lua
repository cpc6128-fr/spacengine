spacengine.graviton={}

spacengine.vaisseaux={
{20000,"Navette","spaceship_navette"},
{50000,"Atlantis","spaceship_atlantis"}
}

spacengine.upgrade={
--controler
{
{"1A",0,"Controler beta5","*¨250¨0¨^x0y0z0v1331¨*","Vaisseaux de base, X=11 Y=11 Z=11"},
{"1B",500,"The Cube","*¨300¨0¨^x2y2z2v6859¨*","Vaisseaux cubique X=19 Y=19 Z=19"},
{"1C",500,"Destroyer","*¨350¨0¨^x4y1z0v4455¨*","X=27 Y=15 Z=11"},
{"1D",750,"VOYAGER","*¨350¨0¨^x0y0z5v3751¨*","Voyager X=11 Y=11 Z=31"},
{"1E",800,"Cargo","*¨350¨0¨^x1y1z4v6075¨*","Cargo X=15 Y=15 Z=27"},
{"1F",800,"Tower","*¨350¨0¨^x1y3z1v5175¨*","The TUBE X=15 Y=23 Z=15"},
{"1G",750,"Discovery","*¨350¨0¨^x0y3z1v3795¨*","X=11 Y=23 Z=15"},
{"1H",250,"Flat","*¨280¨0¨^x3y0z3v5819¨*","X=23 Y=11 Z=23"},
{"2a",0,"stock 6","*¨*¨*¨*¨6","Stockage de base 6 emplacements"},
{"2b",1000,"stock 12","*¨*¨*¨*¨12","Stockage 12 emplacements"},
{"2c",2000,"stock 24","*¨*¨*¨*¨24¨*","Stockage 24 emplacements"}
},
--battery
{
{"1A",0,"BATTERY 50","*¨50¨0¨5000","Capaciter 5000"},
{"1B",250,"BATTERY 100","*¨100¨0¨10000","Capaciter 10000"},
{"1C",500,"BATTERY Mega5","*¨150¨0¨50000","Capaciter 50000"},
{"1D",1000,"BATTERY SUPRA X10","*¨300¨0¨100000","Capaciter 100000"}
},
--power
{
{"1A",0,"Generator Charcoal","*¨100¨0¨5¨^default:coal_lump¨^battery¨10¨0¨0¨0","Generateur utilisant le charbon, il produit 5 U / 10 cycles"},
{"1B",400,"Generateur Hydrogene","*¨150¨0¨75¨^spacengine:hydrogene_tank¨^battery¨15¨0¨0¨0","Generateur utilisant l'Hydrogene, production 75 U / 15 cycles"},
{"1C",500,"Generator petrol","*¨200¨0¨100¨^espace:petrol_can¨^battery¨25¨0¨0¨0","Generateur utilisant du petrole, apporte une puissance de 100 U / 25 Cycles."},
{"1D",550,"Solar panel","*¨100¨0¨25¨^solar¨^battery¨10¨0¨0¨0","Generateur a energie solaire, produit jusqu'a 25 U en plein soleil"},
{"1E",1500,"Nuclear system","*¨2500¨0¨1500¨^technic:uranium_block¨^battery¨200¨0¨0¨0","Nuclear reactor, generer de l'energie depuis l'uranium, grande puissance pendant longtemps, 1500 U / 200 cycles, son poids est problematique 2500 Kg"},
{"1F",250,"Hydro generator","*¨200¨0¨-20¨^default:water_source¨^spacengine:hydrogene_tank¨20¨0¨0¨0","Fabriquer de l'hydrogene c'est possible a partir de l'electrolyse de l'eau, consomme -20 U / 20 cycles pour produire 1 bouteille d'hydrogene"},
{"1G",250,"Oxy generator","*¨200¨0¨-4¨^default:water_source¨^spacengine:oxygene_tank¨10¨0¨0¨0","Besoin d'air, cette option est pour vous, le generateur utilise de l'eau et consomme -4 U / 10 cycles par bouteille d'oxygene"},
{"1H",250,"WaTeR System","*¨200¨0¨0¨^solar¨^default:water_source¨50¨0¨0¨0","Produire de l'eau a partir du soleil c'est simple mais long : 50 cycles. systeme qui ne consomme pas d'energie de la battery"},
{"1I",400,"Hydra","*¨300¨0¨75¨^water¨^battery¨2¨0¨0¨0","Une generatrice a eau, immerger elle produit jusqu'a 75 U par cycle"},
{"1J",150,"Biofuel","*¨300¨0¨-5¨^group:leave¨^biofuel:fuel_can¨10¨0¨0¨0","Transforme des feuilles en carburant Biofuel, consomme 5 U par cycle et genere en 10 cycles une bouteille de Biofuel"},
{"1K",300,"Generator Biofuel","*¨100¨0¨50¨^biofuel:fuel_can¨^battery¨10¨0¨0¨0","Generateur utilisant le Biofuel, il produit 50 U / 10 cycles"}
},
--engine
{
{"1A",0,"Rocket","*¨75¨0¨10¨50¨250¨1000","Rocket pour deplacer une charge de 500 Kg sur un trajet court : 100 blocs maximum, puissance de 10 Teslas"},
{"1B",750,"Magnetosphere","*¨150¨0¨25¨350¨500¨2000","Deplacement dans le systeme planetaire, pour une charge maximale de 1000 Kg, et un rayon d'action de 700 blocs, puissance restitué de 25 Teslas"},
{"1C",1000,"SpeedLight","*¨125¨0¨35¨2500¨750¨10000","Voyage entre différent systeme, rayon d'action de 1000 bloc et pouvant transporter des charges de 5000 Kg, puissance max de 35 Teslas"},
{"1D",2000,"Black_hole","*¨125¨0¨150¨5000¨800¨20000","Ideal pour explorer les confins de la galaxie, des sauts de 10000 blocs et une charge admissible de 10000 Kg, 150 Teslas"},
{"2a",250,"Booster","*¨^>10¨0¨^>5¨^>250¨*¨^>1000","Une option pour booster votre moteur Weight+10 Power+5 Range+50 Storage+500"},
{"2b",500,"More weight","*¨^<10¨0¨^>10¨*¨*¨^>5000","Remplacement de certains organes du moteur par d'autre plus léger, gain de performance pour transporter des marchandises Weight-10 Power+10 Storage+5000"},
{"2c",500,"Freezer","*¨^>50¨0¨^>1¨*¨^>200¨^<25","Rajout d'un refroidisseur pour diminuer le temps d'attente entre chaque jump"}
},

--shield
{
{"1A",0,"Protector one","*¨100¨0¨25¨1","Protection basique contre les radiations cosmiques"},
{"1B",250,"WatchDog","*¨125¨0¨50¨2","Un bouclier qui ammorti les impacts des tirs ennemis"},
{"1C",300,"Guardian","*¨150¨0¨70¨3","Guardian of the Galaxie"},
{"2a",200,"Protect +","*¨^>50¨*¨^>20¨^>1","+20% de protection"},
{"2b",200,"ReGene","*¨^>50¨*¨*¨^>4","regeneration rapide"}
},

--weapons
{
{"1A",0,"Laser","*¨100¨0¨500¨20¨15¨2","Un laser de tres courte porte et petite puissance"},
{"1B",1000,"Canon Plasma","*¨100¨0¨1250¨35¨18¨4","Un canon puissant mais court"},
{"1C",1000,"Destroyer","*¨75¨0¨7500¨75¨14¨5","Pour infliger des degats aux vaisseaux"},
{"2a",250,"Power","*¨^>10¨*¨^>1000¨*¨^<1¨*","Besoin de puissance ? +1000"},
{"2b",150,"Increase Speed","*¨^>100¨*¨^<25¨*¨^<10¨*","Rechargement plus rapide"},
{"2c",300,"Full range","*¨^>100¨*¨^<25¨^>50¨^>2¨*","Augmente la distance des tirs +50"},
{"2d",400,"ZONE extend","*¨^>50¨*¨^<25¨*¨*¨^>5","Augmente la zone des tirs +5"}
},

--radar
{
{"1A",0,"Stone","*¨50¨0¨100¨10¨^$group:stone","Detection courte porter du group stone"},
{"2B",750,"Uranium","*¨^>5¨*¨^>200¨^>5¨^$technic:mineral_uranium","Detection de l'uranium, augmente de 5 bloc le range"},
{"2C",200,"COAL","*¨^>5¨*¨*¨*¨^$default:stone_with_coal","Detection de coal"},
{"2D",500,"COPPER","*¨^>10¨*¨^>25¨^>30¨^$default:stone_with_copper","Detection de copper, augmente de 30 le range"},
{"2E",400,"Diamond","*¨^>15¨*¨^>200¨^>30¨^$default:stone_with_diamond","Detection de diamond, range = +30"},
{"2a",100,"More Range","*¨^>55¨*¨^>10¨^>20¨*","Detection augmenter de 20 blocs"},
{"2b",100,"p-","*¨^>5¨*¨^<25¨*¨*","baisse la consommation d'energie"}
},

--gravitation
{
{"1A",0,"Gravitation","*¨100¨0¨0.5","Gravitation artificielle, permet dans l'espace d'avoir une gravitation de 0.5 G"},
{"2a",200,"+0.2 G","*¨^>200¨0¨^>0.2","Augmente la Gravitation artificielle de 0.2 G"}
},

--storage
{
{"1A",0,"Container 500Kg","*¨100¨0¨500","Container de base, capaciter de 500 Kg"},
{"1B",250,"Container 1000Kg","*¨150¨0¨1000","Container d'une capaciter de 1000 Kg"},
{"1C",750,"Container 5000Kg","*¨200¨0¨5000","Container renforcer pour une capaciter de 5000 Kg"}
},

--passenger
{
{"1A",0,"Crew","*¨50¨0¨^c","Siege pour un membre d'equipage"},
{"1B",150,"Tourist","*¨50¨0¨^t","Siege pour un passager en vacance classe 1"},
{"1C",50,"Worker","*¨50¨0¨^w","Siege pour un travailleur classe 2"},
{"1D",200,"Scientist","*¨60¨0¨^s","Siege pour un scientifique, ingenieur, classe VIP"},
{"1E",100,"Military","*¨75¨0¨^m","Siege pour transport de troupe"}
},

--oxygene
{
{"1A",0,"Oxygene","*¨150¨0¨10¨50","Oxygene le vaisseaux, 10% d'oxygene, attendre 50 cycle entre chaque ventilation"},
{"2a",1000,"Oxygene+","*¨^>15¨0¨^<20¨*","Augmente le seuil d'oxygene a 20%"}
},

--screen
{
{"1C",0,"Controler","*¨*¨0¨^bC0bJ0bM0¨1",""},
{"1B",0,"Battery","*¨*¨0¨^bM0¨1",""},
{"1P",0,"Power","*¨*¨0¨^bD0bP0bM0¨1",""},
{"1E",0,"Engine","*¨*¨0¨^bJ0aA0bM0¨1",""},
{"1S",0,"Shield","*¨*¨0¨^aB0bM0¨1",""},
{"1W",0,"Weapons","*¨*¨0¨^bF0aC0aD0aI0bM0¨1",""},
{"1R",0,"Radar","*¨*¨0¨^bS0aE0br0aI0bM0¨1",""},
{"1G",0,"Graviton","*¨*¨0¨^aF0bM0¨1",""},
{"1s",0,"Storage","*¨*¨0¨^aa0bM0¨1",""},
{"1p",0,"Passenger","*¨*¨0¨^aa0bM0¨1",""},
{"1O",0,"Oxygene","*¨*¨0¨^aG0bM0¨1",""},
{"1M",0,"Manutention","*¨*¨0¨^bE0bc0bs0aH0aI0bM0¨1",""},
{"1A",50,"SWITCH","*¨*¨0¨^iB0iB0iB0iB0iB0iB0iC0¨1",""},
{"1D",50,"ANALOG","*¨*¨0¨^aA0aC0aB0aE0aF0aG0¨1",""},
{"1c",50,"COORDO","*¨*¨0¨^ax0ay0az0aI0bM0¨1",""}
},

--manutention
{
{"1B",0,"Crane","*¨150¨0¨50¨2¨^$default:stone:3:BD:50","Grue pour poser des STONE"},
{"1D",100,"Digger","*¨250¨0¨50¨2¨^$default:stone:3:BD:50","foreuse de STONE"},
{"1P",100,"Pump","*¨150¨0¨50¨2¨^$group:water:4:P:50","Pompe les liquides"},
{"2a",150,"coal","*¨*¨0¨*¨*¨^$default:stone_with_coal:4:DB:60","manutention du coal"},
{"2b",150,"iron","*¨*¨0¨*¨*¨^$default:stone_with_iron:5:DB:75","manutention du iron"},
{"2c",150,"More range","*¨*¨0¨^>25¨*¨*","augmente la distance de 25 blocs"},
{"2d",150,"More zone","*¨*¨0¨*¨^>10¨*","augmente la zone de travail"},
{"2e",150,"Lava","*¨*¨0¨*¨*¨^$default:lava_source:6:P:75","Pompage de lave"},
{"2f",150,"Oil","*¨*¨0¨*¨*¨^$espace:oil_source:6:P:80","Pompage de petrole"},
{"2g",150,"Mud","*¨*¨0¨*¨*¨^$espace:mud_source:5:P:80","Pompage de boue"},
{"2h",150,"Uranium","*¨*¨0¨*¨*¨^$technic:mineral_uranium:7:D:125","Exctraction d'uranium"},
{"2i",150,"mithril","*¨*¨0¨*¨*¨^$moreores:mineral_mithril:8:D:150","Extraction de Mithril"}
},

--switch b
{
{"C","CONTROLER on/off"},
{"P","POWER change source"},
{"J","ENGINE JUMP"},
{"F","WEAPONS FIRE"},
{"S","RADAR SCAN"},
{"r","RADAR CIBLE"},
{"E","MANUTENTION EXECUTE"},
{"c","MANUTENTION change command"},
{"s","MANUTENTION change source"},
{"a","PAGE DOWN"},
{"M","MENU"},
{"H","CHEAT"}
},

--switch i
{
{"A","POWER ON/OFF"},
{"B","Keypad ON/OFF"},
{"C","Light ON/OFF"},
{"D","MANUTENTION ON/OFF"}
},

--switch a
{
{"A","ENGINE PUISSANCE"},
{"B","SHIELD PUISSANCE"},
{"C","WEAPONS PUISSANCE"},
{"D","WEAPONS RANGE"},
{"E","RADAR SEUIL"},
{"F","GRAVITATION PUISSANCE"},
{"G","OXYGENE SEUIL"},
{"H","MANUTENTION range"},
{"J","MANUTENTION zone"},
{"x","X pos"},
{"y","Y pos"},
{"z","Z pos"},
{"I","ZONE"}
}
}
