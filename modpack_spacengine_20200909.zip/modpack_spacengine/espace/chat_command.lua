--just for testing
minetest.register_chatcommand("set_month", {
	params = "",
	description = "Set the month. Use the number 1-12",

	func = function(name, param)
  espace.month=tonumber(param)
  minetest.chat_send_player(name,"month : "..param)
end
})

minetest.register_chatcommand("set_day", {
	params = "",
	description = "Set the day",

	func = function(name, param)
  espace.day=tonumber(param)
  minetest.chat_send_player(name,"day : "..param)
end
})

minetest.register_chatcommand("meteo", {
	params = "",
	description = "meteo on/off",

	func = function(name, param)
  espace.meteo=param
  minetest.chat_send_player(name,"meteo "..param)
end
})

minetest.register_chatcommand("building", {
	params = "",
	description = "building on/off",

	func = function(name, param)
  espace.build=param
  minetest.chat_send_player(name,"building "..param)
end
})

minetest.register_chatcommand("epidemic", {
	params = "",
	description = "epidemic on/off",

	func = function(name, param)
  espace.epidemic=param
  
  if espace.epidemic~="off" then
    espace.epidemic_time=math.random(50,300)
  end
minetest.chat_send_player(name,"epidemic ".. espace.epidemic .." "..espace.epidemic_time)
end
})

minetest.register_chatcommand("priv", {
	params = "",
	description = "priv atroport number",

	func = function(name, param)

    if espace.data[name].priv==nil then
      espace.data[name].priv={}
    end
    table.insert(espace.data[name].priv,param)

minetest.chat_send_player(name,"privilege astroport n.secteur : ".. param)
espace.setpriv(name)
end
})

minetest.register_chatcommand("vacuum", {
    params = "<off>",
    description = "disable vacuum",
    func = function(name,param)
espace.vacuum=param
minetest.chat_send_player(name,"vacuum : "..param)
end})
