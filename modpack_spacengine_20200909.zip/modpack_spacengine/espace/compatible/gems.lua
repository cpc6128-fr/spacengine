--
--Ores
--

minetest.register_node(":gems:ruby_ore", {
	  description = "ruby ore",
	  tiles = {"default_stone.png^ruby_ruby_ore.png"},
	  is_ground_content = true,
	  groups = {cracky=1},
	  sounds = default.node_sound_defaults(),
	  drop = 'craft "gems:raw_ruby" 1',
})

minetest.register_node(":gems:emerald_ore", {
	  description = "emerald ore",
	  tiles = {"default_stone.png^gems_emerald_ore.png"},
	  is_ground_content = true,
	  groups = {cracky=1},
	  sounds = default.node_sound_defaults(),
	  drop = 'craft "gems:raw_emerald" 1',
})

minetest.register_node(":gems:sapphire_ore", {
	  description = "sapphire ore",
	  tiles = {"default_stone.png^gems_sapphire_ore.png"},
	  is_ground_content = true,
	  groups = {cracky=1},
	  sounds = default.node_sound_defaults(),
	  drop = 'craft "gems:raw_sapphire" 1',
})

minetest.register_node(":gems:amethyst_ore", {
	  description = "amethyst ore",
	  tiles = {"default_stone.png^gems_amethyst_ore.png"},
	  is_ground_content = true,
	  groups = {cracky=1},
	  sounds = default.node_sound_defaults(),
	  drop = 'craft "gems:raw_amethyst" 1',
})

--
--Gems
--
  
minetest.register_craftitem( ":gems:ruby_gem", {
	description = "ruby gem",
	tile_images = { "ruby:ruby_gem" },
	inventory_image = "ruby_ruby_gem.png",
	on_place_on_ground = minetest.craftitem_place_item,
})

minetest.register_craftitem( ":gems:emerald_gem", {
	description = "emerald gem",
	tile_images = { "gems:emerald_gem" },
	inventory_image = "gems_emerald_gem.png",
	on_place_on_ground = minetest.craftitem_place_item,
})

minetest.register_craftitem( ":gems:sapphire_gem", {
	description = "sapphire gem",
	tile_images = { "gems:sapphire_gem" },
	inventory_image = "gems_sapphire_gem.png",
	on_place_on_ground = minetest.craftitem_place_item,
})

minetest.register_craftitem( ":gems:amethyst_gem", {
	description = "amethyst gem",
	tile_images = { "gems:amethyst_gem" },
	inventory_image = "gems_amethyst_gem.png",
	on_place_on_ground = minetest.craftitem_place_item,
	
})

--raw ore registry

minetest.register_craftitem( ":gems:raw_amethyst", {
	description = "raw amethyst",
	tile_images = { "gems:raw_amethyst" },
	inventory_image = "gems_raw_amethyst.png",
	on_place_on_ground = minetest.craftitem_place_item,
})

minetest.register_craftitem( ":gems:raw_ruby", {
	description = "raw ruby",
	tile_images = { "gems:raw_ruby" },
	inventory_image = "gems_raw_ruby.png",
	on_place_on_ground = minetest.craftitem_place_item,
})

minetest.register_craftitem( ":gems:raw_emerald", {
	description = "raw emerald",
	tile_images = { "gems:raw_emerald" },
	inventory_image = "gems_raw_emerald.png",
	on_place_on_ground = minetest.craftitem_place_item,
})

minetest.register_craftitem( ":gems:raw_sapphire", {
	description = "raw sapphire",
	tile_images = { "gems:raw_sapphire" },
	inventory_image = "gems_raw_sapphire.png",
	on_place_on_ground = minetest.craftitem_place_item,
})

--register gems for fabrication

minetest.register_craft({
	type = "cooking",
	output = "gems:ruby_gem",
	recipe = "gems:raw_ruby",
})

minetest.register_craft({
	type = "cooking",
	output = "gems:sapphire_gem",
	recipe = "gems:raw_sapphire",
})

minetest.register_craft({
	type = "cooking",
	output = "gems:emerald_gem",
	recipe = "gems:raw_emerald",
})

minetest.register_craft({
	type = "cooking",
	output = "gems:amethyst_gem",
	recipe = "gems:raw_amethyst",
})

--ruby

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "gems:ruby_ore",
		wherein        = "default:stone",
		clust_scarcity = 17 * 17 * 17,
		clust_num_ores = 4,
		clust_size     = 3,
		y_min          = -255,
		y_max          = -128,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "gems:ruby_ore",
		wherein        = "default:stone",
		clust_scarcity = 15 * 15 * 15,
		clust_num_ores = 4,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -256,
	})

--emerald

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "gems:emerald_ore",
		wherein        = "default:stone",
		clust_scarcity = 15 * 15 * 15,
		clust_num_ores = 3,
		clust_size     = 2,
		y_min          = -255,
		y_max          = -64,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "gems:emerald_ore",
		wherein        = "default:stone",
		clust_scarcity = 13 * 13 * 13,
		clust_num_ores = 5,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -256,
	})

--sapphire

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "gems:sapphire_ore",
		wherein        = "default:stone",
		clust_scarcity = 18 * 18 * 18,
		clust_num_ores = 3,
		clust_size     = 2,
		y_min          = -255,
		y_max          = -64,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "gems:sapphire_ore",
		wherein        = "default:stone",
		clust_scarcity = 14 * 14 * 14,
		clust_num_ores = 5,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -256,
	})

--amethyst

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "gems:amethyst_ore",
		wherein        = "default:stone",
		clust_scarcity = 9 * 9 * 9,
		clust_num_ores = 5,
		clust_size     = 3,
		y_min          = -63,
		y_max          = -16,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "gems:amethyst_ore",
		wherein        = "default:stone",
		clust_scarcity = 7 * 7 * 7,
		clust_num_ores = 5,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -64,
	})
