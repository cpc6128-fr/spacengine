minetest.override_item("default:lava_source", {
	groups = {lava = 3, liquid = 2, igniter = 1,fire_heat=1}
})

minetest.override_item("default:lava_flowing", {
	groups = {lava = 3, liquid = 2, igniter = 1,fire_heat=1}
})

minetest.override_item("default:ice", {
	groups = {cracky = 3, cools_lava = 1, slippery = 3, freezer=1}
})

minetest.override_item("fire:permanent_flame", {
groups = {igniter = 2, dig_immediate = 3,fire_heat=1}
})

minetest.override_item("fire:basic_flame", {
groups = {igniter = 2, dig_immediate = 3, not_in_creative_inventory = 1,fire_heat=1}
})

minetest.override_item("default:snow", {
groups = {crumbly = 3, falling_node = 1, snowy = 1,freezer=1}
})

minetest.override_item("default:snowblock", {
groups = {crumbly = 3, cools_lava = 1, snowy = 1,freezer=1}
})
