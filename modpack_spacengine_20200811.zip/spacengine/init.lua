--************************************
--*** SPACENGINE 202007 by CPC6128 ***
--************************************

spacengine = {}
spacengine.area = {}
local mp=minetest.get_modpath("spacengine")
dofile( mp .. "/routine.lua")
dofile(mp .. "/data.lua")
dofile(mp .. "/commande.lua")
dofile(mp .. "/machine.lua")
dofile(mp .. "/oxygene.lua")
dofile(mp .. "/gui.lua")
dofile(mp .. "/fields.lua")
dofile(mp .. "/switch.lua")
dofile(mp .. "/screen.lua")

minetest.register_tool("spacengine:tool", {
	description = "spacengine tool",
	inventory_image = "clef.png",
	tool_capabilities = {
		full_punch_interval = 1.2,
		max_drop_level=0,
		groupcaps={
			cracky = {times={[4]=1}, uses = 50, maxlevel=1},
		},
		damage_groups = {fleshy=1},
	},
	sound = {breaks = "default_tool_breaks"},
})

minetest.register_craft({
    output = "spacengine:tool",
    recipe = {
        {"default:mese_crystal", "", ""},
        {"", "default:steel_ingot", ""},
        {"", "", "default:steel_ingot"}
    }
})

local items={
{"spacengine","controler",500},
{"spacengine","battery",250},
{"spacengine","power",350},
{"spacengine","engine",500},
{"spacengine","shield",450},
{"spacengine","weapons",600},
{"spacengine","radar",750},
{"spacengine","gravitation",700},
{"spacengine","container",150},
{"spacengine","container2",150},
{"spacengine","container3",150},
{"spacengine","passenger",100},
{"spacengine","oxygene",250},
{"spacengine","manutention",800},
{"monitor","screen_up",85},
{"monitor","screen_wall",75},
{"monitor","screen_console",60},
{"monitor","screen_down",80},
{"monitor","console_base",50},
{"spacengine","switch_bp",100},
{"spacengine","switch_emergency",120},
{"spacengine","inter_0",150},
{"spacengine","levier0",200},
{"spacengine","analog00",150},
{"spacengine","analog10",175},
{"spacengine","rotator00",150}
}

local spc_formspec = 
	"size[8,9]" ..
  "button_exit[0,3;2,1;exit;exit]"..
	"list[current_player;main;0,4.85;8,1;]" ..
	"list[current_player;main;0,6.08;8,3;8]"..
  "textlist[2,1;4,3;spc;"
local spc_showitem="item_image_button[6,1;2,2;"..items[1][1]..":".. items[1][2] ..";buy;"..items[1][3].."]"

for i=1,#items do
  spc_formspec=spc_formspec..items[i][2].." : ".. items[i][3]
  if i<#items then
    spc_formspec = spc_formspec..","
  else
    spc_formspec = spc_formspec.."]"
  end
end

minetest.register_node("spacengine:builder", {
	description = "spacengine Node Dealer",
	tiles = {
		"b4b_builder_side.png",
		"b4b_builder_side.png",
		"b4b_builder_side.png",
		"b4b_builder_side.png",
		"b4b_builder_back.png",
		"b4b_builder_front.png"
	},
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {cracky=1, oddly_breakable_by_hand=1},
  on_construct = function(pos)
		local meta = minetest.get_meta(pos)
		meta:set_string("formspec", spc_formspec)
		meta:set_string("infotext", "spacengine Dealer")
	end,
  on_receive_fields=function(pos,formname,fields,sender)

    if fields.spc then --choix item
      local showitem=string.split(fields.spc,":")
      local nb=tonumber(showitem[2])
      local meta = minetest.get_meta(pos)
      spc_showitem="item_image_button[6,1;2,2;".. items[nb][1] ..":".. items[nb][2] ..";buy;".. nb .."]"
      meta:set_string("formspec", spc_formspec..spc_showitem)
    end

    if fields.buy~=nil then --achat bloc
      local nb=tonumber(fields.buy)
      local stack=items[nb][1]..":"..items[nb][2]
      local inv = sender:get_inventory()
      local name=sender:get_player_name()

      if spacengine.transaction(sender,nil,items[nb][3]) then --si money presente
        inv:add_item("main",stack)
      end
    end
  end
})

minetest.register_craft({
    output = "spacengine:builder",
    recipe = {
        {"default:steel_ingot", "group:stone", "default:steel_ingot"},
        {"default:steel_ingot", "default:wood", "default:steel_ingot"}
    }
})


--*** init position ***
minetest.register_lbm({
name="spacengine:change_area_controler",
nodenames = {"spacengine:controler"},
run_at_every_load = true,
action = function(pos,node)
  local nod_met = minetest.get_meta(pos)
  local channel=nod_met:get_string("channel")
minetest.log("abm "..channel)
  if channel=="" then return end --en cas d'erreur
  local cha_spl=string.split(channel,":")
  if cha_spl[1]=="No channel" then return end

  spacengine.test_area_ship(pos,1,cha_spl[1]..":"..cha_spl[2])
end
})
