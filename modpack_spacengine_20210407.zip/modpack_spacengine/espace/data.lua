--***************************
--** Multi layer generator **
--***************************
--By CPC6128 -- Philippe Romand -- FEB 2019 NOV 2019

--[[

description des parametres

layer 1 --> saison = true

      name

      perlinpri={spread = 256, seed = 26566562, octaves = 4},
      perlinsec={spread = 256, seed = 26566562, octaves = 4},
      
      cave={spread = 256, seed = 26566562, octaves = 4},

      pattern={"name",echelle,luminosit,contraste,REPLACE},
            -heightmap-
            option REPLACE : si présent modifie perlinsec ou remplace perlinpri
            0 ou nill=off / 1 perlinprim=pattern / 2 perlinsec=pattern / >3 utilise data surface 3 perlinprim=pattern 4 perlinsec=pattern
            
            name:file name (image bmp 24bit gimp) / zoom:0.5,1,2,4,8 / luminosite -100 +100 / contraste -100 +100

            composante rouge : heightmap
            composante verte : surface
              (0)0-(1)16-(2)32-(3)48-(4)64-(5)80-(6)96-(7)112-(8)128-(9)144- special
              (11)160-water / (12)176-seagrd / (13)192-bottom / (14)208-top / (15)>223  normal surface suivant hauteur bottom/top
              si option trig surface (0) limit hauteur a trig level (1) depression-1(riviere lac), surface 224-239 prim mul sec


      scale=5 : echelle altitude
      top=35 : hauteur max des montagnes
      bottom=5 : hauteur max pour les basses altitudes
      water=4 : hauteur max de l'eau  // valeur negative, dessine le fond sans eau
      cliff=35 : hauteur debut falaise si -30 cratere  !! pour desactiver cliff=top !!
      valley=10 : hauteur fin vallée  !! pour desactiver valley=0 !!
      rnd=3 : rnd par default a 2, modifie la transition bottom/top
      trig=0 : hauteur declenchement du trigger par defaut top (determine aussi la hauteur des couches special)

algorythme de modification de la map
     calc="off"
"dif" difference
"add" addition
"dec" soustraction
"squ" square root
"low" plus bas
"mul" multiplier
"exp" exponentielle
"cloud" roche volante
"smo" smooth
"trig" trigger utile avec option pattern, en dessous du trig=hauteur du prim et au dessus=prim mul sec
        avec option surface, special 1 et 2 pour creer des zone en altitude ->1 plateau ->2 depression -->11 mountain level=0 ->15 mountain level=chaos
   
   nodename   {base},{sec1},{sec2}
                                          sum
              base="default:dirt",25      0:25    default
              sec1="default:sand",50      25:75
              sec1="default:stone",10     75:85

  param "nodename",chance,alt,strate  : alt=altitude max   strate=si ~=nil alt=altitude min et strate=hauteur de la strate max

   air : air/vacuum/dust (air par defaut)
   top : {list} sol haute altitude  {"name",chance, /alt max/ option (layer alt 0->640, surface~242 , top max 302)}
   bottom : {list} sol basse altitude  {"name",chance,alt (layer alt 0->640, surface~242)}
   seagrd : fond marin quand water~=0 (option par defaut=sand)
   water : default=water
   cave1 : remplissage cave air/water/lava... default=lava
   cave2 : idem default=air
   ores : {list} mineraux pour generer dans le sous sol {"name",chance,alt (layer alt 0->640, surface~242)}
   special : {list} 10 en plus qui change la surface suivant l'altitude entre bottom et top (6/12/18...voir parametre trig)

   deco={spawn_on,file,chance,altmin,altmax,y}
  spawn_on :
  "g" (Ground) sur la terre
  "f" forcing
  "w" (Water) sur l'eau
  "O" (Objet) plateforme en sous sol de 10 de hauteur max + initialise les chest, objet...
  "o" (objet) initialise les chest, objet...
  "0" surface 0 jusqu'a "9" / multi-surface autoriser ex: "0 3 O"
file=node / file specifier l'extension .mts ou .we !le programme repere ":" pour les nodes!
chance= % de chance de trouver de 0.2 a 1000
altmin max= altitude de surface
y=option decalage hauteur (si sous sol -5)

la position des objets dans la liste influence le rendu, essayer les gros objet en fin de liste ou les objet plus rare en debut de liste

sky : style de sky (1)underground (2)earth (3)espace (4)moon (5)mars (6)jupiter (7)bonus
biome : majuscule--> !meteo activer!  minuscule--> !meteo desactiver!
U=underground 7°
C=cold(snow blizzard) -30°
T=temperate 20° (snow,blizzard,storm,rain)
J=jungle(storm rain) 35°
D=desert(dust) -10°/45°
S=solar(meteor) 180°
E=espace -180°
N=neutral 18°
M=mars(dust) +-20°
R=rain 15° (rain)
        
--]]

--------------------
-- INIT data layer--
--------------------
planet_layer={
{name="earthtwo",
perlinpri={spread = 384, seed = 454, octaves = 3},
perlinsec={spread = 768, seed = 545, octaves = 3},
cave={spread = 196, seed = 2656656, octaves = 2},
scale=24,
top=60,
bottom=30,
water=5,
cliff=-55,
valley=16,
calc="dif",
rnd=0,
trig=4,
node={
top={{"default:dirt_with_snow",50},{"espace:dirt",50,273,12}},
bottom={{"default:dirt_with_grass",50},{"espace:grass_2",50,263,14},{"espace:dirt",75,265,12},{"espace:stone",2},{"espace:gallet",75,242,6}},
special={"default:dirt_with_rainforest_litter","espace:rock"},
cave1="espace:oil_source",
cave2="air",
water="default:water_source",
ores={{"default:stone",200}, {"default:stone_with_coal",15}, {"default:stone_with_iron",3,240}, {"default:stone_with_iron",5,140}, {"default:stone_with_copper",5,210}, {"default:stone_with_tin",6,150,45}, {"technic:mineral_lead",10,175,25}, {"technic:mineral_zinc",10,100,20},  {"technic:mineral_chromium",10,90,20},{"default:stone_with_mese",5,120,25}, {"technic:granite",10,150,45},{"technic:mineral_uranium",2,50,12}, {"technic:mineral_sulfur",3,190,12}, {"gems:emerald_ore",5,70,15},{"gems:amethyst_ore",2,25},{"default:stone_with_gold",10,180,20},{"default:stone_with_diamond",5,80,20}, {"moreores:mineral_silver",4,250,30}, {"moreores:mineral_mithril",8,40,20}}
},
deco={
{"g 1","espace:rocher",350,37,45},
{"g 0 1","espace:rocherbig",350,29,41},
{"g 0","espace:buisson",500,15,31},
{"g","snowy_small_pine_tree_from_sapling.mts",150,37,45},
{"g 0","pine_tree.mts",250,20,35},
{"g 0","small_pine_tree.mts",180,25,37},
{"w","flowers:waterlily",100,0,15},
{"g","apple_tree.mts",90,12,19},
{"g","aspen_tree.mts",75,14,28},
{"g","new_tree_form.mts",75,14,28},
{"g","moreplants:bigfern",100,12,34},
{"g","poplar_tree_giant.mts",20,6,12},
{"g","verger_tree.mts",20,6,14},
{"g","apple_tree.mts",30,6,9},
{"g","default:grass_5",200,8,20}
},

sky=2,
biome="X"
},

{name="moon",
perlinpri={spread = 256, seed = 88, octaves = 3},
perlinsec={spread = 256, seed = 5566, octaves = 2},
cave={spread = 256, seed = 747, octaves = 4},
pattern={"crater",1,20,-50,1},
scale=4,
top=25,
bottom=7,
water=0,
cliff=-10,
valley=0,
calc="add",
node={
air="vacuum:vacuum",
top={{"espace:rock",100},{"espace:gravel",25}},
bottom={{"espace:talcum",90},{"espace:dust",10}},
cave1="espace:smog",
cave2="default:clay",
ores={{"default:stone",75}, {"default:stone_with_iron",5,150,50}, {"default:clay",10}, {"default:clay",35,180,30}, {"default:silver_sand",50,100}, {"gems:amethyst_ore",2,25,18}, {"gems:ruby_ore",2,75,25}, {"gems:emerald_ore",2,125,12}, {"gems:sapphire_ore",2,35,25}}
},
deco={
{"g f o","moon_station_protect.mts",4,0,5,-4}
},

sky=4,
biome="e"
},

{name="mars",
perlinpri={spread = 256, seed = 99, octaves = 3},
perlinsec={spread = 512, seed = 6666, octaves = 4},
cave={spread = 128, seed = 22, octaves = 4},
scale=6,
top=30,
bottom=15,
water=0,
cliff=25,
valley=0,
calc="exp",
node={
air="vacuum:vacuum",
top={{"default:desert_sandstone",50},{"default:gravel",25}},
bottom={{"espace:desert",50},{"espace:talcum",50}},
cave1="espace:sand",
cave2="default:ice",
ores={{"default:stone",25}, {"technic:mineral_sulfur",8,200,30}, {"technic:marble",12,80,65}, {"default:stone_with_iron",8,100}, {"default:stone_with_diamond",5,5,25}, {"default:stone_with_mese",6,55,35}}
},
deco=nil,

sky=5,
biome="M"
},

{name="cccp",
perlinpri={spread = 128, seed = 667788, octaves = 4},
perlinsec={spread = 512, seed = 33, octaves = 3},
cave={spread = 128, seed = 242, octaves = 3},
scale=12,
top=20,
bottom=10,
water=4,
cliff=18,
valley=5,
calc="low",
node={
top={{"default:permafrost_with_stones",50},{"default:dirt_with_snow",50}},
bottom={{"default:snowblock",50},{"default:dirt_with_snow",25}},
cave1="air",
cave2="default:ice",
water="default:ice",
ores={{"default:stone",50}, {"default:stone_with_mese",8,15}, {"technic:granite",20,150,25}, {"default:stone_with_coal",10,210}, {"default:stone_with_coal",20,180}, {"default:stone_with_diamond",5,65,25}}
},
deco={
{"g","moreplants:taigabush",300,8,18},
{"g","snowy_small_pine_tree_from_sapling.mts",100,0,15},
{"g f","silo.mts",6,5,20,-9},
{"g O","bunker.mts",8,8,30}
},

sky=2,
biome="C"
},

{name="oblivion",
perlinpri={spread = 256, seed = 8877, octaves = 3},
perlinsec={spread = 128, seed = 596, octaves = 3},
cave={spread = 128, seed = 6587, octaves = 3},
scale=20,
top=30,
bottom=12,
water=-5,
cliff=20,
valley=12,
calc="add",
trig=3,
node={
special={"espace:roche","espace:rock","espace:rock_2"},
air="vacuum:vacuum",
top={{"espace:desert",50},{"espace:sand",25}},
bottom={{"espace:rock_2",50},{"espace:cailloux_2",25}},
seagrd="espace:sand",
ores={{"default:silver_sandstone",50}, {"default:silver_sand",50,100}, {"default:clay",25,200}, {"technic:marble",12,220}, {"technic:marble",24,180}}
},
deco={
{"g f o","oblivion.mts",8,15,32}
},

sky=7,
biome="D"
},

{name="halleluia",
perlinpri={spread = 256, seed = 8877, octaves = 4},
perlinsec={spread = 512, seed = 596, octaves = 3},
cave={spread = 128, seed = 6687, octaves = 3},
scale=14,
top=25,
bottom=8,
water=3,
cliff=25,
valley=13,
calc="cloud",
node={
air="espace:brume",
top={{"espace:cailloux_2",50},{"espace:rock",50}},
bottom={{"espace:stone",50},{"espace:grass_2",50},{"espace:cailloux_2",10}},
cave1="default:lava_source",
cave2="vacuum:vacuum",
water="espace:mud_source",
ores={{"default:stone",50}, {"default:stone_with_mese",25,300,12}, {"default:stone_with_copper",12,230}, {"default:stone_with_copper",24,190}, {"default:stone_with_iron",5}, {"technic:mineral_uranium",50,350,8}, {"moreores:mineral_silver",4,400,45}}
},
deco={
{"g","espace:rocherbig",350,0,25},
{"g f o","tower1_protect.mts",5,20,26,-5}
},

sky=6,
biome="J"
},

{name="vulcain",
perlinpri={spread = 256, seed = 224, octaves = 4},
perlinsec={spread = 128, seed = 669, octaves = 3},
cave={spread = 128, seed = 6687, octaves = 3},
scale=8,
top=10,
bottom=8,
water=5,
cliff=-9,
valley=0,
calc="none",
node={
top={{"espace:dust",50},{"espace:rock",25}},
bottom={{"espace:stone_hot",50},{"espace:gravel",25}},
cave2="espace:radioactive_air",
water="default:lava_source",
seagrd="espace:stone_hot",
ores={{"default:stone",100}, {"technic:mineral_uranium",8,48}, {"technic:mineral_uranium",4,100,24}, {"technic:mineral_uranium",2,200,12}, {"technic:mineral_sulfur",3}, {"technic:granite",25}, {"default:obsidian",5}}
},
deco=nil,

sky=1,
biome="S"
},

{name="waterworld",
perlinpri={spread = 256, seed = 6, octaves = 4},
perlinsec={spread = 256, seed = 669, octaves = 2},
cave={spread = 128, seed = 6687, octaves = 3},
scale=12,
top=50,
bottom=16,
water=12,
cliff=20,
valley=12,
calc="squ",
node={
top={{"default:dirt_with_grass",50}},
bottom={{"default:dirt",50}},
cave1="espace:water",
cave2="air",
water="default:water_source",
ores={{"default:stone",50}, {"default:coral_brown",25,263,3}, {"default:coral_orange",25,265,3}, {"technic:mineral_chromium",5,220}, {"technic:mineral_chromium",8,170},{"default:gravel",15}, {"technic:mineral_lead",3,175}, {"technic:mineral_zinc",3,100}, {"default:stone_with_tin",6,150,100}}
},
deco={
{"w o","submarine_protect.mts",1,0,13,-6},
{"w o","pirate_ship_protect.mts",1,0,13,-1},
{"g","default:grass_2",400,20,51},
{"g","moreplants:bulrush",200,20,51},
{"g","moreplants:bigfern",50,35,51},
{"g f O","chalet_02_protect.mts",10,30,51,-1}
},

sky=2,
biome="r"
},

{name="fairyland",
perlinpri={spread = 640, seed = 26566562, octaves = 4},
perlinsec={spread = 512, seed = 52, octaves = 4},
cave={spread = 256, seed = 26566562, octaves = 4},
scale=15,
top=50,
bottom=18,
water=5,
cliff=50,
valley=0,
calc="dif",
node={
top={{"espace:cailloux",50},{"espace:cailloux_grass",30}},
bottom={{"default:dirt_with_grass",75}, {"espace:grass_flowers",25}, {"espace:grass_cailloux",2}},
cave1="default:lava_source",
cave2="air",
water="default:water_source",
ores={{"default:stone",50}, {"default:stone_with_iron",15,200}, {"default:stone_with_coal",8}, {"default:stone_with_copper",2,150}, {"moreores:mineral_mithril",8,60,20}, {"default:stone_with_tin",6,150}, {"default:stone_with_mese",5,120,25}}
},
deco={
{"g","espace:rocher",200,0,30},
{"g","flowers:dandelion_yellow",300,0,15},
{"g","flowers:tulip",300,0,15},
{"g","espace:buisson",200,0,15},
{"g f O","little_farm_protect.mts",5,15,25},
{"g","cherry_tree.mts",100,5,12},
{"g","apple_tree.mts",300,0,18}
},

sky=2,
biome="t"
},

{name="vercors",
perlinpri={spread = 256, seed = 24582, octaves = 2},
perlinsec={spread = 256, seed = 55565, octaves = 3},
cave={spread = 256, seed = 26566562, octaves = 4},
scale=15,
top=50,
bottom=12,
water=5,
cliff=-47,
valley=0,
calc="smo",
node={
top={{"espace:herbe",20}, {"espace:dirt",10}, {"espace:fleur",5,270,20}, {"espace:herbe2",100,253,15}, {"espace:herbe2",25,253,20}},
bottom={{"espace:dirt",50}, {"espace:cailloux_2",25}, {"espace:herbe",30}},
cave1="default:water_source",
water="espace:ocean_source",
seagrd="espace:gallet",
ores={{"default:stone",75}, {"default:stone_with_iron",15,200}, {"default:stone_with_coal",8}, {"default:stone_with_copper",2,250,15}, {"gems:sapphire_ore",2,260,6}, {"gems:ruby_ore",2,272,6}, {"gems:sapphire_ore",5,160,12}, {"gems:ruby_ore",5,80,24}, {"default:stone_with_mese",5,60}}
},
deco={
  {"g","default:junglegrass",400,5,35},
  {"g","aspen_tree.mts",250,10,25},
  {"g","apple_tree.mts",350,15,32},
  {"g f O","house_vercors_protect.mts",5,12,30},
  {"g","cherry_tree.mts",100,5,15},
  {"g","small_pine_tree.mts",200,28,50}
},

sky=2,
biome="T"
},

{name="jungle",
perlinpri={spread = 512, seed = 555, octaves = 2},
perlinsec={spread = 256, seed = 554, octaves = 2},
cave={spread = 256, seed = 26566562, octaves = 4},
scale=5,
top=28,
bottom=5,
water=2,
cliff=-15,
valley=0,
calc="exp",
node={
top={{"default:dirt_with_rainforest_litter",50},{"espace:dirt",25},{"espace:herbe",25}},
bottom={{"default:permafrost_with_moss",50},{"espace:dirt",25}},
cave1="espace:mud_source",
water="espace:mud_source",
ores={{"default:stone",75}, {"default:stone_with_iron",8,230}, {"default:stone_with_gold",5,50}, {"gems:amethyst_ore",2,150,60}, {"gems:ruby_ore",2,75,55}, {"gems:emerald_ore",2,125,75}, {"gems:sapphire_ore",2,35}}
},
deco={
  {"g","jungle_tree.mts",400,0,25},
  {"g","default:junglegrass",500,5,25}
},

sky=2,
biome="J"
},

{name="etretat",
perlinpri={spread = 512, seed = 454, octaves = 4},
perlinsec={spread = 256, seed = 545, octaves = 1},
cave={spread = 256, seed = 26566562, octaves = 4},
scale=16,
top=35,
bottom=6,
water=4,
cliff=30,
valley=6,
calc="dif",
node={
air="vacuum:vacuum",
top={{"default:dirt",50},{"espace:dust",25},{"default:permafrost",15}},
bottom={{"default:stone",50}},
cave1="default:lava_source",
cave2="default:lava_source",
water="default:water_source",
ores={{"default:stone",75}, {"technic:mineral_zinc",8,175}, {"technic:mineral_lead",8,200}, {"default:stone_with_tin",3,200,45}, {"technic:granite",20}}
},
deco=nil,

sky=2,
biome="R"
},

{name="yellowstone",
perlinpri={spread = 256, seed = 454, octaves = 4},
perlinsec={spread = 256, seed = 545, octaves = 2},
cave={spread = 256, seed = 26566562, octaves = 4},
scale=20,
top=55,
bottom=38,
water=6,
cliff=-45,
valley=12,
calc="add",
node={
top={{"default:dirt_with_snow",50}},
bottom={{"espace:herbe2",100},{"espace:stone",2},{"espace:cailloux_2",2}},
cave1="espace:oil_source",
cave2="air",
water="default:water_source",
seagrd="espace:gallet",
ores={{"default:stone",200}, {"default:stone_with_iron",15,125}, {"default:stone_with_coal",10,240}, {"default:stone_with_gold",4,200}, {"default:stone_with_gold",15,270,12},{"default:stone_with_gold",8,150},{"default:stone_with_gold",20,75}}
},
deco={
{"g","espace:rocher",350,20,32},
{"g","espace:rocherbig",350,25,42},
{"g","espace:buisson",500,0,35},
{"g","snowy_small_pine_tree_from_sapling.mts",150,30,45},
{"g","pine_tree.mts",400,0,18},
{"g","default:grass_5",300,0,20},
{"g","small_pine_tree.mts",180,10,30},
{"w","flowers:waterlily",200,0,15},
{"g","aspen_tree.mts",75,0,15},
{"g","new_tree_form.mts",75,10,20},
{"g","poplar_tree.mts",40,0,15}
},

sky=2,
biome="T"
},

{name="dry",
perlinpri={spread = 256, seed = 5665, octaves = 2},
perlinsec={spread = 196, seed = 545, octaves = 4},
cave={spread = 256, seed = 26566562, octaves = 4},
pattern={"terrain01",2,-10,0,1},
scale=10,
top=60,
bottom=18,
water=1,
cliff=60,
valley=0,
calc="add",
trig=3,
node={
special={"espace:rock_2"},
seagrd="espace:dirt",
top={{"espace:desert",50},{"default:desert_sand",36,275,20}},
bottom={{"espace:sand",75},{"espace:cailloux_2",5,254}},
ores={{"default:stone",75}, {"default:stone_with_coal",15,200}, {"default:stone_with_iron",10,175},  {"technic:mineral_lead",6}}
},
deco={
{"g","espace:rocher",250,30,50},
{"g","default:large_cactus_seedling",75,0,25},
{"g","default:dry_grass_3",75,0,50},
{"g","default:marram_grass_1",75,25,50},
{"g","default:dry_shrub",50,0,35}
},

sky=2,
biome="j"
},

{name="testaco",
perlinpri={spread = 128, seed = 666, octaves = 2},
perlinsec={spread = 148, seed = 20, octaves = 4},
cave={spread = 128, seed = 666, octaves = 2},
pattern={"isle",1,0,0,1},
scale=20,
top=50,
bottom=7,
water=3,
cliff=-47,
valley=0,
calc="low",
node={
top={{"default:gravel",25},{"espace:dust",50,260},{"espace:rock",2}},
bottom={{"espace:rock",50}},
water="espace:oil_source",
cave1="espace:oil_source",
seagrd="espace:rock",
ores={{"default:stone",75}, {"default:stone_with_iron",8,200}, {"default:stone_with_diamond",15,100},{"default:stone_with_mese",5,80,40}, {"gems:ruby_ore",5,40}}
},
deco={
{"g","espace:rocher",500,0,10},
{"w","fire:permanent_flame",25,0,10},
{"w o","petrol_one_protect.mts",1,0,10}
},

sky=8,
biome="c"
},

{name="castle",
perlinpri={spread = 225, seed = 455, octaves = 3},
perlinsec={spread = 356, seed = 545, octaves = 2},
cave={spread = 128, seed = 26566562, octaves = 4},
pattern={"castle",2,8,-38,2},
scale=13,
top=29,
bottom=3,
water=3,
cliff=60,
valley=6,
calc="trig",
trig=8,
node={
special={"default:dirt_with_grass","espace:grass_2","espace:rock_2"},
cave1="espace:ocean_source",
cave2="espace:talcum",
top={{"default:dirt_with_grass",90},{"espace:dirt",10},{"espace:cailloux_2",3,247}},
bottom={{"espace:sand",95}},
ores={{"default:stone",75}, {"default:stone_with_coal",10}, {"default:stone_with_iron",10,240}, {"technic:mineral_uranium",10,100}, {"default:stone_with_gold",10,263,5}}
},
deco={
{"2","espace:rocher",250,10,50},
{"0 g","default:grass_1",500,3,60},
{"1","pine_tree.mts",200,6,30},
{"0 1 f o","house_medieval_protect.mts",30,5,60,-1},
{"0 1 f o","chalet_02_protect.mts",20,5,60,-1},
{"g f","ruine_02.mts",40,20,60,-1},
{"g f","ruine_01.mts",40,20,60,-1},
{"g f O","tower_defense.mts",10,20,60},
{"g f o","tower1_protect.mts",30,20,60,-5},
{"0 1","apple_tree.mts",35,1,60},
{"0","verger_tree.mts",15,1,60},
{"0","poplar_tree_giant.mts",10,1,60}
},

sky=2,
biome="R"
},

{name="scottish",
perlinpri={spread = 80, seed = 454, octaves = 1},
perlinsec={spread = 128, seed = 545, octaves = 3},
cave={spread = 128, seed = 26566562, octaves = 2},
pattern={"falaise",2,-15,-30,1},
scale=10,
top=60,
bottom=20,
water=5,
cliff=60,
valley=10,
calc="add",
node={
air="espace:brume",
seagrd="espace:gravel",
top={{"espace:grass_2",2}, {"espace:cailloux_2",50,265},{"espace:herbe",15}},
bottom={{"espace:herbe",5},{"espace:rock_2",50,250}},
ores={{"default:stone",75}, {"default:gravel",18,240}, {"default:cobble",25,240}, {"default:coalblock",5,150}, {"default:clay",20,240}}
},
deco={
{"g","default:grass_2",400,30,50},
{"g","default:marram_grass_2",200,9,18},
{"g","default:fern_3",150,12,22},
{"g f O","chalet_protect.mts",8,25,35},
{"g","espace:rocher",100,10,30}
},

sky=2,
biome="R"
},

{name="sahara",
perlinpri={spread = 256, seed = 545, octaves = 2},
perlinsec={spread = 320, seed = 756, octaves = 3},
cave={spread = 128, seed = 26566562, octaves = 2},
pattern={"dune",1,-10,-50,1},
scale=7,
top=60,
bottom=5,
water=-3,
cliff=60,
valley=0,
calc="add",
node={
seagrd="espace:desert",
top={{"default:sand",50}},
bottom={{"espace:sand",2},{"espace:desert",50,245}},
ores={{"default:desert_sandstone",75}, {"default:desert_sand",45}, {"default:obsidian",10,200}, {"gems:sapphire_ore",8,185}}
},
deco={
{"g f O","pyramide_protect.mts",1,0,5,-3},
{"g f","sahara_camp_protect.mts",3,0,5},
{"g","default:dry_grass_3",30,0,10},
{"g","default:grass_1",20,-1,2}
},

sky=2,
biome="D"
},

{name="river",
perlinpri={spread = 512, seed = 455, octaves = 4},
perlinsec={spread = 256, seed = 545, octaves = 1},
cave={spread = 256, seed = 26566562, octaves = 4},
pattern={"river",3,0,-25,4},
scale=20,
top=60,
bottom=15,
water=4,
cliff=60,
valley=0,
calc="dec",
node={
special={"espace:cailloux_2"},
water="default:river_water_source",
top={{"default:dirt_with_grass",50},{"espace:dirt",36,270}},
bottom={{"default:dirt_with_grass",50},{"default:sand",75,247},{"espace:cailloux_2",5,254}},
ores={{"default:stone",75}, {"default:stone_with_coal",15,200}, {"default:stone_with_iron",10,150}, {"technic:mineral_chromium",10,175},{"default:stone_with_tin",10,200}}
},
deco={
{"g f O","forest_house_02_protect.mts",5,30,50},
{"g","espace:rocher",250,25,50},
{"g","verger_tree.mts",75,10,15},
{"g","apple_tree.mts",400,12,23},
{"g","flowers:dandelion_yellow",250,6,20},
{"g","flowers:tulip",250,6,18},
{"g","espace:buisson",300,0,35},
{"g","pine_tree.mts",300,23,30},
{"g","aspen_tree.mts",250,18,28}
},

sky=2,
biome="T"
},

{name="alpine",
perlinpri={spread = 512, seed = 455, octaves = 2},
perlinsec={spread = 128, seed = 545, octaves = 2},
cave={spread = 128, seed = 26566562, octaves = 4},
scale=20,
top=60,
bottom=15,
water=4,
cliff=-55,
valley=0,
calc="smo",
node={
cave1="default:ice",
water="espace:ocean_source",
top={{"default:snowblock",1},{"default:dirt_with_snow",50,279},{"espace:dirt",36,270}},
bottom={{"default:dirt_with_snow",50},{"default:ice",75,248},{"espace:cailloux_2",5,254}},
ores={{"default:stone",75}, {"default:stone_with_coal",15,200}, {"default:stone_with_iron",10,175}, {"default:stone_with_copper",10,190},{"gems:amethyst_ore",15,125}}
},
deco={
{"g","small_pine_tree.mts",350,15,25},
{"g","snowy_small_pine_tree_from_sapling.mts",300,30,44},
{"g","snowy_pine_tree_from_sapling.mts",150,30,40},
{"g","espace:rocher",250,25,50},
{"g","pine_tree.mts",200,23,30},
{"g f O","forest_house_01_protect.mts",10,35,50}
},

sky=2,
biome="C"
},

{name="cityroad",
perlinpri={spread = 168, seed = 455, octaves = 3},
perlinsec={spread = 196, seed = 545, octaves = 2},
cave={spread = 128, seed = 26566562, octaves = 4},
pattern={"road",2,0,-35,3},
scale=10,
top=40,
bottom=6,
water=1,
cliff=35,
valley=0,
calc="trig",
trig=8,
node={
special={"bloc4builder:road_neutre","espace:ocean_source","bloc4builder:road_neutre","espace:talcum","default:dirt","default:dirt_with_coniferous_litter","bloc4builder:beton","espace:rock","espace:gallet"},
top={{"default:dirt_with_grass",90},{"espace:dirt",10,242,20},{"espace:cailloux_2",3,247},{"default:snowblock",90,260,30}},
bottom={{"espace:herbe",95},{"espace:cailloux_2",3},{"espace:fleur",5}},
ores={{"default:stone",75}, {"default:stone_with_coal",10}, {"default:stone_with_iron",10,175}, {"technic:mineral_uranium",10,100}}
},
deco={
{"g","espace:rocher",250,10,50},
{"g","default:grass_1",500,-1,15},
{"5 g","pine_tree.mts",200,6,20},
{"g","small_pine_tree.mts",200,15,25},
{"g","apple_tree.mts",150,6,15},
{"5 g","aspen_tree.mts",100,6,10},
{"0 6 8 f o","small_house_02_protect.mts",700,-1,3},
{"0 6 f o","house_01_protect.mts",525,-1,30,-1},
{"0 6 8 f o","small_house_01_protect.mts",500,-1,30,-1},
{"6 f o","building_02.mts",485,-1,30,-1},
{"6 f o","building_01.mts",475,-1,30,-1},
{"6 f","small_building_01.mts",450,-1,30,-1},
{"g","apple_tree.mts",35,-1,5},
{"g","verger_tree.mts",20,-1,2},
{"g","poplar_tree_giant.mts",10,-1,2}
},

sky=2,
biome="R"
}

--insert new layer here
}



----------------------------------------------------------------------------------------------------------
-- PLANET REGISTRATION
----------------------------------------------------------------------------------------------------------

--** planete **
--
-- type 0 = one layer // type 1 = multi layer // type 2 = multi layer + radius random
--
-- name,radius,chance,sphere={{radius %,ores={{node,chance}}},{{radius %,ores {node,chance}}}}
-- ores {first} = base
-- radius : nb bloc  -xx = type 1 multi layer only, no random / xx = type 2 / xx>19 = planete geante
-- radius % >100 ring horizontal, >-100 ring vertical see saturn et neptune for example
--- radius % suite   1xx.h   h=0 plein h=1 a 9 taille du hollow
-- chance=10 ->10% de chance
-- good luck

planet_base={
--star
{name="star",
chance=10,
radius=11,
sphere={
{radius=100,
ores={
{"espace:star_material1",50},
{"espace:rock",1}
},
sum=0}
}},

{name="star blue",
chance=10,
radius=11,
sphere={
{radius=100,
ores={
{"espace:sun_blue",50},
{"espace:rock",1}
},
sum=0}
}},

{name="star red",
chance=10,
radius=11,
sphere={
{radius=100,
ores={
{"espace:sun_red",50},
{"espace:rock",1}
},
sum=0}
}},

{name="star2",
chance=10,
radius=-15,
sphere={
{radius=100,
ores={
{"espace:star_material2",50},
{"espace:radioactive_air",1}
},
sum=0}
}},

--planete geante
{name="jupiter",
chance=25,
radius=40,
sphere={
{radius=100,
ores={
{"espace:smog",50},
{"espace:star_material2",5},
{"espace:water",10},
{"espace:dust",10}
},
sum=0},
{radius=50,
ores={
{"espace:smog",75},
{"default:ice",75},
{"espace:dust",20}
},
sum=0},
{radius=20,
ores={
{"espace:gravel",50},
{"default:stone_with_diamond",10},
{"default:stone_with_mese",10}
},
sum=0}
}},

--planete atypique
{name="saturn",
chance=25,
radius=20,
sphere={
{radius=150.5,
ores={
{"default:ice",50},
{"default:snowblock",20}
},
sum=0},
{radius=110.1,
ores={
{"default:ice",50}
},
sum=0},
{radius=80,
ores={
{"default:ice",50},
{"espace:star_material1",50}
},
sum=0}
}},

{name="neptune",
chance=25,
radius=15,
sphere={
{radius=-120.2,
ores={
{"espace:dust",50},
{"default:mossycobble",20}
},
sum=0},
{radius=90,
ores={
{"default:ice",50}
},
sum=0}
}},

{name="ice",
chance=50,
radius=8,
sphere={
{radius=100,
ores={
{"default:ice",50},
{"default:snowblock",20},
{"espace:dirt",20}
},
sum=0}
}},

{name="air",
chance=50,
radius=14,
sphere={
{radius=100,
ores={
{"espace:smog",50},
{"espace:dust",15},
{"espace:gravel",10}
},
sum=0},
{radius=40,
ores={
{"espace:smog",50},
{"espace:stone",20},
{"espace:gravel",10}
},
sum=0}
}},

{name="earth",
chance=30,
radius=-15,
sphere={
{radius=100,
ores={
{"espace:smog",100}
},
sum=0},
{radius=75,
ores={
{"espace:grass_2",50},
{"espace:dirt",20},
{"espace:water",10}
},
sum=0},
{radius=50,
ores={
{"default:stone",50},
{"default:stone_with_coal",30},
{"default:sandstone",10}
},
sum=0},
{radius=15,
ores={
{"default:lava_source",30},
{"default:obsidian",30}
},
sum=0}
}},

{name="le grand bleu",
chance=30,
radius=-15,
sphere={
{radius=100,
ores={
{"espace:water",50},
{"default:coral_brown",2},
{"default:coral_orange",2}
},
sum=0},
{radius=80,
ores={
{"default:water_source",50},
{"default:coral_brown",2},
{"default:coral_orange",2}
},
sum=0},
{radius=20,
ores={
{"espace:water",10},
{"espace:star_material1",10},
{"espace:star_material2",10}
},
sum=0}
}},

{name="dante1",
chance=30,
radius=-15,
sphere={
{radius=100,
ores={
{"espace:smog",50},
},
sum=0},
{radius=80,
ores={
{"default:lava_source",50},
{"espace:smog",30}
},
sum=0}
}},

--planete surprise
{name="dirt1",
chance=50,
radius=8,
sphere={
{radius=100,
ores={
{"espace:dirt",50},
{"espace:gravel",20},
{"espace:dust",20}
},
sum=0},
{radius=20,
ores={
{"default:stone",60},
{"default:stone_with_iron",20},
{"default:stone_with_tin",20}
},
sum=0}
}},

{name="dirt2",
chance=50,
radius=8,
sphere={
{radius=100,
ores={
{"espace:dirt",50},
{"espace:gravel",20},
{"espace:dust",20}
},
sum=0},
{radius=20,
ores={
{"default:stone",60},
{"default:stone_with_copper",20},
{"default:stone_with_gold",20}
},
sum=0}
}},

{name="stone1",
chance=60,
radius=12,
sphere={
{radius=100,
ores={
{"espace:stone",50}
},
sum=0},
{radius=75,
ores={
{"default:stone",50},
{"default:stone_with_iron",10},
{"default:stone_with_coal",30},
{"default:stone_with_copper",10}
},
sum=0},
{radius=50,
ores={
{"default:stone",50},
{"default:stone_with_gold",10},
{"default:stone_with_tin",30}
},
sum=0}
}},

{name="stone2",
chance=60,
radius=12,
sphere={
{radius=100,
ores={
{"espace:stone",50}
},
sum=0},
{radius=75,
ores={
{"default:stone",50},
{"default:stone_with_iron",10},
{"default:stone_with_coal",30},
{"default:stone_with_copper",10}
},
sum=0},
{radius=50,
ores={
{"default:stone",50},
{"default:stone_with_mese",10},
{"default:stone_with_diamond",30}
},
sum=0}
}},

{name="stone3",
chance=60,
radius=12,
sphere={
{radius=100,
ores={
{"espace:stone",50}
},
sum=0},
{radius=75,
ores={
{"default:stone",50},
{"technic:mineral_chromium",15},
{"default:obsidian",10},
{"moreores:mineral_silver",20}
},
sum=0},
{radius=50,
ores={
{"default:stone",50},
{"moreores:mineral_mithril",30},
{"gems:amethyst_ore",10}
},
sum=0}
}},

{name="sand1",
chance=50,
radius=10,
sphere={
{radius=100,
ores={
{"default:sandstone",50}
},
sum=0},
{radius=75,
ores={
{"default:sandstone",50},
{"technic:mineral_zinc",20},
{"technic:mineral_chromium",10}
},
sum=0}
}},

{name="sand2",
chance=50,
radius=10,
sphere={
{radius=100,
ores={
{"default:sandstone",50}
},
sum=0},
{radius=75,
ores={
{"default:sandstone",50},
{"technic:mineral_lead",20},
{"default:lava_source",50},
{"technic:mineral_sulfur",20},
{"technic:mineral_uranium",10}
},
sum=0}
}},

{name="clay style",
chance=50,
radius=9,
sphere={
{radius=100,
ores={
{"espace:stone",50}
},
sum=0},
{radius=75,
ores={
{"default:clay",50},
{"default:coalblock",20},
{"default:stone",30}
},
sum=0}
}}

}

-- ** planet special technic **
--if minetest.get_modpath('technic') then
local technic={name="magellan",
chance=30,
radius=15,
sphere={
{radius=100,
ores={
{"espace:smog",100},
{"espace:star_material2",8},
{"espace:dust",8}
},
sum=0},
{radius=50,
ores={
{"default:stone",50},
{"technic:mineral_chromium",5},
{"technic:mineral_lead",20},
{"technic:mineral_zinc",10}
},
sum=0},
{radius=20,
ores={
{"default:lava_source",50},
{"technic:mineral_sulfur",20},
{"technic:mineral_uranium",10}
},
sum=0}
}}

table.insert(planet_base,technic)

technic={name="caesar palace",
chance=30,
radius=10,
sphere={
{radius=100,
ores={
{"espace:stone",50},
{"technic:granite",10}
},
sum=0},
{radius=60,
ores={
{"technic:marble",50},
{"default:stone",10}
},
sum=0}
}}

table.insert(planet_base,technic)

technic={name="dante2",
chance=30,
radius=10,
sphere={
{radius=100,
ores={
{"espace:radioactive_air",40}
},
sum=0},
{radius=60,
ores={
{"default:stone",75},
{"technic:mineral_uranium",50}
},
sum=0}
}}

table.insert(planet_base,technic)

technic={name="stone4",
chance=60,
radius=12,
sphere={
{radius=100,
ores={
{"espace:stone",50}
},
sum=0},
{radius=75,
ores={
{"default:stone",70},
{"technic:mineral_zinc",20},
{"technic:mineral_chromium",10}
},
sum=0},
{radius=50,
ores={
{"default:stone",70},
{"default:obsidian",10},
{"technic:mineral_uranium",30}
},
sum=0}
}}

table.insert(planet_base,technic)

--end

--*** planet special abriglass ***
if minetest.get_modpath('abriglass') then
local technic={name="saturnday night fever",
chance=15,
radius=12,
sphere={
{radius=100,
ores={
{"abriglass:glass_light_blue",60},
{"abriglass:glass_light_red",10}
},
sum=0},
{radius=30,
ores={
{"default:stone",50},
{"abriglass:glass_light_green",10},
{"abriglass:glass_light_yellow",10}
},
sum=0}
}}

table.insert(planet_base,technic)
technic={name="rollerblade",
chance=15,
radius=16,
sphere={
{radius=140,
ores={
{"abriglass:glass_light_blue",50},
{"abriglass:glass_light_red",10}
},
sum=0},
{radius=100,
ores={
{"default:stone",50},
{"abriglass:glass_light_green",10},
{"abriglass:glass_light_red",10},
{"abriglass:glass_light_yellow",10}
},
sum=0}
}}

table.insert(planet_base,technic)
end

--*** planet special caverealm ***
if minetest.get_modpath('caverealms') then
local technic={name="fairyland",
chance=25,
radius=14,
sphere={
{radius=100,
ores={
{"espace:stone",60},
{"espace:gravel",60},
{"espace:dust",40}
},
sum=0},
{radius=80,
ores={
{"espace:smog",75},
{"caverealms:salt_crystal",2},
{"caverealms:glow_crystal",2},
{"caverealms:glow_ore",2}
},
sum=0}
}}

table.insert(planet_base,technic)

technic={name="fairyland2",
chance=25,
radius=14,
sphere={
{radius=100,
ores={
{"espace:smog",75},
{"caverealms:glow_emerald_ore",5},
{"caverealms:glow_amethyst_ore",5},
{"caverealms:glow_emerald",5},
{"caverealms:glow_mese",5},
{"caverealms:glow_ruby_ore",5}
},
sum=0}
}}

table.insert(planet_base,technic)

end

-- data station
--[[
save file mts or we (don't rotate we) pos1 -x -y -z pos2 +x +y +z
style{1={name, decal},2={}...}
index / descript
1     :coin
2     :couloir
3-6   :embarquement
7     :hall 1
8     :hall 2
9     :hall 3
10-nn :what you want

decalage z/rotation fixe "-"=random "0" "90" "180" "270"/nb etage/filename pour les etages
filename _cave --> decalage y -7
--]]
station_data={
{{"medieval_coin.mts","4/-"},{"medieval_couloir.mts","4/-"}, {"medieval_boarding.mts"}, {"medieval_boarding.mts"}, {"medieval_boarding.mts"}, {"medieval_boarding.mts"}, {"medieval_bloc.mts"}, {"medieval_hall.mts","0/0"}, {"medieval_bloc.mts"}, {"medieval_bloc.mts"}, {"medieval_tower.mts"}, {"medieval_house_1.mts"}, {"medieval_house_2.mts"}},

{{"industrial_coin.mts","6/-"},{"industrial_couloir.mts","6/-"}, {"industrial_boarding.mts"}, {"industrial_boarding.mts"}, {"industrial_boarding.mts"}, {"industrial_boarding.mts"}, {"industrial_hangar.mts"}, {"industrial_hall.mts","0/0"}, {"industrial_bloc.mts"}, {"industrial_bloc.mts"}, {"industrial_hangar.mts"}, {"industrial_raffinerie.mts"}, {"industrial_depot.mts"}},

{{"metal_coin.mts"},{"metal_couloir.mts"}, {"metal_boarding.mts"}, {"metal_boarding.mts"}, {"metal_boarding.mts"}, {"metal_boarding.mts"}, {"metal_module_cave.mts","0/0"}, {"metal_hall_cave.mts","0/0"}, {"metal_module_cave.mts","0/0"}, {"metal_module_cave.mts","0/0"}},

{{"concrete_coin.mts"},{"concrete_couloir.mts"}, {"concrete_boarding.mts"}, {"concrete_boarding.mts"}, {"concrete_boarding.mts"}, {"concrete_boarding.mts"}, {"concrete_hall_cave_1.mts","0/0"}, {"concrete_hall_cave_2.mts","0/0"}, {"concrete_hall_cave_3.mts","0/0"}, {"concrete_crop.mts"}, {"concrete_hangar1.mts"}, {"concrete_rdc.mts","0/0/3/concrete_etage.mts","0/0"}, {"concrete_solar_2.mts"}, {"concrete_solar_1.mts"}, {"concrete_silot_cave.mts"}, {"concrete_garden.mts"}, {"concrete_shop_cave.mts"}, {"concrete_hangar2_cave.mts"}},

{{"lab_coin.mts","2/-"},{"lab_couloir.mts","2/-"}, {"lab_boarding.mts"}, {"lab_boarding.mts"}, {"lab_boarding.mts"}, {"lab_boarding.mts"}, {"lab_bloc.mts"}, {"lab_hall.mts","0/0"}, {"lab_bloc.mts"}, {"lab_bloc.mts"}},

--atelier spatial
{{"atelier_coin_cave.mts","1/-"},{"atelier_couloir_cave.mts","1/-"}, {"atelier_boarding_cave.mts"}, {"atelier_boarding_cave.mts"}, {"atelier_boarding_cave.mts"}, {"atelier_boarding_cave.mts"}, {"atelier_bloc_cave.mts","0/0"}, {"atelier_hall_cave.mts","0/0"}, {"atelier_bloc_cave.mts","0/0"}, {"atelier_bloc_cave.mts","0/0"}}
}


--data galaxie : name , secteur
galaxie_map={
{"deneb",1000},
{"aldebarande",25552},
{"casiope",15652},
{"solar",55252},
{"minetest",55},
{"TATOOwin",72645},
{"solar system",10000}
}
