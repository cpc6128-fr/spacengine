--biome: 0=underground 1=tempere 2=hot 3=jungle 4=cold 5=mars 6=solar  9=espace

-- ******************
-- ** set skylayer **
-- ******************
--<name>,<sky>,<cloud>,<physics>,<day>
-- name,altmin,altmax,dayratio,physics,sky,cloud,biome,secteur
-- layername = "earth"
-- meteolayer = "clear"
-- physicslayer
--"map_ "= {{skylayer},{physics},{meteo}}

espace.build="on"

	map_sky = {
    {name="map_underground",--sky 1
    day=0,
    physic={speed = 1, jump = 1, gravity = 1},
    sky={bgcolor = {r = 0, g = 0, b = 0}, type = "plain",textures=nil},
    clouds={
      density = 0,
      color = "#000000",
      ambient = "#000000",
      height = 31000,
      thickness = 16,
      speed = {z = -2, y = -2}},
    radiation=0,
    oxygene=true
    },

    {name="map_earth",--sky 2
    day=nil,
    physic={speed = 1, jump = 1, gravity = 1},
    sky={bgcolor = {r=0, g=100, b=255},type = "regular",textures=nil},
    clouds={
      density = 0.4,
      color = "#fff0f0e5",
      ambient = "#000000",
      height = 120,
      thickness = 16,
      speed = {z = -2, y = -2}},
    radiation=0,
    oxygene=true
    },

    {name="map_espace",--sky 3
    day=0.25,
    physic={speed = 1, jump = 1, gravity = 0.1},

    sky={bgcolor = {r = 0, g = 0, b = 0}, type = "skybox",textures = {
			"new_skyUP.png",
			"new_skyDN.png",
			"new_skyFT.png",
			"new_skyBK.png",
			"new_skyRT.png",
			"new_skyLF.png"
		}},
--[[
    sky={bgcolor = {r = 0, g = 0, b = 0}, type = "skybox",textures = {
			"asteroid_invZ512.png^[transformR180",
			"asteroid_Z512.png",
			"asteroid_invY512.png",
			"asteroid_Y512.png",
			"asteroid_X512.png^[transformR90",
			"asteroid_invX512.png^[transformR270"
		}},
--]]
    clouds={
      density = 0,
      color = "#000000",
      ambient = "#000000",
      height = 31000,
      thickness = 16,
      speed = {z = -2, y = -2}},
    radiation=10,
    oxygen=false
    },

    {name="map_moon",--sky 4
    day=1,
    physic={speed = 0.9, jump = 1.1, gravity = 0.5},
    sky={bgcolor = {r = 25, g = 25, b = 25}, type = "skybox",textures = {
			"GalaxyTex1_bk.jpg",
			"GalaxyTex1_ft.jpg",
			"GalaxyTex1_dn.jpg^[transformR180",
			"GalaxyTex1_up.jpg^[transformR180",
			"GalaxyTex1_lf.jpg^[transformR180",
			"GalaxyTex1_rt.jpg^[transformR180"
		}},
    clouds={
      density = 0,
      color = "#000000",
      ambient = "#000000",
      height = 31000,
      thickness = 16,
      speed = {z = -2, y = -2}},
    radiation=0,
    oxygen=false
    },

    {name="map_mars",--sky 5
    day=nil,
    physic= {speed = 1, jump = 1, gravity = 1},
    sky={bgcolor = {r = 128, g = 64, b = 0}, type = "skybox",textures = {
			"mars_up.jpg^[transformR270",
			"mars_dn.jpg^[transformR90",
			"mars_ft.jpg",
			"mars_bk.jpg",
			"mars_lf.jpg",
			"mars_rt.jpg"
		}},
    clouds={thickness=64,
      color="#AC670D7F",--{r=172, g=103, b=13},
      thickness=64,
      height=120,
      speed={z=-2,x=-2},
      density=0.4},
    radiation=0,
    oxygen=false
    },

    {name="map_dark",--sky 6
    day=nil,
    physic={speed = 1, jump = 1, gravity = 1},
    sky={bgcolor = {r = 128, g = 64, b = 128}, type = "skybox",textures = {
			"chaos_up.jpg^[transformR270",
			"chaos_dn.jpg^[transformR90",
			"chaos_ft.jpg",
			"chaos_bk.jpg",
			"chaos_lf.jpg",
			"chaos_rt.jpg"
		}},
    clouds={
      density = 0,
      color = "#000000",
      ambient = "#000000",
      height = 31000,
      thickness = 16,
      speed = {z = -2, y = -2}},
    radiation=0,
    oxygen=true
    },

    {name="map_exoplanet",--sky 7
    day=0.4,
    physic={speed = 0.8, jump = 1, gravity = 1.2},
    sky={bgcolor = {r=0, g=100, b=255},type = "regular",textures=nil},
    clouds={
      density = 0.4,
      color = "#fff0f0e5",
      ambient = "#000000",
      height = 31000,
      thickness = 16,
      speed = {z = 0, y = -2}
    },
    radiation=0,
    oxygen=true
    },

    {name="map_constellation",--sky 8
    day=0.5,
    physic={speed = 1, jump = 1, gravity = 1},
    sky={bgcolor = {r = 0, g = 0, b = 0}, type = "skybox",textures = {
			"minetestUP.png",
			"minetestDN.png",
			"minetestFT.png",
			"minetestBK.png",
			"minetestRT.png",
			"minetestLF.png"
		}},
    clouds={
      density = 0,
      color = "#00000000",
      ambient = "#000000",
      height = 31000,
      thickness = 16,
      speed = {z = -2, y = -2}},
    radiation=0,
    oxygen=true
    },
    }

local timer=-5
local delay=0
local mod_spacengine=minetest.get_modpath("spacengine")

  -- ooooooooooooooooooooo
  -- oo choix de la map oo
  -- oo     debut       oo
  -- ooooooooooooooooooooo
minetest.register_globalstep(function(dtime)

  timer = timer + dtime

  if timer<2 then return end
  timer=0
  delay=delay+1

  for nb, player in ipairs(minetest.get_connected_players()) do
--local t0=minetest.get_us_time()
--local t1=minetest.get_us_time()
    local ppos = player:getpos()
    local pname = player:get_player_name()

    local dataplayer=espace.data[pname]
    local skytype=0
    local nuage=0

    if ppos.y<-10 then

      if dataplayer.bloc~=513 then
        dataplayer.secteur=0
        dataplayer.biome="u"
        dataplayer.bloc_protect=false
        dataplayer.bloc=513
        skytype=1
      end

    elseif ppos.y<1008 then
--[[
      local matricex=math.floor((ppos.x+31000)/320)--320)
      local matricez=math.floor((ppos.z+31000)/320)--320)
      local secteur=matricex+matricez*194--194

      if dataplayer.secteur~=secteur then --changement de secteur
        dataplayer.secteur=secteur
        espace.data[pname].secteur=secteur

--[[
        if espace.build=="on" then
          local new_dt=espace.set_dat(0,0,1)
          if new_dt>espace.build_dt then
            --matricex=(matricex*160)-31000
            --matricez=(matricez*160)-31000
            if ppos.y > -10 and ppos.y<120 then
              espace.building({x=math.floor(ppos.x),y=math.floor(ppos.y),z=math.floor(ppos.z)},0,"default:dirt")--,deco)
            end
          end
        end

      end
--]]
      --changement de layer ?
      if dataplayer.bloc~=514 then
        dataplayer.bloc=514
        dataplayer.biome="x"
        dataplayer.bloc_protect=false
        skytype=2
      end

    elseif ppos.y>1007 and ppos.y<10208 then
      local matricex=math.floor((ppos.x+30752)/80)
      local matricey=math.floor((ppos.y-1008)/80)
      local matricez=math.floor((ppos.z+30752)/80)
      local secteurpos={x=math.floor(matricex/8),y=math.floor(matricey/8),z=math.floor(matricez/8)}
      secteurpos.nb=secteurpos.x + ( secteurpos.y * 9216 ) + ( secteurpos.z * 96 )
      secteurpos.seed=secteurpos.nb % 501

      local bloc={x=matricex % 8 , y=matricey % 8 , z=matricez % 8 } 
      local nb=bloc.x+(bloc.y*64)+(bloc.z*8)
      nb=nb+secteurpos.seed

      if nb>511 then nb=nb-512 end
      --changement de bloc ou secteur ?
      if dataplayer.bloc~=nb or dataplayer.secteur~=secteurpos.nb then
        dataplayer.bloc_protect=false

        if nb==45 then
          dataplayer.bloc_protect=true

        elseif nb==283 then
          if secteurpos.nb~=9999 then
            dataplayer.bloc_protect=true
          end

          if dataplayer.priv~=nil then  --privilege pour l'astroport
            for i=1,#dataplayer.priv do
              if dataplayer.priv[i]==secteurpos.nb then
                dataplayer.bloc_protect=false
                break
              end
            end
          end

        end

        skytype=3 --espace
        dataplayer.bloc=nb
        dataplayer.secteur=secteurpos.nb
        dataplayer.biome="e"--espace
        local tmp=secteur_dat[nb+1]

        if tmp==8 then --8=jail
          dataplayer.biome="n"
          skytype=8
        elseif tmp==9 then --relache
          dataplayer.biome="n"
          skytype=8
        elseif tmp==19 then --relache earth
          dataplayer.biome="n"
          skytype=4
        elseif tmp==4 then --4=earth
          dataplayer.biome="t"
          skytype=4
        elseif tmp==2 then --2=solar
          dataplayer.biome="S"
        elseif tmp==1 then --1=astroport
          dataplayer.biome="n"
          skytype=8
        end
      end

    elseif ppos.y>10207 then
      --calcul layer multimap 
      local layer=math.floor((ppos.y-10208)/640)+1
      local matricex=math.floor((ppos.x+30752)/320)
      local matricez=math.floor((ppos.z+30752)/320)
      local secteur=matricex+matricez*194
      local nb_layer=#planet_layer

      if layer>nb_layer then layer=nb_layer end  --en cas d'erreur de depassement

      local calcul=10438+((layer-1)*640)+math.abs(planet_layer[layer]["water"])
      --sous le niveau de la mer pas de meteo
      if ppos.y<calcul then
        dataplayer.biome="u"
        if dataplayer.old_biome~="u" then skytype=1 end
      else
        dataplayer.biome=planet_layer[layer].biome
        if dataplayer.old_biome~=dataplayer.biome then skytype=planet_layer[layer].sky end
      end

      if ppos.y > 10440 and ppos.y<10520 then
        if espace.build=="on" then
          if secteur~=dataplayer.secteur then
            dataplayer.secteur=secteur
            local new_dt=espace.set_dat(0,0,1)

            if new_dt>espace.build_dt then
              espace.building({x=math.floor(ppos.x),y=math.floor(ppos.y),z=math.floor(ppos.z)},calcul+12,"default:dirt")
            end

          end
        end
      end

      --changement de bloc ou secteur ?
      if dataplayer.bloc~=(514+layer) then
        dataplayer.bloc=514+layer
        nuage=(layer*640)+9840+math.random(1,45)--hauteur relative sol 100
        dataplayer.secteur=secteur--matricex+matricez*194
        dataplayer.biome=planet_layer[layer].biome
        dataplayer.bloc_protect=false
        skytype=planet_layer[layer].sky
      end
    end

    --set map layer player avec les nouveaux parametres
    if skytype>0 then

      --test meteo en cour
      if dataplayer.meteo~="clear" then
        espace.weather(ppos,player,"clear",espace.data[pname].meteo)
      end
      --set physic fx
      if not default.player_attached[pname] then
        fxset(player,map_sky[skytype].name,map_sky[skytype].physic.speed,map_sky[skytype].physic.jump,map_sky[skytype].physic.gravity)
      end
      player:set_sky(map_sky[skytype].sky.bgcolor,map_sky[skytype].sky.type,map_sky[skytype].sky.textures)

      if nuage>0 and map_sky[skytype].clouds.height~=31000 then
        player:set_clouds({
          color = map_sky[skytype].clouds.color,
          density = map_sky[skytype].clouds.density,
          ambient = map_sky[skytype].clouds.ambient,
          height = nuage,
          thickness = map_sky[skytype].clouds.thickness,
          speed = map_sky[skytype].clouds.speed
        })
      else
        player:set_clouds(map_sky[skytype].clouds)
      end

      player:override_day_night_ratio(map_sky[skytype].day)
      dataplayer.skytype=skytype
      dataplayer.old_biome=dataplayer.biome
      dataplayer.radiation=map_sky[espace.data[pname].skytype].radiation
    end

    --test spacengine
    if mod_spacengine then
      if ppos.y>1007 and ppos.y<10208 then
        spacengine.environnement(player,delay)
      end
    end

    --test damage
    hurt_test(player)
  
    --test fx
    if not default.player_attached[pname] then
      fxtest(player)
    end

    --horloge
    espace.horloge(player)

  end

if delay>1 then delay=0 end

end)
