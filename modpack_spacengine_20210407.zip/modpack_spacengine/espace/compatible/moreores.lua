  minetest.register_node(":moreores:mineral_silver", {
			description = "Ore silver",
			tiles = {"default_stone.png^moreores_mineral_silver.png"},
			groups = {cracky = 3},
			sounds = default.node_sound_stone_defaults(),
			drop = "moreores:silver_lump"
		})
  minetest.register_craftitem(":moreores:silver_lump", {
			description = "Lump silver",
			inventory_image = "moreores_silver_lump.png",
		})

  minetest.register_craftitem(":moreores:silver_ingot", {
			description = "Ingot silver",
			inventory_image = "moreores_silver_ingot.png",
		})

  minetest.register_craft({
    type = "cooking",
    output = "moreores:silver_ingot",
    recipe = "moreores:silver_lump"
  })

  minetest.register_node(":moreores:mineral_mithril", {
			description = "Ore mithril",
			tiles = {"default_stone.png^moreores_mineral_mithril.png"},
			groups = {cracky = 3},
			sounds = default.node_sound_stone_defaults(),
			drop = "moreores:mithril_lump"
		})
  minetest.register_craftitem(":moreores:mithril_lump", {
			description = "Lump mithril",
			inventory_image = "moreores_mithril_lump.png",
		})

  minetest.register_craftitem(":moreores:mithril_ingot", {
			description = "Ingot mithril",
			inventory_image = "moreores_mithril_ingot.png",
		})

  minetest.register_craft({
    type = "cooking",
    output = "moreores:mithril_ingot",
    recipe = "moreores:mithril_lump"
  })
