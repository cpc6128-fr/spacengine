-- espace-redo by Philippe 2019.04.18
-- re redo 2020.01.12

--*******************
--** objet celeste **
--*******************

--local objet_celest={
--{"spacestation05.we",10,10,10},
--{"vaisseaux01.we",10,10,10}
--}

----------------------------------------------------------------------------------------------------------
-- PLANET REGISTRATION
----------------------------------------------------------------------------------------------------------

--** planete **
--
-- type 0 = one layer // type 1 = multi layer // type 2 = multi layer + radius random
--
-- name,radius,chance,sphere={{radius %,node base,ores={{node,chance}}},{{radius %,node base,ores {node,chance}}}}
-- radius= -xx = type 1 multi layer only, no random / xx = type 2 / xx>19 = planete geante
-- radius % >100 ring horizontal, >-100 ring vertical see saturn et neptune for example
--- radius % suite   1xx.h   h=0 plein h=1 a 9 taille du hollow
-- chance=10 ->10% de chance
-- good luck
--0=vaccum / 1=astroport / 2=solar / 3=planet / 4=earth / 5=neb / 6=aster / 7=objet / 8=radiation / 9=
secteur_dat={}

for i=1,512 do
  secteur_dat[i]=0
  if i==284 then --1=astroport
    secteur_dat[i]=1
  elseif (i % 113)==82 then --2=solar aleatoire
    secteur_dat[i]=12
  elseif i==171 or i==341 then --2=solar
    secteur_dat[i]=2
  elseif (i % 47)==29 then --3 planet aleatoire
    secteur_dat[i]=13
  elseif i==340 then --3=planet
    secteur_dat[i]=3
  elseif i==116 or i==332 then --4=earth
    secteur_dat[i]=4
  elseif i==94 or i==95 or i==86 then --5=nebuleuse
    secteur_dat[i]=15
  elseif (i % 59)==54 or (i % 59)==55 or (i % 59)==47 then --6=asteroid
    secteur_dat[i]=16
  elseif i==46 then --8=JAIL
    secteur_dat[i]=8
  elseif i==18 then --7=chantier spatial
    secteur_dat[i]=7
  end

end

for iz=0,2 do
  for iy=0,2 do
    for ix=0,2 do
      local id=(iz*64)+(iy*8)+ix
      --if secteur_dat[43+id]==0 then
      --  secteur_dat[43+id]=19--9=relache
      --end
      if secteur_dat[211+id]==0 then
        secteur_dat[211+id]=9--9=relache
      end
    end
  end
end

--initialisation sum ores
for i=1, #planet_base do
  local spheres=planet_base[i]["sphere"]
  for j=1, #spheres do
    if spheres[j].sum==0 then
      local summ=espace.sum_ores(spheres[j].ores)
      planet_base[i]["sphere"][j]["sum"]=summ
    end
  end
end

--init asteroids
-- INIT perlin



----------------------------------------------------------------------------------------------------------
--MAPGENERATION
----------------------------------------------------------------------------------------------------------
--*******************************
--** generation spawn earth **
--*******************************
local spawn_earth=function(minp,maxp)
  local vm, emin, emax = minetest.get_mapgen_object("voxelmanip")
  local area = VoxelArea:new{MinEdge=emin, MaxEdge=emax}
  local data = vm:get_data()
  local side_length = maxp.x - minp.x + 1 -- 80
  local map_lengths_xyz = {x=side_length, y=side_length, z=side_length}
  local c_air=minetest.get_content_id("air")
  local c_bedrock=minetest.get_content_id("espace:bedrock")

	for z=minp.z,maxp.z do
	for y=minp.y,maxp.y do
	for x=minp.x,maxp.x do
		local index = area:index(x,y,z)
    if y==minp.y then
      data[index] = c_bedrock
    else
      data[index] = c_air
    end
    
  end
  end
  end
  vm:set_data(data)
	vm:write_to_map()

  local tmp1={x=-3,y=609,z=-3}
  local filename = minetest.get_modpath("espace").."/schematics/stargate.mts"
  minetest.place_schematic(tmp1, filename, "0", nil, true)
  espace.replace_objet({x=tmp1.x-1,y=tmp1.y-1,z=tmp1.z-1},{x=tmp1.x+7,y=tmp1.y+7,z=tmp1.z+7})
end

--****************************
--** generation espace vide **
--****************************
local default_map=function(minp,maxp)
  local vm, emin, emax = minetest.get_mapgen_object("voxelmanip")
  local area = VoxelArea:new{MinEdge=emin, MaxEdge=emax}
  local data = vm:get_data()
  local side_length = maxp.x - minp.x + 1 -- 80
  local map_lengths_xyz = {x=side_length, y=side_length, z=side_length}
  local c_space=minetest.get_content_id("vacuum:vacuum") -- vacuum
  local c_ignore=minetest.get_content_id("ignore")
  local c_air=minetest.get_content_id("air")
  local c_bedrock=minetest.get_content_id("espace:invisible_bedrock")

	for z=minp.z,maxp.z do
	for y=minp.y,maxp.y do
	for x=minp.x,maxp.x do
		local index = area:index(x,y,z)
if y==1008 then
      data[index] = c_bedrock
    else
    if data[index]==c_air or data[index]==c_ignore then
      data[index] = c_space
    end
end
  end
  end
  end
  vm:set_data(data)
	vm:write_to_map()
end

--**********************************
--** generation ceinture asteroid **
--**********************************
local asteroid_map=function(minp,maxp)
-- INIT perlin
local asteroid_perlin
local asteroid_map={}

local asteroid_params = {
	offset = 0,
	scale = 2,
	spread = {x=80, y=80, z=80},
	seed = math.random(1,10000),
	octaves = 4,
	persist = 1
}
  local vm, emin, emax = minetest.get_mapgen_object("voxelmanip")
  local area = VoxelArea:new{MinEdge=emin, MaxEdge=emax}
  local data = vm:get_data()
  local side_length = maxp.x - minp.x + 1 -- 80
  local map_lengths_xyz = {x=side_length, y=side_length, z=side_length}
asteroid_perlin = minetest.get_perlin_map(asteroid_params, map_lengths_xyz)
asteroid_perlin:get3dMap_flat(minp, asteroid_map)

local data_asteroid={
ores={
{"espace:stone",50},
{"espace:gravel",25},
{"espace:talcum",25},
{"espace:rock",25},
{"default:stone_with_iron",4},
{"default:stone_with_copper",4},
{"default:stone_with_tin",4},
{"technic:mineral_lead",4},
{"technic:mineral_zinc",4},
{"technic:mineral_chromium",4},
{"default:stone_with_mese",2},
{"technic:mineral_uranium",2},
{"gems:emerald_ore",2},
{"gems:amethyst_ore",2},
{"default:stone_with_gold",2},
{"moreores:mineral_silver",4},
{"moreores:mineral_mithril",2}
},
sum=165}

local data_surface=minetest.get_content_id("espace:gravel")
local c_space=minetest.get_content_id("vacuum:vacuum") -- vacuum
local c_ignore=minetest.get_content_id("ignore")
local c_air=minetest.get_content_id("air")
local c_bedrock=minetest.get_content_id("espace:invisible_bedrock")
local index3d=1
local xi,zi=0,0
local xx=0
local yy=0
local zz=0
local cptx=0.5
local cpty=1
local cptz=1
local coef=0

for z=minp.z,maxp.z do
for x=minp.x,maxp.x do
index3d=xi+zi+1
for y=minp.y,maxp.y do
yy=yy+cpty
if yy>9 then cpty=-1 end
if yy<1 then cpty=1 end
coef=math.min(xx,yy,zz)/10
local point =math.abs(asteroid_map[index3d])*coef

local index = area:index(x,y,z)
if y==1008 then
      data[index] = c_bedrock
    else
if data[index]==c_air or data[index]==c_ignore then
if point>1.7 then
data[index] = espace.generat_sol(data_asteroid.ores,data_asteroid.sum)
elseif point>1 then
data[index] = data_surface
else
data[index] = c_space
end
end
end
index3d=index3d+80
end--y
xi=xi+1
xx=xx+cptx
if xx>9.5 then cptx=-0.5 end
if xx<0.5 then cptx=0.5 end
end --x
zi=zi+6400
xi=0
zz=zz+cptz
if zz>9 then cptz=-0.25 end
if zz<0.25 then cptz=1 end
end --z
  vm:set_data(data)
	vm:write_to_map()
asteroid_map=nil
end

--**************************
--** generation nebuleuse **
--**************************
local nebuleuse_map=function(minp,maxp)

--init nebuleuse
-- INIT perlin
local nebuleuse_perlin
local nebuleuse_map={}
local modifneb_perlin
local modifneb_map = {}
-- basic planet height noise
  local nebuleuse_params = {
	offset = 0,
	scale = 1,
	spread = {x=80, y=80, z=80},
	seed = math.random(1,10000),
	octaves = 4,
	persist = 1
}
-- cave noise
local modifneb_params = {
	offset = 0,
	scale = 1,
	spread = {x=512 , y=512, z=512},
	seed = 2,
	octaves = 3,
	persist = 1
}
  local vm, emin, emax = minetest.get_mapgen_object("voxelmanip")
  local area = VoxelArea:new{MinEdge=emin, MaxEdge=emax}
  local data = vm:get_data()
  local side_length = maxp.x - minp.x + 1 -- 80
  local map_lengths_xyz = {x=side_length, y=side_length, z=side_length}
nebuleuse_perlin = minetest.get_perlin_map(nebuleuse_params, map_lengths_xyz)
nebuleuse_perlin:get3dMap_flat(minp, nebuleuse_map)
modifneb_perlin = minetest.get_perlin_map(modifneb_params, map_lengths_xyz)
modifneb_perlin:get3dMap_flat(minp, modifneb_map)

local c_purple={
	ores={
{"espace:nebul_purple",95},
{"espace:star_material1",2}
	},
sum=97}
local c_green={
	ores={
{"espace:nebul_blue",90},
{"espace:star_material2",2}
	},
sum=92}
local c_red={
	ores={
{"espace:nebul_red",90},
{"espace:star_material2",2}
	},
sum=92}
local c_coeur={
	ores={
{"espace:radiation",90},
{"espace:sun_red",1},
{"espace:sun_blue",1},
{"espace:star_material2",1}
	},
sum=93}
	
  local c_space=minetest.get_content_id("vacuum:vacuum")
  local c_ignore=minetest.get_content_id("ignore")
  local c_air=minetest.get_content_id("air")
  local c_bedrock=minetest.get_content_id("espace:invisible_bedrock")
  local index3d=1
local xi,zi=0,0
local xx,yy,zz
	for z=minp.z,maxp.z do
zz=math.abs(z-minp.z)-40
zz=math.abs(zz)
	for x=minp.x,maxp.x do
xx=math.abs(x-minp.x)-40
xx=math.abs(xx)
index3d=xi+zi+1
for y=minp.y,maxp.y do
yy=math.abs(y-minp.y)-40
yy=math.abs(yy)
local coef=math.max(xx,yy,zz)
if coef>35 then
coef=0
else
coef=(35-coef)/35
end
local color=math.abs(modifneb_map[index3d])
local point =math.abs(nebuleuse_map[index3d])*coef
		local index = area:index(x,y,z)
if y==1008 then
      data[index] = c_bedrock
    else
    if data[index]==c_air or data[index]==c_ignore then

if point>0.25 and point<0.35 then
  if color<0.25 then
    data[index] = espace.generat_sol(c_purple.ores,c_purple.sum)
  elseif color>0.24 and color<0.75 then
    data[index] = espace.generat_sol(c_red.ores,c_red.sum)
  else
    data[index] = espace.generat_sol(c_green.ores,c_green.sum)
  end
elseif point>1 then
  data[index] = espace.generat_sol(c_coeur.ores,c_coeur.sum)
else
      data[index] = c_space
end
end
    end
index3d=index3d+80
  end --y
xi=xi+1
  end --x
zi=zi+6400
xi=0
  end --z
  vm:set_data(data)
	vm:write_to_map()
end

--************************
--** generation station **
--************************
--a=style b=type
local function shem_to_pos(pos1,a,b,rot,idx)

local filename=""
local stairfile=""
local pos2={x=pos1.x,y=pos1.y,z=pos1.z}
local decal=""
local bigfile=1

filename=station_data[a][b][1]
if station_data[a][b][2]~=nil then
decal=station_data[a][b][2]
end

if string.find(filename,"_cave") then
pos2.y=pos1.y-7
end

if decal~="" then
  local tmp=string.split(decal,"/")
  if tmp[2]~="-" then
    rot=tmp[2]
  end

  if idx==3 then tmp[1]=0 end

    if rot=="0" then
      pos2.z=pos1.z-tonumber(tmp[1])
      if idx==1 then
        pos2.x=pos1.x-tonumber(tmp[1])
        --pos2.z=pos1.z-tonumber(tmp[1])
      end
    elseif rot=="90" then
      pos2.x=pos1.x-tonumber(tmp[1])
      --if idx==1 then
        --pos2.x=pos1.x-tonumber(tmp[1])
      --end
    elseif rot=="270" and idx==1 then
      pos2.z=pos1.z-tonumber(tmp[1])
    end
  

  if tmp[3]~=nil then
    bigfile=tonumber(tmp[3])+1 --nb etage en plus
  end

  if tmp[4]~=nil then
    stairfile=tmp[4] --filename etage
  end

end

local typ_file="mts"

repeat
if string.find(filename,"%.mts") then typ_file="mts" end
if string.find(filename,"%.we") then typ_file="we" end

filename=minetest.get_modpath("espace").."/schematics/"..filename

if typ_file=="mts" then
  minetest.place_schematic(pos2, filename, rot, {["bloc4builder:sas_hidden_mid"]="bloc4builder:hidden"}, true)--nil, true)

  local file = io.open(filename)
  local value = file:read(12)
  file:close()
  local x = string.byte(string.sub(value, 8, 8)) + string.byte(string.sub(value, 7, 7)) * 256
  local y = string.byte(string.sub(value, 10, 10)) + string.byte(string.sub(value, 9, 9)) * 256
  local z = string.byte(string.sub(value, 12, 12)) + string.byte(string.sub(value, 11, 11)) * 256
  local pos22={x=pos2.x+x,y=pos2.y+y,z=pos2.z+z}
  pos2,pos22=worldedit.sort_pos(pos2, pos22)
  if a==#station_data then a=1 end
  espace.replace_objet(pos2,pos22,a)

elseif typ_file=="we" then
  local file = io.open(filename)
  local value = file:read("*a")
  file:close()
  local version, header=worldedit.read_header(value)
  local pos22={}

  if version==5 then
    local size=espace.split_string(header,"%d+")
    pos22={x=pos2.x+size[1],y=pos2.y+size[2],z=pos2.z+size[3]}
    worldedit.set(pos2, pos22, "air")
  end

  worldedit.deserialize(pos2, value)
  if a==#station_data then a=1 end
  espace.replace_objet(pos2,pos22,a)
end

if bigfile>1 then
  if stairfile~="" then
    filename=stairfile
  else
    filename="1"..filename--rajout de 1 devant 1name 11name ... 11111name
  end
end

pos2.y=pos2.y+7
bigfile=bigfile-1
until bigfile<1

end

--**

local function station(systempos,station_style)

local bloc_type=1
local nbtype=#station_data[station_style]
--4 coin
for i=1,4 do
local x,z,rot
local pos1={x=0,y=0,z=0}
if i<3 then
x=0
else
x=62
end
if i>1 and i<4 then
z=62
else
z=0
end
if i==1 then
rot="0"
elseif i==2 then
rot="90"
elseif i==3 then
rot="180"
elseif i==4 then
rot="270"
end
pos1.x=systempos.x-33+x
pos1.z=systempos.z-33+z
pos1.y=systempos.y-30

shem_to_pos(pos1,station_style,bloc_type,rot,1)
end

--couloir / embarquement
for i=1,4 do
local x,z,rot
local pos1={x=0,y=systempos.y-30,z=0}

for j=1,3 do

if i==1 then
rot="0"
pos1.x=systempos.x-28+((j-1)*19)
pos1.z=systempos.z-33
if j==2 then
pos1.z=systempos.z-39
bloc_type=3
else
bloc_type=2
end
elseif i==2 then
rot="90"
pos1.x=systempos.x-33
pos1.z=systempos.z-28+((j-1)*19)
if j==2 then
pos1.x=systempos.x-39
bloc_type=4
else
bloc_type=2
end
elseif i==3 then
rot="180"
pos1.x=systempos.x-28+((j-1)*19)
pos1.z=systempos.z+29
if j==2 then
pos1.z=systempos.z+29
bloc_type=5
else
bloc_type=2
end
elseif i==4 then
rot="270"
pos1.x=systempos.x+29
pos1.z=systempos.z-28+((j-1)*19)
if j==2 then
pos1.x=systempos.x+29
bloc_type=6
else
bloc_type=2
end
end

shem_to_pos(pos1,station_style,bloc_type,rot,2)

end

end

--centre
local tmp=1
bloc_type=6
for k=1,3 do
local x,z,rot
local pos1={x=0,y=systempos.y-30,z=0}
for j=1,3 do
pos1.x=systempos.x-28+((j-1)*19)
pos1.z=systempos.z-28+((k-1)*19)
--** type bloc **
if tmp<4 then
tmp=tmp+1
bloc_type=bloc_type+1
else
bloc_type=math.random(10,nbtype)
end

local i=math.random(1,4)--rotation
if i==1 then
rot="0"
elseif i==2 then
rot="90"
elseif i==3 then
rot="180"
elseif i==4 then
rot="270"
end

shem_to_pos(pos1,station_style,bloc_type,rot,3)

end

end

--inflation dans stargate
local secteur,bloc=espace.secteur(systempos)
if secteur_dat[bloc.nb+1]~=7 then
local _,stargate=espace.astroport(secteur)
local star_met=minetest.get_meta(stargate)
if station_style==#station_data then station_style=1 end
star_met:set_int("inflation",0.5+((station_style-1)*0.25))
end

end

--***************************
--** generation flat earth **
--***************************
local function earth(pos)

	local radius=math.random(20,38) --taille de la planete
	local pos1={x=pos.x-radius,y=pos.y-1,z=pos.z-radius}
	local pos2={x=pos.x+radius,y=pos.y,z=pos.z+radius}
--
local heightmap={}
local rlimit=(radius-5)*(radius-5)
local rwater=(radius/5)*(radius/5)
local index=1

for z=-radius,radius do
for x=-radius,radius do
local calcul=(x*x)+(z*z)

if calcul>rlimit then
heightmap[index]=0
elseif calcul>rwater then
heightmap[index]=pos.y
else
heightmap[index]=0
end

index=index+1
end
end

--atmosphere
	local hollow=2
	local data_sphere={radius=100,
	ores={
	{"espace:smog",100}
	},
sum=100}
	
	espace.dome(pos, radius, data_sphere, hollow)
	
	hollow=0
	data_sphere={radius=100,
	ores={
	{"air",100}
	},
sum=100}
	radius=radius-1
pos.y=pos1.y+1
	espace.dome(pos, radius, data_sphere, hollow)

--surface
	local axis="y"
	local length=1
	hollow=0
	data_sphere={
    radius=100,
    ores={
      {"default:dirt_with_grass",75},
      {"espace:dirt",2},
      {"default:gravel",3}
    },
    sum=80
  }
	pos.y=pos1.y
	radius=radius+1
	espace.cylinder(pos, axis, length, radius, data_sphere, hollow)

  --mur de protection
  local axis="y"
	local length=3
	hollow=1
	data_sphere={radius=100,
	ores={
  {"espace:rock_2",80},
	},
sum=80}
	pos.y=pos1.y
	espace.cylinder(pos, axis, length, radius, data_sphere, hollow)

-- sous-sol
	pos.y=pos1.y-1
	radius=-radius
--bedrock
data_sphere={radius=100,
	ores={
  {"espace:rock_2",100}
	},
sum=100}
hollow=0
espace.dome(pos, radius, data_sphere, hollow)

radius=radius+1
	data_sphere={radius=100,
	ores={
  {"default:stone",75},
	{"default:stone_with_coal",10},
	{"default:stone_with_iron",3},
	{"default:stone_with_tin",3},
	{"default:stone_with_gold",2},
	{"default:stone_with_copper",3}
	},
sum=96}
	hollow=0
	espace.dome(pos, radius, data_sphere, hollow)
--
--sand - water
	pos.y=pos1.y
	radius=math.ceil(radius/5)
	data_sphere={radius=100,
	ores={
	{"default:sand",100}
	},
sum=100}
	
	hollow=2
	espace.dome(pos, radius, data_sphere, hollow)
	
	radius=radius+1
	data_sphere={radius=100,
	ores={
	{"default:water_source",100}
	},
sum=100}

	hollow=0
	espace.dome(pos, radius, data_sphere, hollow)

--decor
local deco={}
if rlimit>700 then --village
--local filename=minetest.get_modpath("espace").."/schematics/house_earth.mts"
--minetest.place_schematic({x=pos.x+radius+5,y=pos.y,z=pos.z}, filename, "0", nil, true)
deco={
{"g","flowers:dandelion_yellow",250,0,20,0,"0/0/0"},
{"g","flowers:tulip",250,0,18,0,"0/0/0"},
{"g","espace:buisson",250,0,35,0,"0/0/0"},
{"g","apple_tree.mts",125,0,22,0,"5/5/5"},
{"g f o","small_house_02_protect.mts",100,0,12,0,"7/7/7"},
{"g f o","chalet_02_protect.mts",75,0,12,-1,"9/6/10"},
{"g f o","small_house_01_protect.mts",50,0,12,-1,"7/7/9"},
{"g f o","house_earth.mts",20,0,12,-1,"9/5/9"}
}
else  --foret
deco={
{"g","espace:rocher",300,0,50,0,"0/0/0"},
{"g","flowers:dandelion_yellow",300,0,20,0,"0/0/0"},
{"g","flowers:tulip",300,0,18,0,"0/0/0"},
{"g","espace:buisson",300,0,35,0,"0/0/0"},
{"g","apple_tree.mts",350,0,22,0,"5/5/5"},
{"g","verger_tree.mts",350,0,30,0,"5/5/5"},
{"g","cherry_tree.mts",150,0,10,0,"3/3/3"}

}
end

espace.deco(deco,{bottom={{"default:dirt_with_grass",50}}},pos1,pos2,heightmap)
	
end

--=================================================================
--
--**************
--** Ores sum **
--**************
local function sum_ores(list)
local nb=#list
local sum=0
repeat
sum=sum+list[nb][2]
nb=nb-1
until nb<1
return sum
end

--***************
--** choix ore **
--***************
function random_ores(list)
if list.sum==nil then
minetest.log("error sum choix ores")
return
end
if list.sum==0 then  --si sum absente
list.sum=sum_ores(list.ores)
end

  local tmp=list.ores
local demisum = math.ceil(list.sum/2)
local rnd = math.random(1,list.sum)-math.random(1,demisum)
if rnd<1 then rnd=rnd+list.sum end
	local node={}
	local c1=0
  local nb=#tmp
  local c2=tmp[nb][2]

	repeat
		node=tmp[nb]

		if rnd>c1 and rnd<=c2 then
			return minetest.get_content_id(tmp[nb][1])
		end

    c1=c2
    nb=nb-1
    if nb>0 then c2=c2+tmp[nb][2] end

    until nb<1

	return minetest.get_content_id(tmp[1][1])
end

--SPHERE
--from worldedit
function espace.sphere(pos, data_sphere,radius,r2)
	
	local volume = function(pos1, pos2)
		pos1 = {x=pos1.x, y=pos1.y, z=pos1.z}
		pos2 = {x=pos2.x, y=pos2.y, z=pos2.z}
		if pos1.x > pos2.x then
			pos2.x, pos1.x = pos1.x, pos2.x
		end
		if pos1.y > pos2.y then
			pos2.y, pos1.y = pos1.y, pos2.y
		end
		if pos1.z > pos2.z then
			pos2.z, pos1.z = pos1.z, pos2.z
		end
		return (pos2.x - pos1.x + 1) * (pos2.y - pos1.y + 1) * (pos2.z - pos1.z + 1)
	end

	local pos1 = vector.subtract(pos, radius)
	local pos2 = vector.add(pos, radius)
	
	local manip = minetest.get_voxel_manip()
	local emerged_pos1, emerged_pos2 = manip:read_from_map(pos1, pos2)
	local area = VoxelArea:new({MinEdge=emerged_pos1, MaxEdge=emerged_pos2})
	
	local data = {} --init zone de stockage
    --effacement du fond pour eviter bug a la generation des spheres
	local c_ignore = minetest.get_content_id("ignore")--("ignore")
	for i = 1, volume(area.MinEdge, area.MaxEdge) do
		data[i] = c_ignore
	end

	-- Fill selected area with node
	local min_radius, max_radius = r2 * (r2 - 1), radius * (radius + 1)
	local offset_x, offset_y, offset_z = pos.x - area.MinEdge.x, pos.y - area.MinEdge.y, pos.z - area.MinEdge.z
	local stride_z, stride_y = area.zstride, area.ystride
	for z = -radius, radius do
		-- Offset contributed by z plus 1 to make it 1-indexed
		local new_z = (z + offset_z) * stride_z + 1
		for y = -radius, radius do
			local new_y = new_z + (y + offset_y) * stride_y
			for x = -radius, radius do
				local squared = x * x + y * y + z * z
				if squared>= min_radius and squared <= max_radius then
					local i = new_y + (x + offset_x)
					data[i] = espace.generat_sol(data_sphere.ores,data_sphere.sum)
				end
			end
		end
	end
	manip:set_data(data)
	manip:write_to_map()
	manip:update_map()
end

--** PLACE PLANET TO POS **
espace.generate_planet = function(pos,spheres,radius,tip)
   --pos,spheres,radius,type
	local nbspheres=0
	local data_sphere={}
	local coef=0
	if tip>0 then
		nbspheres=#spheres
	else
		nbspheres=1
	end

    -- taille aleatoire type 2
    if tip==2 and radius>0 then
      coef=math.random(5,15)/10
      if radius<8 then
        coef=math.max(1,coef)
      end
      
      coef=math.min(1.5,coef)
      coef=coef*radius

    -- type 3
    elseif tip==3 and radius>0 then
      coef=math.random(10,18)/10
      coef=math.min(1.8,coef)

      coef=coef*radius
    else
      coef=math.abs(radius)
    end
    local r2=0
    local temp=0
	--construction sphere par sphere
	for i=1,nbspheres do

		data_sphere=spheres[i]
		temp=data_sphere.radius
		if i<nbspheres then
			r2=math.floor(spheres[i+1].radius)
		else
			r2=0
		end
		-- radius sup a 100 -->ring
		if data_sphere.radius>100 or data_sphere.radius<-100 then
			local hollow=0
			local axis="y"
			if data_sphere.radius<-100 then
				temp=math.ceil(temp)-temp
				if temp~=0 then
					hollow=math.ceil(temp*10)
				end
				temp=math.floor(data_sphere.radius)
				axis="z"
				radius=math.max(1,math.ceil(((temp)/100)*-coef))
			else
				temp=temp-math.floor(temp)
				if temp~=0 then
					hollow=math.ceil(temp*10)
				end
				temp=math.floor(data_sphere.radius)
				axis="y"
				radius=math.max(1,math.ceil(((temp)/100)*coef))
			end
			local pos1={x=pos.x,y=pos.y,z=pos.z}
			local length=1
			
			espace.cylinder(pos, axis, length, radius, data_sphere, hollow)
		else
			temp=math.floor(temp)
			radius=math.max(1,math.ceil((temp/100)*coef))
			r2=math.max(1,math.ceil((r2/100)*coef))
			espace.sphere(pos, data_sphere,radius,r2)
		end
	end
end	

--************
--** MAPGEN **
--************
minetest.register_on_generated(function(minp, maxp, seed)

  if minp.y>1007 and maxp.y<10208 then

-- calcul de la matrice
	local matricex=(minp.x+30752)/640
	local matricey=(minp.y-1008)/640
	local matricez=(minp.z+30752)/640
  local sector=math.floor(matricex)+math.floor(matricey)*9216+math.floor(matricez)*96
  local mapseed=(sector % 501)
  matricex=math.floor((matricex-math.floor(matricex))*8)
  matricey=math.floor((matricey-math.floor(matricey))*8)
  matricez=math.floor((matricez-math.floor(matricez))*8)
  local systemnb=matricex+(matricez*8)+(matricey*64)+mapseed+1
  if systemnb>512 then systemnb=systemnb-512 end
  local systempos={x=minp.x+40,y=minp.y+40,z=minp.z+40}
  
  -- type d'objet rencontrer
--[[
0=vaccum / 1=astroport / 2=solar / 3=planet / 4=earth / 5=neb / 6=aster / 7=atelier / 8=jail / 9=relache
--]]
  local obj_select=secteur_dat[systemnb]
  local alea=math.floor(obj_select/10)
  obj_select=obj_select-(alea*10)

  if alea==1 then 
    local tmp=math.random(1,100)
    if tmp>65 and obj_select==3 then
      obj_select=0
    elseif tmp>35 and obj_select==4 then
      obj_select=0
    elseif tmp>50 and obj_select==5 then
      obj_select=0
    elseif tmp>85 and obj_select==6 then
      obj_select=5
    elseif tmp>75 and obj_select==6 then
      obj_select=0
    end
  end

if maxp.y>9968 then obj_select=0 end

if obj_select==5 then
nebuleuse_map(minp,maxp)
return
end
if obj_select==6 then
asteroid_map(minp,maxp)
return
end
--remplir de vacuum
default_map(minp,maxp)
if obj_select==0 then
return
end

  local tip=1 -- init type de planete
  --*************
  --** station **
  --*************
  if obj_select==1 then
    if sector==9999 then
      station(systempos,#station_data)
    else
      station(systempos,math.random(1,#station_data-1))
    end
  --*********************
  --** systeme solaire **
  --*********************
  elseif obj_select==2 then
    local tx=systempos.x
    local ty=systempos.y
    local tz=systempos.z
    local out=0
    local radius=0
    local spheres={}
    local xx,yy,zz=0,0,0
    tip=1
    --place une star au centre
    local nb=math.random(1,4)
    radius=planet_base[nb].radius
    spheres=planet_base[nb].sphere
    espace.generate_planet(systempos, spheres,radius,tip)
    local x=-1
    local y=-1
    local z=-1
    local rang=1
    tip=2
    local chance=0
    --local debug=#planet_base-2
    nb=1
    repeat
      --nb=nb+1
      --chance=101
      nb=math.random(1,#planet_base)
      chance=planet_base[nb].chance
      if chance>math.random(1,100) then
        radius=planet_base[nb].radius
        --si planete geante, ne pas la creer dans un systeme solaire
        if radius>-20 and radius<20 then
          xx=x*25
          yy=y*25
          zz=z*25
          systempos.x=tx+xx
          systempos.y=ty+yy
          systempos.z=tz+zz
          spheres=planet_base[nb].sphere
          espace.generate_planet(systempos, spheres,radius,tip)
        end
      end
      x=x+(2*rang)
      if x>rang then
        y=y+(2*rang)
        x=-rang
      end
      if y>rang then
        z=z+(2*rang)
        y=-rang
        x=-rang
      end
      if z>rang then
        rang=rang+1
        z=-rang
        y=-rang
        x=-rang
      end
            
      out=out+1
						--until (out>debug)
    until (out>7)

    --**********************
    --** planet aleatoire **
    --**********************
  elseif obj_select==3 then
    tip=3
    local nb=math.random(1,#planet_base)
    espace.generate_planet(systempos,planet_base[nb].sphere,planet_base[nb].radius,tip)
      
  --****************
  --** flat earth **
  --****************
  elseif obj_select==4 then
    earth(systempos)
  
  --*******************
  --** jail  spatial **
  --*******************

  elseif obj_select==8 then
    local center={x=systempos.x-6,y=systempos.y,z=systempos.z-5}
    local filename="jail.mts"
    if string.find(filename,"%.we") then
      local file = io.open(minetest.get_modpath("espace").."/schematics/"..filename)
      local value = file:read("*a")
      file:close()
      local count = worldedit.deserialize(center, value)
    else
      minetest.place_schematic(center,minetest.get_modpath("espace") .."/schematics/"..filename, "0", nil, true)      
    end

  --*************
  --** atelier **
  --*************
  elseif obj_select==7 then
    --if math.random(3)==3 then
      station(systempos,#station_data)
    --end
  end
end

if minp.y<608 or maxp.y>688 then return end

if minp.x>-33 and maxp.x<49 then
if minp.z>-33 and maxp.z<49 then
spawn_earth(minp,maxp)
end
end

end)

-------------------------------------------------------------------------
--**function modifier from worldedit 

function espace.cylinder(pos, axis, length, radius, data_sphere, hollow)
	local other1, other2 = worldedit.get_axis_others(axis)
--espace.DEFAULT_NODENAME = data_sphere.base
	-- Handle negative lengths
	local current_pos = {x=pos.x, y=pos.y, z=pos.z}
	if length < 0 then
		length = -length
		current_pos[axis] = current_pos[axis] - length
	end

	-- Set up voxel manipulator
	local manip, area = espace.init_axis_radius_length(current_pos, axis, radius, length)
	local data = espace.get_empty_data(area)

	-- Add cylinder
	--local node_id = minetest.get_content_id(node_name)
	local min_radius, max_radius = radius * (radius - hollow), radius * (radius + hollow)
	local stride = {x=1, y=area.ystride, z=area.zstride}
	local offset = {
		x = current_pos.x - area.MinEdge.x,
		y = current_pos.y - area.MinEdge.y,
		z = current_pos.z - area.MinEdge.z,
	}
	local min_slice, max_slice = offset[axis], offset[axis] + length - 1
	for index2 = -radius, radius do
		-- Offset contributed by other axis 1 plus 1 to make it 1-indexed
		local new_index2 = (index2 + offset[other1]) * stride[other1] + 1
		for index3 = -radius, radius do
			local new_index3 = new_index2 + (index3 + offset[other2]) * stride[other2]
			local squared = index2 * index2 + index3 * index3
			if squared <= max_radius and (hollow==0 or squared >= min_radius) then
				-- Position is in cylinder
				-- Add column along axis
				for index1 = min_slice, max_slice do
					local vi = new_index3 + index1 * stride[axis]
					data[vi] = espace.generat_sol(data_sphere.ores,data_sphere.sum) --modif ici
				end
			end
		end
	end

	espace.finish(manip, data)

	return
end

function espace.dome(pos, radius, data_sphere, hollow)
--espace.DEFAULT_NODENAME = data_sphere.base
	local min_y, max_y = 0, radius
	local manip, area = espace.init_axis_radius(pos, "y", radius)
	local data = espace.get_empty_data(area)
--!! modif ici
	if radius < 0 then
		radius = -radius
		min_y, max_y = -radius, 0
	end
--!!
	-- Add dome
	local min_radius, max_radius = radius * (radius - hollow), radius * (radius + hollow)
	
	local offset_x, offset_y, offset_z = pos.x - area.MinEdge.x, pos.y - area.MinEdge.y, pos.z - area.MinEdge.z
	local stride_z, stride_y = area.zstride, area.ystride
	for z = -radius, radius do
		local new_z = (z + offset_z) * stride_z + 1 --offset contributed by z plus 1 to make it 1-indexed
		for y = min_y, max_y do
			local new_y = new_z + (y + offset_y) * stride_y
			for x = -radius, radius do
				local squared = x * x + y * y + z * z
				if squared <= max_radius and (hollow==0 or squared >= min_radius) then
					-- Position is in dome
					local i = new_y + (x + offset_x)
					data[i] = espace.generat_sol(data_sphere.ores,data_sphere.sum) --modif ici aussi
				end
			end
		end
	end

	espace.finish(manip, data)

	return
end

function espace.init(pos1, pos2)
	local manip = minetest.get_voxel_manip()
	local emerged_pos1, emerged_pos2 = manip:read_from_map(pos1, pos2)
	local area = VoxelArea:new({MinEdge=emerged_pos1, MaxEdge=emerged_pos2})
	return manip, area
end

function espace.get_empty_data(area)
	-- Fill emerged area with ignore so that blocks in the area that are
	-- only partially modified aren't overwriten.
	local data = {}
	local c_ignore = minetest.get_content_id("ignore")
	for i = 1, worldedit.volume(area.MinEdge, area.MaxEdge) do
		data[i] = c_ignore
	end
	return data
end

function espace.init_radius(pos, radius)
	local pos1 = vector.subtract(pos, radius)
	local pos2 = vector.add(pos, radius)
	return espace.init(pos1, pos2)
end

function espace.init_axis_radius(base_pos, axis, radius)
	return espace.init_axis_radius_length(base_pos, axis, radius, radius)
end

function espace.init_axis_radius_length(base_pos, axis, radius, length)
	local other1, other2 = worldedit.get_axis_others(axis)
	local pos1 = {
		[axis]   = base_pos[axis],
		[other1] = base_pos[other1] - radius,
		[other2] = base_pos[other2] - radius
	}
	local pos2 = {
		[axis]   = base_pos[axis] + length,
		[other1] = base_pos[other1] + radius,
		[other2] = base_pos[other2] + radius
	}
	return espace.init(pos1, pos2)
end

function espace.finish(manip, data)
	-- Update map
	manip:set_data(data)
	manip:write_to_map()
	manip:update_map()
end
