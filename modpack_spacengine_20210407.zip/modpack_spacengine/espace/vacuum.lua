espace.vacuum=true
-- On dignode function. Atmosphere flows into a dug hole.
--
minetest.register_on_dignode(function(pos, oldnode, digger)

  if not digger or not pos or not oldnode then
    return
  end

  local plname=digger:get_player_name()

  espace.xplevel(1,digger,"force")

  --verifie licence d'exploitation dans l'espace
  if math.random(1,1500)<5 then
    
    if pos.y>1007 and pos.y<10208 and espace.data[plname].bloc_protect==false then
      --recherche area spacengine
      local found,cpos,ship_name=spacengine.test_area_ship(pos,0)

      --si extérieur a un vaisseaux pas de protection
      if not found then
        local no_protect=true

        --pas de protection en dehors des astroports
        if espace.data[plname].bloc==283 or espace.data[plname].bloc==18 then no_protect=false end

        if no_protect==true then
          local licence,_,_,meta=commerce.found_item_index(digger,"commerce:licence")
          local err=0

          if licence>0 then
        
            if string.find(meta,"exploitation")~=nil then
              local tmp=string.split(meta,":")
              local dat_actuel=espace.set_dat(0,0)

              if dat_actuel>tonumber(tmp[2]) then err=1 end

            else
              err=1
            end
          else
            err=1
          end

          if err>0 then
            police_arrest(digger,pos)
          end
        end
      end
    end
  end

if pos.y<1008 or espace.vacuum==false then
  return
end
--TODO voxelmanip ?
local pos1={x=pos.x-1,y=pos.y,z=pos.z}
    local node=minetest.get_node(pos1)
    if node.name=="vacuum:vacuum" or node.name=="air" or node.name=="espace:smog" or node.name=="espace:air" then -- -x
      minetest.set_node(pos, {name = node.name})
      return
    end
    pos1={x=pos.x+1,y=pos.y,z=pos.z}
node=minetest.get_node(pos1)
    if node.name=="vacuum:vacuum" or node.name=="air" or node.name=="espace:smog" or node.name=="espace:air" then -- +x
      minetest.set_node(pos, {name = node.name})
      return
    end
pos1={x=pos.x,y=pos.y-1,z=pos.z}
node=minetest.get_node(pos1)
    if node.name=="vacuum:vacuum" or node.name=="air" or node.name=="espace:smog" or node.name=="espace:air" then -- -y
      minetest.set_node(pos, {name = node.name})
      return
    end
pos1={x=pos.x,y=pos.y+1,z=pos.z}
node=minetest.get_node(pos1)
    if node.name=="vacuum:vacuum" or node.name=="air" or node.name=="espace:smog" or node.name=="espace:air" then -- +y
      minetest.set_node(pos, {name = node.name})
      return
    end
pos1={x=pos.x,y=pos.y,z=pos.z-1}
node=minetest.get_node(pos1)
    if node.name=="vacuum:vacuum" or node.name=="air" or node.name=="espace:smog" or node.name=="espace:air" then -- -z
      minetest.set_node(pos, {name = node.name})
      return
    end
pos1={x=pos.x,y=pos.y,z=pos.z+1}
node=minetest.get_node(pos1)
    if node.name=="vacuum:vacuum" or node.name=="air" or node.name=="espace:smog" or node.name=="espace:air" then-- +z
      minetest.set_node(pos, {name = node.name})
    end
  
end)

--
--dans l'espace air  remplacer par vacuum
minetest.register_abm({
	nodenames = {"air"},
	neighbors = {"vacuum:vacuum"},
	interval = 10,
	chance = 5,
	action = function(pos)

    if pos.y<1008 or espace.vacuum==false then
      return
    end

    local pos1={x=pos.x-1,y=pos.y,z=pos.z}
    local node=minetest.get_node(pos1)
    if node.name=="vacuum:vacuum" then -- -x
      minetest.set_node(pos, {name = "vacuum:vacuum"})
    end
    pos1={x=pos.x+1,y=pos.y,z=pos.z}
node=minetest.get_node(pos1)
    if node.name=="vacuum:vacuum" then -- +x
      minetest.set_node(pos, {name = "vacuum:vacuum"})
    end
pos1={x=pos.x,y=pos.y-1,z=pos.z}
node=minetest.get_node(pos1)
    if node.name=="vacuum:vacuum" then -- -y
      minetest.set_node(pos, {name = "vacuum:vacuum"})
    end
pos1={x=pos.x,y=pos.y+1,z=pos.z}
node=minetest.get_node(pos1)
    if node.name=="vacuum:vacuum" then -- +y
      minetest.set_node(pos, {name = "vacuum:vacuum"})
    end
pos1={x=pos.x,y=pos.y,z=pos.z-1}
node=minetest.get_node(pos1)
    if node.name=="vacuum:vacuum" then -- -z
      minetest.set_node(pos, {name = "vacuum:vacuum"})
    end
pos1={x=pos.x,y=pos.y,z=pos.z+1}
node=minetest.get_node(pos1)
    if node.name=="vacuum:vacuum" then -- +z
      minetest.set_node(pos, {name = "vacuum:vacuum"})
    end
end,
})

--vaccum remplacer par air hors espace
minetest.register_abm({
	nodenames = {"vacuum:vacuum"},
	neighbors = {"air"},
	interval = 10,
	chance = 1,
	catch_up = false,
	action = function(pos, node, active_object_count, active_object_count_wider)
    if pos.y>1007 and espace.vacuum==true then
      return
    end
    minetest.set_node(pos,{name = 'air'})
end,
})
