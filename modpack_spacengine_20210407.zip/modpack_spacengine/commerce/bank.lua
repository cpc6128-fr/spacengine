--**********
--** BANK **
--**********
--
--** node bank  item to money

minetest.register_node("commerce:bank", {
	description = "change les objets en pognon, flouze, oseille",
	tiles = {
		"commerce_atm_bord.png",
		"commerce_atm_bord.png",
		"commerce_atm_bord.png",
		"commerce_atm_bord.png",
		"commerce_atm_bord.png",
		"commerce_atm_money.png"
	},
  --drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {unbreakable = 1, not_in_creative_inventory = 1},--cracky=2},
	legacy_facedir_simple = true,
	is_ground_content = false,
  
  on_construct = function(pos)
    local meta = minetest.get_meta(pos)
    local inv = meta:get_inventory()
    local change=tostring(math.random(50,150))--TODO suivant astroport
    meta:set_int('change',change)
    meta:set_string("formspec", "size[8,7]"..
        "background[0,0;1,1;commerce_money_maker.png;true]"..
        "label[3.2,0.55;item]"..
        "label[5,0.55;take money]"..
        "list[context;src;3,1.5;1,1;]"..
        "image[4.3,1.5;1,1;commerce_gui_arrow_blank.png]"..
        "list[context;dst;5.6,1.5;1,1;]"..
        "item_image_button[0,0;1,1;commerce:card;card;]"..
        "item_image_button[0,1;1,1;currency:minegeld_5 10;price;]"..
        "button_exit[7,1.5;1,1;exit;exit]"..
        "list[current_player;main;0,3;8,4;]")
    inv:set_size('src', 1)
    inv:set_size('dst', 1)
  end,
  drop = 'default:dirt',
  on_metadata_inventory_take = function(pos, listname, index, stack, player)
  local meta = minetest.get_meta(pos)
  local inv = meta:get_inventory()
  if listname=="src" then
    inv:set_stack("dst",1,"")
  elseif listname=="dst" then
    inv:set_stack("src",1,"")
  end
  
	end,
on_receive_fields=function(pos,formname,fields,sender)
  if fields.card~=nil then
    local inv = sender:get_inventory()
    if inv:contains_item("main","currency:minegeld_5 10") then
      inv:remove_item("main", "currency:minegeld_5 10")
      inv:add_item("main", {name="commerce:card", count=1})
    end
  end
end,
	on_metadata_inventory_put = function(pos,listname, index, stack, player)
    -- nb d'item
    local nb_obj = #commerce.item
    local objet
    local meta = minetest.get_meta(pos)
    local inv = meta:get_inventory()
    local change=meta:get_int('change') --TODO change suivant rareté sur l'astroport
    local stack = inv:get_stack("src", 1)
    local name=stack:get_name()
    --
    local nplayer=player:get_player_name()
    local xp=espace.xpgetlvl(player,"force")+1
    change=(change*((25+(xp*4))/100))/100 --taux différent suivant XP
    if name~=nil then

    repeat
      objet=commerce.item[nb_obj]  --recuperation des données
      if name==objet[2] then --and string.find(objet[6],"b") then
        
          local quantity=stack:get_count() -- nb objet
          local price=math.ceil(objet[3]*quantity*change)
            
            --currency calcul
            if price>2500 then
              quantity=math.ceil(price/100)
              money="currency:minegeld_100"
              price=quantity*100
            elseif price>500 then
              quantity=math.ceil(price/50)
              money="currency:minegeld_50"
              price=quantity*50
            elseif price>250 then
              quantity=math.ceil(price/10)
              money="currency:minegeld_10"
              price=quantity*10
            elseif price>50 then
              quantity=math.ceil(price/5)
              money="currency:minegeld_5"
              price=quantity*5
            elseif price>12.5 then
              quantity=math.ceil(price)
              money="currency:minegeld"
              price=quantity*1
            elseif price>2.5 then
              quantity=math.ceil(price/0.25)
              money="currency:minegeld_cent_25"
              price=quantity*0.25
            elseif price>0.05 then
              quantity=math.ceil(price/0.05)
              money="currency:minegeld_cent_5"
              price=quantity*0.05
            else
              price=0
            end
            minetest.chat_send_player(nplayer,price .." minegeld")
          if price>0 then
            money=money.." ".. tostring(quantity)
            inv:set_stack("dst",1,money)
            nb_obj=1
            minetest.sound_play("money02",{to_player=nplayer,gain=1.5})
          end


      end
      nb_obj=nb_obj-1
    until nb_obj<1

    end
  end,
})

local mabank_form="size[8,7]"..
        "background[0,0;1,1;commerce_master_bank.png;true]"..
        "list[context;src;2.9,1.5;1,1;]"..
        "image[3.9,1.5;1,1;commerce_gui_arrow_blank.png]"..
        "button_exit[7,2;1,1;exit;exit]"..
        "list[current_player;main;0,3;8,4;]"

minetest.register_node("commerce:master_bank", {
	description = "bank de pro",
	tiles = {
		"commerce_atm_bord.png",
		"commerce_atm_bord.png",
		"commerce_atm_bord.png",
		"commerce_atm_bord.png",
		"commerce_atm_bord.png",
		"commerce_atm.png"
	},
  --drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	groups = {unbreakable = 1, not_in_creative_inventory = 1},--
	legacy_facedir_simple = true,
	is_ground_content = false,
  
  on_construct = function(pos)
    local meta = minetest.get_meta(pos)
    local inv = meta:get_inventory()
    local change=tostring(math.random(50,150))--TODO suivant astroport
    meta:set_int('change',change)
    meta:set_string("formspec",mabank_form)
    inv:set_size('src', 1)
  end,
  drop = 'default:dirt',
  on_metadata_inventory_take = function(pos, listname, index, stack, player)
  local meta = minetest.get_meta(pos)
  local inv = meta:get_inventory()
  if listname=="src" then
    meta:set_string("formspec", mabank_form)
  end
  
	end,
on_receive_fields=function(pos,formname,fields,sender)

  
    if string.find(dump(fields),"accept")~=nil then
      for k, v in pairs(fields) do
        trade = tostring(k)
      end
      local tradesplit=string.split(trade,"#")
      local index=tonumber(tradesplit[2])
      local price=tonumber(tradesplit[3])
      local havecard=commerce.found_item_index(sender,"commerce:card")
      local havelicence=commerce.found_item_index(sender,"commerce:licence")

      if havecard>0 and havelicence>0 then --si card presente
        local name=sender:get_player_name()
        local _,_,_,stackmeta=commerce.found_item_index(sender,"commerce:licence")
        if string.find(stackmeta,"commerce")==nil then return end

        if atm.balance[name]== nil then return end

        local meta = minetest.get_meta(pos)
        local inv = meta:get_inventory()
        inv:set_stack("src",1,"")
        atm.balance[name] = atm.balance[name]+price
        atm.saveaccounts()
        minetest.sound_play("card2",{to_player=name,gain=1.5})
        minetest.chat_send_player(name,"Account : ".. atm.balance[name])
        meta:set_string("formspec", mabank_form)
      end

    end
  
end,
	on_metadata_inventory_put = function(pos,listname, index, stack, player)
    -- nb d'item
    local nb_obj = #commerce.item
    local objet
    local meta = minetest.get_meta(pos)
    local inv = meta:get_inventory()
    local change=meta:get_int('change') --TODO change suivant rareté sur l'astroport
    local stack = inv:get_stack("src", 1)
    local name=stack:get_name()
    --
    local nplayer=player:get_player_name()
    local xp=espace.xpgetlvl(player,"force")+1
    change=(change*((25+(xp*4))/100))/100 --taux différent suivant XP
    if name~=nil then

    repeat
      objet=commerce.item[nb_obj]  --recuperation des données
      if name==objet[2]then
        local quantity=stack:get_count() -- nb objet
        local price=math.ceil(objet[3]*quantity*change)
        --price=tonumber(price))
        meta:set_string("formspec", mabank_form .."label[5,1.75;".. price .."]button[7,1;1,1;accept#".. nb_obj .."#".. price ..";accept]")
    
        nb_obj=1
      end

      nb_obj=nb_obj-1
    until nb_obj<1

    end
  end,
})
