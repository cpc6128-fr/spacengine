commerce.civ={}

commerce.civ_found=function()

  for nb, player in ipairs(minetest.get_connected_players()) do
    local ppos = player:getpos()
    
    if ppos.y>1007 and ppos.y<10268 then
      local secteur,bloc=espace.secteur(ppos)
      if bloc.nb==283 then
        local _,stargate=espace.astroport(secteur)
        local civ_pos=minetest.find_node_near(stargate,4,{"commerce:info_astroport"})
        if  civ_pos then
          commerce.civ_maj(civ_pos)
        end
      end
    end

  end

end

commerce.civ_init=function(civ_pos)
  local name=espace.secteur(civ_pos)
  local data_civ=""--espace.postostring(civ_pos) ..":".. str_dat

  for ii=1,7 do
    data_civ=data_civ .. tostring(math.random(1000,10000)) .. "/" .. tostring(math.random(1,25)) .."/"
  end

  data_civ=data_civ.. tostring(math.random(1000,8000)) .."/".. --population
  tostring(math.random(1000,10000)) .."/".. --bank
  "/".. (name.nb+1) .."/"--name

  for ii=1,5 do
    data_civ=data_civ .. tostring(math.random(1,100)) .. "/"
  end

  local meta = minetest.get_meta(civ_pos)
  meta:set_string("trade",data_civ)

  return data_civ
end

commerce.civ_maj=function(civ_pos)
  local meta = minetest.get_meta(civ_pos)
  local data_civ=meta:get_string("trade")

  if data_civ=="" or data_civ==nil then
    data_civ=commerce.civ_init(civ_pos)
  end

  local civ_table=string.split(data_civ,"/")

  local name_civ=civ_table[17]
  local bank=tonumber(civ_table[16])

  local war=tonumber(civ_table[18])
  local farm=tonumber(civ_table[19])
  local mine=tonumber(civ_table[20])
  local build=tonumber(civ_table[21])
  local trade=tonumber(civ_table[22])

  local eat=tonumber(civ_table[1])
  local ores=tonumber(civ_table[3])
  local tools=tonumber(civ_table[5])
  local material=tonumber(civ_table[7])
  local furniture=tonumber(civ_table[9])
  local machine=tonumber(civ_table[11])
  local misc=tonumber(civ_table[13])

  local population=tonumber(civ_table[15])
  

if population<-1 then
  population=population+1
else
  --*********
  --** WAR **
  --*********
  local x_coef

  if tools>population then
    x_coef=2-(population/math.max(1,tools))
  else
    x_coef=tools/math.max(1,population)
  end

  local probabiliter=math.random(1,war)

  if probabiliter<5 then --ennemie qui attaque
    local degat_defense=(2-x_coef)*((population*(101-war))/100)*0.1
    eat=math.max(0,eat-degat_defense)
    ores=math.max(0,ores-degat_defense)
    tools=math.max(0,tools-degat_defense)
    material=math.max(0,material-degat_defense)
    machine=math.max(0,machine-degat_defense)
    furniture=math.max(0,furniture-degat_defense)
    misc=math.max(0,misc-degat_defense)
    bank=math.max(0,bank-degat_defense)
    population=math.max(0,population-(degat_defense*0.5))
    war=math.min(100,war+20)
--minetest.chat_send_all("defense "..degat_defense)
  else

    probabiliter=math.random(1,(101-war))

    if probabiliter<5 then --attaque
      local degat_attack=(x_coef*((war*population)/100))*0.1
      eat=eat+degat_attack
      ores=ores+degat_attack
      tools=math.max(0,tools-degat_attack)
      machine=machine+degat_attack
      furniture=furniture+degat_attack
      misc=misc+degat_attack
      bank=bank+degat_attack
      population=math.max(0,population-(degat_attack*0.25))
--minetest.chat_send_all("attack "..degat_attack)
    end

  end

  --**************
  --** manger ! **
  --**************
  local tmp=eat-(population*0.2)
--minetest.chat_send_all("eat "..tmp.."/"..eat)
  if tmp<0 then
    eat=0
    population=population-math.abs(tmp)

    if population<1 then
      population=population-20
    end

  else
    eat=math.max(0,tmp)
  end

  --***************
  -- catastrophe **
  --***************
  
  probabiliter=math.random(1,farm)+math.random(1,build)
  if probabiliter<3 then

    if tools>population then
      x_coef=(2-(population/math.max(1,tools)))*0.1
    else
      x_coef=(tools/math.max(1,population))*0.1
    end

    eat=math.max(0,eat-(x_coef*eat))
    ores=math.max(0,ores-(x_coef*ores))
    tools=math.max(0,tools-(x_coef*tools))
    material=math.max(0,material-(x_coef*material))
    machine=math.max(0,machine-(x_coef*machine))
    furniture=math.max(0,furniture-(x_coef*furniture))
    misc=math.max(0,misc-(x_coef*misc))
    bank=math.max(0,bank-(x_coef*bank))
    population=math.max(0,population-(x_coef*population))
--minetest.chat_send_all("catastrophe "..x_coef)
  end
  
  --***************
  --** naissance **
  --***************

  if eat>(population*0.5) and furniture>(population*0.25) then
    tmp=math.floor((population*0.0001)*farm)
    furniture=math.max(0,furniture-tmp)
    population=math.min(10000,population+tmp)
    
--minetest.chat_send_all("naissance : ".. tmp)
  end

  --** FARM **

if tools>0 and farm>0 then
  eat=eat+((farm*0.01)*population)
  tools=math.max(0,tools-(population*(farm*0.01)))
else
  eat=eat+(population*0.01)
end


  --** MINE **
  if tools>0 and mine>0 then
    ores=ores+((mine*0.03)*population)
    tools=math.max(0,tools-(population*(mine*0.01)))
  else
    ores=ores+(population*0.01)
  end

  --**  **

  if build>0 and ores>0 then
    tools=tools+((build*0.1)*population)
    ores=math.max(0,ores-(population*build*0.1))
  else
    tools=tools+(population*0.01)
  end



  
    if build>50 and ores>0 then
      furniture=furniture+((build*0.1)*population)
      ores=math.max(0,ores-(population*(build*0.1)))
    else
      furniture=furniture+(0.01*population)
      ores=math.max(0,ores-(population*0.01))
    end


    if build>75 and furniture>0 then
      misc=misc+((build*0.01)*population)
      furniture=math.max(0,furniture-(population*(build*0.01)))
    else
      misc=misc+(0.001*population)
      furniture=math.max(0,furniture-(population*0.01))
    end


  --** vehicules weapons **
  if war>75 then
    if build>50 and ores>0 then
      tmp=((build*population)/1000)
      tools=tools+tmp
      ores=math.max(0,ores-tmp)
--furniture=math.max(0,furniture-(population*(indus/10)))
--minetest.chat_send_all("weapons")
    end
  else
    if ores>0 then
      tmp=((build*population)/1000)
      machine=machine+tmp
      ores=math.max(0,ores-tmp)
--furniture=math.max(0,furniture-(population*(indus/10)))
--minetest.chat_send_all("machine")
    end
  end
--
war=math.max(0,war-1)

--si eat<50% augmente farm, si eat>10% baisse farm
if eat<(population*0.5) then
farm=math.min(100,farm+2)
elseif eat>(population*1.1) then
  farm=math.max(0,farm-1)
end

--trader


--si ores<75% mine add / >15% mine dec
if ores<(population*0.75) then
mine=math.min(100,mine+2)
elseif ores>(population*1.15) then
  mine=math.max(0,mine-1)
end

--
if tools<(population*0.75) then
build=math.min(100,build+2)
elseif tools>(population*1.15) then
  build=math.max(0,build-1)
end

--
if furniture<(population*0.75) then
build=math.min(100,build+2)
elseif furniture>(population*1.15) then
  build=math.max(0,build-1)
end


--**************
  --** commerce **
  --**************
  probabiliter=math.random(1,101-trade)

  if probabiliter<5 then
    tmp=(ores+tools+furniture+misc+machine)/5

    if tmp>population then
      x_coef=(2-(population/math.max(1,tmp)))*(math.random(1,5)/10)
    else
      x_coef=(tmp/math.max(1,population))*(math.random(1,5)/10)
    end

    
if bank>ores and ores<(0.25*population) then --achat
ores=ores+(x_coef*ores)
bank=math.max(0,bank-(x_coef*bank))
elseif ores>bank then
ores=math.max(0,ores-(x_coef*ores))
bank=bank+(x_coef*bank)
end

if bank>tools and tools<(0.25*population) then --achat
tools=tools+(x_coef*tools)
bank=math.max(0,bank-(x_coef*bank))
elseif tools>bank then
tools=math.max(0,tools-(x_coef*tools))
bank=bank+(x_coef*bank)
end

if bank>furniture and furniture<(0.25*population) then --achat
furniture=furniture+(x_coef*furniture)
bank=math.max(0,bank-(x_coef*bank*2))
elseif furniture>bank then
furniture=math.max(0,furniture-(x_coef*furniture))
bank=bank+(x_coef*bank*2)
end

if bank>machine and machine<(0.25*population) then --achat
machine=machine+(x_coef*machine)
bank=math.max(0,bank-(x_coef*bank*3))
elseif machine>bank then
machine=math.max(0,machine-(x_coef*machine))
bank=bank+(x_coef*bank*3)
end

if bank>material and material<(0.25*population) then --achat
material=material+(x_coef*machine)
bank=math.max(0,bank-(x_coef*bank*3))
elseif material>bank then
material=math.max(0,material-(x_coef*machine))
bank=bank+(x_coef*bank*3)
end

if bank>misc and misc<(0.25*population) then --achat
misc=misc+(x_coef*misc)
bank=math.max(0,bank-(x_coef*bank*3))
elseif misc>bank then
misc=math.max(0,misc-(x_coef*misc))
bank=bank+(x_coef*bank*3)
end

--minetest.chat_send_all("commerce "..x_coef)
    
  end

end

if population==-1 then
  data_civ=commerce.civ_init(civ_pos)
else
  data_civ=math.floor(eat) .."/".. civ_table[2] .."/".. math.floor(ores) .."/".. civ_table[4] .."/".. math.floor(tools) .."/".. civ_table[6] .."/".. math.floor(material) .."/".. civ_table[8] .."/".. math.floor(furniture) .."/".. civ_table[10] .."/".. math.floor(machine) .."/".. civ_table[12] .."/".. math.floor(misc) .."/".. civ_table[14] ..
    "/".. math.floor(population) .."/".. math.floor(bank) .."/".. name_civ .."/".. war .."/".. farm .."/".. mine .."/".. build .."/".. trade
end
  --minetest.chat_send_all("-----------")
  meta:set_string("trade",data_civ)
end


--plot marker village
--TODO achat vente maison
minetest.register_node("commerce:plot", {
	description = "plot marker",
	drawtype = "nodebox",
    node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.5, 0.5, -0.375, 0.5}, -- NodeBox1
			{-0.1875, -0.375, -0.1875, 0.1875, -0.0625, 0.1875}, -- NodeBox2
			{-0.125, -0.0625, -0.125, 0.125, 0.3125, 0.125}, -- NodeBox3
			{-0.1875, 0.3125, -0.1875, 0.1875, 0.4375, 0.1875}, -- NodeBox4
			{-0.125, 0.4375, -0.125, 0.125, 0.5, 0.125}, -- NodeBox5
		}
	},
	tiles = {
		"commerce_borne_top.png",
		"commerce_borne_bottom.png",
		"commerce_borne_side.png",
		"commerce_borne_side.png",
		"commerce_borne_nord.png",
		"commerce_borne_sud.png"
	},
	paramtype = "light",
	drop = "commerce:plot",
	groups = {unbreakable = 1, not_in_creative_inventory = 1},--{cracky=3},--,not_in_creative_inventory=1},
	sunlight_propagates = false,
	sounds = default.node_sound_stone_defaults(),
})
