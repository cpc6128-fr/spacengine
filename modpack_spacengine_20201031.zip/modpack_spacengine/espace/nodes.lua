--[[
liste des nodes
## AIR ##
espace:vacuum = vacuum
espace:radiation = vacuum+radiation
espace:air = air / disapear near vacuum
espace:smog = brouillard épaix
espace:air_brume = brume colorée
espace:radioactive_air = air + radiation

## SUN ##
espace:sun_red
espace:sun_yellow
espace:sun_blue
espace:sun_white

## SOL ##
espace:invisible_bedrock
espace:bedrock = unbreakable bedrock
espace:star_material1 TODO radiation
espace:star_material2 TODO hot
espace:stone
espace:rock = RPGmaker
espace:stone_hot = proche lava RPGmaker
espace:gravel
espace:dust
espace:gallet = petit gallet de riviere RPGmaker
espace:desert = sol de desert sec et dur
espace:sand
espace:grass = style rpg RPGmaker
espace:grass_flowers = RPGmaker
espace:grass_cailloux = RPGmaker
espace:cailloux = RPGmaker
espace:cailloux_grass = RPGmaker
espace:dirt
espace:grass_2
espace:cailloux_2 = RPGmaker
espace:talcum = talc
espace:mur
espace:rock_2 = RPGmaker
espace:herbe
espace:fleur

## OBJET ##
espace:rocher
espace:rocher01
espace:buisson

## LIQUIDE ##
espace:water = bloc
espace:mud
espace:oil

espace:mud_source
espace:oil_source
espace:ocean_source


--]]

--****************
--** atmosphere **
--****************

if not minetest.get_modpath("vacuum") then

minetest.register_node(":vacuum:vacuum", {
	description = "Vacuum",

--original
	drawtype = "airlike",
	drowning = 1,
  groups = {not_in_creative_inventory=1, cools_lava=1},
--]]

--[[for creative mode
drawtype = "glasslike",
tiles = {"asteroid_atmos.png^[colorize:#DD00007F"},
post_effect_color = {a = 100, r = 150, g = 75, b = 125},
alpha = 100,
--]]

  paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	floodable = true,
  pointable = false,
diggable = true,
})
end

minetest.register_node("espace:radiation", {
	description = "radiation",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	drawtype = "glasslike",
	post_effect_color = {a = 100, r = 150, g = 75, b = 125},
	tiles = {"espace_atmos.png^[colorize:#964B7DAA"},
	alpha = 100,
	groups = {not_in_creative_inventory=1},
	paramtype = "light",
	sunlight_propagates =true,
	is_ground_content = false,
  floodable = true,
  drowning = 1,
})


minetest.register_node("espace:air", {
	description = "Air",
	drawtype = "airlike",
  paramtype = "light",
	is_ground_content = false,
	sunlight_propagates = true,
	walkable = false,
	pointable = false,--pointable = false,
	diggable = false,--diggable = false,
	buildable_to = true,--buildable_to = true,
	floodable = true,
  groups = {not_in_creative_inventory=1},
})

minetest.register_node("espace:smog", {
	description = "smog",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	drawtype = "glasslike",
	post_effect_color = {a = 60, r = 50, g = 50, b = 50},
	tiles = {"espace_atmos.png^[colorize:#80808080"},--{"brume.png"},
	alpha = 25,
	groups = {not_in_creative_inventory=1},
	paramtype = "light",
  --floodable = false,
	sunlight_propagates =true,
	is_ground_content = false,
})
--
minetest.register_node("espace:brume", {
	description = "brume",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	drawtype = "glasslike",
	post_effect_color = {a = 100, r = 180, g = 175, b = 190},
	tiles = {"espace_brume.png"},
	--alpha = 50,
	groups = {not_in_creative_inventory=1},
	paramtype = "light",
	sunlight_propagates =true,
	is_ground_content = false,
  --floodable = true,
})
--]]
minetest.register_node("espace:radioactive_air", {
	description = "dust radioactive",
	drawtype = "glasslike",
	tiles = {"espace_radioactive_dust.png"},
	paramtype = "light",
    light_source = 2,
	sunlight_propagates = true,
  post_effect_color = {a = 75, r = 150, g = 50, b = 250},
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	use_texture_alpha = true,
  --floodable = false,
	groups = { radioactive=1, not_in_creative_inventory = 1}
})


-- Items
--

minetest.register_craftitem("espace:helmet", {
	description = "Mesetint Helmet",
	inventory_image = "moonrealm_helmet.png",
	--groups = {not_in_creative_inventory = 1},
})
    
--***************
--** Spacesuit **
--***************

minetest.register_tool("espace:spacesuit", {
	description = "Spacesuit (wear slot 1)",
	inventory_image = "moonrealm_spacesuit.png",
})

minetest.register_craft({
	output = "espace:helmet",
	recipe = {
		{"default:mese_crystal"},
		{"default:glass"},
		{"default:gold_ingot"},
	}
})


minetest.register_craft({
	output = "espace:spacesuit",
	recipe = {
		{"wool:white", "espace:helmet", "wool:white"},
		{"", "vessels:glass_bottle", ""},
		{"wool:white", "", "wool:white"},
	}
})

--toxic
minetest.register_tool("espace:toxic_suit", {
	description = "toxic suit(wear slot 1) protect toxic and poison",
	inventory_image = "espace_toxic_suit.png",
})

minetest.register_craft({
	output = "espace:toxic_suit",
	recipe = {
		{"wool:red", "espace:helmet", "wool:red"},
		{"", "vessels:glass_bottle", ""},
		{"wool:white", "", "wool:white"},
	}
})

--nuclear
minetest.register_tool("espace:nuclear_suit", {
	description = "nuclear (wear slot 1) protect radioactive",
	inventory_image = "espace_nuclear_suit.png",
})

minetest.register_craft({
	output = "espace:nuclear_suit",
	recipe = {
		{"wool:orange", "espace:helmet", "wool:orange"},
		{"", "vessels:glass_bottle", ""},
		{"wool:white", "", "wool:white"},
	}
})

--**********
--** star **
--**********
minetest.register_node( "espace:star_material1", {
	description = "Star Material",
	tiles = { "espace_sun_yellow.png"},
	groups = {cracky=335, radioactive=1},
	light_source = LIGHT_MAX,
	sounds = default.node_sound_stone_defaults(),
  drop = {
		max_items = 1,
		items = {
			{
				items = {'espace:star_material1'},
				rarity = 50,
			},
			{
				items = {'default:mese_crystal_fragment'},
			}
		}
	},
	is_ground_content = false,
}) 

minetest.register_node( "espace:star_material2", {
	description = "Star Material 2",
	tiles = { "espace_sun_white.png"},
	groups = {cracky=335,not_in_creative_inventory = 1, radioactive=1},
	light_source = LIGHT_MAX,
	sounds = default.node_sound_stone_defaults(),
  drop = {
		max_items = 1,
		items = {
			{
				items = {'espace:star_material1'},
				rarity = 50,
			},
			{
				items = {'default:mese_crystal_fragment'},
			}
		}
	},
	is_ground_content = false,
})

minetest.register_node( "espace:sun_red", {
	description = "Sun red",
  drawtype = "glasslike",
  paramtype = "light",
	tiles = { "espace_sun_red_alpha.png"},
	groups = {cracky=335,not_in_creative_inventory = 1, radioactive=1},
	light_source = LIGHT_MAX,
	sounds = default.node_sound_stone_defaults(),
  drop = {
		max_items = 1,
		items = {
			{
				items = {'espace:star_material1'},
				rarity = 50,
			},
			{
				items = {'default:mese_crystal_fragment'},
			}
		}
	},
	is_ground_content = false,
}) 

minetest.register_node( "espace:sun_blue", {
	description = "Sun Blue",
  drawtype = "glasslike",
  paramtype = "light",
	tiles = { "espace_sun_blue_alpha.png"},
	groups = {cracky=335,not_in_creative_inventory = 1, radioactive=1},
	light_source = LIGHT_MAX,
	sounds = default.node_sound_stone_defaults(),
  drop = {
		max_items = 1,
		items = {
			{
				items = {'espace:star_material1'},
				rarity = 50,
			},
			{
				items = {'default:mese_crystal_fragment'},
			}
		}
	},
	is_ground_content = false,
}) 

minetest.register_node( "espace:nebul_red", {
	description = "nebuleuse red",
  paramtype = "light",
	tiles = {"espace_nebuleuse2.png"},
	groups = {cracky=334,not_in_creative_inventory = 1, radioactive=1},
	walkable = false,
	climbable = true,
	sounds = default.node_sound_stone_defaults(),
	drop = "espace:star_dust",
	is_ground_content = false,
})

minetest.register_node( "espace:nebul_purple", {
	description = "nebuleuse purple",
  paramtype = "light",
	tiles = { "espace_nebuleuse1.png"},
	groups = {cracky=334,not_in_creative_inventory = 1, radioactive=1},
	walkable = false,
	climbable = true,
	sounds = default.node_sound_stone_defaults(),
	drop = "espace:star_dust",
	is_ground_content = false,
})

minetest.register_node( "espace:nebul_blue", {
	description = "nebuleuse blue",
  paramtype = "light",
	tiles = { "espace_nebuleuse3.png"},
	groups = {cracky=334,not_in_creative_inventory = 1, radioactive=1},
	walkable = false,
	climbable = true,
	sounds = default.node_sound_stone_defaults(),
	drop = "espace:star_dust",
	is_ground_content = false,
})

minetest.register_craftitem("espace:star_dust", {
    description = "Star Dust",
    inventory_image = "espace_stardust.png"
})

minetest.register_craftitem("espace:antimatiere", {
    description = "Antimatiere",
    inventory_image = "espace_antimatiere.png"
})

minetest.register_craft({
    output = "espace:star_material1 1",
    recipe = {
        {"espace:star_dust", "espace:star_dust", "espace:star_dust"},
        {"espace:star_dust", "espace:star_dust", "espace:star_dust"},
        {"espace:star_dust", "espace:star_dust", "espace:star_dust"}
    }
})

minetest.register_craft({
    output = "espace:antimatiere 1",
    recipe = {
        {"espace:star_material1", "espace:star_material1", "espace:star_material1"},
        {"espace:star_material1", "default:mese", "espace:star_material1"},
        {"espace:star_material1", "espace:star_material1",  "espace:star_material1"}
    }
})
--***************
--** materiaux **
--***************

minetest.register_node("espace:bedrock", {
	description = "Bedrock",
	tile_images = {"espace_bedrock.png"},
	drop = "",
  light_source = 3,
  is_ground_content = false,
	groups = { unbreakable = 1,not_in_creative_inventory = 1}, -- For Map Tools' admin pickaxe unbreakable = 1,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("espace:invisible_bedrock", {
	description = "invisible Bedrock",
  drawtype = "airlike",
  paramtype = "light",
	--tile_images = {"bedrock.png"},
	drop = "",
  is_ground_content = false,
	groups = { unbreakable = 1,not_in_creative_inventory = 1}, -- For Map Tools' admin pickaxe unbreakable = 1,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("espace:stone", {
	description = "Asteroid Stone",
	tiles = {"espace_stone.png"},
	--is_ground_content = false,
	drop = 'default:cobble',
	groups = {cracky = 3, not_in_creative_inventory=1},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("espace:rock", {
	description = "Asteroid Rock",
	tiles = {"espace_rock.png"},
	--is_ground_content = false,
	drop = 'default:cobble',
	groups = {cracky = 3, not_in_creative_inventory=1},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("espace:stone_hot", {
	description = "Asteroid stone hot",
	tiles = {"espace_lava.png"},
	is_ground_content = false,
  paramtype = "light",
    light_source = 5,
	drop = 'default:cobble',
	groups = {cracky = 3, not_in_creative_inventory=1},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("espace:gravel", {
	description = "Asteroid Gravel",
	tiles = {"asteroid_gravel.png"},
	--is_ground_content = false,
	drop = 'default:gravel',
	groups = {crumbly = 2, not_in_creative_inventory=1},
	sounds = default.node_sound_dirt_defaults({
		footstep = {name = "default_gravel_footstep", gain = 0.2},
	}),
})

minetest.register_node("espace:dust", {
	description = "Asteroid Dust",
	tiles = {"asteroid_dust.png"},
	--is_ground_content = false,
	groups = {crumbly = 3},
	sounds = default.node_sound_dirt_defaults({
		footstep = {name = "default_gravel_footstep", gain = 0.1},
	}),
})

minetest.register_node("espace:gallet", {
	description = "Gallet",
	tiles = {"espace_gravel.png"},
	--is_ground_content = false,
	drop = 'default:gravel',
	groups = {crumbly = 2, not_in_creative_inventory=1},
	sounds = default.node_sound_dirt_defaults({
		footstep = {name = "default_gravel_footstep", gain = 0.2},
	}),
})

minetest.register_node("espace:desert", {
	description = "desert ground",
	tiles = {"espace_desert.png"},
	--is_ground_content = false,
	--drop = 'espace:desert',
  sounds = default.node_sound_sand_defaults(),
	groups = {crumbly = 3},--, not_in_creative_inventory=1},
})

minetest.register_node("espace:sand", {
	description = "sand",
	tiles = {"espace_sand.png"},
	--is_ground_content = false,
	--drop = 'espace:sand',
  sounds = default.node_sound_sand_defaults(),
	groups = {crumbly = 3},--, not_in_creative_inventory=1},
})

--
minetest.register_node("espace:roche", {
	description = "roche",
	tiles ={"espace_roche.png"},
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("espace:roche_mousse", {
	description = "roche_mousse",
	tiles ={"espace_roche_mousse.png"},
	groups = {cracky=3},
	sounds = default.node_sound_stone_defaults(),
})
--]]

--fairyland

minetest.register_node("espace:grass_flowers", {
	description = "grass flowers",
	tiles = {"espace_grass_flowers_16.png","default_grass.png"},--{"espace_grass_flowers.png","espace_grass.png"},
	--is_ground_content = false,
	--drop = 'espace:grass_flowers',
  sounds = default.node_sound_leaves_defaults(),
	groups = {crumbly = 3, not_in_creative_inventory=1},
})

minetest.register_node("espace:grass_cailloux", {
	description = "grass cailloux",
	tiles = {"espace_grass_cailloux_16.png","default_grass.png"},--{"espace_grass_cailloux.png","espace_grass.png"},
	--is_ground_content = false,
	--drop = 'espace:grass_cailloux',
  sounds = default.node_sound_leaves_defaults(),
	groups = {crumbly = 3, not_in_creative_inventory=1},
})

minetest.register_node("espace:cailloux", {
	description = "cailloux",
	tiles = {"espace_cailloux.png"},
	--is_ground_content = false,
	--drop = 'espace:cailloux',
  sounds = default.node_sound_gravel_defaults(),
	groups = {cracky = 3, not_in_creative_inventory=1},
})

minetest.register_node("espace:cailloux_grass", {
	description = "cailloux grass",
	tiles = {"espace_cailloux_grass_16.png","espace_cailloux.png"},
	--is_ground_content = false,
	--drop = 'espace:cailloux_grass',
  sounds = default.node_sound_gravel_defaults(),
	groups = {cracky = 3, not_in_creative_inventory=1},
})

--

minetest.register_node("espace:dirt", {
	description = "Asteroid dirt",
	tiles = {"espace_dirt.png"},
	--is_ground_content = false,
	groups = {crumbly = 3},--, not_in_creative_inventory=1},
	sounds = default.node_sound_dirt_defaults(),
})

minetest.register_node("espace:grass_2", {
	description = "Asteroid grass_2",
	tiles = {"espace_grass_3.png"},
	--is_ground_content = false,
	groups = {crumbly = 3, soil=1},--, not_in_creative_inventory=1},
	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_node("espace:fleur", {
	description = "fleur",
	tiles ={"espace_fleur.png","espace_herbe.png"},
	groups = {crumbly=3, soil=1},
	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_node("espace:herbe", {
	description = "herbe",
	tiles ={"espace_herbe.png"},
	groups = {crumbly=3, soil=1},
	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_node("espace:cailloux_2", {
	description = "Asteroid cailloux_2",
	tiles = {"espace_cailloux_2.png"},
	--is_ground_content = false,
	groups = {cracky = 3},--, not_in_creative_inventory=1},
	sounds = default.node_sound_gravel_defaults(),
})

minetest.register_node("espace:talcum", {
	description = "Asteroid talcum powder",
	tiles = {"asteroid_talcum.png"},
	--is_ground_content = false,
	groups = {crumbly = 2},--, not_in_creative_inventory=1},
	sounds = default.node_sound_sand_defaults(),
})

minetest.register_node("espace:mur", {
	description = "Asteroid mur",
	tiles = {"espace_rock01.png"},
	is_ground_content = false,
	groups = {cracky = 3},--, not_in_creative_inventory=1},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("espace:rock_2", {
	description = "Asteroid rock 2",
	tiles = {"espace_dirt02.png","espace_rock02.png"},
	--is_ground_content = false,
	groups = {cracky = 1},--, not_in_creative_inventory=1},
	sounds = default.node_sound_stone_defaults(),
})

--** 3d plant objet **

--Rocks

minetest.register_node("espace:rocher", {
		description = "rocher",
		drawtype = "plantlike",
		tiles = {"espace_rocher11.png"},
		inventory_image = "espace_rocher11.png",
		wield_image = "espace_rocher11.png",
		sunlight_propagates = false,
		paramtype = "light",
		walkable = true,
		buildable_to = true,
    is_ground_content = false,
    groups = {cracky = 3},
		selection_box = {
			type = "fixed",
			fixed = {-0.5,-0.5,-0.5,0.5,0.5,0.5}
		}
	})

minetest.register_node("espace:rocherbig", {
		description = "rocherbig",
		drawtype = "plantlike",
		tiles = {"rocherbig.png"},
--visual_scale=1.,
		inventory_image = "rocherbig.png",
		wield_image = "rocherbig.png",
		sunlight_propagates = false,
		paramtype = "light",
		walkable = true,
		buildable_to = true,
    is_ground_content = false,
    groups = {cracky = 3},
		selection_box = {
			type = "fixed",
			fixed = {-0.5,-0.5,-0.5,0.5,0.5,0.5}
		}
	})  

  minetest.register_node("espace:rocher01", {
		description = "rocher",
		drawtype = "plantlike",
		tiles = {"rocher01.png"},
		inventory_image = "rocher01.png",
		wield_image = "rocher01.png",
		sunlight_propagates = false,
		paramtype = "light",
		walkable = true,
		buildable_to = true,
    is_ground_content = false,
    groups = {cracky = 3},
		selection_box = {
			type = "fixed",
			fixed = {-0.5,-0.5,-0.5,0.5,0.5,0.5}
		}
	})

minetest.register_node("espace:buisson", {
		description = "buisson",
		drawtype = "plantlike",
		tiles = {"buisson.png"},
		inventory_image = "buisson.png",
		wield_image = "buisson.png",
		sunlight_propagates = true,
		paramtype = "light",
		walkable = false,
		buildable_to = true,
    is_ground_content = false,
    groups = {crumbly = 3},
		selection_box = {
			type = "fixed",
			fixed = {-0.4,-0.5,-0.4,0.4,0.5,0.4}
		}
	})
----------------------------------------------------------------------------------------------------------
--WATER
----------------------------------------------------------------------------------------------------------
minetest.register_node("espace:water", {
	description = "water",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	drawtype = "glasslike",
	post_effect_color = {a = 100, r = 0, g = 100, b = 200},
	tiles = {"asteroid_water.png"},
	alpha = 50,
	paramtype = "light",
	sunlight_propagates =true,
	is_ground_content = false,
  drowning = 1,
  climbable = true,
	groups = {water = 3, liquid = 3, puts_out_fire = 1},
})

minetest.register_node("espace:mud", {
	description = "mud",
	walkable = false,
	pointable = true,
	diggable = false,
	buildable_to = true,
	drawtype = "glasslike",
	post_effect_color = {a = 200, r = 81, g = 48, b = 5},
	tiles = {"lib_materials_fluid_mud_source.png"},
	alpha = 240,
	paramtype = "light",
	sunlight_propagates =true,
	is_ground_content = false,
  drowning = 1,
  climbable = true,
	groups = {water = 3, liquid = 3, puts_out_fire = 1},
})

minetest.register_node("espace:oil", {
	description = "oil",
	walkable = false,
	pointable = true,
	diggable = false,
	buildable_to = true,
	drawtype = "glasslike",
	post_effect_color = {a = 200, r = 20, g = 20, b = 20},
	tiles = {"lib_materials_fluid_oil_source.png"},
	alpha = 240,
	paramtype = "light",
	sunlight_propagates =true,
	is_ground_content = false,
	liquid_viscosity = 1,
  drowning = 1,
  climbable = true,
	groups = { liquid = 3},
})

minetest.register_node("espace:mud_source", {
	description = "mud source",
	drawtype = "liquid",
	tiles = {
		{
			name = "lib_materials_fluid_mud_source_animated.png",
			backface_culling = false,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 2.0,
			},
		},
		{
			name = "lib_materials_fluid_mud_source_animated.png",
			backface_culling = true,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 2.0,
			},
		},
	},
	alpha = 240,
	paramtype = "light",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	drowning = 1,
	liquidtype = "source",
	liquid_alternative_flowing = "espace:mud_flowing",
	liquid_alternative_source = "espace:mud_source",
	liquid_viscosity = 3,
	liquid_renewable = false,
	liquid_range = 1,
	post_effect_color = {a = 200, r = 81, g = 48, b = 5},
	groups = {liquid = 3},
	sounds = default.node_sound_water_defaults(),
})

minetest.register_node("espace:mud_flowing", {
	description = "Flowing Oil",
	drawtype = "flowingliquid",
	tiles = {"lib_materials_fluid_mud_source.png"},
	special_tiles = {
		{
			name = "lib_materials_fluid_mud_source_animated.png",
			backface_culling = false,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 0.8,
			},
		},
		{
			name = "lib_materials_fluid_mud_source_animated.png",
			backface_culling = true,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 0.8,
			},
		},
	},
	alpha = 240,
	paramtype = "light",
	paramtype2 = "flowingliquid",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	drowning = 1,
	liquidtype = "flowing",
	liquid_alternative_flowing = "espace:mud_flowing",
	liquid_alternative_source = "espace:mud_source",
	liquid_viscosity = 1,
	liquid_renewable = false,
	liquid_range = 1,
	post_effect_color = {a = 200, r = 81, g = 48, b = 5},
	groups = {liquid = 3, not_in_creative_inventory = 1},
	sounds = default.node_sound_water_defaults(),
})
--
minetest.register_node("espace:oil_source", {
	description = "Oil source",
	drawtype = "liquid",
	tiles = {
		{
			name = "lib_materials_fluid_oil_source_animated.png",
			backface_culling = false,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 2.0,
			},
		},
		{
			name = "lib_materials_fluid_oil_source_animated.png",
			backface_culling = true,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 2.0,
			},
		},
	},
	alpha = 240,
	paramtype = "light",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	drowning = 1,
	liquidtype = "source",
	liquid_alternative_flowing = "espace:oil_flowing",
	liquid_alternative_source = "espace:oil_source",
	liquid_viscosity = 3,
	liquid_renewable = false,
	liquid_range = 2,
	post_effect_color = {a = 200, r = 20, g = 20, b = 20},
	groups = {liquid = 3,toxic=1},
	sounds = default.node_sound_water_defaults(),
})

minetest.register_node("espace:oil_flowing", {
	description = "Flowing Oil",
	drawtype = "flowingliquid",
	tiles = {"lib_materials_fluid_oil_source.png"},
	special_tiles = {
		{
			name = "lib_materials_fluid_oil_source_animated.png",
			backface_culling = false,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 0.8,
			},
		},
		{
			name = "lib_materials_fluid_oil_source_animated.png",
			backface_culling = true,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 0.8,
			},
		},
	},
	alpha = 240,
	paramtype = "light",
	paramtype2 = "flowingliquid",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	drowning = 1,
	liquidtype = "flowing",
	liquid_alternative_flowing = "espace:oil_flowing",
	liquid_alternative_source = "espace:oil_source",
	liquid_viscosity = 1,
	liquid_renewable = false,
	liquid_range = 2,
	post_effect_color = {a = 200, r = 20, g = 20, b = 20},
	groups = {liquid = 3, not_in_creative_inventory = 1, toxic=1},
	sounds = default.node_sound_water_defaults(),
})

minetest.register_craft({
	type = "fuel",
	recipe = "espace:oil_source",
	burntime = 60,
})

minetest.register_node("espace:ocean_source", {
	description = "ocean source",
	drawtype = "liquid",
	tiles = {
		{
			name = "lib_materials_fluid_water_dirty_source_animated.png",
			backface_culling = false,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 2.0,
			},
		},
		{
			name = "lib_materials_fluid_water_dirty_source_animated.png",
			backface_culling = true,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 2.0,
			},
		},
	},
	alpha = 230,
	paramtype = "light",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	drowning = 1,
	liquidtype = "source",
	liquid_alternative_flowing = "espace:ocean_flowing",
	liquid_alternative_source = "espace:ocean_source",
	liquid_viscosity = 3,
	liquid_renewable = false,
	liquid_range = 0,
	post_effect_color = {a = 103, r = 30, g = 60, b = 90},
	groups = {liquid = 3},
	sounds = default.node_sound_water_defaults(),
})

minetest.register_node("espace:ocean_flowing", {
	description = "ocean flowing",
	drawtype = "flowingliquid",
	tiles = {"asteroid_water.png"},
	special_tiles = {
		{
			name = "lib_materials_fluid_water_dirty_source_animated.png",
			backface_culling = false,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 0.8,
			},
		},
		{
			name = "lib_materials_fluid_water_dirty_source_animated.png",
			backface_culling = true,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 0.8,
			},
		},
	},
	alpha = 230,
	paramtype = "light",
	paramtype2 = "flowingliquid",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	drowning = 1,
	liquidtype = "flowing",
	liquid_alternative_flowing = "espace:ocean_flowing",
	liquid_alternative_source = "espace:ocean_source",
	liquid_viscosity = 1,
	liquid_renewable = false,
	liquid_range = 0,
	post_effect_color = {a = 103, r = 30, g = 60, b = 90},
	groups = {liquid = 3, not_in_creative_inventory = 1},
	sounds = default.node_sound_water_defaults(),
})

bucket.register_liquid("espace:oil_source", "air", "espace:bucket_oil","bucket_oil.png","oil bucket",{water_bucket = 1})
bucket.register_liquid("espace:mud_source", "air", "espace:bucket_mud","bucket_mud.png","mud bucket",{water_bucket = 1})

--transform bucket en bloc
minetest.register_craft({
	type = "shapeless",
	output = "espace:oil_source",
	recipe = {"espace:bucket_oil"},
  replacements = {{"espace:bucket_oil", "bucket:bucket_empty"}}
})

minetest.register_craftitem('espace:earth', {
  description = 'Teleport Stargate earth',
  drawtype = "plantlike",
  paramtype = "light",
  tiles = {'espace_teleport.png'},
  inventory_image = 'espace_teleport.png',
  stack_max=1,
  groups = {dig_immediate = 3},
  sounds = default.node_sound_stone_defaults(),
  on_use = function(itemstack, user, pointed_thing)
    local pos=user:get_pos()
    minetest.chat_send_player(user:get_player_name(),math.floor(pos.x).." ".. math.floor(pos.y).." ".. math.floor(pos.z))
    if pos.y<-25 or pos.y>1007 then return end
    if pos.x<-32 or pos.x>48 then return end
    if pos.z<-32 or pos.z>48 then return end
    local tmp=espace.xpgetlvl(user,"force")
    local xp=tonumber(tmp)
    if xp<5 then return end
    if pos.y<608 then
      user:set_pos({x=0,y=611,z=0})
    else
      --lecture voxelmanip
      local pos1,pos2={x=0,y=-25,z=0},{x=0,y=100,z=0}
      local c_air = minetest.get_content_id("air")

      local manip = minetest.get_voxel_manip()
      local e1, e2 = manip:read_from_map(pos1, pos2)
      local area = VoxelArea:new{MinEdge=e1, MaxEdge=e2}
      local data = manip:get_data()
      local new_pos
      local err=true

      for y=-25,100 do
        local cpt = area:index(0, y, 0 )

        if data[cpt] == c_air then
          new_pos={x=0,y=y,z=0}
          err=false
          break
        end
      end
 
      if err==true then return end

      user:set_pos(new_pos)
    end
  end,
})

minetest.register_craft({
  output = 'espace:earth',
  recipe = {
    {'default:mese','',''},
    {'','default:obsidian_shard',''},
    {'','','default:obsidian_shard'},
  }
})
