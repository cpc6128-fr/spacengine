--from pandorabox beacon mods
minetest.register_node("bloc4builder:flyer", {
	description = "invisible wall",
	drawtype = "glasslike",
	tiles = {"b4b_air.png"},
	paramtype = "light",
  use_texture_alpha = true,
	is_ground_content = false,
  groups = {not_in_creative_inventory = 1},
	sunlight_propagates = true,
	walkable = false,
	floodable = false,
  pointable = false,
})

local priv_cache = {} -- playername -> {priv=}
local flyer_timer = 0
local singleplayer_priv=false

minetest.register_globalstep(function(dtime)
	-- Update timer
	flyer_timer = flyer_timer + dtime
	if (flyer_timer > 2) then
		flyer_timer = 0

		-- List all connected player
		local players = minetest.get_connected_players()
		for _,player in ipairs(players) do

			-- Get player infos
			local pos = player:get_pos()
			local name = player:get_player_name()
			local privs = priv_cache[name]
			if not privs then
				privs = minetest.get_player_privs(name)
			end

			local player_has_privs = privs.fly
			local player_is_admin = privs.privs

      if singleplayer_priv==false and name=="singleplayer" then
        player_is_admin=false
      end

			-- Find beacons in radius
			green_beacon_near = minetest.find_node_near(pos, 5, {"bloc4builder:flyer"})

			-- Revoke privs if not found
			if player_has_privs and not green_beacon_near and not player_is_admin then
				privs = minetest.get_player_privs(name)
				privs.fly = nil			-- revoke priv
				minetest.set_player_privs(name, privs)
				minetest.chat_send_player(name, "Far from the HUB, you lost the ability to fly.")
			end
			
			-- Grant privs if found
			if green_beacon_near and not player_has_privs and not player_is_admin then 
				privs = minetest.get_player_privs(name)
				privs.fly = true
				minetest.set_player_privs(name, privs)
				minetest.chat_send_player(name, "Proximity of a HUB grant you the ability you to fly.")
			end

			priv_cache[name] = privs
		
		end
	end
end)
