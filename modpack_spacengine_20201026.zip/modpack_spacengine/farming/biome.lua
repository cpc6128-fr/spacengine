--TODO culture dans le vaisseaux
farming.biome_check=function(ppos)
local biome="T"

  if ppos.y<-32 then
    biome="u"

  elseif ppos.y<1008 then
    biome="x"

  elseif ppos.y>1007 and ppos.y<10208 then
    local matricex=math.floor((ppos.x+30752)/80)
    local matricey=math.floor((ppos.y-1008)/80)
    local matricez=math.floor((ppos.z+30752)/80)
    local secteurpos={x=math.floor(matricex/8),y=math.floor(matricey/8),z=math.floor(matricez/8)}
    secteurpos.nb=secteurpos.x + ( secteurpos.y * 9216 ) + ( secteurpos.z * 96 )
    secteurpos.seed=secteurpos.nb % 501

    local bloc={x=matricex % 8 , y=matricey % 8 , z=matricez % 8 } 
    local nb=bloc.x+(bloc.y*64)+(bloc.z*8)
    nb=nb+secteurpos.seed

    if nb>511 then nb=nb-512 end
    --changement de bloc ou secteur ?

    biome="e"--espace
    tmp=secteur_dat[nb+1]

    if tmp==9 or tmp==19 then --relache
      biome="n"
    elseif tmp==4 then --4=earth
      biome="t"
    elseif tmp==2 then --2=solar
      biome="S"
    elseif tmp==1 then --1=astroport
      biome="n"
    end

    --recherche area
    local found,cpos,ship_name=spacengine.test_area_ship(ppos,0)
    if found then
      if spacengine.area[ship_name].config[5][2]>0 then biome="n" end
    end

  elseif ppos.y>10207 then
    --calcul layer multimap 
    local layer=math.floor((ppos.y-10208)/640)+1
    --local matricex=(ppos.x+30752)/640
    --local matricez=(ppos.z+30752)/640

    local nb_layer=#planet_layer

    if layer>nb_layer then layer=nb_layer end  --en cas d'erreur de depassement
      biome=planet_layer[layer].biome
  end

local temp,new_weather=espace.biome(biome,ppos)

return temp,new_weather
end
