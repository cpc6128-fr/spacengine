--date de creation + delay
espace.set_dat=function(delaymin,delaymax,form)
  local phr=""
  if delaymax==nil then
    delaymax=delaymin
    delaymin=1
  end
  local creat_dat=(espace.year*168)+((espace.month-1)*14)+(espace.day-1)+math.random(delaymin,delaymax)
  if form~=nil then
    local year=creat_dat/168
    local month=(year-math.floor(year))*12
    local day=(month-math.floor(month))*14
    year=math.floor(year)
    month=math.floor(month)+1
    day=math.floor(day)+1
    phr=string.sub(tonumber(year+1000000),2) .."/".. string.sub(tonumber(month+100),2) .."/".. string.sub(tonumber(day+100),2)
  end
  return creat_dat,phr
end

espace.get_dat=function(dte,form)
  local year,month,day
  if form~=nil then
    local tmp=string.split(dte,"/")
    year=tonumber(tmp[1])
    month=tonumber(tmp[2])
    day=tonumber(tmp[3])
  else
    year=dte/168
    month=(year-math.floor(year))*12
    day=(month-math.floor(month))*14
    year=math.floor(year)
    month=math.floor(month)+1
    day=math.floor(day)+1
  end
  return year,month,day
end

--TODO virer ça
espace.postostring=function(pos)
  local tmp=tostring(math.floor(pos.x)+131000)
  local position=string.sub(tmp,2)
  tmp=tostring(math.floor(pos.y)+131000)
  position=position.."/"..string.sub(tmp,2)
  tmp=tostring(math.floor(pos.z)+131000)
  position=position.."/"..string.sub(tmp,2)
  return position
end

--position du magasin extraction
espace.postonumber=function(position)
  local pos={x=0,y=0,z=0}
  local list=string.split(position,"/")
  pos.x=tonumber(list[1])-31000
  pos.y=tonumber(list[2])-31000
  pos.z=tonumber(list[3])-31000
  return pos
end

--*************************************
--** protection compatible protector **
--*************************************
local mod_protector=minetest.get_modpath("protector")

espace.bloc_is_protect=function(pos,player,radius)

  if player and espace.is_jail(player) then return true end

  if not mod_protector or radius then
    if radius==nil then radius=5 end
    local protect_list = minetest.find_nodes_in_area(
      {x = pos.x - radius, y = pos.y - radius, z = pos.z - radius},
      {x = pos.x + radius, y = pos.y + radius, z = pos.z + radius},
      {"protector:protect", "protector:protect2"})

    if #protect_list>0 then
      return true
    end
  end

  if pos.y<1008 then

    --spawn earth protect
    if (pos.y>127 and pos.y<209) and (pos.x>-20 and pos.x<20) and (pos.z>-20 and pos.z<20) then
      return true
    end

  elseif pos.y>1007 and pos.y<10208 then
    --recherche area spacengine
    local found,cpos,ship_name=spacengine.test_area_ship(pos,0)
    --recuperation spacengine crew
    local owner=0
    if found and player then
      owner=spacengine.owner_check(player,cpos)
      if owner<2 then return true end
    end
    --teste player bloc_protect
    local secteur,bloc=espace.secteur(pos)
    
    if bloc.nb==45 then return true end

    local p=false
    if bloc.nb==283 then p=true end
    
    if player then
      local dataplayer=espace.data[player:get_player_name()]
    
      if dataplayer.priv~=nil then  --privilege pour l'astroport
        for i=1,#dataplayer.priv do
          
          if dataplayer.priv[i]==secteur.nb then
            p=false
            break
          end
          
        end
      end
    end

    if p==true then return true end

  elseif pos.y>10207 then

    --protect spawn planete
    if (pos.x>-20 and pos.x<20) and (pos.z>-20 and pos.z<20) then
      local layer=math.floor((pos.y-10208)/640)+1 --calcul layer multimap
      local calcul=10450+((layer-1)*640)+math.abs(planet_layer[layer]["water"])
      if (pos.y>(calcul-5) and pos.y<(calcul+15)) then
        return true
      end
    end
  end

return false
end

--** obtenir le secteur et le bloc par la position **
espace.secteur=function(pos)
  local matricex=math.floor((pos.x+30752)/80)
  local matricey=math.floor((pos.y-1008)/80)
  local matricez=math.floor((pos.z+30752)/80)

  local secteur={x=math.floor(matricex/8),y=math.floor(matricey/8),z=math.floor(matricez/8)}
  secteur.nb=secteur.x+(secteur.y*9216)+(secteur.z*96)
  secteur.seed=secteur.nb % 501

  local bloc={x=matricex % 8 , y=matricey % 8 , z=matricez % 8 } 
  local nb=bloc.x+(bloc.y*64)+(bloc.z*8)
  nb=nb+secteur.seed

  if nb>511 then nb=nb-512 end

  bloc.nb=nb
  --recherhe nom secteur
  local tmp=secteur.nb+1
  for i=1,#galaxie_map do
    if tmp==galaxie_map[i][2] then
      secteur.name=galaxie_map[i][1]
      break
    end
  end

return secteur,bloc
end

--** obtenir le secteur par la matrice **
espace.secteur_by_matrice=function(matrice)
  matrice.x=math.min(96,matrice.x)
  matrice.z=math.min(96,matrice.z)
  matrice.y=math.min(14,matrice.y)
  matrice.x=math.max(0,matrice.x)
  matrice.z=math.max(0,matrice.z)
  matrice.y=math.max(0,matrice.y)

  local secteur={x=matrice.x,y=matrice.y,z=matrice.z}
  secteur.nb=matrice.x+(matrice.y*9216)+(matrice.z*96)
  secteur.seed=secteur.nb % 501
 --recherhe nom secteur
  local tmp=secteur.nb+1
  for i=1,#galaxie_map do
    if tmp==galaxie_map[i][2] then
      secteur.name=galaxie_map[i][1]
      break
    end
  end
  return secteur
end

--** obtenir les position de l'astroport, stargate, jail, planete du secteur **
espace.info_secteur=function(secteurnb,bloc) --get_info_secteur
  local matricey=secteurnb/9216+0.00001
  local matricez=(matricey-math.floor(matricey))*96+0.00001
  local matricex=(matricez-math.floor(matricez))*96+0.00001
  local secteur={nb=secteurnb,x=math.floor(matricex),y=math.floor(matricey),z=math.floor(matricez),seed=secteurnb % 501}

  local tmp=secteur.nb+1
  for i=1,#galaxie_map do
    if tmp==galaxie_map[i][2] then
      secteur.name=galaxie_map[i][1]
      break
    end
  end

  local astroport,stargate,jail=espace.astroport(secteur)

  local planete=espace.planete(secteur)

  if bloc~=nil then
    local ay=bloc/64
    local az=(ay-math.floor(ay))*8
    local ax=(az-math.floor(az))*8

    secteur.y=((math.floor(ay)*80)+(secteur.y*640))+1048
    secteur.z=((math.floor(az)*80)+(secteur.z*640))-30712
    secteur.x=((math.floor(ax)*80)+(secteur.x*640))-30712
  end

return secteur,astroport,stargate,jail,planete
end

--** position planete du secteur **
espace.planete=function(secteur) --get_planet by secteur
local planete={nb=0,alt=1,name="-"}
local sectmp=secteur.nb+1
  if sectmp>9999 and sectmp<124236 then
    local layer=math.floor((sectmp-10000)/3685)
    if ((sectmp-10000)%3685)==0 then
      if layer==0 then
        planete={nb=0,alt=132,name="earth"}
      else
        if layer>(#planet_layer) then  --protection si depassement nb layer en data
          planete={nb=0,alt=1 , name="-"}
        else
          planete={nb=layer,alt=(10451+((layer-1)*640))+math.abs(planet_layer[layer].water) , name=planet_layer[layer].name}
        end
      end
    end
  end
return planete
end

--** position astroport du secteur **
espace.astroport=function(secteur) --get_astroport
  local nb=283-secteur.seed
  
  if nb<0 then nb=nb+512 end  --si depassement

  local ay=nb/64
  local az=(ay-math.floor(ay))*8
  local ax=(az-math.floor(az))*8

  ay=((math.floor(ay)*80)+(secteur.y*640))+1048
  az=((math.floor(az)*80)+(secteur.z*640))-30712
  ax=((math.floor(ax)*80)+(secteur.x*640))-30712
  local astroport={nb=nb,x=ax,y=ay,z=az}
  local stargate={x=ax,y=ay-28,z=az-20}

  nb=45-secteur.seed
  
  if nb<0 then nb=nb+512 end  --si depassement

  ay=nb/64
  az=(ay-math.floor(ay))*8
  ax=(az-math.floor(az))*8

  ay=((math.floor(ay)*80)+(secteur.y*640))+1050
  az=((math.floor(az)*80)+(secteur.z*640))-30712
  ax=((math.floor(ax)*80)+(secteur.x*640))-30712
  local jail={nb=nb,x=ax,y=ay,z=az}

return astroport,stargate,jail
end

--** obtenir la position d'une planete par son nom **
espace.planete_by_name=function(planete_name)
  local nb_layer=#planet_layer
  if planete_name=="earth" then
    planete={nb=0,alt=1,name="earth"}
    secteur=10000
  else 
    for i=1,nb_layer do
      if planete_name==planet_layer[i].name then
        local calcul=10450+((i-1)*640)+math.abs(planet_layer[i]["water"])
        planete={nb=i,alt=calcul,name=planete_name}
        secteur=10000+(i*3685)
      end
    end
  end

  local matricey=secteur/9216+0.00001
  local matricez=(matricey-math.floor(matricey))*96+0.00001
  local matricex=(matricez-math.floor(matricez))*96+0.00001
  local secteurpos={nb=secteur,x=math.floor(matricex),y=math.floor(matricey),z=math.floor(matricez),seed=secteur % 512}

  local astroport,stargate,jail=espace.astroport(secteurpos)
  
  return planete,astroport,stargate,jail
end

--*****************************
--** test si peine de prison **
--*****************************
espace.is_jail=function(player)
  local jail
  local new_dat=((espace.year-1)*168)+((espace.month-1)*14)+espace.day
  if player:get_attribute("jail")==nil then return false end

--    player:set_attribute("jail","none")
--    jail="none"
--  else
    jail=player:get_attribute("jail")
--  end
  if string.find(jail,"out")==nil then
    if tonumber(jail)<new_dat then
      --sortie de prison
      jail="out"
      player:set_attribute("jail","out")
      return false,jail
    else
      return true,jail
    end 
  end

return false,jail
end

--** priv astroport **
espace.setpriv=function(plname)

  if espace.data[plname].priv==nil then return end

  local data=espace.data[plname].priv
  local phr=""

  for i=1,#data do
    phr=phr..data[i]
    if i<#data then phr=phr..":" end
  end

  local player=minetest.get_player_by_name(plname)
  player:set_attribute("priv_astroport",phr)

end

espace.getpriv=function(plname)
  local player=minetest.get_player_by_name(plname)
  local phr=player:get_attribute("priv_astroport")

  if phr==nil then return end

  local data=espace.split_string(phr,"%d+")
  espace.data[plname].priv=data
end

-- police choix amende ou prison, durée de la peine
function police_arrest(player,plpos)
  local secteur=espace.secteur(plpos)
  local _,_,jail=espace.astroport(secteur)
  --local xp=xpgetlvl(player,"xp_lvl")+1
  local price=math.random(5000,15000)--*((25+(xp*4))/100)
  local nb_day=math.random(1,3)
  local inv = player:get_inventory()
  local havecard=commerce.found_item_index(player,"commerce:card")
  local name=player:get_player_name()
  local err=0
  minetest.sound_play("police",{to_player=name,gain=1})
  -- gui accept or refuse ?
return minetest.show_formspec(player:get_player_name(), "police:".. espace.postostring(jail) ..":"..nb_day..":"..price , "size[8,9]background[0,0;1,1;police.png;true]"..
        "label[1,0;Vous exploitez un secteur sans autorisation]"..
        "label[1,1;allez en prison ou payez l'amende]"..
        "button_exit[0,4;2,1;prison;".. nb_day .." jour]"..
        "button_exit[4,4;1,1;amende;"..price.."]")

end

minetest.register_on_player_receive_fields(function(player, formname, fields)

  if string.find(formname,"police")==nil then
    return
  end

  local tmp_split=string.split(formname,":")
  local err=0
  local inv = player:get_inventory()
  local havecard=commerce.found_item_index(player,"commerce:card")
  local name=player:get_player_name()

  if fields.amende~=nil then
    if havecard>0 then --si card presente
      if atm.balance[name]~= nil then
        if atm.balance[name]-tonumber(tmp_split[4])>0 then
          atm.balance[name] = atm.balance[name]-tonumber(tmp_split[4])
          inv:add_item("main",stack)
          atm.saveaccounts()
          err=1
          return
        end
      end
    end
  end

  if err==0 then
    local jail_pos=espace.postonumber(tmp_split[2])
    local new_dat=((espace.year-1)*168)+((espace.month-1)*14)+espace.day+tonumber(tmp_split[3])
    player:set_attribute("jail",tostring(new_dat))
    player:set_pos(jail_pos)
  end

end)

--** grow sapling **
function espace.grow_tree(pos,tree)
  minetest.set_node(pos,{name = 'air'})
	local path = minetest.get_modpath("espace") ..
		"/schematics/"..tree..".mts"
	minetest.place_schematic({x = pos.x - 2, y = pos.y-(math.random(1,3)-1), z = pos.z - 2},
		path, "random", nil, false)
end

-- ++++++++++++++++++++++++++++++++++++++++++++++++++
-- ++ fonction pour determiner si dehors ou dedans ++
-- ++++++++++++++++++++++++++++++++++++++++++++++++++
--
espace.is_inside=function(pos)
  --[[en journée test la lumière
  local day=minetest.env:get_timeofday()*24
  if day>6 and day<18 then
    if minetest.get_node_light({x=pos.x,y=pos.y+1,z=pos.z},0.5) ~= 15 then
      return true
    end
  end--]]

  --autrement test la hauteur d'air
	local inside=false
	local temp_node = minetest.get_node_or_nil({x=pos.x,y=pos.y+1,z=pos.z})

	for i = 2,10 do
		if temp_node ~= nil and temp_node.name ~= "air" then
      inside=true
      break
		end
		temp_node = minetest.get_node_or_nil({x=pos.x,y=pos.y+i,z=pos.z})
	end
	return inside
end


local old_is_protected = minetest.is_protected

-- check for protected area, return true if protected and digger isn't on list
function minetest.is_protected(pos, playername)

  if playername==nil then playername="" end

  if (creative and creative.is_enabled_for and creative.is_enabled_for(playername)) then return old_is_protected(pos, playername) end

  if playername=="" then
    if espace.bloc_is_protect(pos,nil) then return true end
  else
    local player = minetest.get_player_by_name(playername)
    if espace.bloc_is_protect(pos,player) then return true end
  end

return old_is_protected(pos, playername)
end

--**************
--** XP LEVEL **
--**************

local alarm = function(xpname,xplvl,xpnxtstage,player)
	minetest.sound_play({name="ohyeah", gain=0.25}, {to_player=player:get_player_name()})

	local one = player:hud_add({
		hud_elem_type = "image",
		name = "background",
		scale = {x = 1, y = 1},
		text = "espace_xp_up.png",
		position = {x = 0.5, y = 0.5},
		offset = {x = 16, y = 0},
		alignment = {x = 0, y = 0}
	})

	local two = player:hud_add({
		hud_elem_type = "text",
		name = "titre",
		number = 0xFFFFFF,
		scale = {x = 100, y = 20},
		text = "Level-up!",
		position = {x = 0.5, y = 0.5},
		offset = {x = -64, y = -40},
		alignment = {x = 0, y = 0}
	})

	local three = player:hud_add({
		hud_elem_type = "text",
		name = "xp",
		number = 0xFFFFFF,
		scale = {x = 100, y = 30},
		text = xpname,
		position = {x = 0.5, y = 0.5},
		offset = {x = -64, y = -16},
		alignment = {x = 0, y = 0}
	})

	local four = player:hud_add({
		hud_elem_type = "text",
		name = "rank_level",
		number = 0xFF7F7F,
		scale = {x = 100, y = 20},
		text = xplvl,
		position = {x = 0.5, y = 0.5},
		offset = {x = -64, y = 0},
		alignment = {x = 0, y = 0}
	})
    
  local tmp="Next Level : ".. xpnxtstage
  local five = player:hud_add({
		hud_elem_type = "text",
		name = "next_stage",
		number = 0xFFFFFF,
		scale = {x = 100, y = 100},
		text = tmp,
		position = {x = 0.5, y = 0.5},
		offset = {x = -64, y = 32},
		alignment = {x = 0, y = 0}
	})

	minetest.after(6, function()
		player:hud_remove(one)
		player:hud_remove(two)
		player:hud_remove(three)
		player:hud_remove(four)
    player:hud_remove(five)
	end)
end

local xpdisplay = function(xpname,xplvl,xpnxtstage,player)
  local playername = player:get_player_name()
    
  local tmp=xpname.." : "..xplvl
  player:hud_change(espace.data[playername].hud.xplvl,"text",tmp)
    
  tmp="Next Level : ".. xpnxtstage
  player:hud_change(espace.data[playername].hud.stage,"text",tmp)

end

espace.xplevel=function(nb,player,xpname)
  local plname=player:get_player_name()

  if (creative and creative.is_enabled_for and creative.is_enabled_for(plname)) then return end

  local xpattribut = player:get_attribute(xpname)
  --recuperation next stage et level
  local tmp=string.split(xpattribut,"/")
  if tmp[1]==nil or tmp[2]==nil then return end
  --decrement next stage
  local xplvl=tonumber(tmp[1])
  local xpnxtstage=tonumber(tmp[2])-nb

  if xpnxtstage<1 then 
    --si next stage atteind incremente level experience
    xplvl=math.min(100,xplvl+1)
    xpnxtstage=xplvl*xplvl*20
    xpattribut=xplvl .."/".. xpnxtstage
    player:set_attribute(xpname, xpattribut)
    --alarm level up
    alarm(xpname,xplvl,xpnxtstage,player)
        
  else
    xpattribut=xplvl .."/".. xpnxtstage
    player:set_attribute(xpname, xpattribut)
  end
    
  xpdisplay(xpname,xplvl,xpnxtstage,player)     
end

espace.xpgetlvl=function(player,xpname)
    local xptemp = player:get_attribute(xpname)
    --recuperation next stage et level
    local tmp=string.split(xptemp,"/")
    return tmp[1],tmp[2]
end
