--type / name / price weight / chance / nb item max / found in = (c)hest (m)agasin (d)istributeur (b)ank (t)rader
commerce.item={}

--code from lib_materials
commerce.register_store=function(filename)
  local file = io.open(minetest.get_modpath("commerce").."/"..filename..".csv", "r")
	
	for line in file:lines() do
		if line:sub(1,1) ~= "#" and line:find("[^%,% ]") then
      local debug=line:split(",", true)
      local result={}
      for i=1,6 do
        if i==2 or i==6 then
          result[i]=tostring(debug[i])
        else
          result[i]=tonumber(debug[i])
        end
      end
			table.insert(commerce.item, result)
		end
	end

end

commerce.register_store("default")

local scifi=minetest.get_modpath("scifi_nodes")
if scifi then
  commerce.register_store("scifi_nodes")
end

--cgdecor

--homedecor

--3darmor

--bows

--vehicles

--abriglass

--mapopfurniture

--xtraores

--gems

--caverealms

--dfcaverns

--xocean

--fishing

--mobs

--technic

--pipework
