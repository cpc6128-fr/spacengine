--******************************
--** MOD VERGER -> fork FRUIT **
--******************************
minetest.register_node(":verger:leaves_with_pear", {
	description = "Leaves with Pear",
	drawtype = "allfaces",
	tiles = {
		"verger_leaves.png^verger_pear_leaves.png",
	},
	paramtype = "light",
	groups = {snappy = 3, oddly_breakable_by_hand=1, saison=2,not_in_creative_inventory=1},
  drop = {
		max_items = 1,
		items = {
			{items = {"verger:verger_sapling"}, rarity = 20},
			{items = {"verger:leaves"}}
		}
	},
	on_destruct = function(pos)
		minetest.add_item(pos, "verger:pear")
	end,
	sounds = default.node_sound_leaves_defaults()
})

minetest.register_node(":verger:leaves_with_plum", {
	description = "Leaves with Plum",
	drawtype = "allfaces",
	tiles = {
		"verger_leaves.png^verger_plum_leaves.png",
	},
	paramtype = "light",
	groups = {snappy=3, oddly_breakable_by_hand=1, saison=2,not_in_creative_inventory=1},
	drop = {
		max_items = 1,
		items = {
			{items = {"verger:verger_sapling"}, rarity = 20},
			{items = {"verger:leaves"}}
		}
	},
	on_destruct = function(pos)
		minetest.add_item(pos, "verger:plum")
	end,
	sounds = default.node_sound_leaves_defaults()
})

minetest.register_node(":verger:leaves_with_peach", {
	description = "Leaves with Peach",
	drawtype = "allfaces",
	tiles = {
		"verger_leaves.png^verger_peach_leaves.png",
	},
	paramtype = "light",
	groups = {snappy=3, oddly_breakable_by_hand=1, saison=2, not_in_creative_inventory=1},
	drop = {
		max_items = 1,
		items = {
			{items = {"verger:verger_sapling"}, rarity = 20},
			{items = {"verger:leaves"}}
		}
	},
	on_destruct = function(pos)
		minetest.add_item(pos, "verger:peach")
	end,
	sounds = default.node_sound_leaves_defaults()
})

minetest.register_node(":verger:leaves_with_orange", {
	description = "Leaves with Orange",
	drawtype = "allfaces",
	tiles = {
		"verger_leaves.png^verger_orange_leaves.png",
	},
	paramtype = "light",
	groups = {snappy=3, oddly_breakable_by_hand=1, saison=2,not_in_creative_inventory=1},
	drop = {
		max_items = 1,
		items = {
			{items = {"verger:verger_sapling"}, rarity = 20},
			{items = {"verger:leaves"}}
		}
	},
	on_destruct = function(pos)
		minetest.add_item(pos, "verger:orange")
	end,
	sounds = default.node_sound_leaves_defaults()
})

minetest.register_craftitem(":verger:pear", {
	description = "Pear",
	inventory_image = "verger_pear.png",
	on_use = minetest.item_eat(2)
})

minetest.register_craftitem(":verger:plum", {
	description = "Plum",
	inventory_image = "verger_plum.png",
	on_use = minetest.item_eat(2)
})

minetest.register_craftitem(":verger:peach", {
	description = "Peach",
	inventory_image = "verger_peach.png",
	on_use = minetest.item_eat(2)
})

minetest.register_craftitem(":verger:orange", {
	description = "Orange",
	inventory_image = "verger_orange.png",
	on_use = minetest.item_eat(2)
})

minetest.register_node(":verger:verger_tree", {
	description = "Fruit Tree",
	tiles = {"verger_tree_top.png", "verger_tree_top.png",
		"verger_tree.png"},
	paramtype2 = "facedir",
	is_ground_content = false,
	groups = {tree = 1, choppy = 3, oddly_breakable_by_hand = 1, flammable = 3},
	sounds = default.node_sound_wood_defaults(),

	on_place = minetest.rotate_node
})

minetest.register_node(":verger:verger_wood", {
	description = "Fruit Wood Planks",
	paramtype2 = "facedir",
	place_param2 = 0,
	tiles = {"verger_wood.png"},
	is_ground_content = false,
	groups = {choppy = 3, oddly_breakable_by_hand = 2, flammable = 3, wood = 1},
	sounds = default.node_sound_wood_defaults(),
})

minetest.register_craft({
	output = "verger:verger_wood 4",
	recipe = {
		{"verger:verger_tree"},
}
})

minetest.register_node(":verger:leaves", {
	description = "Fruit Tree Leaves",
	drawtype = "allfaces_optional",
	tiles = {"verger_leaves.png"},
	waving = 1,
	paramtype = "light",
	is_ground_content = false,
	groups = {snappy = 3, leafdecay = 3, flammable = 2, leaves = 1, saison=1},
	drop = {
		max_items = 1,
		items = {
			{items = {"verger:verger_sapling"}, rarity = 20},
			{items = {"verger:leaves"}}
		}
	},
	sounds = default.node_sound_leaves_defaults(),

	after_place_node = default.after_place_leaves,
})
--
--autumn leaves
minetest.register_node(":verger:leaves_autumn", {
	description = "Fruit Tree autumn Leaves",
	drawtype = "allfaces_optional",
	tiles = {"verger_leaves_autumn.png"},
	waving = 1,
	paramtype = "light",
	is_ground_content = false,
	groups = {snappy = 3, leafdecay = 3, flammable = 2, leaves = 1, saison=3},
	drop = {
		max_items = 1,
		items = {
			{items = {"verger:verger_sapling"}, rarity = 20},
			{items = {"verger:leaves_autumn"}}
		}
	},
	sounds = default.node_sound_leaves_defaults(),

	after_place_node = default.after_place_leaves,
})
--stick leaves
minetest.register_node(":verger:leaves_stick", {
	description = "Fruit Tree stick Leaves",
	drawtype = "allfaces_optional",
	tiles = {"default_leaves_stick.png"},
	waving = 1,
	paramtype = "light",
	is_ground_content = false,
	groups = {snappy = 3, leafdecay = 3, flammable = 2, leaves = 1, saison=4},
	drop = {
		max_items = 1,
		items = {
			{items = {"verger:verger_sapling"}, rarity = 20},
			{items = {"default:stick"}}
		}
	},
	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_node(":verger:verger_sapling", {
	description = "Fruit Tree Sapling",
	drawtype = "plantlike",
	tiles = {"verger_sapling.png"},
	inventory_image = "verger_sapling.png",
	wield_image = "verger_sapling.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	on_timer = function(pos)
    espace.grow_tree(pos,"verger_tree")
  end,
	selection_box = {
		type = "fixed",
		fixed = {-3 / 16, -0.5, -3 / 16, 3 / 16, 0.5, 3 / 16}
	},
	groups = {snappy = 2, dig_immediate = 3, flammable = 3,
		attached_node = 1, sapling = 1},
	sounds = default.node_sound_leaves_defaults(),

	on_construct = function(pos)
		minetest.get_node_timer(pos):start(math.random(300, 1200))
	end,

	on_place = function(itemstack, placer, pointed_thing)
		itemstack = default.sapling_on_place(itemstack, placer, pointed_thing,
			"verger:verger_sapling",
			{x = -2, y = 1, z = -2},
			{x = 2, y = 12, z = 2},
			4)

		return itemstack
	end,
})

minetest.register_node(":verger:leaves_flowers2", {
	description = "tree flowers2",
	drawtype = "allfaces_optional",
	tiles = {"verger_leaves.png^verger_flowers_2.png"},
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	is_ground_content = false,
	groups = {fleshy = 3, dig_immediate = 3, flammable = 2, leaves = 1, saison=2, not_in_creative_inventory = 1},
    drop="verger:leaves",
	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_node(":verger:leaves_flowers3", {
	description = "tree flowers3",
	drawtype = "allfaces_optional",
	tiles = {"verger_leaves.png^verger_flowers_3.png"},
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	is_ground_content = false,
	groups = {fleshy = 3, dig_immediate = 3, flammable = 2, leaves = 1, saison=2, not_in_creative_inventory = 1},
    drop="verger:leaves",
	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_node(":verger:leaves_flowers4", {
	description = "tree flowers1",
	drawtype = "allfaces_optional",
	tiles = {"verger_leaves.png^verger_flowers_4.png"},
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	is_ground_content = false,
	groups = {fleshy = 3, dig_immediate = 3, flammable = 2, leaves = 1, saison=2, not_in_creative_inventory = 1},
    drop="verger:leaves",
	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_node(":verger:leaves_flowers5", {
	description = "tree flowers1",
	drawtype = "allfaces_optional",
	tiles = {"verger_leaves.png^verger_flowers_5.png"},
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	is_ground_content = false,
	groups = {fleshy = 3, dig_immediate = 3, flammable = 2, leaves = 1, saison=2, not_in_creative_inventory = 1},
    drop="verger:leaves",
	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_abm({
	nodenames = {'verger:leaves'},
	interval = 400,
	chance = 50,

	action = function (pos)

  if pos.y >-25 and pos.y <1008 then return end
  if pos.y >10208 and pos.y <10848 then return end


  local n = math.random(1,4)
   
  --arbre fruitier reperer quel fruit pour ne pas melanger

  --peche
  if n==1 then
    --local a = minetest.find_node_near(pos, 3, 'verger:leaves_with_peach')
    local pos1={x=pos.x-4, y=pos.y-4, z=pos.z-4}
    local pos2={x=pos.x+4, y=pos.y+4, z=pos.z+4}
    local b=minetest.find_nodes_in_area(pos1,pos2, {'verger:leaves_with_plum','verger:leaves_with_pear','verger:leaves_with_orange'})
    if #b==0 then
      local b=minetest.find_nodes_in_area(pos1,pos2,{'verger:leaves_with_peach'})
      if #b>4 then return end
      minetest.set_node(pos,{name = 'verger:leaves_with_peach'})
    end
    return
         
  --prune
  elseif n==2 then
    --local a = minetest.find_node_near(pos, 3, 'verger:leaves_with_plum')
    local pos1={x=pos.x-4, y=pos.y-4, z=pos.z-4}
    local pos2={x=pos.x+4, y=pos.y+4, z=pos.z+4}
    local b=minetest.find_nodes_in_area(pos1,pos2,  {'verger:leaves_with_peach','verger:leaves_with_pear','verger:leaves_with_orange'})
    if #b==0 then
      local b=minetest.find_nodes_in_area(pos1,pos2,{'verger:leaves_with_plum'})
      if #b>4 then return end
      minetest.set_node(pos,{name = 'verger:leaves_with_plum'})
    end
    return
        
  --poire
  elseif n==3 then
    --local a = minetest.find_node_near(pos, 3, 'verger:leaves_with_pear')
    local pos1={x=pos.x-4, y=pos.y-4, z=pos.z-4}
    local pos2={x=pos.x+4, y=pos.y+4, z=pos.z+4}
    local b=minetest.find_nodes_in_area(pos1,pos2,  {'verger:leaves_with_plum','verger:leaves_with_peach','verger:leaves_with_orange'})
    if #b==0 then
      local b=minetest.find_nodes_in_area(pos1,pos2,{'verger:leaves_with_pear'})
      if #b>4 then return end
      minetest.set_node(pos,{name = 'verger:leaves_with_pear'})
    end
    return
        
  --orange
  elseif n==4 then
    --local a = minetest.find_node_near(pos, 3, 'default:apple')
    local pos1={x=pos.x-4, y=pos.y-4, z=pos.z-4}
    local pos2={x=pos.x+4, y=pos.y+4, z=pos.z+4} 
    local b=minetest.find_nodes_in_area(pos1,pos2,  {'verger:leaves_with_plum','verger:leaves_with_pear','verger:leaves_with_peach'})
    if #b==0 then
      local b=minetest.find_nodes_in_area(pos1,pos2,{'verger:leaves_with_orange'})
      if #b>4 then return end
      minetest.set_node(pos,{name = 'verger:leaves_with_orange'})
    end
    return
  end

end})

-- fruit
  minetest.register_decoration({
		name = "verger:verger_tree",
		deco_type = "schematic",
		place_on = {"default:dirt_with_grass"},
		sidelen = 16,
    --fill_ratio=0.001,
    noise_params = {
			offset = 0.0015,
			scale = 0.003,
			spread = {x = 250, y = 250, z = 250},
			seed = 2,
			octaves = 3,
			persist = 0.66
		},
		biomes = {"grassland","grassland_ocean","deciduous_forest"},
		y_max = 1000,
		y_min = 1,
		schematic = minetest.get_modpath("espace") .. "/schematics/verger_tree.mts",
		flags = "place_center_x, place_center_z",
		rotation = "random",
	})
