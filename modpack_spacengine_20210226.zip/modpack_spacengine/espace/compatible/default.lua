minetest.override_item("default:lava_source", {
	groups = {lava = 3, liquid = 2, igniter = 1,fire_heat=1}
})

minetest.override_item("default:lava_flowing", {
	groups = {lava = 3, liquid = 2, igniter = 1,fire_heat=1}
})

minetest.override_item("default:ice", {
	groups = {cracky = 3, cools_lava = 1, slippery = 3, freezer=1}
})

minetest.override_item("fire:permanent_flame", {
groups = {igniter = 2, dig_immediate = 3,fire_heat=1}
})

minetest.override_item("fire:basic_flame", {
groups = {igniter = 2, dig_immediate = 3, not_in_creative_inventory = 1,fire_heat=1}
})

minetest.override_item("default:snow", {
groups = {crumbly = 3, falling_node = 1, snowy = 1,freezer=1}
})

minetest.override_item("default:snowblock", {
groups = {crumbly = 3, cools_lava = 1, snowy = 1,freezer=1}
})

minetest.override_item("default:furnace_active", {
groups = {cracky=2, not_in_creative_inventory=1,fire_heat=1},
})
-- Iron

minetest.register_ore({
		ore_type       = "scatter",
		ore            = "default:stone_with_iron",
		wherein        = "default:stone",
		clust_scarcity = 12 * 12 * 12,
		clust_num_ores = 6,
		clust_size     = 4,
		y_max          = -8,
		y_min          = -64,
	})

minetest.register_node("espace:small_pinetree_sapling", {
	description = "small Pinetree Sapling",
	drawtype = "plantlike",
	tiles = {"espace_small_pinetree_sapling.png"},
	inventory_image = "espace_small_pinetree_sapling.png",
	wield_image = "espace_small_pinetree_sapling.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	on_timer = function(pos)
    espace.grow_tree(pos,"small_pine_tree")
  end,
	selection_box = {
		type = "fixed",
		fixed = {-4 / 16, -0.5, -4 / 16, 4 / 16, 7 / 16, 4 / 16}
	},
	groups = {snappy = 2, dig_immediate = 3, flammable = 2,
		attached_node = 1, sapling = 1},
	sounds = default.node_sound_leaves_defaults(),

	on_construct = function(pos)
		minetest.get_node_timer(pos):start(math.random(250,500))
	end,
})

minetest.register_node("espace:snowy_pinetree_sapling", {
	description = "snowy Pinetree Sapling",
	drawtype = "plantlike",
	tiles = {"espace_snowy_pinetree_sapling.png"},
	inventory_image = "espace_snowy_pinetree_sapling.png",
	wield_image = "espace_snowy_pinetree_sapling.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	on_timer = function(pos)
    espace.grow_tree(pos,"snowy_pine_tree_from_sapling")
  end,
	selection_box = {
		type = "fixed",
		fixed = {-4 / 16, -0.5, -4 / 16, 4 / 16, 7 / 16, 4 / 16}
	},
	groups = {snappy = 2, dig_immediate = 3, flammable = 2,
		attached_node = 1, sapling = 1},
	sounds = default.node_sound_leaves_defaults(),

	on_construct = function(pos)
		minetest.get_node_timer(pos):start(math.random(250,500))
	end,
})

minetest.register_node("espace:small_snowy_pinetree_sapling", {
	description = "small snowy Pinetree Sapling",
	drawtype = "plantlike",
	tiles = {"espace_small_snowy_pinetree_sapling.png"},
	inventory_image = "espace_small_snowy_pinetree_sapling.png",
	wield_image = "espace_small_snowy_pinetree_sapling.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	on_timer = function(pos)
    espace.grow_tree(pos,"snowy_small_pine_tree_from_sapling")
  end,
	selection_box = {
		type = "fixed",
		fixed = {-4 / 16, -0.5, -4 / 16, 4 / 16, 7 / 16, 4 / 16}
	},
	groups = {snappy = 2, dig_immediate = 3, flammable = 2,
		attached_node = 1, sapling = 1},
	sounds = default.node_sound_leaves_defaults(),

	on_construct = function(pos)
		minetest.get_node_timer(pos):start(math.random(250,500))
	end,
})
--[[
	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "default:stone_with_iron",
		wherein        = "default:stone",
		clust_scarcity = 9 * 9 * 9,
		clust_num_ores = 12,
		clust_size     = 3,
		y_max          = 31000,
		y_min          = 1025,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "default:stone_with_iron",
		wherein        = "default:stone",
		clust_scarcity = 7 * 7 * 7,
		clust_num_ores = 5,
		clust_size     = 3,
		y_max          = 0,
		y_min          = -31000,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "default:stone_with_iron",
		wherein        = "default:stone",
		clust_scarcity = 24 * 24 * 24,
		clust_num_ores = 27,
		clust_size     = 6,
		y_max          = -64,
		y_min          = -31000,
	})
--]]
