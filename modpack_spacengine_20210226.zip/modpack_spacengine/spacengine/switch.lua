--*** button ***

--test tool
local function check_tool(player)
  local tool = player:get_wielded_item():get_name()
  if tool=="spacengine:tool" then return true end
  return false
end

--check si switch dans un vaisseaux
local function check_punch(pos,puncher)

  local check=spacengine.owner_check(puncher,pos)

  if check<2 then return false end

  if check_tool(puncher) then return false end

  local nod_met = minetest.get_meta(pos)
  local channel=nod_met:get_string("channel")
  local cha_spl=string.split(channel,":")

  if spacengine.test_area_ship(pos,0,cha_spl[1]..":"..cha_spl[2]) then return true end

  return false
end


spacengine.switch_setup=function(pos,switch)
  local nod_met = minetest.get_meta(pos)
  nod_met:set_string("channel","No channel:noplayer")
  local group=string.find("bia",switch)+13
  nod_met:set_string("spacengine","^".. switch .."¨0¨0¨^".. switch .. spacengine.upgrade[group][1][1] .."0¨1¨^")
  nod_met:set_string("pos_cont","33333¨0¨0")
  nod_met:set_string("infotext",spacengine.upgrade[group][1][2])
end

spacengine.switch_gui=function(pos,player)
  local check=spacengine.owner_check(player,pos)
  if check<2 then return false end

  local nod_met = minetest.get_meta(pos)
  --channel : owner
  local channel=nod_met:get_string("channel")
  local split=string.split(channel,":")
  local owner=split[2]
  channel=split[1]
  local spac_eng=spacengine.decompact(nod_met:get_string("spacengine"))

  if not check_tool(player) then
    --mise a jour switch analog
    local pos_cont=spacengine.decompact(nod_met:get_string("pos_cont"))

    --recuperation position relative ou reel du controler
    local err=false
    local cpos={x=pos_cont[1],y=pos_cont[2],z=pos_cont[3]} --position reel
    local cont_met
    local config

    if channel=="No channel" or cpos.x==33333 then return false end

    --position relative du controler
    cpos.x=pos.x-cpos.x
    cpos.y=pos.y-cpos.y
    cpos.z=pos.z-cpos.z
    cont_met=minetest.get_meta(cpos)

    channel=channel..":"..owner

    if spacengine.test_area_ship(cpos,0,channel)==false then return false end
    
    local config=spacengine.area[channel].config --spacengine.config[channel]
    local switch=string.sub(spac_eng[4],1,1)

    if switch=="b" or switch=="i" then return end
    
    local new_value=spacengine.punch_module(cpos,cont_met,config,spac_eng,channel,14,player,0)

    new_value=math.floor(new_value/20)
    local node=minetest.get_node(pos)
    local l_name=string.len(node.name)-1
    local new_name=string.sub(node.name,1,l_name)..new_value

    minetest.swap_node(pos, {name=new_name,param2=node.param2})

  else
  
  local formspec="size[10,10]button_exit[0,8.25;2,1;submit;exit]" ..
    "field[0.25,0;3,1;channel;;"..channel.."]"..
    "field[0.25,3;4,1;code;code;"..spac_eng[6].."]"..
    "label[0,1;Owner : "..owner.."]textlist[3.5,6.25;5.8,1.3;command;"
  local group=string.find("bia",spac_eng[1])+13

  for i=1,#spacengine.upgrade[group] do
    if string.sub(spac_eng[4],2,2)==spacengine.upgrade[group][i][1] then
      formspec=formspec.. "X "..spacengine.upgrade[group][i][2]
    else
      formspec=formspec.. "- "..spacengine.upgrade[group][i][2]
    end
    if i<#spacengine.upgrade[group] then
      formspec=formspec..","
    end
  end

  formspec=formspec..";1]"

  local info=nod_met:get_string("infotext")
  if string.find(info,"=") then
    formspec=formspec.."label[0.25,4.25;Show code]image_button[2,4;1,1;spacengine_croix.png;disable;]"
  else
    formspec=formspec.."label[0.25,4.25;Show code]image_button[2,4;1,1;spacengine_rien.png;enable;]"
  end
  
  minetest.show_formspec(player:get_player_name(), "spacebutton#".. spacengine.pts(pos) .."#"..spac_eng[6] , formspec)
  end

end

minetest.register_on_player_receive_fields(function(player, formname, fields)

  if string.find(formname,"spacebutton")==nil then
    return
  end

  local pl_name=player:get_player_name()
  local newform=false
--recupere coordo du node, channel et group
  local form_spl=string.split(formname,"#")
  local npos=spacengine.ptn(form_spl[2])
  local nod_met = minetest.get_meta(npos)
  local channel=nod_met:get_string("channel")
  local node=minetest.get_node(npos)

  local pos_cont=spacengine.decompact(nod_met:get_string("pos_cont"))
  local spac_eng=spacengine.decompact(nod_met:get_string("spacengine"))
  local cpos={x=npos.x-pos_cont[1], y=npos.y-pos_cont[2], z=npos.z-pos_cont[3]}

  if fields.enable then
    local info=nod_met:get_string("infotext")
    nod_met:set_string("infotext", info.."="..spac_eng[6] )
    newform=true
  end

  if fields.disable then
    local info=nod_met:get_string("infotext")
    local spl=string.split(info,"=")
    nod_met:set_string("infotext", spl[1] )
    newform=true
  end

  if fields.submit or fields.key_enter_field then
    local split=string.split(channel,":")

    if fields.channel=="" then fields.channel="No channel" end

    nod_met:set_string("channel",fields.channel ..":".. split[2]) --change le channel du node
    nod_met:set_string("pos_cont","33333¨0¨0")
    spac_eng[6]=fields.code
    nod_met:set_string("spacengine",spacengine.compact(spac_eng))
    channel=fields.channel ..":".. split[2]
    local info=nod_met:get_string("infotext")
    if string.find(info,"=") then
      local spl=string.split(info,"=")
      nod_met:set_string("infotext", spl[1] .."="..spac_eng[6] )
    end
    

    --

    if fields.channel~="No channel" then
      local trouver,cpos,crew=spacengine.search_controler(npos,pl_name,channel,range)
      if trouver==true then
        spacengine.maj_pos_node(npos,pl_name,channel,cpos,crew)
      end
    end

  end

  local field_name,field_dat="-","-"
  for k, v in pairs(fields) do
    if string.find(k,"command") then
    field_name = tostring(k)
    field_dat = v
    end
  end

  if string.find(field_name,"command") then
    local field_spl=string.split(field_dat,":")

    if string.find(field_spl[1],"DCL") then
      local tmp=string.split(field_name,"#")
      local tmp1=tonumber(field_spl[2])
      local group=string.find("bia",spac_eng[1])+13
      spac_eng[4]=spac_eng[1] .. spacengine.upgrade[group][tmp1][1] .."0"
      spac_eng[5]=1
      nod_met:set_string("infotext",spacengine.upgrade[group][tmp1][2])
      nod_met:set_string("spacengine",spacengine.compact(spac_eng))
      local trouver,cpos,crew=spacengine.search_controler(npos,pl_name,channel)
      if trouver==true then
        spacengine.maj_pos_node(npos,pl_name,channel,cpos,crew)
      end
      newform=true
    end
  end
  if newform then
    return spacengine.switch_gui(npos,player)
  end
end)

--*** switch Bouton poussoir ***
minetest.register_node("spacengine:switch_bp", {
  description = "switch bp",
  inventory_image = "spacengine_switch_bp.png",
  tiles = {"spacengine_switch_bp.png"},
  drawtype = "nodebox",
  node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, 0.495, 0.5, 0.5, 0.5},
		},
    },
  paramtype = "light",
  paramtype2 = "facedir",
  sunlight_propagates = true,
  groups = {cracky=333,spacengine=20,not_in_creative_inventory = spacengine.creative_enable},
  sounds = default.node_sound_stone_defaults(),
  on_construct=function(pos)
    spacengine.switch_setup(pos,"b")
  end,
  after_place_node=function(pos,placer)
    spacengine.placer_node(pos,placer)
  end,
  on_rightclick = function(pos, node, player)
    spacengine.switch_gui(pos,player)
	end,
  on_punch = function(pos, node, puncher)
    if not check_punch(pos,puncher) then return end
    spacengine.formspec_update(pos,puncher,"sw#1#>",spacengine.owner_check(puncher,pos),1)
  end
})

--*** switch Bouton emergency ***
minetest.register_node("spacengine:switch_emergency", {
  description = "switch emergency",
  inventory_image = "spacengine_switch_emergency.png",
  tiles = {"spacengine_switch_emergency.png"},
  drawtype = "nodebox",
  node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, 0.495, 0.5, 0.5, 0.5},
		},
    },
  paramtype = "light",
  paramtype2 = "facedir",
  sunlight_propagates = true,
  groups = {cracky=333,spacengine=20,not_in_creative_inventory = spacengine.creative_enable},
  sounds = default.node_sound_stone_defaults(),
  on_construct=function(pos)
    spacengine.switch_setup(pos,"b")
  end,
  after_place_node=function(pos,placer)
    spacengine.placer_node(pos,placer)
  end,
  on_rightclick = function(pos, node, player)
    spacengine.switch_gui(pos,player)
	end,
  on_punch = function(pos, node, puncher)
    if not check_punch(pos,puncher) then return end
    spacengine.formspec_update(pos,puncher,"sw#1#>",spacengine.owner_check(puncher,pos),1)
  end
})

--*** switch Gouvernail ***
minetest.register_node("spacengine:gouvernail", {
  description = "gouvernail",
  inventory_image = "spacengine_gouvernail.png",
  tiles = {"spacengine_gouvernail.png"},
  drawtype = "nodebox",
  node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, 0.495, 0.5, 0.5, 0.5},
		},
    },
  paramtype = "light",
  paramtype2 = "facedir",
  sunlight_propagates = true,
  groups = {cracky=333,spacengine=20,not_in_creative_inventory = spacengine.creative_enable},
  sounds = default.node_sound_stone_defaults(),
  on_construct=function(pos)
    spacengine.switch_setup(pos,"b")
  end,
  after_place_node=function(pos,placer)
    spacengine.placer_node(pos,placer)
  end,
  on_rightclick = function(pos, node, player)
    spacengine.switch_gui(pos,player)
	end,
  on_punch = function(pos, node, puncher)
    if check_punch(pos,puncher)<2 then return end
    spacengine.formspec_update(pos,puncher,"sw#1#>",spacengine.owner_check(puncher,pos),1)
  end
})

--*** inter on/off ***
minetest.register_node("spacengine:inter_0", {
  description = "interrupteur",
  inventory_image = "spacengine_inter0.png",
  tiles = {"spacengine_inter0.png"},
  drawtype = "nodebox",
  node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, 0.495, 0.5, 0.5, 0.5},
		},
    },
  paramtype = "light",
  paramtype2 = "facedir",

  sunlight_propagates = true,
  groups = {cracky=333,spacengine=20,not_in_creative_inventory = spacengine.creative_enable},
  sounds = default.node_sound_stone_defaults(),
  on_construct=function(pos)
    spacengine.switch_setup(pos,"i")
  end,
  after_place_node=function(pos,placer)
    spacengine.placer_node(pos,placer)
  end,
  on_rightclick = function(pos, node, player)
    spacengine.switch_gui(pos,player)
	end,
  on_punch = function(pos, node, puncher)
    if not check_punch(pos,puncher) then return end
    minetest.swap_node(pos, {name="spacengine:inter_1",param2=node.param2})
    spacengine.formspec_update(pos,puncher,"sw#1#>",spacengine.owner_check(puncher,pos),1)
  end
})

minetest.register_node("spacengine:inter_1", {
  description = "button_1",
  tiles = {"spacengine_inter1.png"},
  drawtype = "nodebox",
  node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, 0.495, 0.5, 0.5, 0.5},
		},
    },
  paramtype = "light",
  paramtype2 = "facedir",

  sunlight_propagates = true,
  groups = {cracky=333, not_in_creative_inventory=1,spacengine=20},
  sounds = default.node_sound_stone_defaults(),
  on_construct=function(pos)
    spacengine.switch_setup(pos,"i")
  end,
  drop="spacengine:inter_0",
  on_rightclick = function(pos, node, player)
    spacengine.switch_gui(pos,player)
	end,
  on_punch = function(pos, node, puncher)
    if not check_punch(pos,puncher) then return end
    minetest.swap_node(pos, {name="spacengine:inter_0",param2=node.param2})
    spacengine.formspec_update(pos,puncher,"sw#1#>",spacengine.owner_check(puncher,pos),0)
  end
})

--*** levier 3d ***
minetest.register_node("spacengine:levier0", {
  description = "levier0",
  drawtype = "mesh",
  mesh = "levier0.obj",
  tiles = {"spacengine_levier.png"},
  paramtype2 = "facedir",
  selection_box = { type = "fixed", fixed = { -0.2,-0.5,-0.2,0.2,0,0.2} },
  collision_box = { type = "fixed", fixed = { -0.2,-0.5,-0.2,0.2,0,0.2} },
  walkable = false,
  sunlight_propagates = true,
  groups = {cracky=333,spacengine=20,not_in_creative_inventory = spacengine.creative_enable},
  sounds = default.node_sound_stone_defaults(),
  on_place = minetest.rotate_node,
  on_construct=function(pos)
    spacengine.switch_setup(pos,"a")
  end,
  after_place_node=function(pos,placer)
    spacengine.placer_node(pos,placer)
  end,
  on_rightclick = function(pos, node, player)
    spacengine.switch_gui(pos,player)
	end,
  on_punch = function(pos, node, puncher)
    if not check_punch(pos,puncher) then return end
    minetest.swap_node(pos, {name="spacengine:levier1",param2=node.param2})
    spacengine.formspec_update(pos,puncher,"sw#1#>",spacengine.owner_check(puncher,pos),-20)
  end
})

minetest.register_node("spacengine:levier1", {
  description = "levier1",
  drawtype = "mesh",
  mesh = "levier1.obj",
  tiles = {"spacengine_levier.png"},
  paramtype2 = "facedir",
  selection_box = { type = "fixed", fixed = { -0.2,-0.5,-0.2,0.2,0,0.2} },
  collision_box = { type = "fixed", fixed = { -0.2,-0.5,-0.2,0.2,0,0.2} },
  walkable = false,
  sunlight_propagates = true,
  groups = {cracky=333, not_in_creative_inventory=1,spacengine=20},
  sounds = default.node_sound_stone_defaults(),
  drop="spacengine:levier0",
  on_construct=function(pos)
    spacengine.switch_setup(pos,"a")
  end,
  on_rightclick = function(pos, node, player)
    spacengine.switch_gui(pos,player)
	end,
  on_punch = function(pos, node, puncher)
    if not check_punch(pos,puncher) then return end
    minetest.swap_node(pos, {name="spacengine:levier2",param2=node.param2})
    spacengine.formspec_update(pos,puncher,"sw#1#>",spacengine.owner_check(puncher,pos),-40)
  end
})

minetest.register_node("spacengine:levier2", {
  description = "levier2",
  drawtype = "mesh",
  mesh = "levier2.obj",
  tiles = {"spacengine_levier.png"},
  paramtype2 = "facedir",
  selection_box = { type = "fixed", fixed = { -0.2,-0.5,-0.2,0.2,0,0.2} },
  collision_box = { type = "fixed", fixed = { -0.2,-0.5,-0.2,0.2,0,0.2} },
  walkable = false,
  sunlight_propagates = true,
  groups = {cracky=333, not_in_creative_inventory=1,spacengine=20},
  sounds = default.node_sound_stone_defaults(),
  drop="spacengine:levier0",
  on_construct=function(pos)
    spacengine.switch_setup(pos,"a")
  end,
  on_rightclick = function(pos, node, player)
    spacengine.switch_gui(pos,player)
	end,
  on_punch = function(pos, node, puncher)
    if not check_punch(pos,puncher) then return end
    minetest.swap_node(pos, {name="spacengine:levier3",param2=node.param2})
    spacengine.formspec_update(pos,puncher,"sw#1#>",spacengine.owner_check(puncher,pos),-60)
  end
})

minetest.register_node("spacengine:levier3", {
  description = "levier3",
  drawtype = "mesh",
  mesh = "levier3.obj",
  tiles = {"spacengine_levier.png"},
  paramtype2 = "facedir",
  selection_box = { type = "fixed", fixed = { -0.2,-0.5,-0.2,0.2,0,0.2} },
  collision_box = { type = "fixed", fixed = { -0.2,-0.5,-0.2,0.2,0,0.2} },
  walkable = false,
  groups = {cracky=333, not_in_creative_inventory=1,spacengine=20},
  sounds = default.node_sound_stone_defaults(),
  drop="spacengine:levier0",
  on_construct=function(pos)
    spacengine.switch_setup(pos,"a")
  end,
  on_rightclick = function(pos, node, player)
    spacengine.switch_gui(pos,player)
	end,
  on_punch = function(pos, node, puncher)
    if not check_punch(pos,puncher) then return end
    minetest.swap_node(pos, {name="spacengine:levier4",param2=node.param2})
    spacengine.formspec_update(pos,puncher,"sw#1#>",spacengine.owner_check(puncher,pos),-80)
  end
})

minetest.register_node("spacengine:levier4", {
  description = "levier4",
  drawtype = "mesh",
  mesh = "levier4.obj",
  tiles = {"spacengine_levier.png"},
  paramtype2 = "facedir",
  selection_box = { type = "fixed", fixed = { -0.2,-0.5,-0.2,0.2,0,0.2} },
  collision_box = { type = "fixed", fixed = { -0.2,-0.5,-0.2,0.2,0,0.2} },
  walkable = false,
  groups = {cracky=333, not_in_creative_inventory=1,spacengine=20},
  sounds = default.node_sound_stone_defaults(),
  drop="spacengine:levier0",
  on_construct=function(pos)
    spacengine.switch_setup(pos,"a")
  end,
  on_rightclick = function(pos, node, player)
    spacengine.switch_gui(pos,player)
	end,
  on_punch = function(pos, node, puncher)
    if not check_punch(pos,puncher) then return end
    minetest.swap_node(pos, {name="spacengine:levier5",param2=node.param2})
    spacengine.formspec_update(pos,puncher,"sw#1#>",spacengine.owner_check(puncher,pos),-100)
  end
})

minetest.register_node("spacengine:levier5", {
  description = "levier5",
  drawtype = "mesh",
  mesh = "levier5.obj",
  tiles = {"spacengine_levier.png"},
  paramtype2 = "facedir",
  selection_box = { type = "fixed", fixed = { -0.2,-0.5,-0.2,0.2,0,0.2} },
  collision_box = { type = "fixed", fixed = { -0.2,-0.5,-0.2,0.2,0,0.2} },
  walkable = false,
  groups = {cracky=333, not_in_creative_inventory=1,spacengine=20},
  sounds = default.node_sound_stone_defaults(),
  drop="spacengine:levier0",
  on_construct=function(pos)
    spacengine.switch_setup(pos,"a")
  end,
  on_rightclick = function(pos, node, player)
    spacengine.switch_gui(pos,player)
	end,
  on_punch = function(pos, node, puncher)
    if not check_punch(pos,puncher) then return end
    minetest.swap_node(pos, {name="spacengine:levier0",param2=node.param2})
    spacengine.formspec_update(pos,puncher,"sw#1#>",spacengine.owner_check(puncher,pos),0)
  end
})

--*** curseur analogique ***
minetest.register_node("spacengine:analog00", {
  description = "curseur analogique",
  inventory_image = "spacengine_analog00.png",
  tiles = {"spacengine_analog00.png"},
  drawtype = "nodebox",
  node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, 0.495, 0.5, 0.5, 0.5},
		},
    },
  paramtype = "light",
  paramtype2 = "facedir",

  groups = {cracky=333,spacengine=20,not_in_creative_inventory = spacengine.creative_enable},
  sounds = default.node_sound_stone_defaults(),
  drop="spacengine:analog00",
  sunlight_propagates = true,
  on_construct=function(pos)
    spacengine.switch_setup(pos,"a")
  end,
  after_place_node=function(pos,placer)
    spacengine.placer_node(pos,placer)
  end,
  on_rightclick = function(pos, node, player)
    spacengine.switch_gui(pos,player)
	end,
  on_punch = function(pos, node, puncher)
    if not check_punch(pos,puncher) then return end
    minetest.swap_node(pos, {name="spacengine:analog01",param2=node.param2})
    spacengine.formspec_update(pos,puncher,"sw#1#>",spacengine.owner_check(puncher,pos),-20)
  end
})

minetest.register_node("spacengine:analog01", {
  tiles = {"spacengine_analog01.png"},
  drawtype = "nodebox",
  node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, 0.495, 0.5, 0.5, 0.5},
		},
    },
  paramtype = "light",
  paramtype2 = "facedir",

  groups = {cracky=333, not_in_creative_inventory=1,spacengine=20},
  sounds = default.node_sound_stone_defaults(),
  drop="spacengine:analog00",
  sunlight_propagates = true,
  on_construct=function(pos)
    spacengine.switch_setup(pos,"a")
  end,
  on_rightclick = function(pos, node, player)
    spacengine.switch_gui(pos,player)
	end,
  on_punch = function(pos, node, puncher)
    if not check_punch(pos,puncher) then return end
    minetest.swap_node(pos, {name="spacengine:analog02",param2=node.param2})
    spacengine.formspec_update(pos,puncher,"sw#1#>",spacengine.owner_check(puncher,pos),-40)
  end
})

minetest.register_node("spacengine:analog02", {
  tiles = {"spacengine_analog02.png"},
  drawtype = "nodebox",
  node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, 0.495, 0.5, 0.5, 0.5},
		},
    },
  paramtype = "light",
  paramtype2 = "facedir",

  groups = {cracky=333, not_in_creative_inventory=1,spacengine=20},
  sounds = default.node_sound_stone_defaults(),
  drop="spacengine:analog00",
  sunlight_propagates = true,
  on_construct=function(pos)
    spacengine.switch_setup(pos,"a")
  end,
  on_rightclick = function(pos, node, player)
    spacengine.switch_gui(pos,player)
	end,
  on_punch = function(pos, node, puncher)
    if not check_punch(pos,puncher) then return end
    minetest.swap_node(pos, {name="spacengine:analog03",param2=node.param2})
    spacengine.formspec_update(pos,puncher,"sw#1#>",spacengine.owner_check(puncher,pos),-60)
  end
})

minetest.register_node("spacengine:analog03", {
  tiles = {"spacengine_analog03.png"},
  drawtype = "nodebox",
  node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, 0.495, 0.5, 0.5, 0.5},
		},
    },
  paramtype = "light",
  paramtype2 = "facedir",
  groups = {cracky=333, not_in_creative_inventory=1,spacengine=20},
  sounds = default.node_sound_stone_defaults(),
  drop="spacengine:analog00",
  sunlight_propagates = true,
  on_construct=function(pos)
    spacengine.switch_setup(pos,"a")
  end,
  on_rightclick = function(pos, node, player)
    spacengine.switch_gui(pos,player)
	end,
  on_punch = function(pos, node, puncher)
    if not check_punch(pos,puncher) then return end
    minetest.swap_node(pos, {name="spacengine:analog04",param2=node.param2})
    spacengine.formspec_update(pos,puncher,"sw#1#>",spacengine.owner_check(puncher,pos),-80)
  end
})

minetest.register_node("spacengine:analog04", {
  tiles = {"spacengine_analog04.png"},
  drawtype = "nodebox",
  node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, 0.495, 0.5, 0.5, 0.5},
		},
    },
  paramtype = "light",
  paramtype2 = "facedir",

  groups = {cracky=333, not_in_creative_inventory=1,spacengine=20},
  sounds = default.node_sound_stone_defaults(),
  drop="spacengine:analog00",
  sunlight_propagates = true,
  on_construct=function(pos)
    spacengine.switch_setup(pos,"a")
  end,
  on_rightclick = function(pos, node, player)
    spacengine.switch_gui(pos,player)
	end,
  on_punch = function(pos, node, puncher)
    if not check_punch(pos,puncher) then return end
    minetest.swap_node(pos, {name="spacengine:analog05",param2=node.param2})
    spacengine.formspec_update(pos,puncher,"sw#1#>",spacengine.owner_check(puncher,pos),-100)
  end
})

minetest.register_node("spacengine:analog05", {
  tiles = {"spacengine_analog05.png"},
  drawtype = "nodebox",
  node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, 0.495, 0.5, 0.5, 0.5},
		},
    },
  paramtype = "light",
  paramtype2 = "facedir",

  groups = {cracky=333, not_in_creative_inventory=1,spacengine=20},
  sounds = default.node_sound_stone_defaults(),
  drop="spacengine:analog00",
  sunlight_propagates = true,
  on_construct=function(pos)
    spacengine.switch_setup(pos,"a")
  end,
  on_rightclick = function(pos, node, player)
    spacengine.switch_gui(pos,player)
	end,
  on_punch = function(pos, node, puncher)
    if not check_punch(pos,puncher) then return end
    minetest.swap_node(pos, {name="spacengine:analog00",param2=node.param2})
    spacengine.formspec_update(pos,puncher,"sw#1#>",spacengine.owner_check(puncher,pos),0)
  end
})

--*** levier propulsion ***
minetest.register_node("spacengine:analog10", {
  description = "Gaz trust",
  inventory_image = "spacengine_analog10.png",
  drawtype = "mesh",
  tiles = {"spacengine_analog10.png","spacengine_switch_side.png"},
  drawtype = "mesh",
	mesh = "slope.obj",
		selection_box = {
			type = "fixed",
	fixed = {
		{-0.5,  -0.5,  -0.5, 0.5, -0.4, 0.5},
		{-0.5, -0.4, 0.4, 0.5,  0.5, 0.5}
	}
		},
		collision_box = {
			type = "fixed",
	fixed = {
		{-0.5,  -0.5,  -0.5, 0.5, -0.4, 0.5},
		{-0.5, -0.4, 0.4, 0.5,  0.5, 0.5}
	}
		},
  paramtype = "light",
  paramtype2 = "facedir",
  sunlight_propagates = true,
  groups = {cracky=333,spacengine=20,not_in_creative_inventory = spacengine.creative_enable},
  sounds = default.node_sound_stone_defaults(),
  on_construct=function(pos)
    spacengine.switch_setup(pos,"a")
  end,
  after_place_node=function(pos,placer)
    spacengine.placer_node(pos,placer)
  end,
  on_rightclick = function(pos, node, player)
    spacengine.switch_gui(pos,player)
	end,
  on_punch = function(pos, node, puncher)
    if not check_punch(pos,puncher) then return end
    minetest.swap_node(pos, {name="spacengine:analog11",param2=node.param2})
    spacengine.formspec_update(pos,puncher,"sw#1#>",spacengine.owner_check(puncher,pos),-20)
  end
})

minetest.register_node("spacengine:analog11", {
  drawtype = "mesh",
  tiles = {"spacengine_analog11.png","spacengine_switch_side.png"},
  drawtype = "mesh",
	mesh = "slope.obj",
		selection_box = {
			type = "fixed",
	fixed = {
		{-0.5,  -0.5,  -0.5, 0.5, -0.4, 0.5},
		{-0.5, -0.4, 0.4, 0.5,  0.5, 0.5}
	}
		},
		collision_box = {
			type = "fixed",
	fixed = {
		{-0.5,  -0.5,  -0.5, 0.5, -0.4, 0.5},
		{-0.5, -0.4, 0.4, 0.5,  0.5, 0.5}
	}
		},
  paramtype = "light",
  paramtype2 = "facedir",
  sunlight_propagates = true,
  groups = {cracky=333, not_in_creative_inventory=1,spacengine=20},
  sounds = default.node_sound_stone_defaults(),
  drop="spacengine:analog10",
  on_construct=function(pos)
    spacengine.switch_setup(pos,"a")
  end,
  on_rightclick = function(pos, node, player)
    spacengine.switch_gui(pos,player)
	end,
  on_punch = function(pos, node, puncher)
    if not check_punch(pos,puncher) then return end
    minetest.swap_node(pos, {name="spacengine:analog12",param2=node.param2})
    spacengine.formspec_update(pos,puncher,"sw#1#>",spacengine.owner_check(puncher,pos),-40)
  end
})

minetest.register_node("spacengine:analog12", {
  drawtype = "mesh",
  tiles = {"spacengine_analog12.png","spacengine_switch_side.png"},
  drawtype = "mesh",
	mesh = "slope.obj",
		selection_box = {
			type = "fixed",
	fixed = {
		{-0.5,  -0.5,  -0.5, 0.5, -0.4, 0.5},
		{-0.5, -0.4, 0.4, 0.5,  0.5, 0.5}
	}
		},
		collision_box = {
			type = "fixed",
	fixed = {
		{-0.5,  -0.5,  -0.5, 0.5, -0.4, 0.5},
		{-0.5, -0.4, 0.4, 0.5,  0.5, 0.5}
	}
		},
  paramtype = "light",
  paramtype2 = "facedir",
  sunlight_propagates = true,
  groups = {cracky=333, not_in_creative_inventory=1,spacengine=20},
  sounds = default.node_sound_stone_defaults(),
  drop="spacengine:analog10",
  on_construct=function(pos)
    spacengine.switch_setup(pos,"a")
  end,
  on_rightclick = function(pos, node, player)
    spacengine.switch_gui(pos,player)
	end,
  on_punch = function(pos, node, puncher)
    if not check_punch(pos,puncher) then return end
    minetest.swap_node(pos, {name="spacengine:analog13",param2=node.param2})
    spacengine.formspec_update(pos,puncher,"sw#1#>",spacengine.owner_check(puncher,pos),-60)
  end
})

minetest.register_node("spacengine:analog13", {
  drawtype = "mesh",
  tiles = {"spacengine_analog13.png","spacengine_switch_side.png"},
  drawtype = "mesh",
	mesh = "slope.obj",
		selection_box = {
			type = "fixed",
	fixed = {
		{-0.5,  -0.5,  -0.5, 0.5, -0.4, 0.5},
		{-0.5, -0.4, 0.4, 0.5,  0.5, 0.5}
	}
		},
		collision_box = {
			type = "fixed",
	fixed = {
		{-0.5,  -0.5,  -0.5, 0.5, -0.4, 0.5},
		{-0.5, -0.4, 0.4, 0.5,  0.5, 0.5}
	}
		},
  paramtype = "light",
  paramtype2 = "facedir",
  sunlight_propagates = true,
  groups = {cracky=333, not_in_creative_inventory=1,spacengine=20},
  sounds = default.node_sound_stone_defaults(),
  drop="spacengine:analog10",
  on_construct=function(pos)
    spacengine.switch_setup(pos,"a")
  end,
  on_rightclick = function(pos, node, player)
    spacengine.switch_gui(pos,player)
	end,
  on_punch = function(pos, node, puncher)
    if not check_punch(pos,puncher) then return end
    minetest.swap_node(pos, {name="spacengine:analog14",param2=node.param2})
    spacengine.formspec_update(pos,puncher,"sw#1#>",spacengine.owner_check(puncher,pos),-80)
  end
})

minetest.register_node("spacengine:analog14", {
  drawtype = "mesh",
  tiles = {"spacengine_analog14.png","spacengine_switch_side.png"},
  drawtype = "mesh",
	mesh = "slope.obj",
		selection_box = {
			type = "fixed",
	fixed = {
		{-0.5,  -0.5,  -0.5, 0.5, -0.4, 0.5},
		{-0.5, -0.4, 0.4, 0.5,  0.5, 0.5}
	}
		},
		collision_box = {
			type = "fixed",
	fixed = {
		{-0.5,  -0.5,  -0.5, 0.5, -0.4, 0.5},
		{-0.5, -0.4, 0.4, 0.5,  0.5, 0.5}
	}
		},
  paramtype = "light",
  paramtype2 = "facedir",
  sunlight_propagates = true,
  groups = {cracky=333, not_in_creative_inventory=1,spacengine=20},
  sounds = default.node_sound_stone_defaults(),
  drop="spacengine:analog10",
  on_construct=function(pos)
    spacengine.switch_setup(pos,"a")
  end,
  on_rightclick = function(pos, node, player)
    spacengine.switch_gui(pos,player)
	end,
  on_punch = function(pos, node, puncher)
    if not check_punch(pos,puncher) then return end
    minetest.swap_node(pos, {name="spacengine:analog15",param2=node.param2})
    spacengine.formspec_update(pos,puncher,"sw#1#>",spacengine.owner_check(puncher,pos),-100)
  end
})

minetest.register_node("spacengine:analog15", {
  drawtype = "mesh",
  tiles = {"spacengine_analog15.png","spacengine_switch_side.png"},
  drawtype = "mesh",
	mesh = "slope.obj",
		selection_box = {
			type = "fixed",
	fixed = {
		{-0.5,  -0.5,  -0.5, 0.5, -0.4, 0.5},
		{-0.5, -0.4, 0.4, 0.5,  0.5, 0.5}
	}
		},
		collision_box = {
			type = "fixed",
	fixed = {
		{-0.5,  -0.5,  -0.5, 0.5, -0.4, 0.5},
		{-0.5, -0.4, 0.4, 0.5,  0.5, 0.5}
	}
		},
  paramtype = "light",
  paramtype2 = "facedir",
  sunlight_propagates = true,
  groups = {cracky=333, not_in_creative_inventory=1,spacengine=20},
  sounds = default.node_sound_stone_defaults(),
  drop="spacengine:analog10",
  on_construct=function(pos)
    spacengine.switch_setup(pos,"a")
  end,
  on_rightclick = function(pos, node, player)
    spacengine.switch_gui(pos,player)
	end,
  on_punch = function(pos, node, puncher)
    if not check_punch(pos,puncher) then return end
    minetest.swap_node(pos, {name="spacengine:analog10",param2=node.param2})
    spacengine.formspec_update(pos,puncher,"sw#1#>",spacengine.owner_check(puncher,pos),0)
  end
})

--*** rotator analogique ***
minetest.register_node("spacengine:rotator00", {
  description = "Rotator analogique",
  inventory_image = "spacengine_rotator00.png",
  tiles = {"spacengine_rotator00.png"},
  drawtype = "nodebox",
  node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, 0.495, 0.5, 0.5, 0.5},
		},
    },
  paramtype = "light",
  paramtype2 = "facedir",
  groups = {cracky=333,spacengine=20,not_in_creative_inventory = spacengine.creative_enable},
  sounds = default.node_sound_stone_defaults(),
  drop="spacengine:rotator00",
  sunlight_propagates = true,
  on_construct=function(pos)
    spacengine.switch_setup(pos,"a")
  end,
  after_place_node=function(pos,placer)
    spacengine.placer_node(pos,placer)
  end,
  on_rightclick = function(pos, node, player)
    spacengine.switch_gui(pos,player)
	end,
  on_punch = function(pos, node, puncher)
    if not check_punch(pos,puncher) then return end
    minetest.swap_node(pos, {name="spacengine:rotator01",param2=node.param2})
    spacengine.formspec_update(pos,puncher,"sw#1#>",spacengine.owner_check(puncher,pos),-20)
  end
})

minetest.register_node("spacengine:rotator01", {
  tiles = {"spacengine_rotator01.png"},
  drawtype = "nodebox",
  node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, 0.495, 0.5, 0.5, 0.5},
		},
    },
  paramtype = "light",
  paramtype2 = "facedir",
  groups = {cracky=333, not_in_creative_inventory=1,spacengine=20},
  sounds = default.node_sound_stone_defaults(),
  drop="spacengine:rotator00",
  sunlight_propagates = true,
  on_construct=function(pos)
    spacengine.switch_setup(pos,"a")
  end,
  on_rightclick = function(pos, node, player)
    spacengine.switch_gui(pos,player)
	end,
  on_punch = function(pos, node, puncher)
    if not check_punch(pos,puncher) then return end
    minetest.swap_node(pos, {name="spacengine:rotator02",param2=node.param2})
    spacengine.formspec_update(pos,puncher,"sw#1#>",spacengine.owner_check(puncher,pos),-40)
  end
})

minetest.register_node("spacengine:rotator02", {
  tiles = {"spacengine_rotator02.png"},
  drawtype = "nodebox",
  node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, 0.495, 0.5, 0.5, 0.5},
		},
    },
  paramtype = "light",
  paramtype2 = "facedir",
  groups = {cracky=333, not_in_creative_inventory=1,spacengine=20},
  sounds = default.node_sound_stone_defaults(),
  drop="spacengine:rotator00",
  sunlight_propagates = true,
  on_construct=function(pos)
    spacengine.switch_setup(pos,"a")
  end,
  on_rightclick = function(pos, node, player)
    spacengine.switch_gui(pos,player)
	end,
  on_punch = function(pos, node, puncher)
    if not check_punch(pos,puncher) then return end
    minetest.swap_node(pos, {name="spacengine:rotator03",param2=node.param2})
    spacengine.formspec_update(pos,puncher,"sw#1#>",spacengine.owner_check(puncher,pos),-60)
  end
})

minetest.register_node("spacengine:rotator03", {
  tiles = {"spacengine_rotator03.png"},
  drawtype = "nodebox",
  node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, 0.495, 0.5, 0.5, 0.5},
		},
    },
  paramtype = "light",
  paramtype2 = "facedir",
  groups = {cracky=333, not_in_creative_inventory=1,spacengine=20},
  sounds = default.node_sound_stone_defaults(),
  drop="spacengine:rotator00",
  sunlight_propagates = true,
  on_construct=function(pos)
    spacengine.switch_setup(pos,"a")
  end,
  on_rightclick = function(pos, node, player)
    spacengine.switch_gui(pos,player)
	end,
  on_punch = function(pos, node, puncher)
    if not check_punch(pos,puncher) then return end
    minetest.swap_node(pos, {name="spacengine:rotator04",param2=node.param2})
    spacengine.formspec_update(pos,puncher,"sw#1#>",spacengine.owner_check(puncher,pos),-80)
  end
})

minetest.register_node("spacengine:rotator04", {
  tiles = {"spacengine_rotator04.png"},
  drawtype = "nodebox",
  node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, 0.495, 0.5, 0.5, 0.5},
		},
    },
  paramtype = "light",
  paramtype2 = "facedir",

  groups = {cracky=333, not_in_creative_inventory=1,spacengine=20},
  sounds = default.node_sound_stone_defaults(),
  drop="spacengine:rotator00",
  on_construct=function(pos)
    spacengine.switch_setup(pos,"a")
  end,
  sunlight_propagates = true,
  on_rightclick = function(pos, node, player)
    spacengine.switch_gui(pos,player)
	end,
  on_punch = function(pos, node, puncher)
    if not check_punch(pos,puncher) then return end
    minetest.swap_node(pos, {name="spacengine:rotator05",param2=node.param2})
    spacengine.formspec_update(pos,puncher,"sw#1#>",spacengine.owner_check(puncher,pos),-100)
  end
})

minetest.register_node("spacengine:rotator05", {
  tiles = {"spacengine_rotator05.png"},
  drawtype = "nodebox",
  node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, 0.495, 0.5, 0.5, 0.5},
		},
    },
  paramtype = "light",
  paramtype2 = "facedir",

  groups = {cracky=333, not_in_creative_inventory=1,spacengine=20},
  sounds = default.node_sound_stone_defaults(),
  drop="spacengine:rotator00",
  sunlight_propagates = true,
  on_construct=function(pos)
    spacengine.switch_setup(pos,"a")
  end,
  on_rightclick = function(pos, node, player)
    spacengine.switch_gui(pos,player)
	end,
  on_punch = function(pos, node, puncher)
    if not check_punch(pos,puncher) then return end
    minetest.swap_node(pos, {name="spacengine:rotator00",param2=node.param2})
    spacengine.formspec_update(pos,puncher,"sw#1#>",spacengine.owner_check(puncher,pos),0)
  end
})
