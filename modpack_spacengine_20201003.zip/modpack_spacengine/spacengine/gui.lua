local function plantage(pos,playername)
  local node=minetest.get_node(pos)
  local meta=minetest.get_meta(pos)
  local channel=meta:get_string("channel")
  local cont=meta:get_string("pos_cont")
  local spacengine=meta:get_string("spacengine")

  if spacengine=="" then
    local group=minetest.get_item_group(node.name,"spacengine")
    if group~=0 then
      minetest.set_node(pos,{name=node.name, param2=node.param2})
      channel=""
    end
  end

  if channel=="" then
    meta:set_string("channel","No channel:"..playername)
  end

  if cont=="" then
    meta:get_string("pos_cont","33333¨0¨0")
  end
end

spacengine.gui_form={}

--****************
--*** FORMSPEC ***
--****************
spacengine.formspec_update=function(pos,player,option,check,value)
--plantage(pos,player:get_player_name())
  --recuperation data node
  local node=minetest.get_node(pos)
  local nod_met = minetest.get_meta(pos)
  local vente=nod_met:get_string("vente")
  local pl_name=player:get_player_name()
  if spacengine.gui_form[pl_name]==nil then spacengine.gui_form[pl_name]={} end

  --** revente du vaisseaux a d'autre player **
  if vente~="" then
    if check==1 then
      spacengine.gui_form[pl_name]="spacengine#vente#1#+5#".. spacengine.pts(pos)
      return minetest.show_formspec(pl_name, "spacengine" , "size[6,4]button_exit[0,0;2,1;accept;accept]button_exit[0,1;2,1;cancel;cancel]label[2,2.5;Sell Price ".. vente .."]field[1,3.5;5,1;newname;New name ;]")
    end
  end

  if check<2 then return end --si pas membre d'equipage

  --channel : owner
  local channel=nod_met:get_string("channel")
  local cha_spl=string.split(channel,":")
  local owner=cha_spl[2]
  channel=cha_spl[1]..":"..cha_spl[2]
  local channel_only=cha_spl[1]

  local spac_eng=spacengine.decompact(nod_met:get_string("spacengine"))
  local pos_cont=spacengine.decompact(nod_met:get_string("pos_cont"))
  --group
  local group=minetest.get_item_group(node.name,"spacengine")
  local err=false --si fichier config absent

  --recuperation position relative ou reel du controler
  local cpos={x=pos_cont[1],y=pos_cont[2],z=pos_cont[3]} --position reel
  local cont_met
  local config

  if channel_only=="No channel" or cpos.x==33333 then
    err=true
  else
    --position relative du controler
    if group~=1 then
      cpos.x=pos.x-cpos.x
      cpos.y=pos.y-cpos.y
      cpos.z=pos.z-cpos.z
    end

    cont_met=minetest.get_meta(cpos)

    if spacengine.test_area_ship(cpos,0,channel)==false then
      err=true
    else
      config=spacengine.area[channel].config
    end

  end

  --** clic droit param **
  if string.find(option,"<") then
    if channel_only=="No channel" or cpos.x==33333 then return false end
    if not spacengine.test_area_ship(cpos,0,channel) then return false end
    if config[1][1]==0 then return false end
    spac_eng[5]=spac_eng[5]+1
    if spac_eng[5]>math.floor(string.len(spac_eng[4])/3) then spac_eng[5]=1 end

    nod_met:set_string("spacengine",spacengine.compact(spac_eng))
    config[12]=string.sub(spac_eng[1],1,1)
    cont_met:set_string("config",spacengine.compact(config))
    return spacengine.controler(cpos,true) --maj screen
  end

  --** clic gauche value **
  if string.find(option,">") then
    if channel_only=="No channel" or cpos.x==33333 then return false end
    if not spacengine.test_area_ship(cpos,0,channel) then return false end
    local nb_param=spac_eng[5]
    if nb_param>math.floor(string.len(spac_eng[4])/3) then
      spac_eng[5]=1
      nb_param=1
    end
    
    local switch=string.sub(spac_eng[4],nb_param*3-2,nb_param*3-2)
    local vl=string.byte(spac_eng[4],nb_param*3)-48
    local lng=#spac_eng[4]

    --** BP **
    if switch=="b" then
      if value==nil then value=1 end
      option=spacengine.punch_module(cpos,cont_met,config,spac_eng,channel,group,player,value)

    --** INTERUPTEUR **
    elseif switch=="i" then
      local code

      if value==nil then
        if group==12 then
          if string.sub(spac_eng[1],1,1)=="A" then
            if nb_param==1 then
              code="hangar"
            elseif nb_param==2 then
              code="sas_out"
            elseif nb_param==3 then
              code="door_in"
            elseif nb_param==4 then
              code="storage"
            elseif nb_param==5 then
              code="aux_1"
            elseif nb_param==6 then
              code="aux_2"
            end
          end
        end
        --incremente valeur de l'inter
        value=vl+1
        if value>1 then value=0 end
        spac_eng[4]=string.sub(spac_eng[4],1,nb_param*3-1) ..value.. string.sub(spac_eng[4],nb_param*3+1,lng)
        nod_met:set_string("spacengine",spacengine.compact(spac_eng))
      end

      spacengine.punch_module(cpos,cont_met,config,spac_eng,channel,group,player,value,code)

    --** ANALOGIQUE **
    elseif switch=="a" then

      if value==nil then
        value=6
        --incremente valeur du curseur
        vl=vl+1
        if vl>5 then vl=0 end
        spac_eng[4]=string.sub(spac_eng[4],1,nb_param*3-1) ..vl.. string.sub(spac_eng[4],nb_param*3+1,lng)
        nod_met:set_string("spacengine",spacengine.compact(spac_eng))
      end

      spacengine.punch_module(cpos,cont_met,config,spac_eng,channel,group,player,value)

    end

    if config[12]~="n" then spacengine.controler(cpos,true) end --maj screen

    if option==nil then return end

    if not string.find(option,"menu") then return end --menu confirmation

  end

  local formspec

  --***********************
  --**POPuP confirmation **
  --***********************
  if string.find(option,"+") then
    local form_spl=string.split(option,"#")

    --upgrade module
    if string.find(form_spl[3],"+1") then
      formspec="size[5,3]button_exit[0,0;2,1;accept;accept]button_exit[0,1;2,1;cancel;cancel]label[2.5,0;module "..spacengine.upgrade[group][tonumber(form_spl[2])][3].."]label[2.5,1;Price : "..spacengine.upgrade[group][tonumber(form_spl[2])][2].."]"

    --reparation
    elseif string.find(form_spl[3],"+2") then
      formspec="size[5,3]button_exit[0,0;2,1;accept;accept]button_exit[0,1;2,1;cancel;cancel]label[1,2;reparation du vaisseaux]label[1,2.5;Price : ".. math.ceil(config[1][3]*config[1][3]*tonumber(string.sub(config[1][4],8,11))*0.0002) .."]"
      option=option.. string.sub(tostring(config[1][3]+1000),2) .. string.sub(config[1][4],8,11)

    --jumpdrive
    elseif string.find(form_spl[3],"+3") then

      formspec="size[5,3]button_exit[0,0;2,1;accept;accept]button_exit[0,1;2,1;cancel;cancel]label[2.5,0;! JUMPDRIVE !]label[2.5,1;Start FLY ?]"

    --buy new ship/sell to another player
    elseif string.find(form_spl[3],"+4") then
      formspec="size[9,5]button_exit[0,0;2,1;accept;accept]button_exit[0,1;2,1;cancel;cancel]"
      formspec=formspec.."label[2,0;Spaceship list]textlist[2,0.5;6,1.3;achat;"
      for i=1,#spacengine.vaisseaux do
        formspec=formspec.. spacengine.vaisseaux[i][2] .." : ".. spacengine.vaisseaux[i][1] .." Mg "
        if i<#spacengine.vaisseaux then formspec=formspec.."," end
      end
      formspec=formspec..";1;]"

      formspec=formspec.."label[5,2.5;Crew list]textlist[5,3;4,1.3;crew3;"
      local crew_old=cha_spl[2].." : Cpt."
      if #cha_spl>2 then
        for idx=3,#cha_spl do
          crew_old=crew_old..","..cha_spl[idx]
        end
      end
      formspec=formspec..crew_old..";1;]"

      if vente~="" then
        formspec=formspec.."field[0.1,2.5;5,1;data1;Sell Price ;".. vente .."]"
      else
        formspec=formspec.."field[0.1,2.5;5,1;data1;Sell Price ;]"
      end

      formspec=formspec.."field[0.1,3.5;5,1;crew1;Remove crew ;]field[0.1,4.5;5,1;crew2;Insert crew ;]"

    --transaction accept ?
    elseif string.find(form_spl[3],"+6") then
      formspec="size[6,4]button_exit[0,0;2,1;accept;accept]button_exit[0,1;2,1;cancel;cancel]"

    --accept achat nouveau vaisseaux
    elseif string.find(form_spl[3],"+7") then
      formspec="size[5,3]button_exit[0,0;2,1;accept;accept]button_exit[0,1;2,1;cancel;cancel]label[2.5,0;Spaceship "..spacengine.vaisseaux[tonumber(form_spl[2])][2].."]label[2.5,1;Price : "..spacengine.vaisseaux[tonumber(form_spl[2])][1].."]"

    end

  else
  --** gui module **
  local module={"controler", "battery", "power", "engine", "shield", "weapons", "radar", "gforce", "storage", "passenger", "oxygene", "screen", "manutention","switch","analog","coordo","radio","info"}

  local manutention
  local passenger
  local storage
  local scr_opt=""
  formspec="size[10,10]"

  --option screen
  if group==12 and string.find(option,"&")==nil then
    scr_opt=string.sub(spac_eng[1],1,1)
    formspec=formspec.."image_button[0,9.4;1,1;spacengine_screen_icone.png;screen;]"
  end

  local tmp=nod_met:get_string("infotext")
  if tmp=="" then tmp="screen" end

  --menu indication commune a chaque machine
  formspec=formspec.."button_exit[0,7.5;2,1.25;maj;* update *\nspaceship]button_exit[0,8.5;2,1;exit;exit]" ..
    "field[0.25,0;3,1;channel;;".. channel_only .."]"..
    "label[0,0.5;".. tmp.."]"..
    "label[0,1;Owner : "..owner.."]"..
    "label[0,1.5;Damage : ".. spac_eng[3].."]"..
    "label[0,2;Famille : "..module[group].."]label[0,2.5;Upgrade : ".. string.sub(spac_eng[1],1,1) .."]"..
    "label[0,3;weight : ".. spac_eng[2].."]"..
    "list[current_player;main;1,9.4;8,1;]"

  --if espace ?
  local secteur,bloc=espace.secteur(pos)

  if secteur_dat[bloc.nb+1]==9 then --proximiter d'un commerce
    formspec=formspec.."image_button[9.15,9.4;1,1;spacengine_repar.png;repar;]"
  end
  --menu upgrade seulement si outils parametrage
  if string.find(option,"~") or string.find(option,"*") then
    local form_spl=string.split(option,"#")
    local split_up=spacengine.upgrade[group]
    formspec=formspec.."background[0,0;1,1;spacengine_"..module[group]..".png;true]"
    if string.find(option,"&")==nil then --upgrade desactiver ?
    formspec=formspec.."textlist[3.5,6.25;5.8,1.3;upgrade;"
    for i=1,#split_up do
      if group~=3 then
      local j=string.sub(split_up[i][1],2)
      if string.find(spac_eng[1],j) then
        formspec=formspec.."ok : "
      else
        formspec=formspec.."--- : "
      end
      else
      if spac_eng[1]==i then
        formspec=formspec.."ok : "
      else
        formspec=formspec.."--- : "
      end
      end
      formspec=formspec..split_up[i][2].." Mg : "..split_up[i][3]
      if i<#split_up then formspec=formspec.."," end
    end
    formspec=formspec..";".. form_spl[2]..";]textarea[3.75,7.75;6.1,1.75;descript;;".. split_up[tonumber(form_spl[2])][5] .."]"
    end

  else
    local nb_screen=string.find("CBPESWRGspOmMADc",scr_opt)
    formspec=formspec.."background[0,0;1,1;spacengine_"..module[nb_screen]..".png;true]" --background screen
  end

  --pas de menu specifique quand choix changement screen
  if string.find(option,"~") then err=true end

  --menu specifique
  --*** controler ***
  if group==1 or scr_opt=="C" then

    if err==false then
      if scr_opt~="C" and check==2 then
        formspec=formspec.."image_button[2.25,8;1,1;spacengine_sell.png;vente;]"
      end
      local rangex=11+tonumber(string.sub(config[1][4],2,2))*4
      local rangey=11+tonumber(string.sub(config[1][4],4,4))*4
      local rangez=11+tonumber(string.sub(config[1][4],6,6))*4
      local cnt_spl=spacengine.decompact(cont_met:get_string("spacengine"))
      local tmp1=cnt_spl[5]/6
      local spos = cpos.x..','..cpos.y..','..cpos.z
      formspec=formspec.."label[0,3.5;Volume : ".. rangex*rangey*rangez .." Bloc]list[nodemeta:"..spos..";stock;3.5,2.25;6,".. tmp1 .."]"
      if config[2][1]==0 then
        tmp1=0
      else
        tmp1=math.floor((config[2][2]/config[2][1])*100)
      end
      formspec=formspec.."label[0,4;statut : ".. config[1][1] .."]label[0,4.5;Weight Total ".. config[1][2] .."]label[0,5;Bat. level ".. tmp1 .." %]label[0,5.5;Power Moy. ".. config[3][3] .." u]label[3,1.75;Damage ".. config[1][3] .." %]label[7.5,1.75;Shield ".. config[5][1] .." %]label[5,1.75;Oxygene "..config[11][1].." %]"
      --jumpdrive
      formspec=formspec.."label[3,0;Old Pos ".. config[1][5][1] ..":".. config[1][5][2] ..":".. config[1][5][3] .."]label[3,0.35;Now ".. cpos.x+1 ..":".. cpos.y ..":".. cpos.z .."]label[3,0.7;Dest. ".. config[1][6][1] ..":".. config[1][6][2] ..":".. config[1][6][3] .."]"

      if config[6][6]>0 then
        formspec=formspec.."label[7,0;Weapons !WAIT]"--weapons
      else
      formspec=formspec.."label[7,0;Weapons READY]"
      end
      formspec=formspec.."label[0,6;Storage ".. config[9][2] .."/".. config[9][1] .."]"..--storage
      "label[0,6.5;Passenger ".. config[10][2] .."/".. config[10][1] .."]"..--passenger
      "label[7,0.35;Engine]label[8,0.35;Power "..config[4][1].."]label[8,0.7;range ".. config[4][3] .."]label[8,1.05;weight ".. config[4][7] .."]"
    end

  --*** battery ***
  elseif group==2 or scr_opt=="B" then

    if scr_opt~="B" then
      formspec=formspec.."label[0,3.5;Capacitance : ".. spac_eng[4].."]"
    end

    if err==false then
      formspec=formspec.."label[4.5,3.85;Charge : ".. config[2][2]..
      " / ".. config[2][1] .."]"
    end

  --*** power ***
  elseif group==3 or scr_opt=="P" then

    if scr_opt~="P" then
      local src=spac_eng[5]
      local dst=spac_eng[6]
      formspec=formspec.."label[0,3.5;Power : "..spac_eng[4].."]label[0,4;Speed : ".. spac_eng[7].."]image[6.5,2;1,1;spacengine_arrow.png]label[3.5,1.5;Power instant. module : ".. spac_eng[10].."]label[3.5,2;Timer : ".. spac_eng[9].."]"
      if src=="solar" then
        formspec=formspec.."image[5.5,2;1,1;spacengine_solar.png]"
      elseif src=="battery" then
        formspec=formspec.."item_image_button[5.5,2;1,1;spacengine:battery;dst;]"
      elseif src=="water" then
        formspec=formspec.."image[5.5,2;1,1;spacengine_water.png]"
      elseif string.find(src,"group:") then
        formspec=formspec.."label[5.5,2;".. src .."]"
      else
          formspec=formspec.."item_image_button[5.5,2;1,1;".. src ..";src;]"
      end

      if dst~="battery" then
        formspec=formspec.."item_image_button[7.5,2;1,1;".. dst ..";dst;]"
      else
        formspec=formspec.."item_image_button[7.5,2;1,1;spacengine:battery;dst;]"
      end
    end

    if err==false then
      local tmp1
      if config[2][1]==0 then
        tmp1=0
      else
        tmp1=math.floor((config[2][2]/config[2][1])*100)
      end
      formspec=formspec.."textlist[3.5,4;5.75,2;power#"..cpos.x ..":".. cpos.y ..":".. cpos.z..";"
      local phr="refresh list"
      local length=#config[3][4]
      if type(config[3][4])=="table" then
      for i=1,length do
        local idx=config[3][4][i]

        if config[3][4][i]>0 then
          phr=spacengine.upgrade[3][idx][3]
        end
        --for j=1,length do
          --if string.sub(spacengine.upgrade[3][j][1],2,2)==config[3][4][i] then
            --phr=spacengine.upgrade[3][idx][3]
           -- break
          --end
        --end
        if config[3][5][i]==0 then
          formspec=formspec..phr.." : OFF"
        else
          formspec=formspec..phr.." : ON"
        end
        if i<length then formspec=formspec.."," end
      end
      else
        formspec=formspec.."Refresh list"
      end
      formspec=formspec..";1;]label[3.5,3;Power Moy. : ".. config[3][3].."]label[3.5,2.5;Bat. level ".. tmp1 .." %]"
      
    end

  --*** engine ***
  elseif group==4 or scr_opt=="E" then

    if scr_opt~="E" then
      formspec=formspec.. "label[0,3.5;Teslas : ".. spac_eng[4] .."]label[0,4;Range : ".. spac_eng[5] .."]label[0,4.5;Cooler : ".. spac_eng[6] .."]label[0,5;Charge max: ".. spac_eng[7] .."]"
    end

    if err==false then
      local puissance=math.ceil(config[4][1]*(config[4][2]/100))
      
      local rmax=spacengine.conso_engine(cpos,config,1)
      local secteur,bloc=espace.secteur(cpos)
      formspec=formspec.."label[3,0;Poids vaisseaux]label[3,0.35;".. config[1][2] .." Kg]label[6.5,0;Poids max decollage]label[6.5,0.35;".. config[4][7] .."]"..
      "field[3.3,3.5;2,1;data1;Puissance;".. config[4][2] .."]field[3.3,2.35;3,1;data2;secteur;".. secteur.nb+1 .."]field[6.8,2.35;3,1;data3;bloc;"..bloc.nb+1 .."]"..
      "label[3,4;Xmin".. cpos.x-rmax .."]label[5,4;X".. cpos.x .."]label[7,4;Xmax".. cpos.x+rmax .."]label[3,4.35;Ymin".. cpos.y-rmax .."]label[5,4.35;Y"..cpos.y.."]label[7,4.35;Ymax".. cpos.y+rmax .."]label[3,4.7;Zmin".. cpos.z-rmax .."]label[5,4.7;Z"..cpos.z.."]label[7,4.7;Zmax".. cpos.z+rmax .."]field[6.8,3.5;3,1;pos_dst;Destination;"..config[1][6][1].." "..config[1][6][2].." "..config[1][6][3].."]"

      if config[4][6]==0 then
        formspec=formspec.."button_exit[6.5,5.35;3,1;jump;ENGINE START]"
      else
        formspec=formspec.."label[6.5,5.35;>WAIT<]" 
      end

    end

  --**************
  --*** shield ***
  --**************
  elseif group==5 or scr_opt=="S" then
    if scr_opt~="S" then
      formspec=formspec.."label[0,3.5;Protection : ".. spac_eng[4].."]"
    end

    if err==false then
      formspec=formspec.."label[4,1.5;Regeneration : "..config[5][3].."]label[4,2;Damage shield : "..config[5][4].."]label[4,2.5;Protect total : "..config[5][1].."]field[4.3,3.75;2,1;data1;Puissance;".. config[5][2] .."]"
    end

  --***************
  --*** weapons ***
  --***************
  elseif group==6 or scr_opt=="W" then
    if scr_opt~="W" then
      formspec=formspec.."label[0,3.5;Power : "..spac_eng[4].."]label[0,4;Range : "..spac_eng[5].."]label[0,4.5;Speed : "..spac_eng[6].."]"
    end
    if err==false then
      formspec=formspec.."field[4.3,1.75;2,1;data1;Puissance;".. config[6][2] .."]field[4.3,3;2,1;data2;Range;".. config[6][4] .."]field[6.5,1.75;3,1;data3;COORDO;".. config[4][4][1] .." ".. config[4][4][2] .." ".. config[4][4][3] .." ".. config[4][4][4] .."]"
      --if config[6][6]==0 then
      --  formspec=formspec.."button_exit[6.5,4.15;3,1;jump;WEAPONS FIRE]"
      --else
      --  formspec=formspec.."label[6.5,4.15;>WAIT<]" 
      --end
    end

  --*************
  --*** radar ***
  --*************
  elseif group==7 or scr_opt=="R" then
    if scr_opt~="R" then
      formspec=formspec.."label[0,3.5;Range : ".. spac_eng[5].."]"
    end

    if err==false then
      formspec=formspec.."field[4.3,1.75;2,1;data1;Puissance;".. config[7][1] .."]"
    end    

  --*******************
  --*** gravitation ***
  --*******************
  elseif group==8 or scr_opt=="G" then
    if scr_opt~="G" then
      formspec=formspec.."label[0,3.5;Gravitation : ".. spac_eng[4].." G]"
    end
    if err==false then
      formspec=formspec.."field[4.3,1.75;2,1;data1;Puissance;".. config[8][2] .."]"
    end

  --***************
  --*** storage ***
  --***************
  elseif group==9 or scr_opt=="s" then
    
    if err==false then
      --if espace ?
      --local secteur,bloc=espace.secteur(pos)

      if secteur_dat[bloc.nb+1]==9 then --proximiter d'un commerce
        formspec=formspec.."image_button[2.25,8;1,1;spacengine_commerce.png;commerce;]"
      end
    end
    

  --*****************
  --*** passenger ***
  --*****************
  elseif group==10 or scr_opt=="p" then

    if err==false then
      --if espace ?
      --local secteur,bloc=espace.secteur(pos)

      if secteur_dat[bloc.nb+1]==9 then --proximiter d'un commerce
        formspec=formspec.."image_button[2.25,8;1,1;spacengine_commerce.png;commerce;]"
      end
    end

  --***************
  --*** oxygene ***
  --***************
  elseif group==11 or scr_opt=="O" then
    if scr_opt~="O" then
      formspec=formspec.."label[0,3.5;Power : ".. spac_eng[4].."]label[0,4;Seuil : ".. spac_eng[5].."]"
    end
    if err==false then
      formspec=formspec.."field[4.3,1.75;2,1;data1;Puissance;".. config[11][2] .."]"
    end

  --*******************
  --*** manutention ***
  --*******************
  elseif group==13 or scr_opt=="M" then
    if scr_opt~="M" then
    end

  end
end
  spacengine.gui_form[pl_name]="spacengine#".. option .."#".. spacengine.pts(pos)
  return minetest.show_formspec(pl_name, "spacengine" , formspec)
end
