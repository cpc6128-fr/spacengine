commerce={}
--[[
local storage = minetest.get_mod_storage()
local city_data
citymap.load()
minetest.register_on_shutdown(citymap.save)
   
function citymap.load()
    city_data = minetest.parse_json(storage:get_string("city_data")) or {}
end
   
function citymap.save()
    storage:set_string("city_data", minetest.write_json(city_data))
end
--[[
    creation d'un village
    sauvegarde plot marker - data dans fichier
    0-HUT
    1-farming
    2-house
    3-public
    4-mine
    6-building
    7-infrastructure
   
  farming = farm/lumberjack
  public = magasin/atelier/bank
  infrastructure = route/train/bateau/aeroport
   
   "village name" / position matrice / stage / date / {"building",pos,wlh}
   

--]]
local mp_c=minetest.get_modpath("commerce")
dofile(mp_c .. "/data3.lua")
dofile(mp_c .. "/commerce.lua")
dofile(mp_c .. "/bank.lua")
dofile(mp_c .. "/coffre.lua")
dofile(mp_c .. "/licence.lua")
dofile(mp_c .. "/transport.lua")
dofile(mp_c .. "/civilisation2.lua")

--_____________________________________________________
