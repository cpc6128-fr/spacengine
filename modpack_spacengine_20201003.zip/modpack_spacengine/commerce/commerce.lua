--*************
--** magasin **
--*************

--** fonction de base **

-- lecture de l'inventaire et renvoie l'index d'un item + tout ses metadata...
commerce.found_item_index=function(player,item)
  local index=0
  local inv=player:get_inventory()
  local stackname,stackcount,stackwear,stackmeta
  for i=1,32 do
    local stack=inv:get_stack("main",i)
    stackname=stack:get_name()
    if item==stackname then
      index=i
      stackcount=stack:get_count()
      stackwear=stack:get_wear()
      stackmeta=stack:get_metadata()
      break
    end
  end
  return index,stackcount,stackwear,stackmeta
end

--***************************
--** transaction with card **
--***************************
--stack=item / card=prix transaction
commerce.transaction=function(player,stack,card)
  local name=player:get_player_name()
  local inv = player:get_inventory()
  local havecard=commerce.found_item_index(player,"commerce:card")

  if havecard>0 then --si card presente
    if atm.balance[name]~= nil then
      if atm.balance[name]-card>0 then
        atm.balance[name] = atm.balance[name]-card
        if stack~=nil then inv:add_item("main",stack) end
        atm.saveaccounts()
        minetest.sound_play("card2",{to_player=name,gain=1.5})
        minetest.chat_send_player(name,"Account : ".. atm.balance[name])
        return true
      end
    end
  end
  return false
end

--*******************************
--** transaction money or card **
--*******************************
--index = numero objet dans commerce.item / quantity = nb d'objet / money="nodename xx" / card = nil ou montant transaction
local magasin_transaction=function(player,index,money,quantity,card)
  local err=0
  local name=player:get_player_name()
  local xp=25--xpgetlvl(player,"xp_lvl")+1

  local objet=commerce.item[index]

  
    local inv = player:get_inventory()
    local stack=objet[2] .." "..quantity
    local havecard=commerce.found_item_index(player,"commerce:card")

    if card~=nil and havecard>0 and havecard<9 then --si card presente dans le haut de l'inventaire (a l'ecran)
      if atm.balance[name]== nil then return end
      if atm.balance[name]-card>0 then
        atm.balance[name] = atm.balance[name]-card
        inv:add_item("main",stack)
        atm.saveaccounts()
        minetest.sound_play("card2",{to_player=name,gain=1.5})
        err=1
        minetest.chat_send_player(name,"Account : ".. atm.balance[name])
      end

    else --or with money
      if inv:contains_item("main",money) then
        inv:remove_item("main", money)
        inv:add_item("main",stack)
        minetest.sound_play("money",{to_player=name,gain=1.5})
        err=1
      end
    end
  
  if err==0 then
    minetest.sound_play("wrong",{to_player=name,gain=1.5})
  end
end

--********************
--** create magasin **
--********************
local function fill_shop(shop_pos,dealertype,item_type,size)
  if size==nil then size=16 end
  local meta = minetest.get_meta(shop_pos)
  local inv = meta:get_inventory()
  inv:set_size("pay",size)
  inv:set_size("objet",size)
  local trade_index = 1
  local trades_already_added = ""
  local price=0
  local money="currency:minegeld"
  local objet={}
  local list_item=""
  local quantity=0
  local trades = {}
  
  --par type ou aleatoire ?
  if item_type==nil then
      item_type=0
  end

  -- nb d'item enregistrer
  local nb_item = #commerce.item
  --choix premier objet
  local choix_item=nb_item
  
	for i=1,size do
    choix_item=math.random(1,nb_item)
    local rnd=math.random(1,100)
    repeat
      objet=commerce.item[choix_item]  --recuperation des données
      if string.find(objet[6],dealertype) then --type magasin/chest/xpchest/trader/distributeur
        -- objet deja selectionner ?
        if string.find(trades_already_added,objet[2])== nil then
              
          if item_type==0 or item_type==objet[1] then
            if objet[4]>rnd then
            list_item=list_item..choix_item.."/"
            inv:set_stack("objet",i,objet[2])
            trades_already_added=trades_already_added.." "..objet[2]
            choix_item=1
            end
          end
        end
      end
      rnd=rnd-1.5
      choix_item=choix_item-3
    until choix_item<1

  end

  --date de creation + delai
  local creat_dat=((espace.year-1)*168)+((espace.month-1)*14)+espace.day+math.random(40,80)
  meta:set_int("visit",creat_dat)
  meta:set_int("inflation",math.random(10))--TODO suivant secteur civilisation
  meta:set_string("list_item",list_item)

end


local function price_shop(player,shop_pos,card)
  local meta = minetest.get_meta(shop_pos)
  local inv = meta:get_inventory()
  local trades
  local inflation=meta:get_int("inflation")
  local tmp=meta:get_string("list_item")
  local list_item=string.split(tmp,"/")
  local xp=25--xpgetlvl(player,"xp_lvl")+1

  local formspec= "size[8,11]bgcolor[#080808BB;true]background[0,0;1,1;commerce_magasin1.png;true]listcolors[#00000069;#5A5A5A;#141318;#30434C;#FFF]"
  if card==true then
    formspec=formspec.."image[0,5.5;1.5,1.5;commerce_accept_cb.png]"
  end
  local x, y=0,0
	local newprice
  for i=1,#list_item do
    trades=inv:get_stack("objet",i):get_name()

    -- effacement stack
    inv:set_stack("pay",i,"")
    local objet=""
    local money="currency:minegeld"
    local quantity=1
    local index
    if trades then
      index=tonumber(list_item[i])
      local item_data=commerce.item[index]
      objet=item_data[2]
      local price=math.ceil(item_data[3]*(inflation/100))
      newprice=math.ceil(price*((25+(xp*4))/100)) --taux différent suivant XP
      --currency calcul
    if newprice>2500 then
      quantity=math.ceil(newprice/100)
      money="currency:minegeld_100"
      newprice=quantity*100
    elseif newprice>500 then
      quantity=math.ceil(newprice/50)
      money="currency:minegeld_50"
      newprice=quantity*50
    elseif newprice>250 then
      quantity=math.ceil(newprice/10)
      money="currency:minegeld_10"
      newprice=quantity*10
    elseif newprice>50 then
      quantity=math.ceil(newprice/5)
      money="currency:minegeld_5"
      newprice=quantity*5
    elseif newprice>12.5 then
      quantity=math.ceil(newprice)
      money="currency:minegeld"
      newprice=quantity*1
    elseif newprice>2.5 then
      quantity=math.ceil(newprice/0.25)
      money="currency:minegeld_cent_25"
      newprice=quantity*0.25
    elseif newprice>0 then
      quantity=math.ceil(newprice/0.05)
      money="currency:minegeld_cent_5"
      newprice=quantity*0.05
    end

      formspec = formspec.."item_image_button["..x ..",".. y ..";1,1;".. objet ..";objet#".. money .."#".. quantity .."#".. index .."#".. newprice ..";]item_image_button[".. x+1 ..",".. y ..";1,1;".. money .." ".. quantity ..";prices;]label[".. x+0.75 ..",".. y+0.9 ..";".. newprice .."]"

      x=x+2
      if x>6 then
        x = 0
        y = y+1.4
      end

    end
 
    inv:set_stack("pay",i,money)
  end
  formspec = formspec.."button_exit[3,6;2,1;exit;exit]list[current_player;main;0,7;8,4;]";

  if card==true then
    minetest.show_formspec(player:get_player_name(), "magasin#2", formspec)
  else
    minetest.show_formspec(player:get_player_name(), "magasin#1", formspec)
  end

end

--******************
--** node magasin **
--******************
minetest.register_node("commerce:magasin", {
	description = "stand de vente",
  tiles = {
		"commerce_borne_bottom.png",
		"commerce_borne_bottom.png",
		"commerce_etagere_vide.png",
		"commerce_etagere_vide.png",
		"commerce_nourriture1.png",
		"commerce_nourriture3.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
  paramtype2 = "facedir",
	groups = {cracky=2},--unbreakable = 1, not_in_creative_inventory = 1},
	legacy_facedir_simple = true,
	is_ground_content = false,
  on_construct = function(pos)
        fill_shop(pos,"m",0,16) --pos,type de magasin,type objet,size
  end,
  on_rightclick = function(pos,node,player,itemstack,_)
    local meta = minetest.get_meta(pos)
    local old_dat=meta:get_int("visit")
    local new_dat=((espace.year-1)*168)+((espace.month-1)*14)+espace.day

    if old_dat<new_dat then --si depasse la date, refill new item
      fill_shop(pos,"m",0,16)
    end
    price_shop(player,pos,true)
  end,
})

minetest.register_node("commerce:automatic_distributor", {
	description = "automatic distributor",
  tiles = {
		"commerce_distributor_e.png",
	},
	drawtype = "mesh",
  mesh = "homedecor_soda_machine.obj",
selection_box = {
	type = "fixed",
	fixed = {-0.5, -0.5, -0.5, 0.5, 1.5, 0.5}
},
	collision_box = {
	type = "fixed",
	fixed = {-0.5, -0.5, -0.5, 0.5, 1.5, 0.5}
},
	paramtype = "light",
  paramtype2 = "facedir",
	groups = {cracky=2},--unbreakable = 1, not_in_creative_inventory = 1},
	legacy_facedir_simple = true,
	is_ground_content = false,
  on_construct = function(pos)
        fill_shop(pos,"d",0,10)
  end,
  on_rightclick = function(pos,node,player,itemstack,_)
    local meta = minetest.get_meta(pos)
    local old_dat=meta:get_int("visit")
    local new_dat=((espace.year-1)*168)+((espace.month-1)*14)+espace.day

    if old_dat<new_dat then --si plus de 3 mois, refill new item
      fill_shop(pos,"d",0,10)
    end

    price_shop(player,pos,false)
  end,
})

--*********************************
--** commerce avec les vaisseaux **
--********************************

local chg_form={}

local item_type={"eat","ores","tools","build","machine","furniture"}

--calcul distance entre vaisseaux et commerce
local function distance(pos,channel,owner)
  local found,cpos=spacengine.test_area_ship(0,0,channel..":"..owner)
  if found then
    d={x=math.abs(cpos.x-pos.x),y=math.abs(cpos.y-pos.y),z=math.abs(cpos.z-pos.z)}
    d.max=math.max(d.x,d.y,d.z)
    if d.max<160 then
      return true
    end
  end
return false
end

--list tout les vaisseaux du player a proximiter du commerce 160 bloc max
local function list_vaisseaux(pos,player)
  local list=""
  local nb=1
  local plname=player:get_player_name()
  local vaisseaux=player:get_attribute("vaisseaux")
  
  if vaisseaux==nil then return "No channel","" end

  local split_vaisseaux=string.split(vaisseaux,":")
  vaisseaux=""

  for i=1,#split_vaisseaux do
    if split_vaisseaux[i]==nil then
      break
    else
      local found=distance(pos,split_vaisseaux[i],plname)
      if found then
        if nb==1 then vaisseaux=split_vaisseaux[i] end
        list=list..split_vaisseaux[i]..","
        nb=nb+1
      end
    end
  end

  return list.."No channel",vaisseaux
end

--initialise cargo
local function cargo(plname)
  chg_form[plname].marchandise=0
  chg_form[plname].poids_total=0
  chg_form[plname].poids=0

  if chg_form[plname].vaisseaux~="" then
    local channel=chg_form[plname].vaisseaux ..":".. plname
    chg_form[plname].poids_total=spacengine.area[channel].config[9][1]
    chg_form[plname].poids=spacengine.area[channel].config[9][2]

    if chg_form[plname].objet_type~=0 then
      chg_form[plname].marchandise=spacengine.area[channel].config[9][3][chg_form[plname].objet_type]
    end

  end

end

--**************************
--** ITEM -> MARCHANDISE  **
--**************************

--recherche item et type
local function objet_select(plname,inv)
  local stack=inv:get_stack("src",1)
  local nb_obj=#commerce.item
  local name=stack:get_name()
  chg_form[plname].price=0
  chg_form[plname].objet_type=0

  repeat
    objet=commerce.item[nb_obj]

    if name==objet[2] then
      local quantity=stack:get_count() -- nb objet
      chg_form[plname].price=math.ceil(objet[3]*quantity*chg_form[plname].inflation)
      chg_form[plname].objet_type=objet[1]
      nb_obj=0
    end

    nb_obj=nb_obj-1
  until nb_obj<1

end

--affichage formspec
local function affichage_item(plname)
  local valid=0
  local form="size[12,11]list[current_player;main;4,7;8,4;]button_exit[0,10;2,1;exit;exit]list[nodemeta:"..
  chg_form[plname].pos ..";src;5,0;1,1;]label[9,0;"..plname.."]textlist[0,0;4,1.3;spaceship;"..
  chg_form[plname].list ..";".. chg_form[plname].select .."]"

  if chg_form[plname].vaisseaux~="" then
    form=form.."label[0,7;Cargo ".. chg_form[plname].poids .."/"..
    chg_form[plname].poids_total .."]"
    valid=valid+1
  end

  if chg_form[plname].objet_type~=0 then
    form=form.."label[0,7.5;".. chg_form[plname].price .." "..item_type[chg_form[plname].objet_type] .."]"
    valid=valid+1
  end
  
  if valid==2 then
    form=form.."label[0,8;Marchandise "..item_type[chg_form[plname].objet_type] .." : "..
    chg_form[plname].marchandise .."]button[0,9;2,1;item;accept]"
  end

  return minetest.show_formspec(plname,"commerce_i", form)
end

--node commerce item
minetest.register_node("commerce:green_deal", {
  description = "magasin card",
  tiles = {"spacengine_batterie_left.png", "spacengine_batterie_left.png", "spacengine_batterie_left.png", "spacengine_batterie_left.png", "spacengine_batterie_front.png", "commerce_green.png"},
  paramtype = "light",
  paramtype2 = "facedir",
  groups = {cracky=2},--unbreakable = 1, not_in_creative_inventory = 1},
  on_rotate = screwdriver.rotate_simple,
  on_construct = function(pos)
    local meta = minetest.get_meta(pos)
    local inv = meta:get_inventory()
    inv:set_size('src', 1)
    --date de creation + delai et inflation
    local creat_dat=((espace.year-1)*168)+((espace.month-1)*14)+espace.day+math.random(40,80)
    meta:set_int("visit",creat_dat)
    meta:set_int("inflation",math.random(10))
  end,

  on_rightclick = function(pos,node,player)
    local havelicence=commerce.found_item_index(player,"commerce:licence")
    if havelicence>0 then --si card presente
      local _,_,_,stackmeta=commerce.found_item_index(player,"commerce:licence")
      if string.find(stackmeta,"commerce")==nil then
        minetest.sound_play("wrong",{to_player=name,gain=1.5})
        return
      end
    else
      minetest.sound_play("wrong",{to_player=name,gain=1.5})
      return
    end

    local meta = minetest.get_meta(pos)
    local inv = meta:get_inventory()
    local plname=player:get_player_name()
    local old_dat=meta:get_int("visit")
    local new_dat=((espace.year-1)*168)+((espace.month-1)*14)+espace.day

    if old_dat<new_dat then --si depasse la date, refill new item
      meta:set_int("visit",new_dat+math.random(40,80))
      meta:set_int("inflation",math.random(10))
    end

    local list,vaisseaux=list_vaisseaux(pos,player)
    chg_form[plname]={}
    chg_form[plname].inflation=meta:get_int("inflation")
    chg_form[plname].list=list
    chg_form[plname].select=1
    chg_form[plname].vaisseaux=vaisseaux
    chg_form[plname].pos= pos.x ..",".. pos.y ..",".. pos.z
    objet_select(plname,inv)
    cargo(plname)
    affichage_item(plname)
  end,

  on_metadata_inventory_put = function(pos,listname, index, stack, player)
    local plname=player:get_player_name()
    local meta = minetest.get_meta(pos)
    local inv = meta:get_inventory()
    objet_select(plname,inv)
    cargo(plname)
    affichage_item(plname)
  end,

  on_metadata_inventory_take = function(pos, listname, index, stack, player)
    local plname=player:get_player_name()

    if listname=="src" then
      chg_form[plname].objet_type=0
      chg_form[plname].price=0
      affichage_item(plname)
    end

	end,
})

--**************************
--** MARCHANDISE --> ITEM **
--**************************

local function item_list(plname)
  local item_nb=#commerce.item
  local form=""

  repeat
    if commerce.item[item_nb][1]==chg_form[plname].objet_type then
      local calcul=math.ceil(commerce.item[item_nb][3]*chg_form[plname].inflation)
      form=form..commerce.item[item_nb][2].." ".. calcul
      if item_nb>1 then
        form = form..","
      end
    end
    item_nb=item_nb-1
  until item_nb<1

  chg_form[plname].list_item=form
end

--affichage formspec
local function affichage_marchandise(plname)
  local form="size[12,11]list[current_player;main;4,7;8,4;]button_exit[0,10;2,1;exit;exit]label[9,0;"..
  plname.."]textlist[0,0;4,1.3;spaceship;".. chg_form[plname].list ..";".. chg_form[plname].select .."]textlist[4.5,0;4,1.3;marchandise;eat,ores,tools,build,machine,furniture;".. chg_form[plname].objet_type .."]"

  if chg_form[plname].vaisseaux~="" then
    form=form.."label[0,7;Cargo ".. chg_form[plname].poids .."/"..
    chg_form[plname].poids_total .."]label[0,7.5;Marchandise "..item_type[chg_form[plname].objet_type] .." : "..
    chg_form[plname].marchandise .."]"
    local split=string.split(chg_form[plname].list_item,",")
    local stack=string.split(split[chg_form[plname].objet_idx]," ")
    form=form.."textlist[0,2;5,4;objet;"..chg_form[plname].list_item..";"..chg_form[plname].objet_idx.."]item_image_button[7,3;2,2;".. stack[1] ..";transfert;"..stack[2].."]"
    
  end

  return minetest.show_formspec(plname,"commerce_m", form)
end

--node commerce marchandise
minetest.register_node("commerce:red_deal", {
  description = "magasin tonne",
  tiles = {"spacengine_batterie_left.png", "spacengine_batterie_left.png", "spacengine_batterie_left.png", "spacengine_batterie_left.png", "spacengine_batterie_front.png", "commerce_red.png"},
  paramtype = "light",
  paramtype2 = "facedir",
  groups = {cracky=2},--unbreakable = 1, not_in_creative_inventory = 1},
  on_rotate = screwdriver.rotate_simple,
  on_construct = function(pos)
    --initialisation item
    local meta = minetest.get_meta(pos)
    local inv = meta:get_inventory()
    inv:set_size('dst', 60)
    --date de creation + delai et inflation
    local creat_dat=((espace.year-1)*168)+((espace.month-1)*14)+espace.day+math.random(40,80)
    meta:set_int("visit",creat_dat)
    meta:set_int("inflation",math.random(10))
  end,

  on_rightclick = function(pos,node,player)
    local havelicence=commerce.found_item_index(player,"commerce:licence")
    if havelicence>0 then --si card presente
      local _,_,_,stackmeta=commerce.found_item_index(player,"commerce:licence")
      if string.find(stackmeta,"commerce")==nil then
        minetest.sound_play("wrong",{to_player=name,gain=1.5})
        return
      end
    else
      minetest.sound_play("wrong",{to_player=name,gain=1.5})
      return
    end

    --initialisation item
    local meta = minetest.get_meta(pos)
    local inv = meta:get_inventory()
    local plname=player:get_player_name()
    local old_dat=meta:get_int("visit")
    local new_dat=((espace.year-1)*168)+((espace.month-1)*14)+espace.day

    if old_dat<new_dat then --si depasse la date, refill new item
      meta:set_int("visit",new_dat+math.random(40,80))
      meta:set_int("inflation",math.random(10))
    end

    local list,vaisseaux=list_vaisseaux(pos,player)
    chg_form[plname]={}
    chg_form[plname].inflation=meta:get_int("inflation")
    chg_form[plname].list=list
    chg_form[plname].select=1
    chg_form[plname].vaisseaux=vaisseaux
    chg_form[plname].pos= pos.x ..",".. pos.y ..",".. pos.z
    chg_form[plname].objet_type=1
    chg_form[plname].objet_idx=1
    chg_form[plname].list_item=""
    cargo(plname)
    item_list(plname)
    affichage_marchandise(plname)
  end,
})

minetest.register_on_player_receive_fields(function(player, formname, fields)
  if string.find(formname,"commerce") then
    local plname=player:get_player_name()

    if fields.quit then
      chg_form[plname]=nil
    end

    if fields.item then
      if chg_form[plname].vaisseaux=="" then
        return
      end

      if chg_form[plname].objet_type==0 then
        return
      end

      local total=chg_form[plname].poids+chg_form[plname].price

      if chg_form[plname].poids_total > total then
        local channel=chg_form[plname].vaisseaux ..":".. plname
        local nb=chg_form[plname].objet_type
        spacengine.area[channel].config[9][2]=total
        spacengine.area[channel].config[9][3][nb]=spacengine.area[channel].config[9][3][nb]+chg_form[plname].price
        chg_form[plname].poids=spacengine.area[channel].config[9][2]
        chg_form[plname].price=0
        chg_form[plname].objet_type=0
        local cpos=spacengine.area[channel].p0
        local cont_met = minetest.get_meta(spacengine.area[channel].p0)
        cont_met:set_string("config",spacengine.compact(spacengine.area[channel].config))

        local split=string.split(chg_form[plname].pos,",")
        local pos={x=split[1],y=split[2],z=split[3]}
        local meta = minetest.get_meta(pos)
        local inv = meta:get_inventory()
        inv:set_stack("src",1,"")
      end
    end

    if fields.spaceship then
      if string.find(fields.spaceship,"CHG:") then
      chg_form[plname].select=string.gsub(fields.spaceship,"CHG:","")
      local nb=tonumber(chg_form[plname].select)
      local split=string.split(chg_form[plname].list,",")

      if split[nb]~="No channel" then
        local channel=split[nb]..":"..plname
        chg_form[plname].vaisseaux=split[nb]
        chg_form[plname].poids_total=spacengine.area[channel].config[9][1]
        chg_form[plname].poids=spacengine.area[channel].config[9][2]
        cargo(plname)
      else
        chg_form[plname].vaisseaux=""
        chg_form[plname].poids_total=0
        chg_form[plname].poids=0
      end
      end
    end

    if fields.marchandise then
      if string.find(fields.marchandise,"CHG:") then
      local nb=string.gsub(fields.marchandise,"CHG:","")
      chg_form[plname].objet_type= tonumber(nb)
      chg_form[plname].objet_idx=1

      if chg_form[plname].vaisseaux~="" then
        cargo(plname)
        item_list(plname)
      end
      end
    end

    if fields.objet then --choix item
      if string.find(fields.objet,"CHG:") then
        local nb=string.gsub(fields.objet,"CHG:","")
        chg_form[plname].objet_idx=tonumber(nb)
      end
    end

    if fields.transfert then
      local nb=chg_form[plname].objet_idx
      local split=string.split(chg_form[plname].list_item,",")

      local stack=string.split(split[nb]," ")

      local inv = player:get_inventory()

      local total=chg_form[plname].marchandise-tonumber(stack[2])

      if total>-1 then
        if inv:room_for_item("main",stack[1]) then
        local channel=chg_form[plname].vaisseaux ..":".. plname
        nb=chg_form[plname].objet_type
        spacengine.area[channel].config[9][2]=spacengine.area[channel].config[9][2]-tonumber(stack[2])
        spacengine.area[channel].config[9][3][nb]=total
        local cpos=spacengine.area[channel].p0
        local cont_met = minetest.get_meta(spacengine.area[channel].p0)
        cont_met:set_string("config",spacengine.compact(spacengine.area[channel].config))
        inv:add_item("main",stack[1])
        cargo(plname)
        affichage_marchandise(plname)
        end
      end

    end

    if not fields.quit then
      if string.find(formname,"_i") then
        return affichage_item(plname)
      else
        return affichage_marchandise(plname)
      end
    end
  
  end

end)
