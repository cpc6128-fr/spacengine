--** AUTORISATION **
--[["ticket#00000/00000/00000#"
local stargate="size[11,9]"..
        "background[0,0;1,1;ticket_stargate.png;true]"..
        "image_button[0,0;2,1;bg_green.png;stargate;stargate]"..
        "image_button[3,0;2,1;bg_darkred.png;boarding;boarding]"..
        "image_button[6,0;2,1;bg_darkred.png;transfert;planete]"..
        "button[9,8;2,1;accept;accept]"..
        "button_exit[0,8;2,1;exit;exit]"

local boarding="size[11,9]"..
        "image_button[0,0;2,1;bg_darkred.png;stargate;stargate]"..
        "image_button[3,0;2,1;bg_green.png;boarding;boarding]"..
        "image_button[6,0;2,1;bg_darkred.png;transfert;planete]"..
        "button_exit[0,8;2,1;exit;exit]"

local transfert="size[11,9]"..
        "image_button[0,0;2,1;bg_darkred.png;stargate;stargate]"..
        "image_button[3,0;2,1;bg_darkred.png;boarding;boarding]"..
        "image_button[6,0;2,1;bg_green.png;transfert;planete]"..
        "button_exit[0,8;2,1;exit;exit]"

local function init_ticket(pos,player)
  local plname=player:get_player_name()
  local position=shop_postostring(pos)
  local meta=minetest.get_meta(pos)
  local secteur,_,astroport,_,planete=startest.position(pos)
  local xp=xpgetlvl(player,"xp_lvl")+1
  local zone=math.min(10,math.ceil(xp/5))
  local dblzone=zone*10
  local zonex=math.max(1,secteur.x-zone)
  local zonez=math.max(1,secteur.z-zone)
  local zoney=math.max(1,secteur.y-math.floor(zone/2))
  local posx=""
  local posy=""
  local posz=""
  -- list coordo suivant xp
  for i=0,dblzone do
    posx=posx..zonex+i
    if zonex+i==96 then
      break
    else
      posx=posx..","
    end
  end
  for i=0,dblzone do
    posz=posz..zonez+i
    if zonez+i==96 then
      break
    else
      posz=posz..","
    end
  end
  dblzone=zone*10
  for i=1,dblzone do
    posy=posy..zoney+i
    if zoney+i==14 then
      break
    else
      posy=posy..","
    end
  end
  meta:set_string("posx",posx)
  meta:set_string("posy",posy)
  meta:set_string("posz",posz)

  formspec=stargate.."textlist[1,2;1,2;posx;".. posx ..";1;true]"..
            "textlist[5,2;1,2;posy;".. posy ..";1;true]"..
            "textlist[9,2;1,2;posz;".. posz ..";1;true]"
  if planete~=nil then

  end

  return formspec,position,plname
end
--]]
--[[
  mission  :
 transport :
  explorer :
   battle  :
    type     :
 marchandise :
  passenger  :
   extract   :
  construct  :
  sect. :
 129000 :
   price    
 5000000 mg :
--]]
local formspec_update=function(pos,channel,data)

  local formspec="size[8,10]button_exit[5.5,3;2,1;exit;exit]button[3,3;2,1;accept;accept]"..
    "background[0,0;1,1;transport.png;true]"..
    "label[0,0;mission]label[1.5,0;type]label[3,0;secteur]label[4.5,0;price]"..
    "textlist[0,0.5;7.5,2;mission;transport : marchandise : sect.129000 : 25000 Mg : 18/8/2019,transport : voyager : sect.57800 : 50000 Mg : 25/8/2019,explorer : extract : sect.88025 : 5000 Mg : 18/8/2019,explorer : construct : sect.88025 : 5000 Mg,transport : marchandise : sect.88025 : 5000 Mg;1;true]"..
    "list[current_name;input;6.5,4.5;1,1;]button[6,5.5;2,1;cargo;cargo]"..
    "button[0.5,3;2,1;info;info]"..
    "textarea[0.25,5;5,2;descript;description des missions;Transport de marchandise pour le secteur 129000,ores 15000 Kg,furniture 5000 Kg,prix 50000 Mg, bonus temps 500 Mg livraison avant le 18/8/2019 l'offre expire dans 2 Jours]"..
    "list[current_player;main;0,7.85;8,1;]list[current_player;main;0,9.15;8,1;8]"

  
  return formspec
end

minetest.register_node("commerce:guichet_b", {
description = "guichet B",
	tiles = {
		"commerce_guichetd.png",
		"commerce_guichetd.png",
		"commerce_guichetd.png^[transformR90",
		"commerce_guichetd.png^[transformR90",
		"commerce_guichetc.png",
		"commerce_guichetb.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
paramtype2 = "facedir",
use_texture_alpha = true,
groups = {cracky=3},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.375, -0.0625, 0.5, 0.5, 0.0625}, -- NodeBox1
			{-0.5, -0.5, -0.5, 0.5, -0.375, 0.5}, -- NodeBox2
		}
	},
on_construct=function(pos)
  local meta = minetest.get_meta(pos)
  local inv = meta:get_inventory()
  inv:set_size("input", 1)
  local channel="No channel"
  local data="CNM beta10/1/battery_level1.png/1/250/250/10"
  meta:set_string("channel",channel)
  meta:set_string("infotext",data)
  meta:set_string("formspec", formspec_update(pos,channel,data))
end,
on_receive_fields=function(pos,formname,fields,sender)

end
})
--[[
minetest.register_on_player_receive_fields(function(player, formname, fields)

if string.find(formname,"ticket") then
  local new_formspec=false
  local position=string.sub(formname,8,24)
  local plname=player:get_player_name()
  local pos=shop_postonumber(position)
  local meta=minetest.get_meta(pos)
  local formspec --=player:get_formspec(formname)
  if fields.boarding~=nil then
    formname= "ticket#"..position.."#boarding"
    formspec=boarding
    new_formspec=true
  elseif fields.transfert~=nil then
    formname= "ticket#"..position.."#transfert"
    formspec=transfert
    new_formspec=true
  elseif fields.stargate~=nil then
    formname= "ticket#"..position.."#stargate"
    formspec=stargate
    new_formspec=true
  end

  if string.find(formname,"stargate") then
    if fields.posx~=nil then
      meta:set_string("posx",fields.posx)
    elseif fields.posy~=nil then
      meta:set_string("posy",fields.posy)
    elseif fields.posz~=nil then
      meta:set_string("posz",fields.posz)
    end
  elseif string.find(formname,"boarding") then
    
  elseif string.find(formname,"transfert") then
    
  end

  if new_formspec==true then
    minetest.show_formspec(plname, formname, formspec)
  end
end
  
end)
--]]
