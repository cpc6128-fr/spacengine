
--position du magasin integration sous la forme 00000/00000/00000
local function shop_postostring(shop_pos)
  local tmp=tostring(shop_pos.x+131000)
  local position=string.sub(tmp,2)
  tmp=tostring(shop_pos.y+131000)
  position=position.."/"..string.sub(tmp,2)
  tmp=tostring(shop_pos.z+131000)
  position=position.."/"..string.sub(tmp,2)
  return position
end

--position du magasin extraction
local function shop_postonumber(position)
  local shop_pos={x=0,y=0,z=0}
  local list=string.split(position,"/")
  shop_pos.x=tonumber(list[1])-31000
  shop_pos.y=tonumber(list[2])-31000
  shop_pos.z=tonumber(list[3])-31000
  return shop_pos
end
--
-- ** GUICHET FEDERATION GALACTIQUE **
--** LICENCE **
minetest.register_node("citymap:guichet_a", {
description = "guichet A",
	tiles = {
		"guichetd.png",
		"guichetd.png",
		"guichetd.png^[transformR90",
		"guichetd.png^[transformR90",
		"guichetc.png",
		"guicheta.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
paramtype2 = "facedir",
use_texture_alpha = true,
groups = {cracky=3},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.375, -0.0625, 0.5, 0.5, 0.0625}, -- NodeBox1
			{-0.5, -0.5, -0.5, 0.5, -0.375, 0.5}, -- NodeBox2
		}
	},
on_construct = function(pos)
    local meta = minetest.get_meta(pos)
    local inv = meta:get_inventory()
    
    meta:set_string("formspec", "size[8,9]background[0,0;1,1;licence_bg.png;true]"..
        "button[0,0;1,1;exploitation;50]label[1,0.25;EXPLOITATION]"..
        "button[0,1;1,1;commerce;100]label[1,1.25;COMMERCE]"..
        "button[0,2;1,1;marchandise;500]label[1,2.25;MARCHANDISE]"..
        "button[0,3;1,1;voyageur;1000]label[1,3.25;VOYAGEUR]"..
        "button[0,4;1,1;special;2000]label[1,4.25;SPECIAL]"..
        "item_image_button[4,3.5;1,1;citymap:licence;card;50]"..
        "button_exit[6.25,3.5;1.5,1;exit;exit]"..
        "list[current_player;main;0,5;8,4;]")
        
  end,
on_receive_fields=function(pos,formname,fields,sender)
  if fields.exit then
    return
  end
  local name = sender:get_player_name()
  local inv = sender:get_inventory()
  local stack={name="citymap:card",count=1}
  local index=0
  local price=0
  local licence=""
  local account=0
  local stackmeta
  if inv:contains_item("main",stack) then
    if fields.exploitation~=nil then
      price=50
      licence="exploitation"
    elseif fields.marchandise~=nil then
      price=500
      licence="marchandise"
    elseif fields.commerce~=nil then
      price=100
      licence="commerce"
    elseif fields.voyageur~=nil then
      price=1000
      licence="voyageur"
    elseif fields.special~=nil then
      price=2000
      licence="special"
    elseif fields.card~=nil then
      price=50
      licence="card"
    end
    if licence~="" then
      
      if not (atm.balance[name] == nil) then
        account=atm.balance[name]
      end
      if account-price>0 then
        index,_,_,stackmeta=citymap.found_item_index(sender,"citymap:licence")
        if licence~="card" then
          --test licence
          stack={name="citymap:licence",count=1}
          if inv:contains_item("main",stack) then
            if stackmeta=="" then
              stackmeta="licence : "
            end
            if string.find(stackmeta,licence)==nil then
              stackmeta=stackmeta.." "..licence
              --debit account
              atm.balance[name] = account-price
              --sound
              minetest.chat_send_player(name,stackmeta)
              atm.saveaccounts ()
            end
            inv:remove_item("main", "citymap:licence")
            inv:add_item("main", {name="citymap:licence", count=1, wear=0, metadata=stackmeta})
          end
        else
          if index>0 then return end
          --debit account
          atm.balance[name] = account-price
          --sound
          minetest.chat_send_player(name,"LICENCE")
          atm.saveaccounts ()
          inv:add_item("main", {name="citymap:licence", count=1, wear=0, metadata="Licence :"})
        end
      end
    end
  else
    minetest.chat_send_player(name,"NO CREDIT CARD PRESENT IN INVENTORY")
  end    
end,
})

--** AUTORISATION **

minetest.register_node("citymap:guichet_b", {
description = "guichet B",
	tiles = {
		"guichetd.png",
		"guichetd.png",
		"guichetd.png^[transformR90",
		"guichetd.png^[transformR90",
		"guichetc.png",
		"guichetb.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
paramtype2 = "facedir",
use_texture_alpha = true,
groups = {cracky=3},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.375, -0.0625, 0.5, 0.5, 0.0625}, -- NodeBox1
			{-0.5, -0.5, -0.5, 0.5, -0.375, 0.5}, -- NodeBox2
		}
	},
on_construct = function(pos)
    local meta = minetest.get_meta(pos)
    local inv = meta:get_inventory()
    
    meta:set_string("formspec", "size[8,9]"..
        "button[0,0;1,1;boarding;10]label[1,0.25;Arrimage]"..
        "button[0,1;1,1;transfert;20]label[1,1.25;Transfert]"..
        "button[0,2;1,1;stargate;500]label[1,2.25;Stargate]"..
        "button_exit[6,3;1,2;exit;exit]"..
        "list[current_player;main;0,5;8,4;]")
        
  end,
on_receive_fields=function(pos,formname,fields,sender)
  if fields.exit then
    return
  end
  local name = sender:get_player_name()
  local inv = sender:get_inventory()
  local stack={name="citymap:card",count=1}
  local index=0
  local price=0
  local licence=""
  local account=0
  local stackmeta
  if inv:contains_item("main",stack) then
    if fields.boarding~=nil then
      price=10
      licence="boarding"
    elseif fields.transfert~=nil then
      price=20
      licence="transfert"
    elseif fields.stargate~=nil then
      price=500
      licence="stargate"
    end
      
    if not (atm.balance[name] == nil) then
      account=atm.balance[name]
    end
    if account-price>0 then
      if licence~="" then
        --debit account
        atm.balance[name] = account-price
        --sound TODO type et pos astroport / planete en metadata
        local position=shop_postostring(pos)
        local creat_dat=((startest.year-1)*168)+((startest.month-1)*14)+startest.day
        local hour = math.floor(minetest.get_timeofday() * 2400)
        stackmeta=licence.." "..position.." "..creat_dat.."_"..name.."_"..hour -- type pos date_player_heure
        inv:add_item("main", {name="citymap:certif", count=1, wear=0, metadata=stackmeta})
        minetest.chat_send_player(name,atm.balance[name])
        atm.saveaccounts ()
      end
    end
  else
    minetest.chat_send_player(name,"NO CREDIT CARD PRESENT IN INVENTORY")
  end    
end,
})

-- neutre

minetest.register_node("citymap:guichet", {
description = "guichet",
	tiles = {
		"guichetd.png",
		"guichetd.png",
		"guichetd.png^[transformR90",
		"guichetd.png^[transformR90",
		"guichet.png",
		"guichet.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
paramtype2 = "facedir",
use_texture_alpha = true,
groups = {cracky=3},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.375, -0.0625, 0.5, 0.5, 0.0625}, -- NodeBox1
			{-0.5, -0.5, -0.5, 0.5, -0.375, 0.5}, -- NodeBox2
		}
	}
})

--plot marker village contient les metadata du village
    
minetest.register_node("citymap:plot", {
	description = "plot marker",
	drawtype = "nodebox",
    node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.5, 0.5, -0.375, 0.5}, -- NodeBox1
			{-0.1875, -0.375, -0.1875, 0.1875, -0.0625, 0.1875}, -- NodeBox2
			{-0.125, -0.0625, -0.125, 0.125, 0.3125, 0.125}, -- NodeBox3
			{-0.1875, 0.3125, -0.1875, 0.1875, 0.4375, 0.1875}, -- NodeBox4
			{-0.125, 0.4375, -0.125, 0.125, 0.5, 0.125}, -- NodeBox5
		}
	},
	tiles = {
		"borne_top2.png",
		"borne_top.png",
		"borne_side.png",
		"borne_side.png",
		"borne_nord.png",
		"borne_sud.png"
	},
	paramtype = "light",
	drop = "citymap:plot",
	groups = {cracky=3,not_in_creative_inventory=1},
	sunlight_propagates = false,
	sounds = default.node_sound_stone_defaults(),
})


--*****************
--** node coffre **
--*****************

-- ** remplissage des coffres **

local function fill_chest(chest_pos,size,locker)
  local meta = minetest.get_meta(chest_pos)
  local inv = meta:get_inventory()
  local w=math.floor(size/10)
  local h=size-(w*10)
  local x=math.floor(4-(w/2))
  local y=math.floor(2-(h/2))
  size=w*h
  local form="invsize[8,9;]".."list[context;main;".. x ..",".. y ..";"..w..","..h..";]".."list[current_player;main;0,5;8,4;]"
  inv:set_size("main",size)
  local boucle=0
  local objet={}
  local quantity=0

  -- nb d'item enregistrer
  local nb_item = #citymap.item
  --choix premier objet
  local choix_item=math.random(1,nb_item)

	for i=1,size do
    boucle=5
    choix_item=math.random(1,nb_item)
    local rnd=math.random(1,100)

    repeat
      objet=citymap.item[choix_item]  --recuperation des données
              
        if objet[4]<rnd then
          if string.find(objet[8],locker) then --fill si autorisation
            local tmp=math.ceil(objet[5]/2)--quantite mini
            quantity=math.random(tmp,objet[5])--quantite maxi
            inv:set_stack("main",i,objet[2] .." ".. tostring(quantity))
            boucle=0
          end
        end
    
      choix_item=choix_item+10
      if choix_item>nb_item then choix_item=choix_item-nb_item end
      boucle=boucle-1
    until boucle<1
    
  end
  local creat_dat=((startest.year-1)*168)+((startest.month-1)*14)+startest.day+math.random(40,80)
  meta:set_int("visit",creat_dat)
  meta:set_string("formspec",form)

end

minetest.register_node("citymap:xpchest", {
	description = "coffre",
    tiles = {
		"caisse_top.png",
        "caisse_top.png",
        "caisse.png",
        "caisse.png",
        "caisse_xp.png",
        "caisse_xp.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
    paramtype2 = "facedir",
	groups = {cracky=2},
	is_ground_content = false,
    on_construct = function(pos)
    local size=math.random(2,8)*10+math.random(2,4)
    fill_chest(pos,size,"x")
    end,

  allow_metadata_inventory_take=function(pos,listname,index,stack,player)
    local name=player:get_player_name()
    local xp=xpgetlvl(player,"xp_lvl")+1
    local item_name=stack:get_name()

    --recherche objet
    local nb_obj = #citymap.item
    local out=1
    local obj_recherche
   
    repeat
      obj_recherche=citymap.item[nb_obj]  --recuperation des données
   
      if item_name==obj_recherche[2] then
        nb_obj=1
        if xp>obj_recherche[6] then
          out=1
        else
          out=2
        end
      end
   
      nb_obj=nb_obj-1
    until nb_obj<1
   
    if out==2 then
      minetest.chat_send_player(name,"sorry, not enought XP")
      return 0
    end
   
    return stack:get_count()
  end,
  can_dig = function(pos,player)
    local meta = minetest.get_meta(pos);
		local inv = meta:get_inventory()
		return inv:is_empty("main")
  end,
  drop = 'default:dirt'
})

minetest.register_craftitem("citymap:licence", {
	description = "licence",
	inventory_image = "licence.png",
	groups = {flammable = 3},
  stack_max = 1,
  on_use = function(itemstack, user, pointed_thing)
		local nplayer = user:get_player_name()
		local stackmeta = itemstack:get_metadata()
		if stackmeta==nil then
      stackmeta="empty"
    end
    minetest.chat_send_player(nplayer, stackmeta)
	end,
})

minetest.register_craftitem("citymap:card", {
	description = "Bank card",
	inventory_image = "credit_card.png",
	groups = {flammable = 3},
stack_max = 1,
on_use = function(itemstack, user, pointed_thing)
		local name = user:get_player_name()
		--atm.readaccounts ()
    if not (atm.balance[name] == nil) then
      minetest.chat_send_player(name, atm.balance[name])
    end
	end,
})

minetest.register_craftitem("citymap:certif", {
	description = "autorisation de transfert et d'arrimage",
	inventory_image = "certif.png",
	groups = {flammable = 3},
stack_max = 1,
on_use = function(itemstack, user, pointed_thing)
		local nplayer = user:get_player_name()
		local stackmeta = itemstack:get_metadata()
		if stackmeta==nil then
      stackmeta="empty"
    end
    minetest.chat_send_player(nplayer, stackmeta)
	end,
})
