
--plot marker village
    
minetest.register_node("citymap:plot", {
	description = "plot marker",
	drawtype = "nodebox",
    node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.5, 0.5, -0.375, 0.5}, -- NodeBox1
			{-0.1875, -0.375, -0.1875, 0.1875, -0.0625, 0.1875}, -- NodeBox2
			{-0.125, -0.0625, -0.125, 0.125, 0.3125, 0.125}, -- NodeBox3
			{-0.1875, 0.3125, -0.1875, 0.1875, 0.4375, 0.1875}, -- NodeBox4
			{-0.125, 0.4375, -0.125, 0.125, 0.5, 0.125}, -- NodeBox5
		}
	},
	tiles = {
		"borne_top2.png",
		"borne_top.png",
		"borne_side.png",
		"borne_side.png",
		"borne_nord.png",
		"borne_sud.png"
	},
	paramtype = "light",
	drop = "citymap:plot",
	groups = {cracky=3,not_in_creative_inventory=1},
	sunlight_propagates = false,
	sounds = default.node_sound_stone_defaults(),
})

--[[
--
   village={
   pos={x,y,z},--position
   race="elfes",--race
   population=7,--population
   bank=25,--argent
   peace=65,--pacifique/hostile 0=hostil 99=pacifik
   technologie=10,--niveaux technologique
   allier={"barbarian"},--alliance
   fermier=1,--nb fermier
   bucheron=1,
   chasseur=1,
   mineur=1,
   ouvrier=1,
   batisseur=1,
   soldat=1,

   defense=0,
   attack=0,
   army={x,y,z},position armée

   --   stock :
   legume="tomato 25",
  growlegume=10,
  tree="apple 25",
  leave="",
  growtree=3,
   minerai="iron 18",
   energie="coal 10",
   roche="coblestone 15",
   objet="brick 25",
   maison=1,
   gibier="chicken 18",
           }
   
   fermier={legume1,legume2,legume3,grow1..10}
  
   bucheron={sapling,tree,leaves,grow1...grow3}
  
   legume="name/stack"
   grow="name/timer"
  
   chasseur = gibier-timer
   
   mineur = minerai 1 .. 3 / minerai 4 (coblestone,desertcoblestone,sand,silversand...)
   timer - nb - minerai
   
   ouvrier = objet1..8
   timer - 
   
   batisseur = maison
   
   soldat = arme
   
nmr_vil=1 --init depart jeu sauvegarde en sortant etat du compteur
   --toute les 60 secondes
   nmr_vil
   local data=village[nmr_vil]
   nmr_vil+1
--]]


local function fermier()
  --test grow de 1  a 10
  --si timer a 0 recolte legume
  --si planche de culture libre et stock de legume ok, en planter grow + timer 
  
end

local function bucheron()
  --test grow de 1  a 3
  --si timer a 0 coupe arbre
  --si place pour un arbre et stock ok, en planter grow + timer 
  
end
