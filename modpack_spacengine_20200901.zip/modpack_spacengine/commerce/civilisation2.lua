commerce.civ={}
--[[
local function sum_work(civ_table,index,point)
local total=0
local tmp
for work=1,5 do
tmp=civ_table[6+work]

if work==index then
tmp=math.max(0,tmp+point)
civ_table[6+work]=tmp
point=point*-1
end

if work>index then
tmp=math.max(0,tmp+point)
civ_table[6+work]=tmp
end

total=total+tmp
end

end
--]]

commerce.civ_found=function()

  for nb, player in ipairs(minetest.get_connected_players()) do
    local ppos = player:getpos()
    
    if ppos.y>1007 and ppos.y<10268 then
      local secteur,bloc=espace.secteur(ppos)
      if bloc.nb==283 then
        local _,stargate=espace.astroport(secteur)
        local civ_pos=minetest.find_node_near(stargate,4,{"commerce:info_astroport"})
        if  civ_pos then
          commerce.civ_maj(civ_pos)
        end
      end
    end

  end

end

local civ_init=function(civ_pos)
  local _,str_dat=espace.set_dat(50,100,true)
  local data_civ=espace.postostring(civ_pos) ..":".. str_dat

  data_civ=data_civ..":2"--war
  data_civ=data_civ..":2"--farm
  data_civ=data_civ..":2"--mine
  data_civ=data_civ..":1"--build
  data_civ=data_civ..":1"--trade
  data_civ=data_civ..":1"--indus
  data_civ=data_civ..":1"--indus2
  data_civ=data_civ..":0"--scienc

  data_civ=data_civ..":".. tostring(math.random(1000,10000)) --eat
  data_civ=data_civ..":".. tostring(math.random(1000,10000)) --ores
  data_civ=data_civ..":".. tostring(math.random(1000,10000)) --tools
  data_civ=data_civ..":".. tostring(math.random(1000,10000)) --weapons
  data_civ=data_civ..":".. tostring(math.random(1000,10000)) --vehicules / machine
  data_civ=data_civ..":".. tostring(math.random(1000,10000)) --furniture
  data_civ=data_civ..":".. tostring(math.random(1000,10000)) --hightech

  data_civ=data_civ..":".. tostring(math.random(1000,10000)) --population
  data_civ=data_civ..":".. tostring(math.random(1000,10000)) --bank

  data_civ=data_civ..":0/0"--memory

  data_civ=data_civ..":".. tostring(math.random(1,100)) --hostiliter
  data_civ=data_civ..":".. tostring(math.random(1,100)) --technologie
  data_civ=data_civ..":".. tostring(math.random(1,100)) --commerce

  local meta = minetest.get_meta(civ_pos)
  meta:set_string("civilisation",data_civ)

  return data_civ
end

commerce.civ_maj=function(civ_pos)
  local meta = minetest.get_meta(civ_pos)
  local data_civ=meta:get_string("civilisation")

  if data_civ=="" or data_civ==nil then
    data_civ=civ_init(civ_pos)
  end

  local civ_table=string.split(data_civ,":")

  local name_civ=civ_table[1]
  local dat_civ=civ_table[2]

  local war=tonumber(civ_table[3])
  local farm=tonumber(civ_table[4])
  local mine=tonumber(civ_table[5])
  local build=tonumber(civ_table[6])
  local trade=tonumber(civ_table[7])
  local indus=tonumber(civ_table[8])
  local indus2=tonumber(civ_table[9])
  local scienc=tonumber(civ_table[10])

  local eat=tonumber(civ_table[11])--farm
  local ores=tonumber(civ_table[12])--mine
  local tools=tonumber(civ_table[13])--indus
  local weapons=tonumber(civ_table[14])--war
  local machine=tonumber(civ_table[15])--indus
  local furniture=tonumber(civ_table[16])--build
  local hightech=tonumber(civ_table[17])--scienc

  local population=tonumber(civ_table[18])
  local bank=tonumber(civ_table[19])--trade

  local memory=civ_table[20]

  local hostiliter=tonumber(civ_table[21])
  local technologie=tonumber(civ_table[22])
  local commerce=tonumber(civ_table[23])

  local memory_table=string.split(memory,"/")
  local war_cpt=tonumber(memory_table[1])
  local death_cpt=tonumber(memory_table[2])

if death_cpt>1 then
death_cpt=death_cpt-1
else
  --*********
  --** WAR **
  --*********
  local hostiliter_coef=hostiliter/50
  local defense=((war*100)*hostiliter_coef)+10
  local x_coef

  if weapons>population then
    x_coef=2-(population/math.max(1,weapons))
  else
    x_coef=weapons/math.max(1,population)
  end
  
  local probabiliter=math.random(1,defense)

  if probabiliter<5 then --ennemie qui attaque
    local degat_defense=(2-x_coef)*((population*(10-war))/100)*0.1
    eat=math.max(0,eat-degat_defense)
    ores=math.max(0,ores-degat_defense)
    tools=math.max(0,tools-degat_defense)
    weapons=math.max(0,weapons-degat_defense)
    machine=math.max(0,machine-degat_defense)
    furniture=math.max(0,furniture-degat_defense)
    hightech=math.max(0,hightech-degat_defense)
    bank=math.max(0,bank-degat_defense)
    population=math.max(0,population-(degat_defense*0.5))
    war_cpt=5
--minetest.chat_send_all("defense "..degat_defense)
  else
    local attack=910-((war*50)*hostiliter_coef)
    probabiliter=math.random(1,attack)

    if probabiliter<5 then --attaque les ennemies
      local degat_attack=(x_coef*((war*population)/100))*0.1
      eat=eat+degat_attack
      ores=ores+degat_attack
      weapons=math.max(0,weapons-degat_attack)
      machine=machine+degat_attack
      furniture=furniture+degat_attack
      hightech=hightech+degat_attack
      bank=bank+degat_attack
      population=math.max(0,population-(degat_attack*0.25))
      war_cpt=0
--minetest.chat_send_all("attack "..degat_attack)
    end

  end

  --**************
  --** manger ! **
  --**************
  local tmp=eat-(population*0.2)
  if tmp<0 then
    eat=0
    population=math.max(0,population-math.abs(tmp))
if population<1 then
death_cpt=20
end
  else
    eat=math.max(0,tmp)
  end
  --***************
  -- catastrophe **
  --***************
  local catastrophe=(farm*100)*(technologie/100)+10
  probabiliter=math.random(1,catastrophe)
  if probabiliter<3 then

    if tools>population then
      x_coef=(2-(population/math.max(1,tools)))*0.1
    else
      x_coef=(tools/math.max(1,population))*0.1
    end

    eat=math.max(0,eat-(x_coef*eat))
    ores=math.max(0,ores-(x_coef*ores))
    tools=math.max(0,tools-(x_coef*tools))
    weapons=math.max(0,weapons-(x_coef*weapons))
    machine=math.max(0,machine-(x_coef*machine))
    furniture=math.max(0,furniture-(x_coef*furniture))
    hightech=math.max(0,hightech-(x_coef*hightech))
    bank=math.max(0,bank-(x_coef*bank))
    population=math.max(0,population-(x_coef*population))
--minetest.chat_send_all("catastrophe "..x_coef)
  end
  
  --***************
  --** naissance **
  --***************

  if eat>(population*0.5) and furniture>(population*0.25) then
    tmp=math.floor((population*0.01)*(farm+1))
    furniture=math.max(0,furniture-tmp)
    population=math.min(10000,population+tmp)
    
--minetest.chat_send_all("naissance : ".. tmp)
  end

  --** FARM **

if tools>0 and farm>0 then
  eat=eat+((farm*0.1)*population)
  tools=math.max(0,tools-(population*(farm/100)))
else
  eat=eat+(population*0.01)
end


  --** MINE **
  if tools>0 and mine>0 then
    ores=ores+((mine*0.3)*population)
    tools=math.max(0,tools-(population*(mine/100)))
  else
    ores=ores+(population*0.01)
  end

  --**  **

  if indus2>0 and ores>0 then
    tools=tools+((indus2*0.1)*population)
    ores=math.max(0,ores-(population*(indus2/10)))
  else
    tools=tools+(population*0.01)
  end



  
    if build>0 and ores>0 then
      furniture=furniture+((build/10)*population)
      ores=math.max(0,ores-(population*(build/10)))
    else
      furniture=furniture+(0.01*population)
      ores=math.max(0,ores-(population*0.01))
    end


    if scienc>0 and furniture>0 then
      hightech=hightech+((scienc/100)*population)
      furniture=math.max(0,furniture-(population*(scienc/10)))
    else
      hightech=hightech+(0.001*population)
      furniture=math.max(0,furniture-(population*0.01))
    end


  --** vehicules weapons **
  if (war*hostiliter)>250 then
    if indus>0 and hightech>0 then
      tmp=((indus*population)/1000)
      weapons=weapons+tmp
      hightech=math.max(0,hightech-tmp)
--furniture=math.max(0,furniture-(population*(indus/10)))
--minetest.chat_send_all("weapons")
    end
  else
    if indus>0 and hightech>0 then
      tmp=((indus*population)/1000)
      machine=machine+tmp
      hightech=math.max(0,hightech-tmp)
--furniture=math.max(0,furniture-(population*(indus/10)))
--minetest.chat_send_all("machine")
    end
  end
--
local total=0

if war_cpt>1 then
war=math.min(9,war+2)
war_cpt=war_cpt-1
else
war=math.max(0,war-1)
end

tmp=math.floor(hostiliter/25)
war=math.max(tmp,war)
total=total+war

--si eat<50% augmente farm, si eat>10% baisse farm
if eat<(population*0.5) then
farm=math.min(9,farm+2)
elseif eat>(population*1.1) then
  farm=math.max(0,farm-1)
end

if total+farm>10 then
farm=10-total
total=10
else
total=total+farm
end

--trader
tmp=math.floor(commerce/25)
trade=math.max(tmp,trade)
if total+tmp>10 then
trade=10-total
total=10
else
total=total+trade
end


--si ores<75% mine add / >15% mine dec
if ores<(population*0.75) then
mine=math.min(9,mine+2)
elseif ores>(population*1.15) then
  mine=math.max(0,mine-1)
end

if total+mine>10 then
mine=10-total
total=10
else
total=total+mine
end

--techno
tmp=math.floor(technologie/25)
indus=math.max(tmp,indus)
if machine<(population*0.25) then
indus=math.min(9,indus+2)
elseif machine>(population*0.75) then
  indus=math.max(tmp,indus-1)
end

if total+indus>10 then
indus=10-total
total=10
else
total=total+indus
end
--
if tools<(population*0.75) then
indus2=math.min(9,indus2+2)
elseif tools>(population*1.15) then
  indus2=math.max(0,indus2-1)
end

if total+indus2>10 then
indus2=10-total
total=10
else
total=total+indus2
end
--
if furniture<(population*0.75) then
build=math.min(9,build+2)
elseif furniture>(population*1.15) then
  build=math.max(0,build-1)
end

if total+build>10 then
build=10-total
total=10
else
total=total+build
end
--

scienc=10-total

--**************
  --** commerce **
  --**************
  local prob_trad=110-((trade+1)*(commerce/10))
  probabiliter=math.random(1,prob_trad)

  if probabiliter<5 then
    tmp=(ores+tools+furniture+hightech+machine)/5

    if tmp>population then
      x_coef=(2-(population/math.max(1,tmp)))*(math.random(1,5)/10)
    else
      x_coef=(tmp/math.max(1,population))*(math.random(1,5)/10)
    end

    
if bank>ores and ores<(0.25*population) then --achat
ores=ores+(x_coef*ores)
bank=math.max(0,bank-(x_coef*bank))
elseif ores>bank then
ores=math.max(0,ores-(x_coef*ores))
bank=bank+(x_coef*bank)
end

if bank>tools and tools<(0.25*population) then --achat
tools=tools+(x_coef*tools)
bank=math.max(0,bank-(x_coef*bank))
elseif tools>bank then
tools=math.max(0,tools-(x_coef*tools))
bank=bank+(x_coef*bank)
end

if bank>furniture and furniture<(0.25*population) then --achat
furniture=furniture+(x_coef*furniture)
bank=math.max(0,bank-(x_coef*bank*2))
elseif furniture>bank then
furniture=math.max(0,furniture-(x_coef*furniture))
bank=bank+(x_coef*bank*2)
end

if bank>machine and machine<(0.25*population) then --achat
machine=machine+(x_coef*machine)
bank=math.max(0,bank-(x_coef*bank*3))
elseif machine>bank then
machine=math.max(0,machine-(x_coef*machine))
bank=bank+(x_coef*bank*3)
end

if bank>weapons and weapons<(0.25*population) then --achat
weapons=weapons+(x_coef*machine)
bank=math.max(0,bank-(x_coef*bank*3))
elseif weapons>bank then
weapons=math.max(0,weapons-(x_coef*machine))
bank=bank+(x_coef*bank*3)
end

if bank>hightech and hightech<(0.25*population) then --achat
hightech=hightech+(x_coef*hightech)
bank=math.max(0,bank-(x_coef*bank*3))
elseif hightech>bank then
hightech=math.max(0,hightech-(x_coef*hightech))
bank=bank+(x_coef*bank*3)
end

--minetest.chat_send_all("commerce "..x_coef)
    
  end

end

if death_cpt==1 then
  data_civ=civ_init(civ_pos)
else
  data_civ=name_civ..":"..dat_civ..":".. war ..":".. farm ..":".. mine ..":".. build ..":".. trade ..":".. indus ..":".. indus2 ..":".. scienc ..":".. math.floor(eat) ..":".. math.floor(ores) ..":".. math.floor(tools) ..":".. math.floor(weapons) ..":".. math.floor(machine) ..":".. math.floor(furniture) ..":".. math.floor(hightech) ..
    ":".. math.floor(population) ..":".. string.format("%.2f",bank) ..":".. war_cpt .."/"..death_cpt..":".. hostiliter ..":".. technologie ..":".. commerce
end
  --minetest.chat_send_all("-----------")
  meta:set_string("civilisation",data_civ)
end

commerce.civ_info=function(civ_pos)
  local meta = minetest.get_meta(civ_pos)
  local data_civ=meta:get_string("civilisation")

  if data_civ=="" or data_civ==nil then
    data_civ=civ_init(civ_pos)
  end

  local civ_table=string.split(data_civ,":")
  return civ_table
end


minetest.register_node("commerce:info_astroport", {
	description = "astroport information",
	tiles = {
		"commerce_info_astroport2.png",
	},
	drawtype = "mesh",
  mesh = "info.obj",
selection_box = {
	type = "fixed",
	fixed = {-0.5, -0.5, -0.1, 0.5, 1.5, 0.1}
},
	collision_box = {
	type = "fixed",
	fixed = {-0.5, -0.5, -0.1, 0.5, 1.5, 0.1}
},
  on_rightclick = function(pos,node,player,itemstack,pointed_thing)
    local meta = minetest.get_meta(pos)
    local data_civ=meta:get_string("civilisation")

    if data_civ=="" or data_civ==nil then
      data_civ=civ_init(pos)
    end

    local civ_table=string.split(data_civ,":")
    local formspec = "size[10,10]label[0,0;Name ".. civ_table[1] .."]label[8,0;pop : ".. civ_table[18] .."]label[0,2.2;eat=".. civ_table[11] .."]label[0,3.2;ores=".. civ_table[12] .."]label[0,4.2;tools=".. civ_table[13] .."]label[0,5.2;weapons=".. civ_table[14] .."]label[0,6.2;machine=".. civ_table[15] .."]label[0,7.2;furniture=".. civ_table[16] .."]label[0,8.2;hightech=".. civ_table[17] .."]label[8,1;bank=".. civ_table[19] .."]"..
"label[8,2.2;".. civ_table[11] .."]label[8,3.2;".. civ_table[12] .."]label[8,4.2;".. civ_table[13] .."]label[8,5.2;".. civ_table[14] .."]label[8,6.2;".. civ_table[15] .."]label[8,7.2;".. civ_table[16] .."]label[8,8.2;".. civ_table[17] .."]"..
"label[3.5,2.2;".. civ_table[11] .."]label[3.5,3.2;".. civ_table[12] .."]label[3.5,4.2;".. civ_table[13] .."]label[3.5,5.2;".. civ_table[14] .."]label[3.5,6.2;".. civ_table[15] .."]label[3.5,7.2;".. civ_table[16] .."]label[3.5,8.2;".. civ_table[17] .."]"..
"button[2.5,2;1,1;buy1;buy]button[2.5,3;1,1;buy2;buy]button[2.5,4;1,1;buy3;buy]button[2.5,5;1,1;buy4;buy]button[2.5,6;1,1;buy5;buy]button[2.5,7;1,1;buy6;buy]button[2.5,8;1,1;but7;sell]"..
"button[5,2;1,1;sell1;sell]button[5,3;1,1;sell2;sell]button[5,4;1,1;sell3;sell]button[5,5;1,1;sell4;sell]button[5,6;1,1;sell5;sell]button[5,7;1,1;sell6;sell]button[5,8;1,1;sell7;sell]"..
"button_exit[0,9;2,1;exit;exit]list[context;src;8,9;1,1]label[8,8.5;cargo]"
formspec=formspec.."label[0,1;H".. civ_table[21] .."]label[2.5,1;T".. civ_table[22] .."]label[5,1;C".. civ_table[23] .."]"

    minetest.show_formspec(player:get_player_name(), "info_astroport", formspec)
  end,
	paramtype = "light",
  paramtype2 = "facedir",
	groups = {cracky = 3},--, not_in_creative_inventory=1},
	sounds = default.node_sound_stone_defaults(),
})

--plot marker village
    
minetest.register_node("commerce:plot", {
	description = "plot marker",
	drawtype = "nodebox",
    node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.5, 0.5, -0.375, 0.5}, -- NodeBox1
			{-0.1875, -0.375, -0.1875, 0.1875, -0.0625, 0.1875}, -- NodeBox2
			{-0.125, -0.0625, -0.125, 0.125, 0.3125, 0.125}, -- NodeBox3
			{-0.1875, 0.3125, -0.1875, 0.1875, 0.4375, 0.1875}, -- NodeBox4
			{-0.125, 0.4375, -0.125, 0.125, 0.5, 0.125}, -- NodeBox5
		}
	},
	tiles = {
		"commerce_borne_top.png",
		"commerce_borne_bottom.png",
		"commerce_borne_side.png",
		"commerce_borne_side.png",
		"commerce_borne_nord.png",
		"commerce_borne_sud.png"
	},
	paramtype = "light",
	drop = "commerce:plot",
	groups = {cracky=3},--,not_in_creative_inventory=1},
	sunlight_propagates = false,
	sounds = default.node_sound_stone_defaults(),
})
