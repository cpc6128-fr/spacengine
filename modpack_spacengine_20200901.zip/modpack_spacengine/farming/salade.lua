
--[[
	Textures edited from:
	http://www.minecraftforum.net/forums/mapping-and-modding/minecraft-mods/1288375-food-plus-mod-more-food-than-you-can-imagine-v2-9)
]]


minetest.register_craftitem("farming:salade_seed", {
	description = "Salade seed",
	inventory_image = "salade_seed.png",
	on_place = function(itemstack, placer, pointed_thing)
		return farming.place_seed(itemstack, placer, pointed_thing, "farming:salade_1")
	end
})

minetest.register_craftitem("farming:salade", {
	description = "Salade",
	inventory_image = "salade.png",
	on_use = minetest.item_eat(2)
})

minetest.register_craftitem("farming:salade_tomate", {
	description = "Salade et Tomate",
	inventory_image = "salade_tomate.png",
	on_use = minetest.item_eat(6)
})

minetest.register_craft({
	output = "farming:salade_tomate",
	recipe = {
		{"farming:salade", "farming:tomato", "farming:corn"},
	}
})

local crop_def = {
	drawtype = "plantlike",
	tiles = {"salade_1.png"},
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	drop = "",
	selection_box = farming.select,
	groups = {
		snappy = 3, flammable = 2, attached_node = 1,
		not_in_creative_inventory = 1, growing = 8
	},
	sounds = default.node_sound_leaves_defaults()
}

-- stage 1
minetest.register_node("farming:salade_1", table.copy(crop_def))

-- stage2
crop_def.tiles = {"salade_2.png"}
minetest.register_node("farming:salade_2", table.copy(crop_def))

-- stage 3
crop_def.tiles = {"salade_3.png"}
minetest.register_node("farming:salade_3", table.copy(crop_def))

-- stage 4
crop_def.tiles = {"salade_4.png"}
minetest.register_node("farming:salade_4", table.copy(crop_def))

-- stage 5
crop_def.tiles = {"salade_5.png"}
minetest.register_node("farming:salade_5", table.copy(crop_def))

-- stage 6
crop_def.tiles = {"salade_6.png"}
crop_def.groups.growing = 12
crop_def.drop = {
	items = {
		{items = {'farming:salade 2'}, rarity = 1},
    {items = {'farming:salade'}, rarity = 2},
		{items = {'farming:salade_seed'}, rarity = 3},
	}
}
minetest.register_node("farming:salade_6", table.copy(crop_def))

-- stage 7
crop_def.tiles = {"salade_7.png"}
crop_def.groups.growing = 0
crop_def.drop = {
	items = {
		{items = {'farming:salade_seed'}, rarity = 1},
    {items = {'farming:salade_seed'}, rarity = 3},
		{items = {'farming:salade'}, rarity = 3},
	}
}
minetest.register_node("farming:salade_7", table.copy(crop_def))
