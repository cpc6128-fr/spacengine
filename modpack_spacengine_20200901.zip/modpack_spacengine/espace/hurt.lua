
espace.data={}
local hurt_active=false
if minetest.setting_getbool("enable_damage") then
  hurt_active=true
end

minetest.register_node("espace:health_jail", {
	description = "refill health",
	tiles ={"espace_health.png"},
	groups = {cracky=3},
  on_rightclick=function(pos,node,player,itemstack)
    player:set_hp(20)
    player:set_attribute("fatigue","500")
  end,
	sounds = default.node_sound_stone_defaults(),
})

--**********************
--** init data player **
--**********************
minetest.register_on_joinplayer(function(player)
    local playername=nil

    if not player or player.is_fake_player then
        return
    end
   
	playername = player:get_player_name()
   
	if espace.data[playername] == nil then
		espace.data[playername] = {}
	end

  if not player:get_attribute("fatigue") then player:set_attribute("fatigue","500") end

  atm.readaccounts()
  if not atm.balance[playername] then
    atm.balance[playername] = 300000 --test only
  end

    local sec = (86400*minetest.env:get_timeofday());
    local mn = math.floor(sec/60) % 60;
    local hr = math.floor(sec/3600) % 60;
    local nb=0x00FF00
    local h=(espace.day*2).."/"..espace.month.."/"..espace.year.."\n"..string.format("%02d",hr)..":"..string.format("%02d",mn).."\nT. 20°C"
    
    local affichage = player:hud_add({
    hud_elem_type = "text";
    position = {x=0.1, y=0.91};
    text = h;
    number = nb;
    scale = 20;
    });

    espace.data[playername] = {temp=20, meteo="clear", radiation=20, oxygen=true, biome="n",  hud=affichage,  bloc_protect=false, bloc=999, secteur=0,skytype=2,old_biome="n",new_meteo="clear"}
    espace.getpriv(playername)
    player:set_attribute("sound_meteo",nil) --reset sound

end)


minetest.register_on_leaveplayer(function(player)
  --stop sound et reset sound player
  local sound_nb=player:get_attribute("sound_meteo")
  if sound_nb then
    minetest.sound_stop(tonumber(sound_nb))
    player:set_attribute("sound_meteo",nil)
  end

  local name = player:get_player_name()
  espace.data[name]=nil
end)

minetest.register_on_respawnplayer(function(player)
  player:set_attribute("fatigue","500")
end)

--biome t=temperate h=hot c=cold
--***************
--** Hurt Test **
--***************
local hurt_timer=0

hurt_test=function(player)

  if hurt_active==false then return end

  hurt_timer=hurt_timer+1

  local playerpos=player:get_pos()
  local playername = player:get_player_name()
  local hurt = tonumber(player:get_attribute("fatigue"))

  -- marche dans la neige difficile fxspeed 0.3
  local snowpos=player:get_pos()
  local nodeup = minetest.get_node({x=snowpos.x,y=snowpos.y,z=snowpos.z})
  local nodedn = minetest.get_node({x=snowpos.x,y=snowpos.y-1,z=snowpos.z})

  if string.find(nodedn.name,"snow") or string.find(nodeup.name,"snow") then
    fxadd(player,"snow",2,60,0,0,1)
  end

  if hurt_timer<3 then return end
  hurt_timer=0

  --suit dans le slot 1 1:space:suit 2:nuclear_suit 3:toxic_suit
  local inv=player:get_inventory()
  local suit=0
  local w=0
  local x
            
  -- test si source de froid
  local ice_pos=minetest.find_node_near(playerpos, 6, {"group:cools_lava"})
  local ice=0
  if ice_pos~=nil then
    ice=5
  end

  -- test si source de chaleur
  local heat_pos=minetest.find_node_near(playerpos, 6, {"group:lava","group:igniter"})
  local heat=0
  if heat_pos~=nil then
    heat=5
  end

  local suit_tmp=inv:get_stack("main", 1):get_name()
  if suit_tmp=="espace:spacesuit" then --froid/chaud
    suit=1
  elseif suit_tmp=="espace:nuclear_suit" then --chaud
    suit=2
  elseif suit_tmp=="espace:toxic_suit" then --chaud
    suit=3
  end
            
  if suit>0 then
    w=inv:get_stack("main", 1):get_wear()
  end

  if espace.data[playername].temp<5 then -- teste si la temperature est inferieur a 5
    if suit>0 then 
      if heat==0 then
        w=math.min(65535,w+50)--usure de la combi
      end
    else
      if heat==0 then
        x=math.ceil(espace.data[playername].temp-5)
        hurt=hurt+x --epuisement plus rapide en fonction de la temp.
      end
    end
  end

  if espace.data[playername].temp>38 then -- teste si la temperature est superieur a 38
    if suit>0 then
      if ice==0 then
        w=math.min(65535,w+50)
      end
    else
      if ice==0 then
        if espace.data[playername].temp>38 then
          x=math.floor(espace.data[playername].temp-38)
          hurt=hurt-x --epuisement plus rapide quand forte chaleur                    
        else
          hurt=hurt-heat --epuisement plus rapide quand forte chaleur 
        end
      end
    end
  end

  --oxygene
  local o=player:get_breath()
  local node=minetest.get_node(playerpos)
  if espace.data[playername].oxygen==false then
    if not string.find(node.name,"air") and suit~=1 then
      hurt=hurt-20
    end
  end

  if suit==1 then
    if o<10 then
      player:set_breath(10)
      w=math.min(65535,w+150)--(500*coef_use))
    
    elseif espace.data[playername].oxygen==false and not string.find(node.name,"air") then
      --player:set_breath(10)
      w=math.min(65535,w+150)--(500*coef_use))
    end
  end

  --radiation
  local radiation=espace.data[playername].radiation
  local radioactive_node=minetest.find_nodes_in_area({x=playerpos.x-3,y=playerpos.y-3,z=playerpos.z-3}, {x=playerpos.x+3,y=playerpos.y+3,z=playerpos.z+3}, {"group:radioactive"})
  if radioactive_node~=nil then radiation=radiation+(#radioactive_node*5) end

  if radiation>0 then
    if suit==1 or suit==2 then
      w=math.min(65535,w+((25*radiation)/suit))
    else
      hurt=hurt-radiation
    end
  end

  --nuage toxique
  if minetest.find_node_near(playerpos, 1, {"group:toxic"})~=nil then
    if suit==3 then
      w=math.min(65535,w+150)
    else
      hurt=hurt-5
    end
  end

  --meteo
  if not espace.is_inside(playerpos) then
    --pluie et neige légère
    if espace.data[playername].meteo=="weather_snow" or espace.data[playername].meteo=="weather_rain" then
      if suit==3 or suit==4 then
        w=math.min(65535,w+50)
      else
        hurt=hurt-5
      end
    end
    --orage et tempete de neige ou de sable
    if espace.data[playername].meteo=="weather_storm" or espace.data[playername].meteo=="weather_snow_storm" then
      if suit==3 or suit==4 then
        w=math.min(65535,w+50)
      else
        hurt=hurt-10
      end
    end
  end

  if suit>0 then
    if w>65534 then
      inv:set_stack("main", 1,ItemStack({name=""}))
      suit=0
    end

    if suit==1 then
      inv:set_stack("main", 1,ItemStack({name="espace:spacesuit",wear=w}))
    elseif suit==2 then
      inv:set_stack("main", 1,ItemStack({name="espace:nuclear_suit",wear=w}))
    elseif suit==3 then
      inv:set_stack("main", 1,ItemStack({name="espace:toxic_suit",wear=w}))
    end
  end

  local hp_lvl=player:get_hp()
  if hp_lvl<20 and hurt>400 then
    hurt=hurt-10
    player:set_hp(hp_lvl+1)
  end

  hurt=math.ceil(hurt)


  if hurt<1 then 
    hurt=0
    --local h=player:get_hp()-1
    player:set_hp(hp_lvl-1)
  end

  player:set_attribute("fatigue",tostring(hurt))

end

-- override core.do_item_eat() so we can redirect hp_change to stamina
core.do_item_eat = function(hp_change, replace_with_item, itemstack, user, pointed_thing)
	local old_itemstack = itemstack
	itemstack = espace.eat(hp_change, replace_with_item, itemstack, user, pointed_thing)
	for _, callback in pairs(core.registered_on_item_eats) do
		local result = callback(hp_change, replace_with_item, itemstack, user, pointed_thing, old_itemstack)
		if result then
			return result
		end
	end
	return itemstack
end

-- not local since it's called from within core context
function espace.eat(hp_change, replace_with_item, itemstack, user, pointed_thing)
	if not itemstack then
		return itemstack
	end

	if not user then
		return itemstack
	end

	local level = tonumber(user:get_attribute("fatigue"))
	if level >= 500 then
		return itemstack
	end

	if hp_change > 0 then
    --local coef=0.5+(1.5/xpgetlvl(user,"endurance"))
		level = math.min(500,level + (hp_change*5))--(hp_change*coef))
		--stamina_update_level(user, level)
    user:set_attribute("fatigue", level)
	end

     --incremente level endurance
    --xplevel(hp_change,user,"endurance")
    
	--minetest.sound_play("stamina_eat", {to_player = user:get_player_name(), gain = 0.7})

	-- particle effect when eating
	local pos = user:getpos()
	pos.y = pos.y + 1.5 -- mouth level
	local itemname = itemstack:get_name()
	local texture  = minetest.registered_items[itemname].inventory_image
	local dir = user:get_look_dir()

	minetest.add_particlespawner({
		amount = 5,
		time = 0.1,
		minpos = pos,
		maxpos = pos,
		minvel = {x = dir.x - 1, y = dir.y, z = dir.z - 1},
		maxvel = {x = dir.x + 1, y = dir.y, z = dir.z + 1},
		minacc = {x = 0, y = -5, z = 0},
		maxacc = {x = 0, y = -9, z = 0},
		minexptime = 1,
		maxexptime = 1,
		minsize = 1,
		maxsize = 2,
		texture = texture,
	})

	itemstack:take_item()

	if replace_with_item then
		if itemstack:is_empty() then
			itemstack:add_item(replace_with_item)
		else
			local inv = user:get_inventory()
			if inv:room_for_item("main", {name=replace_with_item}) then
				inv:add_item("main", replace_with_item)
			else
				pos.y = math.floor(pos.y - 1.0)
				core.add_item(pos, replace_with_item)
			end
		end
	end

	return itemstack
end
