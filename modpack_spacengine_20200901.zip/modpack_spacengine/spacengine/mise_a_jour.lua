--***************************
--*** recherche controler ***
--***************************
spacengine.search_controler=function(pos,player,channel,range)

  if range==nil then range="x5y5z5" end

  --double la distance
  local rangex=10+tonumber(string.sub(range,2,2))*4
  local rangey=10+tonumber(string.sub(range,4,4))*4
  local rangez=10+tonumber(string.sub(range,6,6))*4

  local pos1={x=pos.x-rangex,y=pos.y-rangey,z=pos.z-rangez}
  local pos2={x=pos.x+rangex,y=pos.y+rangey,z=pos.z+rangez}

  local list=minetest.find_nodes_in_area(pos1,pos2,"spacengine:controler")
  local nb=#list
  local idx=0
  local cpos
  local channel_cont

  for i=1,nb do -- recherche controler = channel:owner
    local nod_met=minetest.get_meta(list[i])    
    local channel_dst=nod_met:get_string("channel")
    local cha_spl=string.split(channel_dst,":")

    if channel==cha_spl[1]..":"..cha_spl[2] then
      cpos=list[i]
      channel_cont=channel_dst--channel_dst
      idx=idx+1
    end

  end

  if idx==0 then --pas de channel
    return false
  elseif idx>1 then --plusieurs channel identique
    minetest.chat_send_player(player:get_player_name(),"Same Channel Found")
    return false
  end

  local crew=""
  local cha_spl=string.split(channel_cont,":")
  --si equipage
  if #cha_spl>2 then
    for nb_crew=2,#cha_spl do
      crew=crew..cha_spl[nb_crew]
      if nb_crew<#cha_spl then crew=crew..":" end
    end
    crew=cha_spl[1]..":"..crew
  else
    crew=cha_spl[1]..":"..cha_spl[2]
  end
  
  spacengine.test_area_ship(cpos,2,channel)

  return true,cpos,crew
end

--*************************
--*** MaJ position node ***
--*************************
spacengine.maj_pos_node=function(pos,player,channel,cpos,crew)
  --recuperation data node
  local nod_met = minetest.get_meta(pos)
  local nod_spl=spacengine.decompact(nod_met:get_string("spacengine"))
  local pos_cont=spacengine.decompact(nod_met:get_string("pos_cont"))
  local node=minetest.get_node(pos)
  local group=minetest.get_item_group(node.name,"spacengine")

--position controler
  local err=0
  if group==1 then
    pos_cont[1]=cpos.x
    pos_cont[2]=cpos.y
    pos_cont[3]=cpos.z

  else
    pos_cont[1]=pos.x-cpos.x
    pos_cont[2]=pos.y-cpos.y
    pos_cont[3]=pos.z-cpos.z

    local cont_met=minetest.get_meta(cpos)
    local cont_dat=spacengine.decompact(cont_met:get_string("spacengine"))

    local rangex=5+tonumber(string.sub(cont_dat[4],2,2))*2
    local rangey=5+tonumber(string.sub(cont_dat[4],4,4))*2
    local rangez=5+tonumber(string.sub(cont_dat[4],6,6))*2

    local tmp1=pos_cont[1]+rangex
    if tmp1<0 or tmp1>(rangex*2) then
      err=err+1
      minetest.chat_send_player(player:get_player_name(),"Out of range X coordo")
    end

    tmp1=pos_cont[2]+rangey
    if tmp1<0 or tmp1>(rangey*2) then
      err=err+1
      minetest.chat_send_player(player:get_player_name(),"Out of range Y coordo")
    end

    tmp1=pos_cont[3]+rangez
    if tmp1<0 or tmp1>(rangez*2) then
      err=err+1
      minetest.chat_send_player(player:get_player_name(),"Out of range Z coordo")
    end
  end

  if err>0 then
    nod_met:set_string("pos_cont","33333¨0¨0")
    return false
  end

  nod_met:set_string("channel",crew)
  nod_met:set_string("pos_cont",spacengine.compact(pos_cont))
  return true
end

--***************************
--*** Mise A Jour channel ***
--***************************

local function stockmax(src,calcul,smax)
if calcul+src>smax then
  src=smax-calcul
else
  calcul=calcul+src
end
return src,calcul
end

--
spacengine.maj_channel=function(cpos,channel,repar) --repar 0 normal 1 reset 2 reparartion
  local controler=minetest.get_meta(cpos)
  --recuperation channel controler
  local channel_cont=controler:get_string("channel")
  local spl_tmp=string.split(channel_cont,":")
  local cha_cnt=spl_tmp[1]..":"..spl_tmp[2]

  --invalid controler or channel
  if cha_cnt~=channel then
    return
  end

  local config=spacengine.area[channel].config

  local rangex=5+tonumber(string.sub(config[1][4],2,2))*2
  local rangey=5+tonumber(string.sub(config[1][4],4,4))*2
  local rangez=5+tonumber(string.sub(config[1][4],6,6))*2

  --controler center
  local list=minetest.find_nodes_in_area({x=cpos.x-rangex,y=cpos.y-rangey,z=cpos.z-rangez},{x=cpos.x+rangex,y=cpos.y+rangey,z=cpos.z+rangez},"group:spacengine")
  nb=#list

  local storage=config[9]--spacengine.decompact(controler:get_string("storage"))
  local passenger=config[10]--spacengine.decompact(controler:get_string("passenger"))
  local manutention=config[13]--spacengine.decompact(controler:get_string("manutention"))

  --reset compteur
  local idx4,idx5,idx6=0,0,0
  local idx7,idx8,idx11,idx13=0,0,0,0
  --controler
  config[1][2]=math.floor(((rangex*2+1)*(rangey*2+1)*(rangez*2+1))/10) --poids
  config[1][3]=0 --damage
  local stock_pos={{33333,0,0}}
  local id_stock_pos=1
  --battery
  config[2][1]=0
  --power
  config[3][2]=0
  local cont1,cont2
  if type(config[3][4])=="table" then
    cont1=config[3][4]
    cont2=config[3][5]
    if cont2[1]==1 then --reset list
      cont1={0}
      cont2={0}
    end
  else
    cont1={0}
    cont2={0}
  end
  --engine
  config[4][1]=0
  config[4][3]=0
  config[4][5]=0
  config[4][7]=0
  --shield
  config[5][1]=0
  config[5][3]=0
  --weapons
  config[6][1]=0
  config[6][3]=0
  config[6][5]=0
  config[6][8]=0
  --radar
  config[7][1]=0
  config[7][3]=0
  local cont7={"none:none"}
  local cont77={0}
  --gravitation
  config[8][1]=0
  --storage
  storage[1]=0
  --passenger
  passenger[1]=0
  --oxygene
  config[11][1]=0
  config[11][3]=0
  --screen

  --manutention
  local cont11={"none:none:0:none:0"}
  manutention[7]=""
  manutention[1]=0
  manutention[3]=0
  manutention[12]=0
  if manutention[9]=="" then manutention="***" end
  --radio
  local radio={}
  local idx_radio=0
  if config[15]==nil then
    config[15]={}
  end

  for i=1,nb do
    local dst=minetest.get_node(list[i]) 
    local dst_met=minetest.get_meta(list[i])    
    local dst_channel=dst_met:get_string("channel")
    local spl_dst=string.split(dst_channel,":")
    dst_channel=spl_dst[1]..":"..spl_dst[2] --recuperation du premier nom
    if dst_channel==channel then --ifchannel ok
      local sauvegarde=false
      local dst_group=minetest.get_item_group(dst.name,"spacengine")
      local dst_space=spacengine.decompact(dst_met:get_string("spacengine"))

      if dst_group~=20 then --20=module switch
        config[1][2]=config[1][2]+dst_space[2] --weight

        if repar<2 then
          config[1][3]=config[1][3]+dst_space[3] --damage
        else
          dst_space[3]=0 --reparation
          sauvegarde=true
        end
      end
    --controler
    if dst_group==1 then
      config[1][4]=dst_space[4] --volume
      --config[1][7]=dst_space[5] --stock

    --battery
    elseif dst_group==2 then
      config[2][1]=config[2][1]+dst_space[4]

    --power      
    elseif dst_group==3 then
      id_stock_pos=id_stock_pos+1
      stock_pos[id_stock_pos]={list[i].x-cpos.x,list[i].y-cpos.y,list[i].z-cpos.z}
      local err=false
      for j=1,#cont1 do
        if dst_space[1]==cont1[j] then --present ?
          dst_space[8]=cont2[j]
          err=true
        end
      end

      if err==false then
        local j=#cont1+1 
        cont1[j]=dst_space[1]
        cont2[j]=dst_space[8] --on/off
      end

      config[3][2]=config[3][2]+dst_space[10]
      sauvegarde=true

    --engine
    elseif dst_group==4 then
      idx4=idx4+1
      config[4][1]=config[4][1]+dst_space[4]
      config[4][3]=config[4][3]+dst_space[5]
      config[4][5]=config[4][5]+dst_space[6]
      config[4][7]=config[4][7]+dst_space[7]
    
    --shield
    elseif dst_group==5 then
      idx5=idx5+1
      config[5][1]=config[5][1]+dst_space[4]
      config[5][3]=config[5][3]+dst_space[5]

    --weapons
    elseif dst_group==6 then
      idx6=idx6+1
      config[6][1]=math.max(10000,config[6][1]+dst_space[4])
      config[6][3]=math.max(100,config[6][3]+dst_space[5])
      config[6][5]=config[6][5]+dst_space[6]
      config[6][8]=config[6][8]+dst_space[7]

    --radar
    elseif dst_group==7 then
      idx7=idx7+1
      config[7][1]=config[7][1]+dst_space[4]
      config[7][3]=config[7][3]+dst_space[5]
      local err=false
      if type(dst_space[6])=="table" then

        for chk=1,#dst_space[6] do
          err=false
          for j=1,#cont7 do
            if dst_space[6][chk]==cont7[j] then --present ?
            err=true
            end
          end
          if err==false then
            local j=#cont7+1 
            cont7[j]=dst_space[6][chk]
            cont77[j]=0
          end
        end

      else
        for j=1,#cont7 do
          if dst_space[6]==cont7[j] then --present ?
            err=true
          end
        end
        if err==false then
          local j=#cont7+1 
          cont7[j]=dst_space[6]
          cont77[j]=0
        end
      end

    --gravitation
    elseif dst_group==8 then
      idx8=idx8+1
      config[8][1]=config[8][1]+dst_space[4]

    --storage
    elseif dst_group==9 then
      storage[1]=storage[1]+dst_space[4]

    --passenger
    elseif dst_group==10 then
      passenger[1]=passenger[1]+1

    --oxygene
    elseif dst_group==11 then
      idx11=idx11+1
      config[11][1]=config[11][1]+dst_space[4]
      config[11][3]=config[11][3]+dst_space[5]

    --screen
    elseif dst_group==12 then
      id_stock_pos=id_stock_pos+1
      stock_pos[id_stock_pos]={list[i].x-cpos.x,list[i].y-cpos.y,list[i].z-cpos.z}

    --manutention
    elseif dst_group==13 then
      idx13=idx13+1
      manutention[1]=manutention[1]+dst_space[4]
      manutention[3]=manutention[3]+dst_space[5]
      manutention[12]=manutention[12]+dst_space[7]

      local err=false
      if type(dst_space[6])=="table" then

        for chk=1,#dst_space[6] do
          err=false
          for j=1,#cont11 do
            if dst_space[6][chk]==cont11[j] then --present ?
            err=true
            end
          end
          if err==false then
            local j=#cont11+1 
            cont11[j]=dst_space[6][chk]
          end
        end

      else
        for j=1,#cont11 do
          if dst_space[6]==cont11[j] then --present ?
            err=true
          end
        end
        if err==false then
          local j=#cont11+1 
          cont11[j]=dst_space[6]
        end
      end

      if string.find(manutention[7],string.sub(dst_space[1],1,1)) then --present ?
      else
        manutention[7]=manutention[7] .. string.sub(dst_space[1],1,1)
      end

    --radio
    elseif dst_group==17 then
      radio=list[i]
      idx_radio=idx_radio+1
    end

    local prelativ
    --calcul position relative
    if dst_group~=1 then
      if repar==1 then
        prelativ={33333,0,0}
      else
        prelativ={list[i].x-cpos.x,list[i].y-cpos.y,list[i].z-cpos.z}
      end
    else
      prelativ={cpos.x,cpos.y,cpos.z}
    end
    
    dst_met:set_string("pos_cont",spacengine.compact(prelativ))
    
    if sauvegarde then --sauvegarde nouvelle donnée du module
      dst_met:set_string("spacengine",spacengine.compact(dst_space))
    end

    end --ifchannel

  end --for

  config[1][3]=math.ceil(config[1][3]/nb) --damage

    if config[2][2]>config[2][1] then config[2][2]=config[2][1] end --limitation battery

    if idx4>1 then --engine
      config[4][1]=math.floor(config[4][1]/idx4)+idx4
      config[4][3]=math.floor(config[4][3]/idx4)
      config[4][5]=math.floor(config[4][5]/idx4)
    end

    if idx5>1 then --shield
      config[5][3]=math.floor(config[5][3]/idx5)
      config[5][1]=math.min(150,math.floor((config[5][1]/idx5)+(idx5*2)))
    end

    if idx6>1 then --weapons
      config[6][1]=math.floor(config[6][1]/idx6)
      config[6][3]=math.min(160,math.floor(config[6][3]/idx6))
      config[6][5]=math.floor(config[6][5]/idx6)
      config[6][8]=math.floor(config[6][8]/idx6)
    end

    if idx7>1 then --radar
      config[7][1]=math.floor(config[7][1]/idx7)+(idx7*2)
      config[7][3]=math.min(200,math.floor(config[7][3]/idx7)+idx7)
    end

    if idx8>1 then --gravitation
      config[8][1]=math.floor(config[8][1]/idx8)
    end

    if idx11>1 then --oxygene
      config[11][1]=math.min(100,math.floor(config[11][1]/idx11))
      config[11][3]=math.floor(config[11][3]/idx11)
    end

    if idx13>1 then --manutention
      manutention[1]=math.floor(manutention[1]/idx13)
      manutention[3]=math.floor(manutention[3]/idx13)
      manutention[12]=math.ceil(manutention[12]/idx13)
    end

    config[3][4]=cont1
    config[3][5]=cont2
    config[6][7]=idx6
    config[7][4]=cont7
    config[7][5]=cont77
    config[9][1]=storage[1]
    config[10][1]=passenger[1]
    manutention[5]=cont11

    if manutention[7]=="" then manutention[7]="n" end

    config[13]=manutention

    local calcul=0
    storage[3][7],calcul=stockmax(storage[3][7],calcul,config[9][1])
    storage[3][6],calcul=stockmax(storage[3][6],calcul,config[9][1])
    storage[3][5],calcul=stockmax(storage[3][5],calcul,config[9][1])
    storage[3][4],calcul=stockmax(storage[3][4],calcul,config[9][1])
    storage[3][3],calcul=stockmax(storage[3][3],calcul,config[9][1])
    storage[3][2],calcul=stockmax(storage[3][2],calcul,config[9][1])
    storage[3][1],calcul=stockmax(storage[3][1],calcul,config[9][1])
    config[1][2]=config[1][2]+calcul
    storage[2]=calcul
    config[9]=storage

    calcul=0
    passenger[3][1],calcul=stockmax(passenger[3][1],calcul,config[10][1])
    passenger[3][2],calcul=stockmax(passenger[3][2],calcul,config[10][1])
    passenger[3][3],calcul=stockmax(passenger[3][3],calcul,config[10][1])
    passenger[3][4],calcul=stockmax(passenger[3][4],calcul,config[10][1])
    passenger[3][5],calcul=stockmax(passenger[3][5],calcul,config[10][1])
    config[1][2]=config[1][2]+calcul
    passenger[2]=calcul
    config[10]=passenger
    
    if idx_radio==1 then
      config[15][1]=radio.x
      config[15][2]=radio.y
      config[15][3]=radio.z
      config[15][4]="0000"
    else
      config[15][1]=33333
      config[15][2]=0
      config[15][3]=0
      config[15][4]="0000"

    end

    if id_stock_pos>1 then
      controler:set_string("stock_pos",spacengine.compact(stock_pos))
    else
      controler:set_string("stock_pos","")
    end

    controler:set_string("config",spacengine.compact(config))

end
