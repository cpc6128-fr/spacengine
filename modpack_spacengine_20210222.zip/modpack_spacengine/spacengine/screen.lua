--position display +00000
local function p_dis(p,nz)
if nz==nil then nz=5 end
local a=""
if p<0 then
a="-"..string.sub(tostring(math.abs(p)+10^nz),2)
else
a="+"..string.sub(tostring(p+10^nz),2)
end
return a
end

--battery display 888%
local function battery(config)
  local b1
  local b2="k"
  if config[2][1]==0 then --% battery
    b1=0
  else
    b1=math.ceil(((config[2][2])/config[2][1])*100)
  end
  if b1>74 then --couleur pile
    b2="f"
  elseif b1<26 then
    b2="h"
  end

  return "(1(".. b2 ..string.char(math.floor(b1/25)+112) ..")(q".. string.sub(tostring(b1+1000),2) .."%"
end

--chargement display 888%
local function chargement(config)
  local poid1=config[1][2]
  local poid2=config[4][7]
  local poid=""
if poid1<poid2 then
          if poid2==0 then
            poid1=0
          else
            poid1=math.ceil((poid1/poid2)*100)
          end
          poid=poid.."(l(2`)"..string.sub(tostring(poid1+1000),2).."%"
        else
          poid=poid.."(h(2`)OVER"
        end
  return poid
end

--
local function energy_total(config)
  local u_t=config[2][2]
  local unit=" U"

  if u_t>100000 then
    u_t=math.floor(u_t/1000)
    unit="KU"
  end
  return "(q(1*)"..string.sub(tostring(math.floor(u_t)+100000),2)..unit
end

---- barre graphe horizontal **
local function vumetre(value,value_max,color)
  local coef=100/value_max
  local case=math.min(10,math.floor((value*coef)/10))
  local barre=""
  if case>8 then
    if color then
      barre="(h"..string.char(72+case)
    else
      barre=string.char(72+case)
    end
    case=8
  else
    if color then
      barre="(hP"..barre
    else
      barre="P"..barre
    end
  end

  if case>6 then
    if color then
      barre="(k"..string.char(74+case)..barre
    else
      barre=string.char(74+case)..barre
    end
    case=6
  else
    if color then
      barre="(kP"..barre
    else
      barre="P"..barre
    end
  end

  if case>4 then
    if color then
      barre="(k"..string.char(76+case)..barre
    else
      barre=string.char(76+case)..barre
    end
    case=4
  else
    if color then
      barre="(kP"..barre
    else
      barre="P"..barre
    end
  end

  if case>2 then
    barre=string.char(78+case)..barre
    case=2
  else
    barre="P"..barre
  end
  if case>0 then
    barre=string.char(80+case)..barre
  else
    barre="P"..barre
  end

  if color then
    barre="(f"..barre
  else
    if value<(value_max*0.25) then
      barre="(h"..barre
    elseif value<(value_max*0.5) then
      barre="(K"..barre
    else
      barre="(f"..barre
    end
  end

  return barre
end

--**********************
--*** screen display ***
--**********************
spacengine.screen_display=function(npos,nod_met,cpos,cont_met,config)
  local channel=nod_met:get_string("channel")

  local pos_cont=spacengine.decompact(nod_met:get_string("pos_cont"))
  local split=string.split(channel,":")
  local owner=split[2]
  channel=split[1]

  if channel=="No channel" or pos_cont[2]>31000 then
    nod_met:set_string("text","ERROR")
    monitor.update_sign(npos,nil,nil,nil)
    return false
  end

  local nod_space=spacengine.decompact(nod_met:get_string("spacengine"))
  local scr_opt=string.sub(nod_space[1],1,1)
  local phr=""
  local page=""

  --spacengine off
  if config[1][1]==0 then
    phr="(u".. string.sub(owner,1,16) .." | (s(2CBBBBBBBBBBBBBBD) | (s(2A)(hSPACENGINE OFF(2(sA) | (s(2EBBBBBBBBBBBBBBF) | (u".. string.sub(channel,1,16)

  else
    local bymodule=config[12]
    local by_all=false

    if string.find(config[12],"y") then
      by_all=true
    end

    --multipage
  if bymodule~="n" then
    local lng=string.len(nod_space[4])/3
    page="(2(b"
    for i=1,lng do
      if i==nod_space[5] then
        page=page.."(c"..i.."(b"
      else
        page=page..i
      end
    end
    page=page.. string.rep("_",9-lng)..")(c"
  end

  --*****************
  --*** controler ***
  --*****************
  if string.find(bymodule,"C") or string.find(bymodule,"e") or by_all then
    if scr_opt=="C" then
      local vl=tonumber(string.sub(nod_space[4],12,12))+1
      if nod_space[5]==1 then
        page=page.."(1;)ON(1:)OFF"
      elseif nod_space[5]==2 then
        page=page.."(h(1!)JUMP "
        if config[4][6]<250 then
          page=page.."(f(1u)"
        else
          page=page.."(h(1!)"
        end
      elseif nod_space[5]==3 then
        page=page.."(3?MENU=@)"
      elseif nod_space[5]==4 then
        page=page.."MSG "..vl.."(1_6)"        
      elseif nod_space[5]==5 then
        page=page.."CLR MSG"
      end
      
      if nod_space[5]<4 then
      phr=page.." | (P(3?CONTROLER@)".. battery(config) .." | "
      if config[3][3]<0 then
        phr=phr.."(2(df(h".. string.char(math.min(7,math.ceil(config[3][3]*-0.001))+110) .."(df"
      else
        phr=phr.."(2(df(t".. string.char(math.min(7,math.ceil(config[3][3]*0.001))+110) .."(df"
      end

      if config[4][2]>0 then
        phr=phr.."(f(1_'"..string.char(math.floor(config[4][2]/15)+97).."_)"
      else
        phr=phr.."(h(1_'a_)"
      end

      if config[6][2]>0 then
        phr=phr.."(f(1%"..string.char(math.floor(config[6][2]/15)+97).."_)"
      else
        phr=phr.."(h(1%a_)"
      end

      if config[5][2]>0 then
        phr=phr.."(f(1`"..string.char(math.floor(config[5][2]/15)+97).."_)"
      else
        phr=phr.."(h(1`a_)"
      end

      if config[11][2]>0 then 
        phr=phr.."(f (2:(1"..string.char(math.floor(config[11][2]/15)+97)..")"
      else
        phr=phr.."(h (2:(1a)"
      end
      end
      local rmax=spacengine.conso_engine(cpos,config,1)
      
      if nod_space[5]==1 then
        local rangex=11+tonumber(string.sub(config[1][4],2,2))*4
        local rangey=11+tonumber(string.sub(config[1][4],4,4))*4
        local rangez=11+tonumber(string.sub(config[1][4],6,6))*4
        phr=phr.." | (r(1x)"
        if config[1][3]>75 then
          phr=phr.."(h"
        elseif config[1][3]>50 then
          phr=phr.."(j"
        else
          phr=phr.."(f"
        end
        phr=phr .. string.sub(tostring(math.floor(config[1][3])+1000),2) .."%"
        phr=phr .. "(c(1_v)X".. rangex .."Y"..rangey.."Z"..rangez.." | "
        phr=phr.. "(1(kV)"..chargement(config) .."(l(14$)"..string.sub(tostring(config[1][2]+10000000),2)

      elseif nod_space[5]==2 then
        phr=phr.." | (jX"..p_dis(config[1][6][1]) .."(1__)Z"..p_dis(config[1][6][3]) .." | (jY"..p_dis(config[1][6][2]) .."(1__(m+w)".. string.sub(tostring(rmax+100000),2)

      elseif nod_space[5]==3 then
        phr=phr.." | (fX"..p_dis(cpos.x) .."(1__)Z"..p_dis(cpos.z) .." | (fY"..p_dis(cpos.y) .."(1__(m+w)".. string.sub(tostring(rmax+100000),2)
      elseif nod_space[5]>3 then
        phr=page.." | (E"
        local nb_msg=string.split(config[13][9],";")

        if vl<#nb_msg+1 then
          local lng=string.len(nb_msg[vl])
          local s1,s2,s3="","",""
          if lng>32 then
            s3=string.sub(nb_msg[vl],33,48) 
          end
          if lng>16 then
            s2=string.sub(nb_msg[vl],17,32)
          end
          s1=string.sub(nb_msg[vl],1,16)
          phr=phr..s1
          if s2~="" then --2 ligne
            phr=phr.." | ".. s2
          end
          if s3~="" then --3 ligne
            phr=phr.." | ".. s3
          end
        end
      end
    end
  end

  if string.find(bymodule,"B") or string.find(bymodule,"e") or by_all then
    --***************
    --*** battery ***
    --***************
    if scr_opt=="B" then
      page=page.."(3?MENU=@) | "
      phr=page.."(p(3?BATTERY@) ".. battery(config) .." | (qlvl ".. string.sub(tostring(math.floor(config[2][2])+10000000000),2) .." | (emax ".. string.sub(tostring(math.floor(config[2][1])+10000000000),2).." | "

      if config[3][3]<0 then
        phr=phr.."(2(df(h".. string.char(math.min(7,math.ceil(config[3][3]*-0.001))+110) .."(df_)(h".. string.sub(tostring(math.floor(math.abs(config[3][3])+10000000)),2)
      else
        phr=phr.."(2(df(t".. string.char(math.min(7,math.ceil(config[3][3]*0.001))+110) .."(df_)(f".. string.sub(tostring(math.floor(config[3][3])+10000000),2)
      end
    end
  end
  --*************
  --*** power ***
  --*************
  if string.find(bymodule,"P") or string.find(bymodule,"e") or by_all then
    if scr_opt=="P" then

      if nod_space[5]==1 then
        page=page.." ON/OFF"
      elseif nod_space[5]==2 then
        page=page.."- SRC -"
      elseif nod_space[5]==3 then
        page=page.."(3?MENU=@)"
      end

      phr=page.." | (p(3?POWER@)"

        local tmp1=config[3][1]
        
        if type(config[3][4])=="table" then
          if #config[3][4]>1 then
          if tmp1<2 or tmp1>#config[3][4] then tmp1=2 end

          local id=config[3][4][tmp1]
          if config[3][5][tmp1]==0 then
            phr=phr.."(h(3?OFF@) | (g"
          else
            phr=phr.."(f(3?ON=@) | (g"
          end
          phr=phr.. string.sub(spacengine.upgrade[3][id][3],1,16) .." | "
          end
        else
          phr=phr.."(jNONE | (h(3?OFF@) | "
        end

      if config[3][3]<0 then
        phr=phr.."(2(df(h".. string.char(math.min(7,math.ceil(config[3][3]*-0.001))+110) .."(df)(h".. string.sub(tostring(math.floor(math.abs(config[3][3])+10000000)),2)
      else
        phr=phr.."(2(df(t".. string.char(math.min(7,math.ceil(config[3][3]*0.001))+110) .."(df)(f".. string.sub(tostring(math.floor(config[3][3])+10000000),2)
      end

      local tmp1=config[2][1]
      local tmp2=config[2][2]
      local tmp3="U"
      if tmp1>100000 then
        tmp1=math.floor(tmp1/1000)
        tmp2=math.floor(tmp2/1000)
        tmp3="KU"
      end
      phr=phr.." | (1(qt)"..string.sub(tostring(math.floor(tmp2)+100000),2).."(o/(e".. string.sub(tostring(math.floor(tmp1)+100000),2) ..tmp3
    end
  end
  --**************
  --*** engine ***
  --**************
  if string.find(bymodule,"E") or string.find(bymodule,"e") or by_all then
    if scr_opt=="E" then
      if nod_space[5]==1 then
        phr=page.."(h(1!)JUMP (1!)"
      elseif nod_space[5]==2 then
        phr=page.."PUISSAN"
      elseif nod_space[5]==3 then
        phr=page.."(3?MENU=@)"
      elseif nod_space[5]==4 then
        phr=page.."(nQUICK(2(k_=)"
      elseif nod_space[5]==5 then
        phr=page.."(nQUICK(1(d_3)"
      elseif nod_space[5]==6 then
        phr=page.."(nQUICK(1(h_u)"
      end

      phr=phr.." | (p(3?ENGINE@)"
      if config[4][6]<250 then
        phr=phr.."(f(1u)"
      else
        phr=phr.."(h(1!)"
      end
      
      if config[4][6]>5000 then
        phr=phr.." (2(h"
      elseif config[4][6]>999 then
        phr=phr.." (2(k"
      else
        phr=phr.." (2(f"
      end

      phr=phr.."m)".. string.sub(tostring(config[4][6]+100000),2).." | "
      local conso,rmax,distance=spacengine.conso_engine(cpos,config,2)

      if nod_space[5]==1 then
        phr=phr.."(jX"..p_dis(config[1][6][1]).."(1____)".. battery(config).." | (jY".. p_dis(config[1][6][2]) .."(1____(rx)"..string.sub(tostring(math.floor(config[1][3])+1000),2) .."% | (jZ".. p_dis(config[1][6][3]) .."(1___(du)".. string.sub(tostring(distance+100000),2)

      elseif nod_space[5]==2 then
        local conso_2
        if config[2][2]>0 then
          conso_2=math.min(200,math.ceil((conso/config[2][2])*100))
        else
          conso_2=200
        end
        local tmp1="f"
        if conso_2>75 then
          tmp1="h"
        elseif conso_2>50 then
          tmp1="k"
        end

        local tmp3=math.floor(config[4][2]/16)+65
        tmp2=math.ceil((config[4][1]*config[4][2])/100)
        phr=phr.."(1(n3)".. string.sub(tostring(rmax+100000),2) .."(k(1R*)".. string.sub(tostring(conso+100000000),2) .." | (1(mw)".. string.sub(tostring(config[4][3]+100000),2) .."(q(1Rt)".. string.sub(tostring(config[2][2]+100000000),2) .." | (g(1".. string.char(tmp3) .."')".. string.sub(tostring(tmp2+1000),2).."T(j(1R)("..tmp1.. string.sub(tostring(conso_2+1000),2) .."%".. chargement(config)

      elseif nod_space[5]==3 then
        phr=phr.."(fX"..p_dis(cpos.x).."(1(l$V)".. string.sub(tostring(config[1][2]+10000000),2) .." | (fY"..p_dis(cpos.y).. "(2(k`(1V)".. string.sub(tostring(config[4][7]+10000000),2) .." | (fZ".. p_dis(cpos.z).."(2(dmR__)".. string.sub(tostring(config[4][5]+100000),2)

      elseif nod_space[5]>3 then
        local vl=0
        if config[4][8]~=nil then vl=config[4][8] end
        --local vl=tonumber(string.sub(nod_space[4],12,12))+1
        phr=phr.."(d".. string.sub(tostring(rmax+100000),2) .."(1w(e__"

        if vl==0 then
          phr=phr.."(h2(e"
        else
          phr=phr.."2"
        end

        phr=phr.."__"

        if vl==4 then
          phr=phr.."(h2(e"
        else
          phr=phr.."2"
        end

        local conso_2
        if config[2][2]>0 then
          conso_2=math.min(200,math.ceil((conso/config[2][2])*100))
        else
          conso_2=200
        end
        phr=phr.." | (i(1*)".. string.sub(tostring(conso_2+1000),2) .."%(1(e__"

        if vl==3 then
          phr=phr.."(h0(e"
        else
          phr=phr.."0"
        end

        phr=phr.."(g$(e"

        if vl==1 then
          phr=phr.."(h4(e"
        else
          phr=phr.."4"
        end

        phr=phr.."_(g+) | "..battery(config).."(e(1___"

        if vl==2 then
          phr=phr.."(h6(e"
        else
          phr=phr.."6"
        end

        phr=phr.."__"

        if vl==5 then
          phr=phr.."(h6)"
        else
          phr=phr.."6)"
        end

      end
      
    end
  end

--************
--** shield **
--************
if string.find(bymodule,"S") or by_all then
  if scr_opt=="S" then

    if nod_space[5]==1 then
      page=page.."PUISSAN"
    elseif nod_space[5]==2 then
        page=page.."(3?MENU=@)"
    end

    phr=page.." | (p(3?SHIELD@)"
    if config[5][2]>0 then
      phr=phr.."(f (3?ON=@)"
    else
      phr=phr.."(h (3?OFF@)"
    end
    local tmp1=math.floor(config[5][1]*config[5][2]*(100-config[5][4])*0.0001)
    local tmp2=math.floor(config[5][2]/15)+65
    phr=phr.." | (1(k"..string.char(tmp2)..")"..string.sub(tostring(tmp1+1000),2).." | (n(1`)"..string.sub(tostring(config[5][1]+1000),2).." | (1x)"
    if config[5][4]>75 then
        phr=phr.."(h"
      elseif config[5][4]>50 then
        phr=phr.."(j"
      else
        phr=phr.."(f"
      end
    phr=phr.. string.sub(tostring(math.ceil(config[5][4])+1000),2).."%"
  end
end

--*************
--** weapons **
--*************
if string.find(bymodule,"W") or by_all then
  if scr_opt=="W" then

    phr=" | (p (3?WEAPONS@) "
    if config[6][6]==0 then
      phr=phr.."(fREADY!"
    else
      phr=phr.."(hRELOAD"
    end
    
    if nod_space[5]==1 then
      page=page.."(h(1!)FIRE (1!)"
    elseif nod_space[5]==2 then
      page=page.."PUISSAN"
    elseif nod_space[5]==3 then
      page=page.."-RANG -"
    elseif nod_space[5]==4 then
      page=page.."-ZONE -"
    elseif nod_space[5]==5 then
      page=page.."(3?MENU=@)"
    end
    
    local puissance=math.floor(config[6][1]*config[6][2]*0.01)
    local range=math.floor(config[6][3]*config[6][4]*0.01)
    local zone=math.ceil(config[6][8]*config[4][4][4]*0.01)
    local xrng=math.ceil((-1+(0.02*config[4][4][1]))*range)
    local yrng=math.ceil((-1+(0.02*config[4][4][2]))*range)
    local zrng=math.ceil((-1+(0.02*config[4][4][3]))*range)
    local rmax=math.max(math.abs(xrng),math.abs(yrng),math.abs(zrng))
    local conso=puissance+rmax+(zone*zone*zone)

    local tmp2=math.floor(config[6][2]/15)+65

    
    phr=page..phr.." | ".. battery(config) .."(l(1_%)".. string.sub(tostring(config[6][7]+1000),2) .." (d(1v)".. string.sub(tostring(config[6][8]+1000),2) .." | (1(g*".. string.char(tmp2) ..")".. string.sub(tostring(conso+100000),2).."U(1_(mw"
    
    tmp2=math.floor(config[6][4]/15)+65
    phr=phr..string.char(tmp2)..")"..string.sub(tostring(range+1000),2)
    if nod_space[5]<4 then
      phr=phr.." | (e(2_Q)"..string.sub(tostring(config[6][6]+10000),2) .."/".. string.sub(tostring(config[6][5]+10000),2)
    elseif nod_space[5]==4 then
      
      tmp2=math.floor(config[4][4][4]/15)+72
      phr=phr.." | (kZONE (1".. string.char(tmp2) .."_)"..zone
    else
      tmp1=math.floor((config[6][3]*config[6][4])/100)
      local xrng=math.ceil((-1+(0.02*config[4][4][1]))*range)
      local yrng=math.ceil((-1+(0.02*config[4][4][2]))*range)
      local zrng=math.ceil((-1+(0.02*config[4][4][3]))*range)
      phr=phr.." | (pX"..xrng.." Y"..yrng.." Z"..zrng
    end

  end
end

--*****************
--** gravitation **
--*****************
if string.find(bymodule,"G") or by_all then
  if scr_opt=="G" then

    if nod_space[5]==1 then
      page=page.."PUISSAN"
    elseif nod_space[5]==2 then
        page=page.."(3?MENU=@)"
    end

    phr=page.." | (p(3?GFORCE@)"
    if config[8][2]>0 then
      phr=phr.."(f(3?ON=@)"
    else
      phr=phr.."(h(3?OFF@)"
    end
    local tmp1=math.max(10,(config[8][1]*config[8][2]))/100
    local tmp2=math.floor(config[8][2]/14.4)+65
    phr=phr.." | (1(l"..string.char(tmp2)..") | (l"..tmp1.."G"
  end
end

--*************
--** oxygene **
--*************
if string.find(bymodule,"O") or by_all then
  if scr_opt=="O" then --oxygene

    if nod_space[5]==1 then
      page=page.."PUISSAN"
    elseif nod_space[5]==2 then
      page=page.."(h(1!)OXYGEN"
    elseif nod_space[5]==3 then
      page=page.."(3?MENU=@)"
    end

    local tmp1=math.floor((config[11][1]*config[11][2])/100)
    local tmp2=math.floor(config[11][2]/15)+65
    phr=page.." | (p(3?OXYGENE@(1_(i"..string.char(tmp2)
    if config[11][2]>0 then
      phr=phr.."(f(3?ON=@)"
    else
      phr=phr.."(h(3?OFF@)"
    end
    
    local volume=math.ceil((tonumber(string.sub(config[1][4],8,11))*config[11][1]*config[11][2])/3000000)
    phr=phr.." | (2(fR(1"..vumetre(config[11][4],config[11][3],false).."(2_(c:(1"..vumetre(tmp1,100,true).." | (1(j&"..vumetre(volume,25,true)..") | (d"..volume

  end
end

--***********
--** radar **
--***********
if string.find(bymodule,"R") or by_all then
  if scr_opt=="R" then --radar

    if nod_space[5]==1 then
      page=page.."(j-SCAN -"
    elseif nod_space[5]==2 then
      page=page.."PUISSAN"
    elseif nod_space[5]==3 then
      page=page.."-CIBLE-"
    elseif nod_space[5]==4 then
      page=page.."-ZONE -"
    elseif nod_space[5]==5 then
      page=page.."(3?MENU=@)"
    end

    phr=page.." | (p(3?RADAR@(1(rU_(lw)"..config[7][3]
    local tmp1=math.floor((config[7][1]*config[7][2])/100)
    local tmp2=math.floor(config[7][2]/15)+65
    local tmp3=math.floor((config[7][3]*config[4][4][4])/100)
    phr=phr.." | "..battery(config).."(1(d_"..string.char(tmp2).."*)"..string.sub(tostring(tmp1+1000),2).."U (p(1v)"..tmp3
    if nod_space[5]<4 then
      local id=math.max(1,config[7][6])
      if type(config[7][4])=="table" then
        id=math.min(#config[7][4],id)
        tmp3=string.split(config[7][4][id],":")
        phr=phr.." | (p".. string.sub(tmp3[2],1,16).." | (p"..config[7][5][id]
      else
        tmp3=string.split(config[7][4],":")
        phr=phr.." | (p".. string.sub(tmp3[2],1,16).." | (p"..config[7][5]
      end

    else
      local xrng=math.ceil((-1+(0.02*config[4][4][1]))*config[7][3])
      local yrng=math.ceil((-1+(0.02*config[4][4][2]))*config[7][3])
      local zrng=math.ceil((-1+(0.02*config[4][4][3]))*config[7][3])
      phr=phr.." | (pX"..xrng.." Y"..yrng.." Z"..zrng
    end
  end
end

--*****************
--** manutention **
--*****************
if string.find(bymodule,"M") or by_all then
  if scr_opt=="M" then
    local manutention=config[13]

    if nod_space[5]==1 then
      page=page.."!EXEC !"
    elseif nod_space[5]==2 then
      page=page.."COMMAND"
    elseif nod_space[5]==3 then
      page=page.."-SRCE -"
    elseif nod_space[5]==4 then
      page=page.."-RANGE-"
    elseif nod_space[5]==5 then
      page=page.."-ZONE -"
    elseif nod_space[5]==6 then
      page=page.."(3?MENU=@)"
    end

    local tmp1=math.floor((manutention[1]*manutention[2])/100)
    local tmp2=math.floor(manutention[2]/15)+65
    local tmp3
    local tmp4=math.floor((manutention[3]*config[4][4][4])/100)

    if type(manutention[5])=="table" then
      if manutention[6]>#manutention[5] then manutention[6]=1 end
      tmp3=string.split(manutention[5][manutention[6]],":")
    else
      tmp3=string.split(manutention[5],":")
    end

    if config[13][10]<0 then
      phr=page.." | (3(h?MANUTENTION@)"
    else
      phr=page.." | (3(f?MANUTENTION@)"
    end

    phr=phr.."(j(2R)".. string.sub(tostring(tmp3[3]+100),2) .." | (1(mw".. string.char(tmp2) ..")".. string.sub(tostring(tmp1+1000),2)
    
    tmp2=math.floor(config[4][4][4]/15)+65

    phr=phr.."(1(d_v"..string.char(tmp2)..")".. string.sub(tostring(tmp4+1000),2).."(i(1_*)".. string.sub(tostring(tmp3[5]+1000),2)

  if nod_space[5]<4 then
    phr=phr.." | (f".. string.sub(tmp3[2],1,16).." | "

    if string.find(manutention[7],"B") and string.find(tmp3[4],"B") then
      if manutention[8]==1 then
        phr=phr.."(1(kT)"
      else
        phr=phr.."(1(wT)"
      end
    else
      phr=phr.."(1(w/)"
    end
    if string.find(manutention[7],"D") and string.find(tmp3[4],"D") then
      if manutention[8]==2 then
        phr=phr.."(2(k*)"
      else
        phr=phr.."(2(w*)"
      end
    else
      phr=phr.."(1(w/)"
    end
    if string.find(manutention[7],"P") and string.find(tmp3[4],"P") then
      if manutention[8]==3 then
        phr=phr.."(2(k+)"
      else
        phr=phr.."(2(w+)"
      end
    else
      phr=phr.."(1(w/)"
    end
  else
    local xrng=math.ceil((-1+(0.02*config[4][4][1]))*tmp1)
    local yrng=math.ceil((-1+(0.02*config[4][4][2]))*tmp1)
    local zrng=math.ceil((-1+(0.02*config[4][4][3]))*tmp1)
    phr=phr.." | (pX"..xrng.." Y"..yrng.." Z"..zrng .." "..config[13][11]

end

  end
end

--*************
--** storage **
--*************
if string.find(bymodule,"s") or by_all then
  if scr_opt=="s" then
    local storage=config[9]

    if nod_space[5]==1 then
      page=page.."STORAGE"
    elseif nod_space[5]==2 then
      page=page.."VOYAGER"
    elseif nod_space[5]==3 then
      page=page.."MISSION"
    elseif nod_space[5]==4 then
        page=page.."(3?MENU=@)"
    end

    local nb_param=nod_space[5]
    if nb_param>math.floor(string.len(nod_space[4])/3) then
      nb_param=1
    end

    local vl=string.sub(nod_space[4],nb_param*3,nb_param*3)
    phr=page.." | (p(3?STORAGE@(2_(w`(1(e_6)"..vl.."(12) | "

    if nod_space[5]==1 then
    phr=phr.."(o".. string.sub(tostring(storage[2]+1000000),2) .."/".. string.sub(tostring(storage[1]+1000000),2)
    if vl=="0" then
      phr=phr.." | (pEat "..storage[3][1].." | (pOres"..storage[3][2]
    elseif vl=="1" then
      phr=phr.." | (pTools "..storage[3][3].." | (pMaterial"..storage[3][4]
    elseif vl=="2" then
      phr=phr.." | (pFurniture "..storage[3][5].." | (pMachine"..storage[3][6]
    elseif vl=="3" then
      phr=phr.." | (pMisc "..storage[3][3]
    elseif vl=="4" then
      phr=phr.." | (pWeight "..config[1][2]
    end
    end

    if nod_space[5]==2 then
    phr=phr.."(o".. string.sub(tostring(config[10][2]+1000000),2) .."/".. string.sub(tostring(config[10][1]+1000000),2)
    if vl=="0" then
      phr=phr.." | (pcrew "..config[10][3][1]
    elseif vl=="1" then
      phr=phr.." | (pworker "..config[10][3][3]
    elseif vl=="2" then
      phr=phr.." | (ptourist "..config[10][3][5]
    elseif vl=="3" then
      phr=phr.." | (pscientist "..config[10][3][3]
    elseif vl=="4" then
      phr=phr.." | (pmilitary "..config[10][3][3]
    elseif vl=="5" then
      phr=phr.." | (pWeight "..config[1][2]
    end
    end

    if nod_space[5]==3 then
      local tmp=cont_met:get_string("delivery")
      if tmp~="" then
        local mission=string.split(tmp,"/")
        local vl_nb=tonumber(vl)+1
        if vl_nb<#mission+1 then
        local creat_dat=((espace.year-1)*168)+((espace.month-1)*14)+espace.day
        local this_secteur=espace.secteur(cpos)
        local passenger_type={"worker","tourist","scientist","military"}
        local item_type={"eat","ores","tools","material","furniture","machine","misc"}
    
        local destination=string.split(mission[vl_nb],":")
        local nb=tonumber(destination[2])
        local days=""
        local arrival=""
        local tmp=tonumber(destination[5])-creat_dat

        if tmp>0 then
          days= " (d".. tmp .."D"
        else
          days="(1(h!)"..tmp
        end
        --test coordo destination
        if tonumber(destination[7])==this_secteur.nb then
          arrival="(fOK"
        else
          arrival="(kS".. tonumber(destination[7])+1
        end

        if destination[1]=="0" then
          phr = phr .."(j"..item_type[nb].." ".. destination[3] .." U | "..arrival..days.." | (j"..destination[4].."Mg"
        else
          phr = phr .."(n".. destination[3].." "..passenger_type[nb].." | "..arrival..days.." | (n"..destination[4].."Mg"
        end
        end
      else
        phr=phr.."No MISSION"
      end
    end

  end
end
--[[
--***************
--** passenger **
--***************
if string.find(bymodule,"p") or by_all then
  if scr_opt=="p" then
    local passenger=config[10]

    if nod_space[5]==1 then
      page=page.."PAGE (162)"
    elseif nod_space[5]==2 then
        page=page.."(3?MENU=@)"
    end

    phr=page.." | (p(3?MISSION@(2_(n@) | (o".. string.sub(tostring(passenger[2]+1000000),2) .."/".. string.sub(tostring(passenger[1]+1000000),2) .." | (pCrew"..passenger[3][1]
    local nb_param=nod_space[5]
    if nb_param>math.floor(string.len(nod_space[4])/3) then
      nb_param=1
    end

    local vl=string.sub(nod_space[4],nb_param*3,nb_param*3)
    phr=page.." | (p(3?PASSENGER@(2_(n@) | (o".. string.sub(tostring(passenger[2]+1000000),2) .."/".. string.sub(tostring(passenger[1]+1000000),2)
    if vl=="0" then
      phr=phr.." | (pCrew "..passenger[3][1]
    elseif vl=="1" then
      phr=phr.." | (pWorker "..passenger[3][2]
    elseif vl=="2" then
      phr=phr.." | (pTourist "..passenger[3][3]
    elseif vl=="3" then
      phr=phr.." | (pScientist "..passenger[3][4]
    elseif vl=="4" then
      phr=phr.." | (pMilitary "..passenger[3][5]
    elseif vl=="5" then
      phr=phr.." | (pWeight "..config[1][2]
    end

  end
end
--]]
if string.find(bymodule,"A") or by_all then
--** SWITCH **
  if scr_opt=="A" then
    
    if nod_space[5]==1 then
      page=page.."HANGAR(1_)"
    elseif nod_space[5]==2 then
      page=page.."SAS_OUT"
    elseif nod_space[5]==3 then
      page=page.."DOOR_IN"
    elseif nod_space[5]==4 then
      page=page.."STORAGE"
    elseif nod_space[5]==5 then
      page=page.."AUX_1(1__)"
    elseif nod_space[5]==6 then
      page=page.."AUX_2(1__)"
    elseif nod_space[5]==7 then
      page=page.."-LIGHT-"
    end

    phr=page.." | (p(3?SWITCH@) | (1"
    local lign_up,lign_down="",""
    local value
    for nb_param=1, 7 do
      value=tonumber(string.sub(nod_space[4],nb_param*3,nb_param*3))
      if value==0 then
        lign_up=lign_up.."(h_Y"
        lign_down=lign_down.." "..nb_param
      else
        lign_up=lign_up.."(f_Z"
        lign_down=lign_down.." "..nb_param
      end
    end
    phr=phr..lign_up.."_) | (p"..lign_down .."(1_) | (2(sBBBBBBBBBBBBBBBB)"
  end
end

if string.find(bymodule,"D") or by_all then
--** analog **
  if scr_opt=="D" then
    
    if nod_space[5]==1 then
      page=page.."-ENGINE"
    elseif nod_space[5]==2 then
      page=page.."WEAPONS"
    elseif nod_space[5]==3 then
      page=page.."-SHIELD"
    elseif nod_space[5]==4 then
      page=page.."-RADAR-"
    elseif nod_space[5]==5 then
      page=page.."GRAVITO"
    elseif nod_space[5]==6 then
      page=page.."OXYGENE"
    elseif nod_space[5]==7 then
      page=page.."COORDO-"
    end

    if nod_space[5]<7 then
    local lign_up=""
    local lign_down=""
    phr=page.." | (p(3?ANALOG@) | "

    if config[4][2]>0 then
      lign_up=lign_up.."(f(1"..string.char(math.floor(config[4][2]/15)+65)
      --lign_down=lign_down.."(f(1'"
    else
      lign_up=lign_up.."(h(1A"
      --lign_down=lign_down.."(h(1'"
    end

    if config[6][2]>0 then
      lign_up=lign_up.."(f_"..string.char(math.floor(config[6][2]/15)+65)
      --lign_down=lign_down.."(f_%"
    else
      lign_up=lign_up.."(h_A"
      --lign_down=lign_down.."(h_%"
    end

    if config[5][2]>0 then
      lign_up=lign_up.."(f_"..string.char(math.floor(config[5][2]/15)+65)
      --lign_down=lign_down.."(f_`"
    else
      lign_up=lign_up.."(h_A"
      --lign_down=lign_down.."(h_`"
    end

    if config[7][2]>0 then
      lign_up=lign_up.."(f_"..string.char(math.floor(config[7][2]/15)+65)
      --lign_down=lign_down.."(f_U"
    else
      lign_up=lign_up.."(h_A"
      --lign_down=lign_down.."(h_U"
    end

    if config[8][2]>0 then 
      lign_up=lign_up.."(f_"..string.char(math.floor(config[8][2]/15)+65)
      --lign_down=lign_down.."(f_)G"
    else
      lign_up=lign_up.."(h_A"
      --lign_down=lign_down.."(h_)G"
    end

    if config[11][2]>0 then 
      lign_up=lign_up.."(f_"..string.char(math.floor(config[11][2]/15)+65)
      --lign_down=lign_down.."(f(2_:)"
    else
      lign_up=lign_up.."(h_A)"
      --lign_down=lign_down.."(h(2_:)"
    end

    phr=phr..lign_up.." | (1(p'_%_`_U_)G(2_:)"

    else

    local zone=math.floor(config[4][4][4]/15)+65
    phr=page.." | (1(m".. string.char(math.floor(config[4][4][1]/15)+65) .."(e".. string.char(math.floor(config[4][4][2]/15)+65) .."(j".. string.char(math.floor(config[4][4][3]/15)+65) .."(p(3?COORDO@(k(1_"..string.char(zone) ..") | "
    local wpns=math.floor((config[6][3]*config[6][4])/100)
    local radar=config[7][3]
    local manut=math.floor((config[13][1]*config[13][2])/100)
    local xrng=(-1+(0.02*config[4][4][1]))
    local yrng=(-1+(0.02*config[4][4][2]))
    local zrng=(-1+(0.02*config[4][4][3]))
    phr=phr.."(1(h%)(mX".. p_dis(math.floor(xrng*wpns),2).." (eY"..p_dis(math.floor(yrng*wpns),2).." (jZ"..p_dis(math.floor(zrng*wpns),2).." | " --.."(1(d"..string.char(zone)..")"
    phr=phr.."(1(dU)(mX"..p_dis(math.floor(xrng*radar),2).." (eY"..p_dis(math.floor(yrng*radar),2).." (jZ"..p_dis(math.floor(zrng*radar),2).." | "
    phr=phr.."(1(kT)(mX"..p_dis(math.floor(xrng*manut),2).." (eY"..p_dis(math.floor(yrng*manut),2).." (jZ"..p_dis(math.floor(zrng*manut),2)

    end
  
  end
end

if string.find(bymodule,"c") or by_all then
--** AIM **
  if scr_opt=="c" then
    local xrng=math.floor(0.069*config[4][4][1])+1
    local yrng=math.floor(0.069*config[4][4][2])+1
    local zrng=math.floor(0.069*config[4][4][3])+1    

    local lgn={}

    for ligne=1,7 do
      local inv_lgn=8-ligne
      lgn[ligne]="(b"

      if zrng==ligne then

        for colone=1,7 do
          if xrng==colone then
            lgn[ligne]=lgn[ligne].."(k/(b"
          else
            lgn[ligne]=lgn[ligne]..","
          end
        end

      else
        lgn[ligne]=lgn[ligne]..",,,,,,,"
      end

      if nod_space[5]+1==inv_lgn then
        lgn[ligne]=lgn[ligne].."4"
      else
        if ligne==1 or ligne==7 then
          lgn[ligne]=lgn[ligne].."(2(sB"
        else
          lgn[ligne]=lgn[ligne].."_"
        end
      end

      if ligne==7 then
        lgn[ligne]=lgn[ligne].."BB(1(b"
      elseif ligne==6 then
        lgn[ligne]=lgn[ligne].."(m".. string.char(math.floor(config[4][4][1]/15)+65)..")X(1(b"
      elseif ligne==5 then
        lgn[ligne]=lgn[ligne].."(j".. string.char(math.floor(config[4][4][3]/15)+65)..")Z(1(b"
      elseif ligne==4 then
        lgn[ligne]=lgn[ligne].."(e".. string.char(math.floor(config[4][4][2]/15)+65)..")Y(1(b"
      elseif ligne==3 then
        lgn[ligne]=lgn[ligne].."(k".. string.char(math.floor(config[4][4][4]/15)+65).."v(b"
      elseif ligne==2 then
        lgn[ligne]=lgn[ligne].."(2(v=_(1(b"
      elseif ligne==1 then
        lgn[ligne]=lgn[ligne].."BB(1(b"
      end

    end

    for ligne=1,7 do
      if yrng==ligne then
        for colone=1,7 do
          if zrng==colone then
            lgn[ligne]=lgn[ligne].."(k/(b"
          else
            lgn[ligne]=lgn[ligne]..","
          end
        end
      else
        lgn[ligne]=lgn[ligne]..",,,,,,,"
      end
    end

    phr="(h(1%"..lgn[7]..
    " | (h(1"..string.char(math.floor(config[6][4]/15)+104)..lgn[6]..
    " | (g(1U"..lgn[5]..
    " | (g(1"..string.char(math.floor(config[7][3]/15)+104)..lgn[4]..
    " | (k(1T"..lgn[3]..
    " | (k(1"..string.char(math.floor(config[13][2]/15)+104)..lgn[2]..
    " | (1_"..lgn[1]

  end
end

if string.find(bymodule,"m") or by_all then
--** central message **
  if scr_opt=="m" then
    local idx_msg=nod_space[5]
    local nb_msg=string.split(config[13][9],";")
    
    if idx_msg>#nb_msg[1] then idx_msg=1 end

    phr=" |  | (h".. string.sub(nb_msg[1],idx_msg,idx_msg+16)
    phr=phr.. string.rep("(1_)",17-#phr)
    idx_msg=idx_msg+8
    nod_space[5]=idx_msg
    nod_met:set_string("spacengine",spacengine.compact(nod_space))
  end
end


end

if phr=="" then return end
nod_met:set_string("text",phr)
monitor.update_sign(npos,nil,nil,nil)
end
