
--[[
	Original textures from Crops Plus mod
	Copyright (C) 2018 Grizzly Adam
	https://forum.minetest.net/viewtopic.php?f=9&t=19488
]]

local S = farming.intllib

minetest.register_craftitem("farming:mustard_seed", {
	description = S("Mustard seed"),
	inventory_image = "farming_mustard_seed.png",
	on_place = function(itemstack, placer, pointed_thing)
		return farming.place_seed(itemstack, placer, pointed_thing, "farming:mustard_1")
	end,
})


-- crop definition
local crop_def = {
	drawtype = "plantlike",
	tiles = {"farming_mustard_1.png"},
	paramtype = "light",
	paramtype2 = "meshoptions",
	place_param2 = 3,
	sunlight_propagates = true,
	waving = 1,
	walkable = false,
	buildable_to = true,
	drop = "",
	selection_box = farming.select,
	groups = {
		snappy = 3, flammable = 3, plant=1, attached_node = 1,
		not_in_creative_inventory = 1, growing = 2
	},
	sounds = default.node_sound_leaves_defaults()
}

-- stage 1
minetest.register_node("farming:mustard_1", table.copy(crop_def))

-- stage 2
crop_def.tiles = {"farming_mustard_2.png"}
minetest.register_node("farming:mustard_2", table.copy(crop_def))

-- stage 3
crop_def.tiles = {"farming_mustard_3.png"}
minetest.register_node("farming:mustard_3", table.copy(crop_def))

-- stage 4
crop_def.tiles = {"farming_mustard_4.png"}
minetest.register_node("farming:mustard_4", table.copy(crop_def))

-- stage 5
crop_def.tiles = {"farming_mustard_5.png"}
crop_def.groups.growing = 0
crop_def.drop = {
	max_items = 5, items = {
		{items = {'farming:mustard_seed'}, rarity = 1},
		{items = {'farming:mustard_seed'}, rarity = 1},
		{items = {'farming:mustard_seed'}, rarity = 1},
		{items = {'farming:mustard_seed'}, rarity = 2},
		{items = {'farming:mustard_seed'}, rarity = 5},
	}
}
minetest.register_node("farming:mustard_5", table.copy(crop_def))
