-- Do files
espace = {}
espace.data={}
local mp=minetest.get_modpath("espace")

--**********************
--** init data player **
--**********************
-- Save table to file
function espace.save_table()

	local data = {day=espace.day, month=espace.month, year=espace.year, build_dt=espace.build_dt, epidemic=espace.epidemic, epidemic_time=espace.epidemic_time}--, rain_lvl=espace.rain_lvl}
	local f, err = io.open(minetest.get_worldpath() .. "/espace_data", "w")

	if err then
		return err
	end

	f:write(minetest.serialize(data))
	f:close()
end

-- Reads saved file
function espace.read_startest()

	local f, err = io.open(minetest.get_worldpath() .. "/espace_data", "r")
	local data = minetest.deserialize(f:read("*a"))

	f:close()

	return data
end

minetest.register_on_shutdown(function()
		espace.save_table()
end)

-- Check to see if file exists and if not sets default values.
local f, err = io.open(minetest.get_worldpath().."/espace_data", "r")

if f == nil then

	espace.day = 1
	espace.month = 6
  espace.year = 2019
  espace.build_dt = 0
  espace.epidemic="off"
	espace.epidemic_time=0
  --espace.rain_lvl=0
  espace.save_table()

else
  local filedata=espace.read_startest()
	espace.day = filedata.day
	espace.month = filedata.month
  espace.year = filedata.year
  espace.build_dt = filedata.build_dt or 0
  --espace.rain_lvl = filedata.rain_lvl or 0
  if filedata.epidemic==nil then
    espace.epidemic="off"
    espace.epidemic_time=0
  else
    espace.epidemic=filedata.epidemic
    espace.epidemic_time=filedata.epidemic_time
  end

end

minetest.register_on_joinplayer(function(player)

    local playername=nil

    if not player or player.is_fake_player then
        return
    end
   
	playername = player:get_player_name()
   
	if espace.data[playername] == nil then
		espace.data[playername] = {}
	end

  if not player:get_attribute("force") then  --punch=force
    player:set_attribute("force", "1/20")
  end

  local xplvl,xpnxtstage=1,20

  if player:get_attribute("endurance") then  --eat=endurance
    local xpattribut = player:get_attribute("endurance")
    --recuperation next stage et level
    local tmp=string.split(xpattribut,"/")
    if tmp[1]==nil or tmp[2]==nil then
    else
      xplvl=tonumber(tmp[1])
      xpnxtstage=tonumber(tmp[2])
    end
  else
    player:set_attribute("endurance", "1/20")
  end

  if not player:get_attribute("fatigue") then player:set_attribute("fatigue","1000") end

  atm.readaccounts()
  if not atm.balance[playername] then
    atm.balance[playername] = 30--300000 --test only
  end

  local sec = (86400*minetest.env:get_timeofday());
  local mn = math.floor(sec/60) % 60;
  local hr = math.floor(sec/3600) % 60;
  local nb=0x00FF00
  local h=(espace.day*2).."/"..espace.month.."/"..espace.year.." - "..string.format("%02d",hr)..":"..string.format("%02d",mn).."\nT 20°C"

  local affichage={}
  affichage["clock"] = player:hud_add({
    hud_elem_type = "text";
    position = {x=0.1, y=0.89};
    text = h;
    number = nb;
    scale = 20;
    });

  local tmp="endurance : "..xplvl
  affichage["xplvl"] = player:hud_add({
		hud_elem_type = "text",
		name = "xp_lvl",
		number = 0xFFFFFF,
		scale = 10,
		text = tmp,
		position = {x = 0.88, y = 0.91},
	})
    
  tmp="Next Level : "..xpnxtstage
  affichage["stage"] = player:hud_add({
		hud_elem_type = "text",
		name = "next_stage",
		number = 0xFFFFFF,
		scale = 10,
		text = tmp,
		position = {x = 0.88, y = 0.95},
	})

  espace.data[playername] = {temp=20, meteo="clear", radiation=20, oxygen=true, biome="n",  hud=affichage,  bloc_protect=false, bloc=999, secteur=0,skytype=2,old_biome="n",new_meteo="clear"}
  espace.getpriv(playername)
  player:set_attribute("sound_meteo",nil) --reset sound

end)


minetest.register_on_leaveplayer(function(player)
  --stop sound et reset sound player
  local sound_nb=player:get_attribute("sound_meteo")
  if sound_nb then
    minetest.sound_stop(tonumber(sound_nb))
    player:set_attribute("sound_meteo",nil)
  end

  local name = player:get_player_name()
  espace.data[name]=nil
end)

minetest.register_on_respawnplayer(function(player)
  player:set_attribute("fatigue","1000")
end)


dofile( mp.. "/data.lua")
dofile(mp .. "/nodes.lua")
dofile(mp .. "/deco.lua")
dofile(mp .. "/vacuum.lua")
dofile(mp .. "/planete.lua")
dofile(mp .. "/spacemap.lua")
dofile(mp .. "/routine.lua")
dofile(mp .. "/fx.lua")
dofile(mp .. "/hurt.lua")

dofile(mp .. "/compatible/default.lua")

if not minetest.get_modpath("moreores") then
  dofile(mp.."/compatible/moreores.lua")
end

if not minetest.get_modpath("moretrees") then
  dofile(mp.."/compatible/moretrees.lua")
end

if not minetest.get_modpath("moreplants") then
  dofile(mp.."/compatible/moreplants.lua")
end

if not minetest.get_modpath("verger") then
  dofile(mp.."/compatible/verger.lua")
end

if not minetest.get_modpath("technic") then
  dofile(mp.."/compatible/technic.lua")
end

if not minetest.get_modpath("gems") then
  dofile(mp.."/compatible/gems.lua")
end

if not minetest.get_modpath("cg_decor") then
  dofile(mp.."/compatible/cg_decor.lua")
end

if not minetest.get_modpath("protector") then
  dofile(minetest.get_modpath("espace").."/compatible/protector.lua")
end

if minetest.get_modpath("building_blocks") then
  minetest.override_item("building_blocks:Fireplace", {
	groups = {cracky=2,fire_heat=1}
})

end

dofile(mp.."/compatible/spawner.lua")

--dofile(minetest.get_modpath("espace").."/energy.lua") --petrole methane

dofile(mp .. "/biome.lua")
dofile(mp .. "/gestion_layer.lua")
dofile(mp .. "/stargate_univers.lua")
dofile(mp .. "/weather.lua")
dofile(mp .. "/chat_command.lua")
