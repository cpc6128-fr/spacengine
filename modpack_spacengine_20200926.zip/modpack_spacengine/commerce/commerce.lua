--*************
--** magasin **
--*************

--** fonction de base **

-- lecture de l'inventaire et renvoie l'index d'un item + tout ses metadata...
commerce.found_item_index=function(player,item)
  local index=0
  local inv=player:get_inventory()
  local stackname,stackcount,stackwear,stackmeta
  for i=1,32 do
    local stack=inv:get_stack("main",i)
    stackname=stack:get_name()
    if item==stackname then
      index=i
      stackcount=stack:get_count()
      stackwear=stack:get_wear()
      stackmeta=stack:get_metadata()
      break
    end
  end
  return index,stackcount,stackwear,stackmeta
end

--***************************
--** transaction with card **
--***************************
--stack=item / card=prix transaction
commerce.transaction=function(player,stack,card)
  local name=player:get_player_name()
  local inv = player:get_inventory()
  local havecard=commerce.found_item_index(player,"commerce:card")

  if havecard>0 then --si card presente
    if atm.balance[name]~= nil then
      if atm.balance[name]-card>0 then
        atm.balance[name] = atm.balance[name]-card
        if stack~=nil then inv:add_item("main",stack) end
        atm.saveaccounts()
        minetest.sound_play("card2",{to_player=name,gain=1.5})
        minetest.chat_send_player(name,"Account : ".. atm.balance[name])
        return true
      end
    end
  end
  return false
end

--*******************************
--** transaction money or card **
--*******************************
--index = numero objet dans commerce.item / quantity = nb d'objet / money="nodename xx" / card = nil ou montant transaction
local magasin_transaction=function(player,index,money,quantity,card)
  local err=0
  local name=player:get_player_name()
  local xp=25--xpgetlvl(player,"xp_lvl")+1

  local objet=commerce.item[index]

  
    local inv = player:get_inventory()
    local stack=objet[2] .." "..quantity
    local havecard=commerce.found_item_index(player,"commerce:card")

    if card~=nil and havecard>0 and havecard<9 then --si card presente dans le haut de l'inventaire (a l'ecran)
      if atm.balance[name]== nil then return end
      if atm.balance[name]-card>0 then
        atm.balance[name] = atm.balance[name]-card
        inv:add_item("main",stack)
        atm.saveaccounts()
        minetest.sound_play("card2",{to_player=name,gain=1.5})
        err=1
        minetest.chat_send_player(name,"Account : ".. atm.balance[name])
      end

    else --or with money
      if inv:contains_item("main",money) then
        inv:remove_item("main", money)
        inv:add_item("main",stack)
        minetest.sound_play("money",{to_player=name,gain=1.5})
        err=1
      end
    end
  
  if err==0 then
    minetest.sound_play("wrong",{to_player=name,gain=1.5})
  end
end

--********************
--** create magasin **
--********************
local function fill_shop(shop_pos,dealertype,item_type,size)
  if size==nil then size=16 end
  local meta = minetest.get_meta(shop_pos)
  local inv = meta:get_inventory()
  inv:set_size("pay",size)
  inv:set_size("objet",size)
  local trade_index = 1
  local trades_already_added = ""
  local price=0
  local money="currency:minegeld"
  local objet={}
  local list_item=""
  local quantity=0
  local trades = {}
  
  --par type ou aleatoire ?
  if item_type==nil then
      item_type=0
  end

  -- nb d'item enregistrer
  local nb_item = #commerce.item
  --choix premier objet
  local choix_item=nb_item
  
	for i=1,size do
    choix_item=math.random(1,nb_item)
    local rnd=math.random(1,100)
    repeat
      objet=commerce.item[choix_item]  --recuperation des données
      if string.find(objet[6],dealertype) then --type magasin/chest/xpchest/trader/distributeur
        -- objet deja selectionner ?
        if string.find(trades_already_added,objet[2])== nil then
              
          if item_type==0 or item_type==objet[1] then
            if objet[4]>rnd then
            list_item=list_item..choix_item.."/"
            inv:set_stack("objet",i,objet[2])
            trades_already_added=trades_already_added.." "..objet[2]
            choix_item=1
            end
          end
        end
      end
      rnd=rnd-1.5
      choix_item=choix_item-3
    until choix_item<1

  end

  --date de creation + delai
  local creat_dat=((espace.year-1)*168)+((espace.month-1)*14)+espace.day+math.random(40,80)
  meta:set_int("visit",creat_dat)
  meta:set_int("inflation",math.random(75,200))--TODO suivant secteur civilisation
  meta:set_string("list_item",list_item)

end


local function price_shop(player,shop_pos,card)
  local meta = minetest.get_meta(shop_pos)
  local inv = meta:get_inventory()
  local trades
  local inflation=meta:get_int("inflation")
  local tmp=meta:get_string("list_item")
  local list_item=string.split(tmp,"/")
  local xp=25--xpgetlvl(player,"xp_lvl")+1

  local formspec= "size[8,11]bgcolor[#080808BB;true]background[0,0;1,1;magasin1.png;true]listcolors[#00000069;#5A5A5A;#141318;#30434C;#FFF]"
  if card==true then
    formspec=formspec.."image[0,5.5;1.5,1.5;accept_cb.png]"
  end
  local x, y=0,0
	local newprice
  for i=1,#list_item do
    trades=inv:get_stack("objet",i):get_name()

    -- effacement stack
    inv:set_stack("pay",i,"")
    local objet=""
    local money="currency:minegeld"
    local quantity=1
    local index
    if trades then
      index=tonumber(list_item[i])
      local item_data=commerce.item[index]
      objet=item_data[2]
      local price=math.ceil(item_data[3]*(inflation/100))
      newprice=math.ceil(price*((25+(xp*4))/100)) --taux différent suivant XP
      --currency calcul
    if newprice>2500 then
      quantity=math.ceil(newprice/100)
      money="currency:minegeld_100"
      newprice=quantity*100
    elseif newprice>500 then
      quantity=math.ceil(newprice/50)
      money="currency:minegeld_50"
      newprice=quantity*50
    elseif newprice>250 then
      quantity=math.ceil(newprice/10)
      money="currency:minegeld_10"
      newprice=quantity*10
    elseif newprice>50 then
      quantity=math.ceil(newprice/5)
      money="currency:minegeld_5"
      newprice=quantity*5
    elseif newprice>12.5 then
      quantity=math.ceil(newprice)
      money="currency:minegeld"
      newprice=quantity*1
    elseif newprice>2.5 then
      quantity=math.ceil(newprice/0.25)
      money="currency:minegeld_cent_25"
      newprice=quantity*0.25
    elseif newprice>0 then
      quantity=math.ceil(newprice/0.05)
      money="currency:minegeld_cent_5"
      newprice=quantity*0.05
    end

      formspec = formspec.."item_image_button["..x ..",".. y ..";1,1;".. objet ..";objet#".. money .."#".. quantity .."#".. index .."#".. newprice ..";]item_image_button[".. x+1 ..",".. y ..";1,1;".. money .." ".. quantity ..";prices;]label[".. x+0.75 ..",".. y+0.9 ..";".. newprice .."]"

      x=x+2
      if x>6 then
        x = 0
        y = y+1.4
      end

    end
 
    inv:set_stack("pay",i,money)
  end
  formspec = formspec.."button_exit[3,6;2,1;exit;exit]list[current_player;main;0,7;8,4;]";

  if card==true then
    minetest.show_formspec(player:get_player_name(), "magasin#2", formspec)
  else
    minetest.show_formspec(player:get_player_name(), "magasin#1", formspec)
  end

end

--******************
--** node magasin **
--******************
minetest.register_node("commerce:magasin", {
	description = "stand de vente",
  tiles = {
		"commerce_borne_bottom.png",
		"commerce_borne_bottom.png",
		"etagere_vide.png",
		"etagere_vide.png",
		"nourriture1.png",
		"nourriture3.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
  paramtype2 = "facedir",
	groups = {cracky=2},
	legacy_facedir_simple = true,
	is_ground_content = false,
  on_construct = function(pos)
        fill_shop(pos,"m",0,16) --pos,type de magasin,type objet,size
  end,
  on_rightclick = function(pos,node,player,itemstack,_)
    local meta = minetest.get_meta(pos)
    local old_dat=meta:get_int("visit")
    local new_dat=((espace.year-1)*168)+((espace.month-1)*14)+espace.day

    if old_dat<new_dat then --si depasse la date, refill new item
      fill_shop(pos,"m",0,16)
    end
    price_shop(player,pos,true)
  end,
    
    drop = 'default:dirt'
})

minetest.register_node("commerce:automatic_distributor", {
	description = "automatic distributor",
  tiles = {
		"distributor_e.png",
	},
	drawtype = "mesh",
  mesh = "homedecor_soda_machine.obj",
selection_box = {
	type = "fixed",
	fixed = {-0.5, -0.5, -0.5, 0.5, 1.5, 0.5}
},
	collision_box = {
	type = "fixed",
	fixed = {-0.5, -0.5, -0.5, 0.5, 1.5, 0.5}
},
	paramtype = "light",
  paramtype2 = "facedir",
	groups = {cracky=2},
	legacy_facedir_simple = true,
	is_ground_content = false,
  on_construct = function(pos)
        fill_shop(pos,"d",0,10)
  end,
  on_rightclick = function(pos,node,player,itemstack,_)
    local meta = minetest.get_meta(pos)
    local old_dat=meta:get_int("visit")
    local new_dat=((espace.year-1)*168)+((espace.month-1)*14)+espace.day

    if old_dat<new_dat then --si plus de 3 mois, refill new item
      fill_shop(pos,"d",0,10)
    end

    price_shop(player,pos,false)
  end,
    
    drop = 'default:dirt'
})

--**********************************
--** transfert item - marchandise **
--**********************************

--list 60 nodes
local commerce_fill=function(pos,item_type)
  local meta = minetest.get_meta(pos)
  -- nb d'item enregistrer
  local nb_item = #commerce.item
  local item_nb=nb_item--index item
  if item_type==0 then
    item_nb=math.random(1,nb_item)
  end
  local index=1--index shop
  local objet={}
  local quantity=0
  local list_item=""

  repeat
      objet=commerce.item[item_nb]
    
    if objet[1]==item_type or item_type==0 then
      list_item=list_item..item_nb
      index=index+1
      if index>60 then item_nb=0 end
    end

  if item_type==0 and item_nb>0 then
    item_nb=math.random(1,nb_item)
  else
    item_nb=item_nb-1
  end

  if index<61 or item_nb>0 then
    list_item=list_item.."/"
  end
  until item_nb<1
  --date de creation + delai
  local creat_dat=((espace.year-1)*168)+((espace.month-1)*14)+espace.day+math.random(40,80)
  meta:set_int("visit",creat_dat)
  meta:set_string("list_item",list_item)
  meta:set_int("inflation",math.random(75,200))--TODO suivant secteur
    
end

local commerce_price=function(pos,commerce_type,background,player)
  local meta = minetest.get_meta(pos)
  
  local tmp=meta:get_string("list_item")
  local list_item=string.split(tmp,"/")
  local inflation=meta:get_int("inflation")
  inflation=inflation/100
  local nplayer=player:get_player_name()
  
  local objet={}
  local quantity=0
  local price=0
  local account=0
  local x,y=0,0
  if atm.balance[nplayer]~=nil then account=atm.balance[nplayer] end
  minetest.chat_send_player(nplayer,"Account : "..account)
  local formspec="size[12,11]list[current_player;main;4,7;8,4;]background[0,0;0,0;".. background ..";true]button_exit[0,10;2,1;exit;exit]"
  if commerce_type==1 then
    formspec=formspec.."image[0,9;1.5,1.5;sigle_cb.png]image[1.5,9;1.5,1.5;licence.png]"
  else
    formspec=formspec.."image[0,9;1.5,1.5;sigle_cb.png]"
  end

  local index=1
  local xp=25--xpgetlvl(player,"xp_lvl")+1
  xp=(25+(xp*4))/100
  
for index=1,#list_item do
    local nb=tonumber(list_item[index])
    if nb~=nil then
      objet=commerce.item[nb]
      quantity=objet[5]

      if quantity~=1 then
        local tmp=math.ceil(quantity*xp)
        quantity=math.min(99,tmp)
      end

      price=objet[3]*xp*quantity*inflation
      price=math.ceil(tonumber(price))
      formspec=formspec.."item_image_button["..x..","..y..";1,1;".. objet[2] .." "..  quantity ..";item#".. nb .."#"..quantity.."#".. tostring(price) ..";]label[".. x ..",".. y+0.9 ..";"..price.."]"

      x=x+1
      if x>11 then
        x=0
        y=y+1.4
      end
    end
  end
  if commerce_type==1 then
    minetest.show_formspec(player:get_player_name(), "commerce#l", formspec)
  else
    minetest.show_formspec(player:get_player_name(), "commerce", formspec)
  end
end

local magdata={11,"bloc4builder_shop.png",0,12,"shop_scifinodes.png",1,0,"magasin3.png",0,2,"magasin3.png",0,3,"magasin3.png",0}

local marchandise_form="size[8,7]"..
        "field[0.25,0;3,1;channel;;No channel]"..
        "label[0.25,1;Owner : owner]"..
        "list[context;src;2.9,1.5;1,1;]"..
        "image[3.9,1.5;1,1;gui_arrow_blank.png]"..
        "button_exit[7,2;1,1;exit;exit]"..
        "list[current_player;main;0,3;8,4;]"

--**************************
--** MARCHANDISE --> ITEM **
--**************************
minetest.register_node("commerce:green_deal", {
  description = "magasin card",
  tiles = {"spacengine_batterie_left.png", "spacengine_batterie_left.png", "spacengine_batterie_left.png", "spacengine_batterie_left.png", "spacengine_batterie_front.png", "commerce_green.png"},
  paramtype = "light",
  paramtype2 = "facedir",
  groups = {cracky=2},
  on_rotate = screwdriver.rotate_simple,
  on_construct = function(pos)
    local rnd=math.random(0,4)*3
    local meta = minetest.get_meta(pos)
    meta:set_int("commerce",rnd)
    
    commerce_fill(pos,magdata[rnd+1]) --pos,type d'objet
end,
  on_rightclick = function(pos,node,player,itemstack,_)
    local meta = minetest.get_meta(pos)
    local rnd=meta:get_int("commerce")
    local old_dat=meta:get_int("visit")
    local new_dat=((espace.year-1)*168)+((espace.month-1)*14)+espace.day
    local index,_,_,_=commerce.found_item_index(player,"commerce:licence")
-- choix du type en mode admin
    if creative.is_enabled_for(player:get_player_name()) and index==8 then
      rnd=rnd+3
      if rnd>12 then rnd=0 end
      meta:set_int("commerce",rnd)
      old_dat=new_dat-1
    end
    
    if old_dat<new_dat then --si plus de 3 mois, refill new item
      commerce_fill(pos,magdata[rnd+1])
    end

    commerce_price(pos,magdata[rnd+3],magdata[rnd+2],player) --pos,licence commerce,background,player
    
  end,
  drop="default:dirt"
})

--*************************
--** ITEM -> MARCHANDISE **
--*************************
minetest.register_node("commerce:red_deal", {
  description = "magasin tonne",
  tiles = {"spacengine_batterie_left.png", "spacengine_batterie_left.png", "spacengine_batterie_left.png", "spacengine_batterie_left.png", "spacengine_batterie_front.png", "commerce_red.png"},
  paramtype = "light",
  paramtype2 = "facedir",
  groups = {cracky=2},
  on_rotate = screwdriver.rotate_simple,
  on_construct = function(pos)
    local meta = minetest.get_meta(pos)
    local inv = meta:get_inventory()
    local change=tostring(math.random(50,150))--TODO suivant astroport
    meta:set_int('change',change)
    meta:set_string("formspec",marchandise_form)
    inv:set_size('src', 1)
  end,
  drop = 'default:dirt',
  on_metadata_inventory_take = function(pos, listname, index, stack, player)
  local meta = minetest.get_meta(pos)
  local inv = meta:get_inventory()
  if listname=="src" then
    meta:set_string("formspec", marchandise_form)
  end
  
	end,
  on_receive_fields=function(pos,formname,fields,sender)
    if string.find(dump(fields),"accept")~=nil then
      for k, v in pairs(fields) do
        trade = tostring(k)
      end
      local tradesplit=string.split(trade,"#")
      local index=tonumber(tradesplit[2])
      local price=tonumber(tradesplit[3])
      local havecard=commerce.found_item_index(sender,"commerce:card")
      local havelicence=commerce.found_item_index(sender,"commerce:licence")

      if havecard>0 and havelicence>0 then --si card presente
        local name=sender:get_player_name()
        local _,_,_,stackmeta=commerce.found_item_index(sender,"commerce:licence")
        if string.find(stackmeta,"commerce")==nil then return end

        if atm.balance[name]== nil then return end

        local meta = minetest.get_meta(pos)
        local inv = meta:get_inventory()
        inv:set_stack("src",1,"")
        atm.balance[name] = atm.balance[name]+price
        atm.saveaccounts()
        minetest.sound_play("card2",{to_player=name,gain=1.5})
        minetest.chat_send_player(name,"Account : ".. atm.balance[name])
        meta:set_string("formspec", marchandise_form)
      end

    end
  
  end,
	on_metadata_inventory_put = function(pos,listname, index, stack, player)
    -- nb d'item
    local nb_obj = #commerce.item
    local objet
    local meta = minetest.get_meta(pos)
    local inv = meta:get_inventory()
    local change=meta:get_int('change') --TODO change suivant rareté sur l'astroport
    local stack = inv:get_stack("src", 1)
    local name=stack:get_name()
    --
    local nplayer=player:get_player_name()
    local xp=25--xpgetlvl(player,"xp_lvl")+1
    change=(change*((25+(xp*4))/100))/100 --taux différent suivant XP
    if name~=nil then

    repeat
      objet=commerce.item[nb_obj]  --recuperation des données

      if name==objet[2]then
        local quantity=stack:get_count() -- nb objet
        local price=objet[3]*quantity*change
        price=math.ceil(tonumber(price))
        meta:set_string("formspec", marchandise_form .."label[5,1.75;".. price .."]button[7,1;1,1;accept#".. nb_obj .."#".. price ..";accept]")
        nb_obj=1
      end

      nb_obj=nb_obj-1
    until nb_obj<1

    end

  end,
  drop="default:dirt"
})

minetest.register_on_player_receive_fields(function(player, formname, fields)
  if string.find(formname,"magasin") then
    local trade

    if string.find(dump(fields),"objet")~=nil then
      for k, v in pairs(fields) do
        trade = tostring(k)
      end
      local tradesplit=string.split(trade,"#")
      local index=tonumber(tradesplit[4])
      local money=tradesplit[2].." "..tradesplit[3]
      if string.find(formname,"#2") then
        magasin_transaction(player,index,money,1,tradesplit[5])
      else
        magasin_transaction(player,index,money,1)
      end
    end

  elseif string.find(formname,"commerce") then
    local havelicence=commerce.found_item_index(player,"commerce:licence")
    if  string.find(formname,"#l") and havelicence==0 then
      minetest.sound_play("wrong",{to_player=name,gain=1.5})
    else
    local tmp
    --recuperation table
    for k, v in pairs(fields) do
      tmp = tostring(k)
    end

    if tmp~=nil then
      if string.find(tmp,"item") then
        local list=string.split(tmp,"#")
        local item_nb=tonumber(list[2])
        local quantity=tonumber(list[3])
        local price=tonumber(list[4])
        magasin_transaction(player,item_nb,"-",quantity,price)
        --minetest.close_formspec( player:get_player_name(), formname )
      end
    end
    end
  end
end)
