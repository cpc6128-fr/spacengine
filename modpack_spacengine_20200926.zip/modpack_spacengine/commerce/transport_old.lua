--[[
citymap.transport={player1={},playern={}}


numero transport : date+time
mission :
nb mission
pos1 : transport:type:list transport et quantiter:destination
pos2 : exploration:type:list secteur et action:retour

2#1:1:2/25 4/10:00028:3111/2121/02012#2:1:00256/3 00257/1:00025:2252/5656/2323#n

n = ...

action{type,sub}
destination{type,nom,dst}
chargement{list{type nbmin nbmax},poids_total_max}
delai{date,before{%,action},after{%,action},action}
xp
prix

1 eat  2 ores  3 tools  4 weapons  5 vehicules  6 furniture  7 build low  8 hightech

1 ouvrier  2 touriste  3 ingenieur  4 scientifique  5 militaire

1 dig  2 place  3 checkpoint
--]]

local function transport_add(player)
end

local function transport_remove(player)
end

local function transport_check(player)
--choix marchandise ou voyageur
end

local function transport_exploration()
end

local function transport_init(pos,node,player)
  local plmeta=player:get_meta()
  local nodemeta = minetest.get_meta(pos)
  local new_dat=startest.set_dat(0,0)
  local old_dat=nodemeta:get_int("visit")
  local data_tmp=""
  local index=1
  

  if old_dat<new_dat then
    local mission_nb=math.random(3,10)
    for j=1,mission_nb do
    --choix entre transport ou exploration
    local rnd=math.random(1,2)
    data_tmp=rnd..":"

    if rnd==1 then --transport
      rnd=math.random(1,2)
      data_tmp=data_tmp..rnd..":"
      index=index+1
      local item,nb_item
      if rnd==1 then
        item=8 --marchandise
        nb_item=20
      else
        item=5 --voyageur
        nb_item=10
      end

      local nb=math.random(1,5)

      for i=1,nb do
        rnd=math.random(1,item)
        data_tmp=data_tmp..rnd.."/"
        rnd=math.random(1,nb_item)
        data_tmp=data_tmp..rnd
        if i<nb then
          data_tmp=data_tmp.." "
        else
          data_tmp=data_tmp..":"
        end
      end

--choix secteur
    local xpos,ypos,zpos
    local secteur=startest.secteur(pos)
    rnd=math.random(1,10)

    if math.random(1,10)>5 then
      xpos=math.min(96,secteur.x+rnd)
    else
      xpos=math.max(1,secteur.x-rnd)
    end

    rnd=math.random(1,10)

    if math.random(1,10)>5 then
      zpos=math.min(96,secteur.z+rnd)
    else
      zpos=math.max(1,secteur.z-rnd)
    end

    rnd=math.random(1,5)

    if math.random(1,10)>5 then
      ypos=math.min(14,secteur.y+rnd)
    else
      ypos=math.max(1,secteur.y-rnd)
    end

    local newsecteur=startest.secteur_by_matrice(secteur)
    local _,astroport,stargate=startest.info_secteur(newsecteur.nb)
    data_tmp=data_tmp.. newsecteur.nb ..":"
    data_tmp=data_tmp.. astroport.x .."/".. astroport.y .."/".. astroport.z

    else --exploration
    --si exploration list de destination
local nb=math.random(1,5)
local secteur=startest.secteur(pos)

      for i=1,nb do
        local xpos,ypos,zpos
    
    rnd=math.random(1,10)

    if math.random(1,10)>5 then
      xpos=math.min(96,secteur.x+rnd)
    else
      xpos=math.max(1,secteur.x-rnd)
    end

    rnd=math.random(1,10)

    if math.random(1,10)>5 then
      zpos=math.min(96,secteur.z+rnd)
    else
      zpos=math.max(1,secteur.z-rnd)
    end

    rnd=math.random(1,5)

    if math.random(1,10)>5 then
      ypos=math.min(14,secteur.y+rnd)
    else
      ypos=math.max(1,secteur.y-rnd)
    end

    local newsecteur=startest.secteur_by_matrice(secteur)
    data_tmp=data_tmp.. newsecteur.nb .."/"
    local rnd=math.random(1,3)
    data_tmp=data_tmp.. newsecteur.nb --action
        if i<nb then
          data_tmp=data_tmp.." "
        else
          data_tmp=data_tmp..":"
        end
      end



    end
    

    if j<mission_nb then data_tmp=data_tmp.."#" end
    end

    nodemeta:set_string("transport",mission_data)

    end

  end


end

local function mission_start()

end

local function mission_stop()

end

citymap.mission_checkpoint()

end
--
-- ** mission **
minetest.register_node("citymap:transport", {
description = "Entreprise de transport",
	tiles = {
		"guichetd.png",
		"guichetd.png",
		"guichetd.png^[transformR90",
		"guichetd.png^[transformR90",
		"guichetc.png",
		"guicheta.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
paramtype2 = "facedir",
use_texture_alpha = true,
groups = {cracky=3},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.375, -0.0625, 0.5, 0.5, 0.0625}, -- NodeBox1
			{-0.5, -0.5, -0.5, 0.5, -0.375, 0.5}, -- NodeBox2
		}
	},
on_construct = function(pos)
    local meta = minetest.get_meta(pos)
    local inv = meta:get_inventory()
    
    meta:set_string("formspec", "size[8,9]background[0,0;1,1;licence_bg.png;true]"..
        "button[0,0;1,1;exploitation;50]label[1,0.25;EXPLOITATION]"..
        "button[0,1;1,1;commerce;100]label[1,1.25;COMMERCE]"..
        "button[0,2;1,1;marchandise;500]label[1,2.25;MARCHANDISE]"..
        "button[0,3;1,1;voyageur;1000]label[1,3.25;VOYAGEUR]"..
        "button[0,4;1,1;special;2000]label[1,4.25;SPECIAL]"..
        "item_image_button[4,3.5;1,1;citymap:licence;card;50]"..
        "button_exit[6.25,3.5;1.5,1;exit;exit]"..
        "list[current_player;main;0,5;8,4;]")
        
  end,
on_receive_fields=function(pos,formname,fields,sender)
  if fields.exit then
    return
  end
  local name = sender:get_player_name()
  local inv = sender:get_inventory()
  local stack={name="citymap:card",count=1}
  local index=0
  local price=0
  local licence=""
  local account=0
  local stackmeta
  if inv:contains_item("main",stack) then
    if fields.exploitation~=nil then
      price=50
      licence="exploitation"
    elseif fields.marchandise~=nil then
      price=500
      licence="marchandise"
    elseif fields.commerce~=nil then
      price=100
      licence="commerce"
    elseif fields.voyageur~=nil then
      price=1000
      licence="voyageur"
    elseif fields.special~=nil then
      price=2000
      licence="special"
    elseif fields.card~=nil then
      price=50
      licence="card"
    end
    if licence~="" then
      
      if not (atm.balance[name] == nil) then
        account=atm.balance[name]
      end
      if account-price>0 then
        index,_,_,stackmeta=citymap.found_item_index(sender,"citymap:licence")
        if licence~="card" then
          --test licence
          stack={name="citymap:licence",count=1}
          if inv:contains_item("main",stack) then
            if stackmeta=="" then
              stackmeta="licence : "
            end
            if string.find(stackmeta,licence)==nil then
              stackmeta=stackmeta.." "..licence
              --debit account
              atm.balance[name] = account-price
              --sound
              minetest.chat_send_player(name,stackmeta)
              atm.saveaccounts ()
            end
            inv:remove_item("main", "citymap:licence")
            inv:add_item("main", {name="citymap:licence", count=1, wear=0, metadata=stackmeta})
          end
        else
          if index>0 then return end
          --debit account
          atm.balance[name] = account-price
          --sound
          minetest.chat_send_player(name,"LICENCE")
          atm.saveaccounts ()
          inv:add_item("main", {name="citymap:licence", count=1, wear=0, metadata="Licence :"})
        end
      end
    end
  else
    minetest.chat_send_player(name,"NO CREDIT CARD PRESENT IN INVENTORY")
  end    
end,
})


minetest.register_craftitem("citymap:certif", {
	description = "autorisation de transfert et d'arrimage",
	inventory_image = "certif.png",
	groups = {flammable = 3},
stack_max = 1,
on_use = function(itemstack, user, pointed_thing)
		local nplayer = user:get_player_name()
		local stackmeta = itemstack:get_metadata()
		if stackmeta==nil then
      stackmeta="empty"
    end
    minetest.chat_send_player(nplayer, stackmeta)
	end,
})
