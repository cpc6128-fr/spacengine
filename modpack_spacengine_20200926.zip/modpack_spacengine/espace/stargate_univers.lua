--** from mod STARGATE **
--** stargate univers version 2020.2.11 philipe **

if gui_player==nil then
  gui_player={}
end

--**********************************************
--** creation liste element coordone satrgate **
--**********************************************
--secteurxyz=position secteur stargate origine / zone=delta secteur / sectidx=index secteur
--ex: 15,2,16 -->xyz=13,14,15,16,17 index=4

local function fill_coordo_gui(secteurxyz,zone,sectidx,zy)
  local xyz=""
  local zonemin,zonemax

  if zy==0 then 
    zonemin=math.max(0,secteurxyz-zone)
    zonemax=math.min(95,secteurxyz+zone)
  else 
    zonemin=math.max(0,secteurxyz-math.ceil(zone/2))
    zonemax=math.min(14,secteurxyz+math.ceil(zone/2))
  end

  local index=1

  for i=zonemin,zonemax do
    xyz=xyz..i
    if i<sectidx then index=index+1 end
    if i<zonemax then
      xyz=xyz..","
    end
  end

  return xyz,index
end

--*********************************
--** initialisation gui stargate **
--*********************************
local function init_stargate(pos,player)
  local plname=player:get_player_name()
  local formspec=""
  local data_espace=""
  local data_surface=""
  if gui_player[plname]==nil then
    gui_player[plname]={}
  end
  local formname="stargate_u#pg1"

  --** PAGE position dans l'espace **
  if pos.y>1007 and pos.y<10268 then
    local zone=5--math.min(10,math.ceil(xp/5)) --zone -/+ autour du secteur suivant xp
    local price=250--100*(xp/50+0.6) --prix du voyage suivant xp
    local secteur,bloc=espace.secteur(pos)
    local astroport,stargate,jail=espace.astroport(secteur)
    local planete=espace.planete(secteur)

    data_espace="stargate_u*".. espace.postostring(secteur) .."*".. price

    --** creation list coordonée STARGATE **
    local posxyz,index=fill_coordo_gui(secteur.x,zone,secteur.x,0)
    formspec="textlist[1,2;1,2;posx;".. posxyz ..";".. index ..";true]"
    data_espace=data_espace .."*"..posxyz.."*"..index

    posxyz,index=fill_coordo_gui(secteur.z,zone,secteur.z,0)
    formspec=formspec.."textlist[9,2;1,2;posz;".. posxyz ..";".. index ..";true]"
    data_espace=data_espace .."*"..posxyz.."*"..index

    posxyz,index=fill_coordo_gui(secteur.y,zone,secteur.y,1)
    formspec=formspec.."textlist[5,2;1,2;posy;".. posxyz ..";".. index ..";true]"
    data_espace=data_espace .."*"..posxyz.."*"..index
    
    gui_player[plname].pg10="size[11,9]"..
        "background[0,0;1,1;stargate_bg1.png;true]"..
        "button[0,0;2,1;stargate_u;stargate]"..
        "button_exit[0.5,8;2,1;exit;exit]"

    --** ACHAT VENTE ASTROPORT **
    local metanode=minetest.get_meta(pos)
    local owner=metanode:get_string("owner")
    gui_player[plname].pg15=""
    if owner=="" then 
      gui_player[plname].pg15="label[3,8.75;BUY SPACEPORT]button[3,8;2,1;buy;800000]"
    else
      if owner==plname then
        gui_player[plname].pg15="label[3,8.75;SELL SPACEPORT]button[3,8;2,1;sell;400000]"
      else
        gui_player[plname].pg15="label[3,8.75;OWNER]label[3,8;<"..owner..">]"
      end
    end

    --** secteur PLANETE **
    if planete.name=="-" then --planete pas presente
      data_surface="-*0*31000/31130/31000"
      gui_player[plname].pg21="label[0.5,5;NO PLANET]"
    else
      gui_player[plname].pg10=gui_player[plname].pg10 .."button[9,0;2,1;transfert;planete]"
      local tmp=planete.alt+131000
      data_surface=planete.name .."*".. planete.nb .."*31000/".. string.sub(tmp,2) .."/31000*".. price .."*".. secteur.nb
      gui_player[plname].pg21="label[0.5,4.4;DESTINATION]label[0.5,5;".. planete.name .."]label[9.5,4.4;FROM]label[9.5,5;".. string.sub(tostring(secteur.nb+1000001),2) .."]image_button_exit[9,8;2,1;bg_price.png;accept;".. tostring(price/2) .."]"
    end

    --numero secteur de galaxie
    gui_player[plname].pg11=formspec
    gui_player[plname].pg12="label[9.5,5;".. string.sub(tostring(secteur.nb+1000001),2) .."]"

    --** Nom du secteur de la GALAXIE **
    if secteur.name~=nil then
      gui_player[plname].pg13="label[0.5,4.4;SYSTEM NAME]label[0.5,5;".. secteur.name .."]"
    else
      gui_player[plname].pg13="label[0.5,4.4;SYSTEM NAME]label[0.5,5;UNKNOW]"
    end

    gui_player[plname].pg14="image_button_exit[9,8;2,1;bg_price.png;accept;"..price.."]"
    gui_player[plname].pg20="size[11,9]"..
        "background[0,0;1,1;stargate_bg2.png;true]"..
        "button[0,0;2,1;stargate;stargate]"..
        "button[9,0;2,1;transfert;planete]"..
        "button_exit[0.5,8;2,1;exit;exit]"
    formspec=gui_player[plname].pg10 .. gui_player[plname].pg11 .. gui_player[plname].pg12 .. gui_player[plname].pg13 .. gui_player[plname].pg14 .. gui_player[plname].pg15
  
  --** PAGE surface planete **
  elseif pos.y>10267 then
    local layer=math.floor((pos.y-10208)/640)+1 --calcul layer multimap
    local tmp=(layer*3685)+9999
    local secteur,astroport,stargate,jail,planete=espace.info_secteur(tmp)
    
    local price=250--50*(xp/50+0.6)
    data_espace="surface*000"
    data_surface=planet_layer[layer].name .."*".. layer .."*".. espace.postostring(stargate) .."*".. price .."*".. secteur.nb
    gui_player[plname].pg21= "label[0.5,4.4;FROM]label[0.5,5;".. planet_layer[layer].name .."]"..
              "label[9.1,4.4;TO ASTROPORT]label[9.5,5;".. string.sub(tostring(secteur.nb+1000001),2) .."]"..
              "image_button_exit[9,8;2,1;bg_price.png;accept;"..price.."]"

    gui_player[plname].pg20="size[11,9]"..
        "background[0,0;1,1;stargate_bg2.png;true]"..
        "button[9,0;2,1;transfert;planete]"..
        "button_exit[0.5,8;2,1;exit;exit]"
    formspec=gui_player[plname].pg20 .. gui_player[plname].pg21
    formname="stargate_u#pg2"

  --** surface terre **
  elseif pos.y<1008 then
    local layer=0
    local secteur,astroport,stargate,jail,planete=espace.info_secteur(9999)
    local price=250--50*(xp/50+0.6)
    data_espace="none*000"
    data_surface="earth*".. layer .."*".. espace.postostring(stargate) .."*".. price .."*".. secteur.nb

    gui_player[plname].pg21= "label[0.5,4.4;FROM]label[0.5,5;earth]"..
              "label[9.1,4.4;TO ASTROPORT]label[9.5,5;".. string.sub(tostring(secteur.nb+1000001),2) .."]"..
              "image_button_exit[9,8;2,1;bg_price.png;accept;"..price.."]"

    gui_player[plname].pg20="size[11,9]"..
        "background[0,0;1,1;stargate_bg2.png;true]"..
        "button[9,0;2,1;transfert;planete]"..
        "button_exit[0.5,8;2,1;exit;exit]"
    formspec=gui_player[plname].pg20 .. gui_player[plname].pg21
    formname="stargate_u#pg2"
  end
  
  gui_player[plname].espace=data_espace
  gui_player[plname].surface=data_surface
  
  return minetest.show_formspec(plname, formname.."#".. espace.postostring(pos) , formspec)
end

--********************
--** stargate on/off**
--********************
function espace.activateGate(pos)
	local node = minetest.get_node(pos)
	minetest.sound_play("gateOpen", {pos = pos, max_hear_distance = 72,})
	minetest.swap_node(pos,{name="espace:gatenode_on",param2 = node.param2})
  local timer = minetest.get_node_timer(pos)
  if timer:is_started() == false then
			timer:start(10)
  end
end

function espace.deactivateGate(pos)
	local node = minetest.get_node(pos)
	minetest.sound_play("gateClose", {pos = pos, gain = 1.0,loop = false, max_hear_distance = 72,})
	minetest.swap_node(pos,{name="espace:gatenode_off",param2 = node.param2})
end

local function teleportation(newpos,player)
  gui_player[player:get_player_name()]=nil
  player:set_pos(newpos)
  core.sound_play("enterEventHorizon", {pos = newpos, max_hear_distance = 72})
  player:set_look_yaw(math.rad(180))
end

local sg_collision_box = {
	type = "fixed",
	fixed={{-1.5,-0.5,-3/20,1.5,2.5,3/20},},
}

local sg_selection_box = {
	type = "fixed",
	fixed={{-1.5,-0.5,-3/20,1.5,2.5,3/20},},
}

--**************
--** stargate **
--**************
minetest.register_node("espace:gatenode_on",{
	tiles = {
		{name = "gray.png"},
		{
		name = "puddle_animated0.png",
		animation = {
			type = "vertical_frames",
			aspect_w = 32,
			aspect_h = 32,
			length = 2.0,
			},
		},
		{name = "0003.png"},
		{name = "0002.png"},
		{name = "0001.png"},
		{name = "null.png"},
	},
	drawtype = "mesh",
	mesh = "stargate.obj",
	visual_scale = 3.0,
	groups = {snappy=2,choppy=2, not_in_creative_inventory=1},
	drop="espace:gatenode_off",
	paramtype2 = "facedir",
	paramtype = "light",
	light_source = 10,
	selection_box = sg_selection_box,
	collision_box = sg_collision_box,
	on_construct = function(pos)
    local timer = minetest.get_node_timer(pos)
    if timer:is_started() == false then
        timer:start(10)
    end
  end,
	on_rightclick=function(pos,node,player,itemstack)
    local plname=player:get_player_name()
    if espace.is_jail(player) then
      minetest.chat_send_player(plname,"!! Vous purgez une peine de prison !!")
      return
    end
    init_stargate(pos,player)
  end,
  on_timer=function(pos,elapsed)
    espace.deactivateGate(pos)
  end
})

minetest.register_node("espace:gatenode_off",{
	description = "Stargate",
	inventory_image = "stargate.png",
	wield_image = "stargate.png",
	tiles = {
		{name = "gray.png"},
		{name = "null.png"},
		{name = "0003.png"},
		{name = "0002.png"},
		{name = "0001.png"},
		{name = "null.png"},
	},
	groups = {snappy=2,choppy=2},--unbreakable = 1, not_in_creative_inventory=1},
	paramtype2 = "facedir",
	paramtype = "light",
	drawtype = "mesh",
	mesh = "stargate.obj",
	visual_scale = 3.0,
	selection_box = sg_selection_box,
	collision_box = sg_collision_box,
  on_rightclick=function(pos,node,player,itemstack)
    espace.activateGate(pos)
  end,
})

--**************
--**gui appli **
--**************
minetest.register_on_player_receive_fields(function(player, formname, fields)

  if string.find(formname,"stargate_u")==nil then
    return
  end

  if fields.quit~=nil and fields.accept==nil then
    gui_player[player:get_player_name()]=nil
    return
  end

  local tmp=string.split(formname,"#")
  local posnode=espace.postonumber(tmp[3])
  local new_formspec=false
  local plname=player:get_player_name()
  local formspec
--recuperation donnée matrice
  local data_espace
  local data_surface
  if gui_player[plname].espace~="" then
    data_espace=string.split(gui_player[plname].espace,"*")
  end

  if gui_player[plname].surface~="" then
    data_surface=string.split(gui_player[plname].surface,"*")
  end
--changement de page
  if fields.transfert~=nil then
    formname= "stargate_u#pg2"
    formspec=gui_player[plname].pg20 .. gui_player[plname].pg21
    new_formspec=true
  elseif fields.stargate~=nil and data_espace[1]=="stargate_u" then
    formname= "stargate_u#pg1"
    formspec=gui_player[plname].pg10 .. gui_player[plname].pg11 .. gui_player[plname].pg12 .. gui_player[plname].pg13 .. gui_player[plname].pg14
    new_formspec=true
  end


  if string.find(formname,"pg1") then --pg1 coordonée stargate
    formname= "stargate_u#pg1"
    new_formspec=true
    --data_espace=(1)stargate /(2)position /(3)price /(5)posx /(6)idx /(7)posz /(8)idz /(9)posy /(10)idy
    --zone
    local tmp=data_espace[4]
    local posx=string.split(tmp,",")
    tmp=data_espace[8]
    local posy=string.split(tmp,",")
    tmp=data_espace[6]
    local posz=string.split(tmp,",")
    --changement index list
    if fields.posx~=nil then
      data_espace[5]=string.sub(fields.posx,5)
    elseif fields.posy~=nil then
      data_espace[9]=string.sub(fields.posy,5)
    elseif fields.posz~=nil then
      data_espace[7]=string.sub(fields.posz,5)
    end
    --nouvelle coordonée secteur
    local matrice_secteur={}
    local index=tonumber(data_espace[5])
    matrice_secteur.x=tonumber(posx[index])
    index=tonumber(data_espace[9])
    matrice_secteur.y=tonumber(posy[index])
    index=tonumber(data_espace[7])
    matrice_secteur.z=tonumber(posz[index])

    local secteurpos=espace.secteur_by_matrice(matrice_secteur)
    local _,astroport,stargate,jail,planete=espace.info_secteur(secteurpos.nb)


    if fields.buy~=nil then
      local inv = player:get_inventory()
      local havecard=commerce.found_item_index(player,"commerce:card")
      if havecard>0 and havecard<9 then --si card presente dans le haut de l'inventaire (a l'ecran)
        if atm.balance[plname]-800000>0 then
          atm.balance[plname] = atm.balance[plname]-800000
          atm.saveaccounts()
          local metanode=minetest.get_meta(posnode)
          metanode:set_string("owner",plname)

          if espace.data[plname].priv==nil then
            espace.data[plname].priv={}
          end

          table.insert(espace.data[plname].priv,secteurpos.nb)
          espace.data[plname].bloc_protect=false
          minetest.chat_send_player(plname,"privilege astroport n.secteur :".. secteurpos.nb+1)
          espace.setpriv(plname)
          gui_player[plname].pg15="label[3,8;<"..plname..">]"
        end
      end
    end

  if fields.sell~=nil then
      local inv = player:get_inventory()
      local havecard=commerce.found_item_index(player,"commerce:card")
      if havecard>0 and havecard<9 then --si card presente dans le haut de l'inventaire (a l'ecran)
        atm.balance[plname] = atm.balance[plname]+400000
        atm.saveaccounts()
        local metanode=minetest.get_meta(posnode)
        metanode:set_string("owner","")

        if espace.data[plname].priv~=nil then
          local priv=espace.data[plname].priv
          for i=1, #priv do
            if priv[i]==secteurpos.nb then
              table.remove(espace.data[plname].priv,i)
              break
            end
          end
          espace.data[plname].bloc_protect=false
          minetest.chat_send_player(plname,"remove privilege astroport n.secteur :".. secteurpos.nb+1)
          espace.setpriv(plname)
          gui_player[plname].pg15="button[3,8;2,1;buy;800000]"
        end
      end
    end

    if fields.accept~=nil then
  
      if player:get_attribute("jail")~=nil then
      --sortie de prison=1 voyage gratuit
      if string.find(player:get_attribute("jail"),"out") then
        player:set_attribute("jail","")
        teleportation(stargate,player)
      end
      else
        local inv = player:get_inventory()
        local havecard=commerce.found_item_index(player,"commerce:card")
        if havecard>0 and havecard<9 then --si card presente dans le haut de l'inventaire (a l'ecran)
          if atm.balance[plname]-tonumber(data_espace[3])>0 then
            atm.balance[plname] = atm.balance[plname]-tonumber(data_espace[3])
            atm.saveaccounts()
            teleportation(stargate,player)
          end
        end
      end

      new_formspec=false
      
    else
      gui_player[plname].pg12="label[9.5,5;".. string.sub(tostring(secteurpos.nb+1000001),2) .."]"

      if secteurpos.name~=nil then
        gui_player[plname].pg13="label[0.5,5;".. secteurpos.name .."]"
      else
        gui_player[plname].pg13="label[0.5,5;UNKNOW]"
      end

      gui_player[plname].pg11="textlist[1,2;1,2;posx;".. data_espace[4] ..";".. data_espace[5] ..";true]"

      gui_player[plname].pg11=gui_player[plname].pg11 .."textlist[9,2;1,2;posz;".. data_espace[6] ..";".. data_espace[7] ..";true]"

      gui_player[plname].pg11=gui_player[plname].pg11 .."textlist[5,2;1,2;posy;".. data_espace[8] ..";".. data_espace[9] ..";true]"
    
      formspec=gui_player[plname].pg10 .. gui_player[plname].pg11 .. gui_player[plname].pg12 .. gui_player[plname].pg13 .. gui_player[plname].pg14 .. gui_player[plname].pg15

      --sauvegarde data
      tmp=""
      for i=1,#data_espace do
        tmp=tmp .. data_espace[i]
        if i<#data_espace then tmp=tmp .. "*" end
      end
      gui_player[plname].espace=tmp
    end

  elseif string.find(formname,"pg2") then --pg2 coordonée planète
    local stargate=espace.postonumber(data_surface[3])

    if fields.accept~=nil then
  
      if player:get_attribute("jail")~=nil then
      --sortie de prison=1 voyage gratuit
      if string.find(player:get_attribute("jail"),"out")~=nil then
        player:set_attribute("jail",nil)
        teleportation(stargate,player)
      end
      else
        local inv = player:get_inventory()
        local havecard=commerce.found_item_index(player,"commerce:card")
        if havecard>0 and havecard<9 then --si card presente dans le haut de l'inventaire (a l'ecran)
          if atm.balance[plname]-tonumber(data_surface[4])>0 then
            atm.balance[plname] = atm.balance[plname]-tonumber(data_surface[4])
            atm.saveaccounts()
            teleportation(stargate,player)
          end
        end
      end
    end
  end

  if new_formspec==true then
    return minetest.show_formspec(plname, formname.."#".. espace.postostring(posnode), formspec)
  end
  
end)
