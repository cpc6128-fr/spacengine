
---------------------------------------
-- Happy Weather: Utilities / Helpers

-- License: MIT

-- Credits: xeranas
---------------------------------------

--if not minetest.global_exists("hw_utils") then
--	hw_utils = {}
--end

local strike=false
if minetest.get_modpath("lightning") then strike=true end
espace.meteo="on" --active meteo
-- outdoor check based on node light level
local function is_outdoor(pos)

	if minetest.get_node_light({x=pos.x, y=pos.y, z=pos.z}, 0.5) == 15 then
		return true
	end
	return false
end

-- checks if player is undewater. This is needed in order to
-- turn off weather particles generation.
local function is_underwater(player)
	local ppos = player:getpos()
	local offset = player:get_eye_offset()
	local player_eye_pos = {
		x = ppos.x + offset.x, 
		y = ppos.y + offset.y + 1.5, 
		z = ppos.z + offset.z}
	local node_level = minetest.get_node_level(player_eye_pos)
	if node_level == 8 or node_level == 7 then
		return true
	end
	return false
end

-- trying to locate position for particles by player look direction for performance reason.
-- it is costly to generate many particles around player so goal is focus mainly on front view.  
local function get_random_pos(player, offset)
	local look_dir = player:get_look_dir()
	local player_pos = player:getpos()

	local random_pos_x = 0
	local random_pos_y = 0
	local random_pos_z = 0

	if look_dir.x > 0 then
		if look_dir.z > 0 then
			random_pos_x = math.random(player_pos.x - offset.back, player_pos.x + offset.front) + math.random()
			random_pos_z = math.random(player_pos.z - offset.back, player_pos.z + offset.front) + math.random() 
		else
			random_pos_x = math.random(player_pos.x - offset.back, player_pos.x + offset.front) + math.random()
			random_pos_z = math.random(player_pos.z - offset.front, player_pos.z + offset.back) + math.random()
		end
	else
		if look_dir.z > 0 then
			random_pos_x = math.random(player_pos.x - offset.front, player_pos.x + offset.back) + math.random()
			random_pos_z = math.random(player_pos.z - offset.back, player_pos.z + offset.front) + math.random()
		else
			random_pos_x = math.random(player_pos.x - offset.front, player_pos.x + offset.back) + math.random()
			random_pos_z = math.random(player_pos.z - offset.front, player_pos.z + offset.back) + math.random()
		end
	end

	if offset.bottom ~= nil then
		random_pos_y = math.random(player_pos.y - offset.bottom, player_pos.y + offset.top)
	else
		random_pos_y = player_pos.y + math.random(offset.top)+3
	end

	return {x=random_pos_x, y=random_pos_y, z=random_pos_z}
end

-----------------------------------------------------

--***************************************************
--** changement du ciel suivant le jour ou la nuit **
--***************************************************
local function set_sky(pos,player,sky_data,clouds_data)
  local dt=minetest.get_timeofday()*100
  if dt>20 and dt<81 then
    dt=2
  else
    dt=1
  end

  local nuage=0

  if pos.y>10207 then
    local layer=math.floor((pos.y-10208)/640)+1
    local nb_layer=#planet_layer
    if layer>nb_layer then layer=nb_layer end  --en cas d'erreur de depassement
    nuage=(layer*640)+9840+math.random(1,45)--hauteur relative sol 100
  end

  local bgcolor
  if sky_data.gradient_colors then
    bgcolor = sky_data.gradient_colors[dt]
  else
    if sky_data.bgcolor then
      bgcolor=sky_data.bgcolor
    else
      bgcolor=nil
    end
  end
  player:set_sky(bgcolor,sky_data.type,sky_data.textures)

  if clouds_data.gradient_colors then
    bgcolor = clouds_data.gradient_colors[dt]
  else
    if clouds_data.color then
      bgcolor=clouds_data.color
    else
      bgcolor=nil
    end
  end

  if nuage>0 and clouds_data.height~=31000 then
    player:set_clouds({
      color = bgcolor,
      density = clouds_data.density,
      ambient = clouds_data.ambient,
      height = nuage,
      thickness = clouds_data.thickness,
      speed = clouds_data.speed
    })
  else
    player:set_clouds({
      color = bgcolor,
      density = clouds_data.density,
      ambient = clouds_data.ambient,
      height = clouds_data.height,
      thickness = clouds_data.thickness,
      speed = clouds_data.speed
    })
  end
  
end

--***********
--** meteo **
--***********
local weather_data={}

weather_data.weather_dust={
  sky = {
		gradient_colors = {
			{r=0, g=0, b=0},
			{r=128, g=64, b=0}
		},
    type="plain",
    textures=nil
	},
  clouds = {
		gradient_colors = {--"#000000","#402004"
			{r=0, g=0, b=0},
			{r=64, g=32, b=4}
		},
    height=120,
		speed = {z = 0, y = -40},
		density = 0.6
	},
  image= "dust",
  alea=1,
  amount=10,
  particle={
		velocity = {x=5,y=-15,z=-5},
    acceleration = {x=5,y=-15,z=-7},
    expirationtime = 4,
    sizemin = 6,
    sizemax = 10,
    vertical=false
	}
}


weather_data.weather_storm={
  sky={	gradient_colors = {
			{r=0, g=0, b=0},
			{r=40, g=40, b=60}
		},
    textures = {
			"DarkStormyUp.jpg",
			"DarkStormyDown.jpg",
			"DarkStormyFront.jpg",
			"DarkStormyBack.jpg",
			"DarkStormyLeft.jpg",
			"DarkStormyRight.jpg"
		},
    type = "skybox"    
	},
  clouds = {
		gradient_colors = {--"#000000","#706E77"
			{r=0, g=0, b=0},
			{r=112, g=110, b=119}
		},
    height = 120,
    speed = {z = 10, y = -40},
		density = 0.6
	},
  sound="heavy_rain_drop",
  image="hardrain",
  alea=1,
  amount=16,
  particle={
		velocity = {x=5,y=-15,z=-5},
    acceleration = {x=5,y=-15,z=-7},
    expirationtime = 3,
    sizemin = 8,
    sizemax = 15,
    vertical=false
	},
}

weather_data.weather_cloud={
  sky = {
    gradient_colors = {
			{r=0, g=0, b=0},
			{r=100, g=100, b=120}
		},
    type="plain",
  },
  clouds = {
		gradient_colors = {--"#0A0A0A70","#66646D70"
			{r=10, g=10, b=10},
			{r=102, g=100, b=109}
		},
    height = 31000,
    speed = {z = 1, y = 1},
		density = 0.6
	}
}

weather_data.weather_rain={
sky = {
		gradient_colors = {
			{r=0, g=0, b=0},
			{r=112, g=110, b=119}
		},
    type="plain",
	},
	clouds = {
		gradient_colors = {--"#0A0A0A","#66646D"
			{r=10, g=10, b=10},
			{r=102, g=100, b=109}
		},
    height = 120,
    speed = {z = -2, y = 1},
		density = 0.5
	},
  sound="rain_drop",
  image="happy_weather_light_rain_raindrop_",
  alea=4,
  amount=5,
  particle={
		velocity = {x=0,y=-15,z=-0},
    acceleration = {x=0, y=-35, z=0},
    expirationtime = 4,
    sizemin = 1,
    sizemax = 4,
    vertical=true
	},
}

weather_data.weather_snow={
  sky = {
		gradient_colors = {
			{r=30, g=30, b=40},
			{r=231, g=234, b=239}
		},
    type="plain",
	},
  clouds = {
		gradient_colors = {--"#191919","#828CA0"
			{r=25, g=25, b=25},
			{r=130, g=140, b=160}
		},
    height = 120,
		speed = {z = -2, y = -2},
		density = 0.6
	},
  image="happy_weather_light_snow_snowflake_",
  alea=3,
  amount=5,
  particle={
		velocity = {x = -1, y = -2, z = -1},
    acceleration = 2,
    expirationtime = 4,
    sizemin = 1,
    sizemax = 3,
    vertical=false
	},
}

weather_data.weather_snow_storm={
  sky = {
		gradient_colors = {
			{r=0, g=0, b=0},
			{r=128, g=130, b=155}
		},
    type="plain",
	},
  clouds = {
		gradient_colors = {--"#000000","#828CA0"
			{r=0, g=0, b=0},
			{r=130, g=140, b=160}
		},
    height = 120,
		speed = {z = 10, y = -40},
		density = 0.6
	},
  sound="snow_storm_drop",
  image="happy_weather_light_snow_snowflake_",
  alea=3,
  amount=16,
  particle={
		velocity = {x = -5, y = -2, z = 5},
    acceleration = 15,
    expirationtime = 4,
    sizemin = 3,
    sizemax = 6,
    vertical=false
	},
}

weather_data.weather_meteor={
  sky = {
		gradient_colors = {
			{r=50, g=0, b=0},
			{r=150, g=75, b=80}
		},
    type="plain",
	},
clouds = {
		gradient_colors = {--"#000000","#82463C"
			{r=0, g=0, b=0},
			{r=130, g=70, b=60}
		},
    height = 31000,
		speed = {z = 10, y = -40},
		density = 0.5
	},
  sound="meteor",
  image="meteor",
  alea=1,
  amount=1,
  particle={
		velocity = {x = -10, y = -15, z = -10},
    acceleration = {x = -1, y = -15, z = -1},
    expirationtime = 4,
    sizemin = 8,
    sizemax = 18,
    vertical=false,
    glow=8,
	}
}

local day_state=6

espace.weather=function(pos,player,new_weather,weather)
  local playername=player:get_player_name()
if string.find(espace.meteo,"weather_") then new_weather=espace.meteo end
  if new_weather~=weather then

    --retour au ciel normal
    if new_weather=="clear" then
      set_sky(pos,player,map_sky[espace.data[playername].skytype].sky,map_sky[espace.data[playername].skytype].clouds)

      --sound
      local sound_nb=player:get_attribute("sound_meteo")
      if sound_nb then --stop et reset player
        minetest.sound_stop(tonumber(sound_nb))
        player:set_attribute("sound_meteo",nil)
      end

      day_state=6

    --changement d'état du ciel
    else
      set_sky(pos,player,weather_data[new_weather].sky,weather_data[new_weather].clouds)
      espace.data[playername].meteo=new_weather

      --sound
      local sound_nb=player:get_attribute("sound_meteo")
      if sound_nb then --stop et reset player
        minetest.sound_stop(tonumber(sound_nb))
        player:set_attribute("sound_meteo",nil)
      end

      --si sound present, play et sauvegarde dans player
      if weather_data[new_weather].sound then
        sound_nb=minetest.sound_play(weather_data[new_weather].sound, {object = player, max_hear_distance = 2, loop = true,})
        player:set_attribute("sound_meteo",tostring(sound_nb))
      end
    end

    espace.data[playername].meteo=new_weather
    weather=new_weather
  end

  if weather=="clear" then return end

  if day_state==6 then day_state=math.floor(minetest.get_timeofday()*4)+1 end

  --changement de la couleur du ciel la nuit/le jour
  local dt = minetest.get_timeofday()*100

  if dt<21 and day_state==1 then
    set_sky(pos,player,weather_data[new_weather].sky,weather_data[new_weather].clouds)
    day_state=2
  elseif dt>20 and dt<81 and day_state==2 then
    set_sky(pos,player,weather_data[new_weather].sky,weather_data[new_weather].clouds)
    day_state=3
  elseif dt>80 and day_state>2 then
    day_state=1
    set_sky(pos,player,weather_data[new_weather].sky,weather_data[new_weather].clouds)
  end

  --pas de particule ni d'eclair sous l'eau
  if is_underwater(player) then
		return
	end

  --particle
  if weather_data[new_weather].particle then
    for i=1,weather_data[new_weather].amount do
      local image_particle = weather_data[new_weather].image .. math.random(1, weather_data[new_weather].alea) .. ".png"
      local random_pos = get_random_pos(player, {front = 6, back = 2, top = 8})

      if is_outdoor(random_pos) then
        local meteo=weather_data[new_weather].particle
        local accel
        if type(meteo.acceleration)=="number" then
          accel={x=math.random(2,meteo.acceleration),y=-meteo.acceleration,z=math.random(2,meteo.acceleration)}
        else
          accel=meteo.acceleration
        end

        local sz=math.random(meteo.sizemin,meteo.sizemax)

        minetest.add_particle({
          pos = {x=random_pos.x, y=random_pos.y, z=random_pos.z},
          velocity = meteo.velocity,
          acceleration = accel,
          expirationtime = meteo.expirationtime,
          size = sz,
          collisiondetection = true,
          collision_removal = true,
          vertical = meteo.vertical,
          glow=meteo.glow,
          texture = image_particle,
          playername = player:get_player_name()

        })
      end
    end
  end

  -- ** foudre **
  if strike and weather== "weather_storm" then
    if math.random(50)<3 then
      lightning.strike()
    end
  end

end

--**************************************
--** timer rapide pour particle meteo **
--**************************************
local meteo_timer=-5

minetest.register_globalstep(function(dtime)

  meteo_timer = meteo_timer + dtime

  if meteo_timer<0.25 then return end
  meteo_timer=0

  for nb, player in ipairs(minetest.get_connected_players()) do
    local ppos = player:getpos()
    local pname = player:get_player_name()

    local new_weather=espace.data[pname].new_meteo
    if espace.meteo=="off" then new_weather="clear" end       

    espace.weather(ppos,player,new_weather,espace.data[pname].meteo)

  end
end)
