--just for testing
minetest.register_chatcommand("set_month", {
	params = "",
	description = "Set the month. Use the number 1-12",

	func = function(name, param)
  espace.month=tonumber(param)
  minetest.chat_send_player(name,"month : "..param)
end
})

minetest.register_chatcommand("set_day", {
	params = "",
	description = "Set the day",

	func = function(name, param)
  espace.day=tonumber(param)
  minetest.chat_send_player(name,"day : "..param)
end
})

minetest.register_chatcommand("meteo", {
	params = "",
	description = "meteo on/off",

	func = function(name, param)
  espace.meteo=param
  minetest.chat_send_player(name,"meteo "..param)
end
})

minetest.register_chatcommand("building", {
	params = "",
	description = "building on/off",

	func = function(name, param)
  espace.build=param
  minetest.chat_send_player(name,"building "..param)
end
})

minetest.register_chatcommand("build_time", {
	params = "",
	description = "build_time 1->x",

	func = function(name, param)
  if param=="" then
    param=espace.build_dt
  else
    espace.build_dt=tonumber(param)
  end
  minetest.chat_send_player(name,"build_time "..param .." ".. espace.set_dat(0,0,1))
end
})

minetest.register_chatcommand("cheat", {
	params = "",
	description = "cheat code",

	func = function(name, param)
  if atm.balance[name]~= nil then
    atm.balance[name] = param
    atm.saveaccounts()
  end

minetest.chat_send_player(name,"cheat ".. param)
end
})

minetest.register_chatcommand("cheat_astroport", {
	params = "",
	description = "priv atroport number",

	func = function(name, param)

    if espace.data[name].priv==nil then
      espace.data[name].priv={}
    end
    table.insert(espace.data[name].priv,param)

minetest.chat_send_player(name,"privilege astroport n.secteur : ".. param)
espace.setpriv(name)
end
})

minetest.register_chatcommand("vacuum", {
    params = "<off>",
    description = "disable vacuum",
    func = function(name,param)
espace.vacuum=param
minetest.chat_send_player(name,"vacuum : "..param)
end})

--[[
minetest.register_chatcommand("upgrade", {
    params = "",
    description = "upgrade mts",
    func = function(name,param)

local player=minetest.get_player_by_name(name)
local pos1=player:get_pos()

--lecture du MTS
local file = io.open(minetest.get_modpath("espace").."/schematics/"..param..".mts")
local value = file:read(12)--("*a")
file:close()

local path = minetest.get_worldpath() .. "/schems"
		-- Create directory if it does not already exist
		minetest.mkdir(path)
local filename = minetest.get_modpath("espace").."/schematics/"..param..".mts"
local new_filename = path.."/"..param.."_new.mts"
local x = string.byte(string.sub(value, 8, 8)) + string.byte(string.sub(value, 7, 7)) * 256
local y = string.byte(string.sub(value, 10, 10)) + string.byte(string.sub(value, 9, 9)) * 256
local z = string.byte(string.sub(value, 12, 12)) + string.byte(string.sub(value, 11, 11)) * 256

local pos2={x=(pos1.x+x)-1,y=(pos1.y+y)-1,z=(pos1.z+z)-1}
pos1,pos2=worldedit.sort_pos(pos1, pos2)

minetest.place_schematic(pos1, filename, "0", {["bloc4builder:sas_closed_down"]="bloc4builder:sas1",["bloc4builder:sas_closed_up"]="doors:hidden",["bloc4builder:switch1_off"]="bloc4builder:switch_off"}, true)

local ok=minetest.create_schematic(pos1, pos2, nil, new_filename)

if ok==nil then
minetest.chat_send_player(name,"file "..param.." failed")
else
minetest.chat_send_player(name,"file "..param.." transfering")
end
end})
--]]
