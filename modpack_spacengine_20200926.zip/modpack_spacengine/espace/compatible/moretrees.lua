--***************
--** MORETREES **
--***************
--from MORETREES poplar

minetest.register_node(":moretrees:poplar_trunk", {
	description = "Poplar Tree",
	tiles = {"moretrees_poplar_trunk_top.png", "moretrees_poplar_trunk_top.png", "moretrees_poplar_trunk.png"},
	paramtype2 = "facedir",
	is_ground_content = false,
	groups = {tree = 1, choppy = 2, oddly_breakable_by_hand = 1, flammable = 2},
	sounds = default.node_sound_wood_defaults(),

	on_place = minetest.rotate_node
})

minetest.register_node(":moretrees:poplar_wood", {
	description = "Poplar Wood Planks",
	paramtype2 = "facedir",
	place_param2 = 0,
	tiles = {"moretrees_poplar_wood.png"},
	is_ground_content = false,
	groups = {choppy = 2, oddly_breakable_by_hand = 2, flammable = 2, wood = 1},
	sounds = default.node_sound_wood_defaults(),
})

minetest.register_node(":moretrees:poplar_sapling", {
	description = "Poplar Tree Sapling",
	drawtype = "plantlike",
	tiles = {"moretrees_poplar_sapling.png"},
	inventory_image = "moretrees_poplar_sapling.png",
	wield_image = "moretrees_poplar_sapling.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	on_timer = function(pos)
    espace.grow_tree(pos,"poplar_tree_giant")
  end,
	selection_box = {
		type = "fixed",
		fixed = {-4 / 16, -0.5, -4 / 16, 4 / 16, 7 / 16, 4 / 16}
	},
	groups = {snappy = 2, dig_immediate = 3, flammable = 2,
		attached_node = 1, sapling = 1},
	sounds = default.node_sound_leaves_defaults(),

	on_construct = function(pos)
		minetest.get_node_timer(pos):start(math.random(300,1500))--300, 1500))
	end,

	on_place = function(itemstack, placer, pointed_thing)
		itemstack = default.sapling_on_place(itemstack, placer, pointed_thing,
			"moretrees:poplar_sapling",
			-- minp, maxp to be checked, relative to sapling pos
			-- minp_relative.y = 1 because sapling pos has been checked
			{x = -3, y = 1, z = -3},
			{x = 3, y = 6, z = 3},
			-- maximum interval of interior volume check
			4)

		return itemstack
	end,--]]
})

minetest.register_node(":moretrees:poplar_leaves", {
	description = "Poplar Tree Leaves",
	drawtype = "allfaces_optional",
	waving = 1,
	tiles = {"moretrees_poplar_leaves.png"},
	--special_tiles = {"default_leaves_simple.png"},
	paramtype = "light",
	is_ground_content = false,
	groups = {snappy = 3, leafdecay = 3, flammable = 2, leaves = 1, saison=1},
	drop = {
		max_items = 1,
		items = {
			{
				-- player will get sapling with 1/20 chance
				items = {'moretrees:poplar_sapling'},
				rarity = 20,
			},
			{
				-- player will get leaves only if he get no saplings,
				-- this is because max_items is 1
				items = {'moretrees:poplar_leaves'},
			}
		}
	},
	sounds = default.node_sound_leaves_defaults(),

	after_place_node = default.after_place_leaves,
})

minetest.register_node(":moretrees:poplar_leaves_autumn", {
	description = "Poplar autumn Leaves",
	drawtype = "allfaces_optional",
	waving = 1,
	tiles = {"moretrees_poplar_leaves_autumn.png"},
	--special_tiles = {"default_leaves_simple.png"},
	paramtype = "light",
	is_ground_content = false,
	groups = {snappy = 3, leafdecay = 3, flammable = 2, leaves = 1, saison=3},--,not_in_creative_inventory = 1},
	drop = {
		max_items = 1,
		items = {
			{
				-- player will get sapling with 1/20 chance
				items = {'moretrees:poplar_sapling'},
				rarity = 20,
			},
			{
				-- player will get leaves only if he get no saplings,
				-- this is because max_items is 1
				items = {'moretrees:poplar_leaves'},
			}
		}
	},
	sounds = default.node_sound_leaves_defaults(),

	after_place_node = default.after_place_leaves,
})

minetest.register_node(":moretrees:poplar_leaves_stick", {
	description = "Fruit Tree stick Leaves",
	drawtype = "allfaces_optional",
	tiles = {"espace_leaves_stick.png"},
	waving = 1,
	paramtype = "light",
	is_ground_content = false,
	groups = {snappy = 3, leafdecay = 3, flammable = 2, leaves = 1, saison=4},
	drop = {"default:stick"},
	sounds = default.node_sound_leaves_defaults(),
})

	minetest.register_decoration({
		name = "moretrees:poplar_tree",
		deco_type = "schematic",
		place_on = {"default:dirt_with_grass"},
		sidelen = 2,
    --fill_ratio=0.005,
    noise_params = {
			offset = 0.001,
			scale = 0.00001,
			spread = {x = 350, y = 350, z = 350},
			seed = 2,
			octaves = 2,
			persist = 0.008
		},
		biomes = {"deciduous_forest","coniferous_forest"},
		y_max = 50,
		y_min = 1,
		schematic = minetest.get_modpath("espace") .. "/schematics/poplar_tree_giant.mts",
		flags = "place_center_x, place_center_z",
		rotation = "random",
	})
