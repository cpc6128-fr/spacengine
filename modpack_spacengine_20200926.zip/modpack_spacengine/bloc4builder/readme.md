## BLOC4BUILDER
Add many block to MINETEST, new form, new texture, new interact-system.

Thanks all

Compatible moreblocks


texture :
wall, floor : RPGMAKER
streets_support : mod STREETS
cammouflage : mod MOBS_WAR
