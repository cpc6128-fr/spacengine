local function switch_analog(dst,value)
  local calcul=0
  if value<1 then
    dst=math.abs(value)
  else
    calcul=math.ceil(dst/(100/value))+1
    if calcul>value then calcul=0 end
    dst=math.floor(calcul*(100/value))
  end
  return dst
end

local function dec_index(src,vmax,dec)
  src=src-dec
  if src<0 then src=vmax end
  return src
end

local function inc_index(src,vmax,inc)
  src=src+inc
  if src>vmax then src=0 end
  return src
end

--** GIROPHARE **
spacengine.warning=function(cpos,config,value)
  --taille du vaisseaux
  local rangex=5+tonumber(string.sub(config[1][4],2,2))*2
  local rangey=5+tonumber(string.sub(config[1][4],4,4))*2
  local rangez=5+tonumber(string.sub(config[1][4],6,6))*2
  local pos1={x=cpos.x-rangex,y=cpos.y-rangey,z=cpos.z-rangez}
  local pos2={x=cpos.x+rangex,y=cpos.y+rangey,z=cpos.z+rangez}
      
  if value>0 then
    local list=minetest.find_nodes_in_area(pos1,pos2,"bloc4builder:girophare")
    for i=1,#list do
      dst=minetest.get_node(list[i]) 
      minetest.swap_node(list[i],{name="bloc4builder:girophare_on",param2=dst.param2})
    end

  else
    local list=minetest.find_nodes_in_area(pos1,pos2,"bloc4builder:girophare_on")
    for i=1,#list do
      dst=minetest.get_node(list[i]) 
      minetest.swap_node(list[i],{name="bloc4builder:girophare",param2=dst.param2})
    end

  end
end

--********************
--*** PUNCH MODULE ***
--********************

--********************
--** choix commande **
--********************
spacengine.punch_module=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  local nb_param=spac_eng[5]*3
  local switch=string.sub(spac_eng[4],nb_param-2,nb_param-2)
  local command=string.sub(spac_eng[4],nb_param-1,nb_param-1)

  if config[1][1]==0 and group==12 then
    local timer=minetest.get_node_timer(cpos)
    timer:set(5,0)
    config[1][1]=1
    config[14]=minetest.get_us_time()
    config[12]="y"
    return spacengine.controler(cpos)
  end

  
  return spacengine[switch..command](cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)

end

--***************
--** switch BP **
--***************

--controler on/off

spacengine.bC=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  local timer=minetest.get_node_timer(cpos)
  if timer:is_started() then
    timer:stop()
    config[1][1]=0
    config[12]="y"
    cont_met:set_string("config",spacengine.compact(config))
    return-- spacengine.controler(cpos)
  else
    timer:set(5,0)
    config[1][1]=1
    config[14]=minetest.get_us_time()
    config[12]="y"
    return-- spacengine.controler(cpos)
  end
end

--engine jump
spacengine.bJ=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  return "menu#1#+3-"
end

--acces menu
spacengine.bM=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  return "menu#1#-"
end

--power change src
spacengine.bP=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  if type(config[3][4])=="table" then
    if config[3][1]<2 then config[3][1]=2 end
    config[3][1]=config[3][1]+1
    if config[3][1]>#config[3][4] then config[3][1]=2 end
  end
  config[12]="e"
  return --spacengine.controler(cpos)
end

--weapons fire
spacengine.bF=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  spacengine.weapons(cpos,channel,cont_met,config,puncher)
  config[12]="We"
  return --spacengine.controler(cpos)
end

--radar cible
spacengine.br=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  local n=1
  if config[7][6]<1 then config[7][6]=1 end
  config[7][6]=config[7][6]+1
  if type(config[7][4])=="table" then
    n=#config[7][4]
  end
  if config[7][6]>n then config[7][6]=1 end
  config[12]="R"
  return --spacengine.controler(cpos)
end

--radar scan
spacengine.bS=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  spacengine.radar(cpos,channel,cont_met,config)
  config[12]="R"
  return --spacengine.controler(cpos)
end

--manutention source
spacengine.bs=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  local n=1
  if config[13][10]>-1 then return end
  config[13][6]=config[13][6]+1
  if type(config[13][5])=="table" then
    n=#config[13][5]
  end
  if config[13][6]>n then config[13][6]=1 end
  config[12]="M"
  return --spacengine.controler(cpos)
end

--manutention command
spacengine.bc=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  if config[13][10]>-1 then return end
  config[13][8]=config[13][8]+1
  if config[13][8]>3 then config[13][8]=1 end
  config[12]="M"
  return --spacengine.controler(cpos)
end

--manutention execute
spacengine.bE=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  if config[13][10]>-1 then return end
  config[13][10]=1 --active manutention
  config[12]="M"
  return --spacengine.controler(cpos)
end

--on off src power
spacengine.bD=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  if type(config[3][4])=="table" then
    id=config[3][1]
    if id<2 then id=2 end
    if config[3][5][id]==0 then
      config[3][5][id]=1
    else
      config[3][5][id]=0
    end
  end
  config[12]="e"
  cont_met:set_string("config",spacengine.compact(config))
  spacengine.maj_channel(cpos,channel,0)
  return --spacengine.controler(cpos)
end

--Gouvernail
spacengine.bG=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  if config[13][10]>-1 then
    config[13][10]=-1
    spacengine.central_msg("STOP",config)
    spacengine.make_sound("notification",config[15])
  end

  local xrng=config[4][4][1]
  local zrng=config[4][4][3]

  config[4][4][1]=zrng
  config[4][4][3]=100-xrng
      
  config[12]="WRMcD"
  return --spacengine.controler(cpos)
end

--force oxygene
spacengine.bf=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  config[11][4]=1
  spacengine.oxygene(cpos,config)
  config[12]="O"
  return --spacengine.controler(cpos)
end

--IDX-1
spacengine.bg=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  if config[13][10]>-1 then return end
  local zone=(math.floor((config[13][3]*config[4][4][4])/100)*2+1)^3
  config[13][11]=dec_index(config[13][11],zone-1,1)
  config[12]="M"
  return --spacengine.controler(cpos)
end

--IDX-10
spacengine.bh=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  if config[13][10]>-1 then return end
  local zone=(math.floor((config[13][3]*config[4][4][4])/100)*2+1)^3
  config[13][11]=dec_index(config[13][11],zone-1,10)
  config[12]="M"
  return --spacengine.controler(cpos)
end

--clear central message
spacengine.bi=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  config[13][9]="---"
  config[12]="mC"
  return --spacengine.controler(cpos)
end

--QUICK jump
spacengine.bj=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  local _,rmax=spacengine.conso_engine(cpos,config,2)
  --local vl=tonumber(string.sub(spac_eng[4],12,12))+1
  local vl=0
  if config[4][8]~=nil then vl=config[4][8] end

  if vl==0 then
    config[1][6][1]=cpos.x
    config[1][6][2]=cpos.y
    config[1][6][3]=cpos.z+rmax
  end
  if vl==1 then
    config[1][6][1]=cpos.x+rmax
    config[1][6][2]=cpos.y
    config[1][6][3]=cpos.z
  end
  if vl==2 then
    config[1][6][1]=cpos.x
    config[1][6][2]=cpos.y
    config[1][6][3]=cpos.z-rmax
  end
  if vl==3 then
    config[1][6][1]=cpos.x-rmax
    config[1][6][2]=cpos.y
    config[1][6][3]=cpos.z
  end
  if vl==4 then
    config[1][6][1]=cpos.x
    config[1][6][2]=cpos.y+rmax
    config[1][6][3]=cpos.z
  end
  if vl==5 then
    config[1][6][1]=cpos.x
    config[1][6][2]=cpos.y-rmax
    config[1][6][3]=cpos.z
  end

  return "menu#1#+3-"
end

--quick jump direction
spacengine.bk=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  config[4][8]=inc_index(config[4][8],5,1)
  config[12]="E"
  return
end

--cheat mod
spacengine.bH=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  config[2][2]=config[2][1]
  config[5][4]=0
  config[4][6]=0
  config[6][6]=0
  if atm.balance[puncher:get_player_name()]~= nil then
    atm.balance[puncher:get_player_name()] = 3000000
    atm.saveaccounts()
  end
  config[12]="e"
  return --spacengine.controler(cpos)
end

--******************
--** switch Inter **
--******************

--on off power
spacengine.iA=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  --code=cible
  code=spac_eng[6]

  if type(config[3][4])=="table" then
    for i=2,#config[3][4] do
      idx=config[3][4][i]
      if code==spacengine.upgrade[3][idx][3] then
        config[3][5][i]=value
      end
    end
  end

  config[12]="e"
  cont_met:set_string("config",spacengine.compact(config))
  spacengine.maj_channel(cpos,channel,0)
  return --spacengine.controler(cpos)
end

--active switch
spacengine.iB=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code) 
  local rangex=5+tonumber(string.sub(config[1][4],2,2))*2
  local rangey=5+tonumber(string.sub(config[1][4],4,4))*2
  local rangez=5+tonumber(string.sub(config[1][4],6,6))*2
  local pos1={x=cpos.x-rangex,y=cpos.y-rangey,z=cpos.z-rangez}
  local pos2={x=cpos.x+rangex,y=cpos.y+rangey,z=cpos.z+rangez}
  local spl_channel=string.split(channel,":")

  if not code then
    code=spac_eng[6]
  end

  if value>0 then
    local list=minetest.find_nodes_in_area(pos1,pos2,"bloc4builder:switch_off")
    for i=1,#list do
      dst=minetest.get_node(list[i]) 
      dst_met=minetest.get_meta(list[i])
      local cha_dst=dst_met:get_string("channel")
      local cha_spl=string.split(cha_dst,":")
          
      if spl_channel[1]==cha_spl[1] then
        if dst_met:get_string("code")==code then
          bloc4builder.switch_on(list[i],"bloc4builder:switch_on",10)
        end
      end
    end

  else
    local list=minetest.find_nodes_in_area(pos1,pos2,"bloc4builder:switch_on")
    for i=1,#list do
      dst=minetest.get_node(list[i]) 
      dst_met=minetest.get_meta(list[i])
      local cha_dst=dst_met:get_string("channel")
      local cha_spl=string.split(cha_dst,":")
          
      if spl_channel[1]==cha_spl[1] then
        if dst_met:get_string("code")==code then
          bloc4builder.switch_off(list[i],"bloc4builder:switch_off",10)
        end
      end
    end

  end

  config[12]="A"
  return --spacengine.controler(cpos)
end

--light on/off
spacengine.iC=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  local rangex=5+tonumber(string.sub(config[1][4],2,2))*2
  local rangey=5+tonumber(string.sub(config[1][4],4,4))*2
  local rangez=5+tonumber(string.sub(config[1][4],6,6))*2
  local pos1={x=cpos.x-rangex,y=cpos.y-rangey,z=cpos.z-rangez}
  local pos2={x=cpos.x+rangex,y=cpos.y+rangey,z=cpos.z+rangez}
      
  if value>0 then
    local list=minetest.find_nodes_in_area(pos1,pos2,"bloc4builder:light_off")
    for i=1,#list do
      dst=minetest.get_node(list[i]) 
      minetest.swap_node(list[i],{name="bloc4builder:light_up",param2=dst.param2})
    end

  else
    local list=minetest.find_nodes_in_area(pos1,pos2,"bloc4builder:light_up")
    for i=1,#list do
      dst=minetest.get_node(list[i]) 
      minetest.swap_node(list[i],{name="bloc4builder:light_off",param2=dst.param2})
    end

  end

  config[12]="A"
  return --spacengine.controler(cpos)
end

--manutention on off
spacengine.iD=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  if value==1 then
    if config[13][10]<0 then
      config[13][10]=-config[13][10]
    end
  else
    if config[13][10]>0 then
      config[13][10]=-config[13][10]
    elseif config[13][10]==0 then
      config[13][10]=-1
    end
  end

  config[12]="M"
  return --spacengine.controler(cpos)
end

--warning on off
spacengine.iE=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  spacengine.warning(cpos,config,value)

  return --spacengine.controler(cpos)
end

--*******************
--** switch Analog ** -- group=14 pour lecture switch
--*******************

--engine
spacengine.aA=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  if group==14 then return config[4][2] end
  config[4][2]=switch_analog(config[4][2],value)
  config[12]="eD"
  return --spacengine.controler(cpos)
end

--shield
spacengine.aB=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  if group==14 then return config[5][2] end
  config[5][2]=switch_analog(config[5][2],value)
  config[12]="SCD"
  return --spacengine.controler(cpos)
end

--weapons puissance
spacengine.aC=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  if group==14 then return config[6][2] end
  config[6][2]=switch_analog(config[6][2],value)
  config[12]="WCD"
  return --spacengine.controler(cpos)
end

--weapons range
spacengine.aD=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  if group==14 then return config[6][4] end
  config[6][4]=switch_analog(config[6][4],value)
  config[12]="W"
  return --spacengine.controler(cpos)
end

--gravitation
spacengine.aF=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  if group==14 then return config[8][2] end
  config[8][2]=switch_analog(config[8][2],value)
  config[12]="GD"
  return --spacengine.controler(cpos)
end

--oxygene
spacengine.aG=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  if group==14 then return config[11][2] end
  config[11][2]=switch_analog(config[11][2],value)
  config[12]="OD"
  return --spacengine.controler(cpos)
end

--radar
spacengine.aE=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  if group==14 then return config[7][2] end
  config[7][2]=switch_analog(config[7][2],value)
  config[12]="RD"
  return --spacengine.controler(cpos)
end
--manutention
spacengine.aH=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  if group==14 then return config[13][2] end
  if config[13][10]>-1 then return end
  config[13][2]=switch_analog(config[13][2],value)
  config[12]="M"
  return --spacengine.controler(cpos)
end

--manutention
spacengine.aJ=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  if group==14 then return config[13][4] end
  if config[13][10]>-1 then return end
  config[13][4]=switch_analog(config[13][4],value)
  config[12]="M"
  return --spacengine.controler(cpos)
end

--xpos
spacengine.ax=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  if group==14 then return config[4][4][1] end
  if config[13][10]>-1 then
  config[13][10]=-1
  spacengine.central_msg("STOP",config)
  spacengine.make_sound("notification",config[15])
  end
  config[4][4][1]=switch_analog(config[4][4][1],value)
  config[12]="WRMcD"
  return --spacengine.controler(cpos)
end

--ypos
spacengine.ay=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  if group==14 then return config[4][4][2] end
  if config[13][10]>-1 then
    config[13][10]=-1
    spacengine.central_msg("STOP",config)
    spacengine.make_sound("notification",config[15])
  end
  config[4][4][2]=switch_analog(config[4][4][2],value)
  config[12]="WRMcD"
  return --spacengine.controler(cpos)
end

--zpos
spacengine.az=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  if group==14 then return config[4][4][3] end
  if config[13][10]>-1 then
    config[13][10]=-1
    spacengine.central_msg("STOP",config)
    spacengine.make_sound("notification",config[15])
  end
  config[4][4][3]=switch_analog(config[4][4][3],value)
  config[12]="WRMcD"
  return --spacengine.controler(cpos)
end

--zone
spacengine.aI=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  if group==14 then return config[4][4][4] end
  if config[13][10]>-1 then
    config[13][10]=-1
    spacengine.central_msg("STOP",config)
    spacengine.make_sound("notification",config[15])
  end
  config[4][4][4]=switch_analog(config[4][4][4],value)
  config[12]="WRMcD"
  return --spacengine.controler(cpos)
end

--page down
spacengine.aa=function(cpos,cont_met,config,spac_eng,channel,group,puncher,value,code)
  config[12]="spmCE"
  return --spacengine.controler(cpos)
end
