--saison 45°paralèle nord (VALENCE - FRANCE) climat tempéré
local spd1=300 --interval
local spd2=50 --chance

local saison_enable=true
local lbm_enable=true
local alt_saison=10208

local param_perlin_heat={
        offset=50,
        scale=50,
        spread={x=1000,y=1000,z=1000},
        seed=5349,
        octaves=3,persist=0.5,
        lacunarity=2,
        flags="default"}


farming.flowers = {"default:grass_1", "default:grass_2", "default:grass_3","default:grass_4", "default:grass_5", "default:fern_1", "default:fern_2", "default:fern_3", "default:dry_grass_3"}

farming.legume = {}

   table.insert(farming.flowers,'flowers:dandelion_white')
   table.insert(farming.flowers,'flowers:dandelion_yellow')
   table.insert(farming.flowers,'flowers:geranium')
   table.insert(farming.flowers,'flowers:rose')
   table.insert(farming.flowers,'flowers:tulip')
   table.insert(farming.flowers,'flowers:viola')
   table.insert(farming.flowers,'flowers:chrysanthemum_green')
   table.insert(farming.flowers,'flowers:tulip_black')
   table.insert(farming.flowers,'flowers:mushroom_brown')
   table.insert(farming.flowers,'flowers:mushroom_red')

if minetest.get_modpath("bakedclay") then
   table.insert(farming.flowers,'bakedclay:delphinium')
   table.insert(farming.flowers,'bakedclay:lazarus')
   table.insert(farming.flowers,'bakedclay:mannagrass')
   table.insert(farming.flowers,'bakedclay:thistle')
end
if minetest.get_modpath("moreplants") then
   table.insert(farming.flowers, 'moreplants:tallgrass')
   table.insert(farming.flowers, 'moreplants:aliengrass')
   table.insert(farming.flowers, 'moreplants:umbrella')
   table.insert(farming.flowers, 'moreplants:bigflower')
   table.insert(farming.flowers, 'moreplants:medflower')
   table.insert(farming.flowers, 'moreplants:spikefern')
   table.insert(farming.flowers, 'moreplants:weed')
   table.insert(farming.flowers, 'moreplants:bluespike')
   table.insert(farming.flowers, 'moreplants:blueflower')
   table.insert(farming.flowers, 'moreplants:eyeweed')
   table.insert(farming.flowers, 'moreplants:moonflower')
   table.insert(farming.flowers, 'moreplants:caveflower')
   table.insert(farming.flowers, 'moreplants:fireflower')
   table.insert(farming.flowers, 'moreplants:deadweed')
   table.insert(farming.flowers, 'moreplants:jungleflower')
   table.insert(farming.flowers, 'moreplants:curly')
   table.insert(farming.flowers, 'moreplants:clover')
end

    table.insert(farming.flowers, 'moreplants:bigfern')
    table.insert(farming.flowers, 'moreplants:taigabush')
    table.insert(farming.flowers, 'moreplants:bulrush')

    table.insert(farming.legume,'farming:salade_7')
    table.insert(farming.legume,'farming:tea_8')
    table.insert(farming.legume,'farming:strawberry_8')
    table.insert(farming.legume,'farming:pineapple_8')
    table.insert(farming.legume,'farming:pea_5')
    table.insert(farming.legume,'farming:mustard_5')
    table.insert(farming.legume,'farming:beetroot_5')
   table.insert(farming.legume,'farming:cotton_8')
   table.insert(farming.legume,'farming:tomato_8')
   table.insert(farming.legume,'farming:carrot_8')
   table.insert(farming.legume,'farming:corn_8')
   table.insert(farming.legume,'farming:cucumber_4')
   table.insert(farming.legume,'farming:potato_4')
   table.insert(farming.legume,'farming:rhubarb_3')
   table.insert(farming.legume,'farming:raspberry_4')
   table.insert(farming.legume,'farming:pumpkin_8')
   table.insert(farming.legume,'farming:onion_5')
   table.insert(farming.legume,'farming:garlic_5')
   table.insert(farming.legume,'farming:coffee_5')
   table.insert(farming.legume,'farming:barley_7')
   table.insert(farming.legume,'farming:blueberry_4')
   table.insert(farming.legume,'farming:pepper_5')
   table.insert(farming.legume,'farming:hemp_8')
   table.insert(farming.legume,'farming:chili_8')
   table.insert(farming.legume,'farming:beanbush')
   table.insert(farming.legume,'farming:melon_8')
   table.insert(farming.legume,'farming:grapebush')

farming.flower_number = table.getn(farming.flowers)
farming.legume_number = table.getn(farming.legume)

--================================================================


--*************
--** PLANTES **
--*************

-- Flowers grow in spring, flower spread ABM is in flower mod, this just gives
-- initial population as that ABM won't grow flowers where there are none.
minetest.register_abm({
	nodenames = {'group:soil'},
    neighbors = {"air"},
	interval = spd1,--150,
	chance = spd2,--50,

	action = function (pos, node)

    if node.name == 'default:dirt_with_snow' or node.name == 'default:dirt' then
      return
    end

    if saison_enable then alt_saison=10848 end

    if pos.y>alt_saison or (pos.y<1008 and pos.y>25) then
      local rnd=math.random(1,2500)
      if rnd>2490 then
        local flowers=minetest.find_node_near(pos,4,{"group:growing"})
        if flowers == nil then
          --si de la place pour poser
          pos.y = pos.y + 1
          if minetest.get_node(pos).name == 'air' then
            local key = math.random(1, farming.legume_number)
            local placed_legume = farming.legume[key]
            minetest.set_node(pos, {name = placed_legume})
            return
          end
        end
      elseif rnd<10 then
        local flowers=minetest.find_node_near(pos,4,{"group:flower","group:flora"})
        if flowers ==nil then
          -- si de la place pour poser
          pos.y = pos.y + 1
          if minetest.get_node(pos).name == 'air' then
            local key = math.random(1, farming.flower_number)
            local placed_flower = farming.flowers[key]
            minetest.set_node(pos, {name = placed_flower})
          end
        end
      end

      return
    end

if not saison_enable then return end

    if pos.y <-25 or pos.y >10847 then return end
    if pos.y >1000 and pos.y <10208 then return end

-- herbe repousse au printemps
    if espace.month > 3 and espace.month < 9 then
      
      if node.name=="farming:fall_grass" then
        minetest.set_node(pos, {name = 'default:dirt_with_grass'})
      end
	end

    -- printemps groupe fleur mois de mars et avril
    if espace.month == 4 or espace.month == 5 then
        local flowers=minetest.find_node_near(pos,4,{"group:flower","group:flora"})
        if flowers ~=nil then
            return
        end
        -- si de la place pour poser
        pos.y = pos.y + 1
        if minetest.get_node(pos).name == 'air' then
          local key = math.random(1, farming.flower_number)
          local placed_flower = farming.flowers[key]
          minetest.set_node(pos, {name = placed_flower})
        end
        return
    end
      
    -- printemps groupe legume  mois de mai et juin
    if espace.month == 5 or espace.month == 6 then
      if math.random(1,250)>248 then
        local flowers=minetest.find_node_near(pos,5,{"group:growing"})
        if flowers == nil then
          --si de la place pour poser
          pos.y = pos.y + 1
          if minetest.get_node(pos).name == 'air' then
            local key = math.random(1, farming.legume_number)
            local placed_legume = farming.legume[key]
            minetest.set_node(pos, {name = placed_legume})
            return
          end
          pos.y = pos.y - 1
        end
      end
    end
  
    --mois juillet & aout herbe qui seche
    if espace.month == 7 or espace.month == 8 then
      local temp,meteo
      if pos.y >10208 and pos.y <10648 then
        temp,meteo=espace.biome("X",pos)
      else
        temp,meteo=espace.biome("x",pos)
      end

        if temp>32 and node.name=="default:dirt_with_grass" then
            minetest.set_node(pos, {name = 'farming:dirt_summer'})
        end
        return
    end
    
    --mois septembre & octobre herbe deperit ou repousse
    if espace.month > 8 and espace.month < 11 then
        if node.name=="default:dirt_with_grass" then
            minetest.set_node(pos, {name = 'farming:fall_grass'})
        end
        if node.name=="farming:dirt_summer" then
            minetest.set_node(pos, {name = 'default:dirt_with_grass'})
        end
        return
    end
    
    --herbe deperit en fin d'année
    if espace.month > 10 then
        if node.name=="default:dirt_with_grass" then
            minetest.set_node(pos, {name = 'farming:fall_grass'})
        end
        return
    end
    
  end
})

if saison_enable then
--remplacer les fleurs par plante morte en octobre et novembre
minetest.register_abm({
	nodenames = {'group:flower','group:flora'},
	interval = spd1/2,--75,
	chance = spd2,--50,

	action = function (pos, node)

    if pos.y <-25 or pos.y >10847 then return end
    if pos.y >1000 and pos.y <10208 then return end

    if espace.month > 2 and espace.month < 10 then return end

    if node.name == 'flowers:waterlily' then
      return
    else

      local temp,meteo
      if pos.y >10208 and pos.y <10648 then
        temp,meteo=espace.biome("X",pos)
      else
        temp,meteo=espace.biome("x",pos)
      end
      
      if temp<1 then
        minetest.set_node(pos, {name = 'farming:deadplant'})
      end
    end

	end})

-- remplacer plante morte par de l'air en decembre et janvier
minetest.register_abm({
	nodenames = {'farming:deadplant'},
	interval = spd1/2,--75,
	chance = spd2*2,--50,

	action = function (pos)

    if pos.y <-25 or pos.y >10847 then return end
    if pos.y >1000 and pos.y <10208 then return end

    if espace.month < 5 then
        minetest.set_node(pos, {name = 'air'})
    end
end})

--================================================================

--************
--** LEAVES **
--************

--abm x 4

-- Functions
function leaves_fall(pos)
   local i = 9
   local n
   repeat
      n = minetest.get_node({x = pos.x, y = pos.y - i, z = pos.z})
      local def = minetest.registered_items[n.name]
        
      --passe a travers les feuilles
        if n.name ~= 'air' then
          if minetest.get_item_group(n.name, "saison")>0 then
            i=1

          elseif n.name=='default:water_source' or n.name=='default:river_water_source' or n.name=='default:lava_source' then
            i=1

          elseif n.name == 'farming:fall_leaves_1' then
            minetest.set_node({x = pos.x, y = pos.y - i, z = pos.z}, {name = 'farming:fall_leaves_2'})
            i=1

          elseif n.name == 'farming:fall_leaves_2' then
            minetest.set_node({x = pos.x, y = pos.y - i, z = pos.z}, {name = 'farming:fall_leaves_3'})
            i=1

          elseif n.name == 'farming:fall_leaves_3' then
            minetest.set_node({x = pos.x, y = pos.y - i, z = pos.z}, {name = 'farming:fall_leaves_4'})
            i=1

          elseif n.name == 'farming:fall_leaves_4' then
            i=1
          elseif def.buildable_to then
            minetest.set_node({x = pos.x, y = pos.y - i, z = pos.z}, {name = 'farming:fall_leaves_1'})
            i=1
          end
        elseif n.name == 'air' then
          if i>8 then
            i=1
          else
            minetest.set_node({x = pos.x, y = pos.y - i, z = pos.z}, {name = 'farming:fall_leaves_1'})
            i=1
          end
        end
      i=i-1

    until i<1

end


-- ABMs and LBMs ##################
        --group:leaves

-- Leaves changing
minetest.register_abm({
   label = 'leaf changing',
   nodenames = {'group:saison'},
   interval = spd1,--310,
   chance = spd2,--50,
   action = function (pos, node)

    if pos.y <-25 or pos.y >10847 then return end
    if pos.y >1000 and pos.y <10208 then return end

    local feuille=node.name
    local group_saison=minetest.get_item_group(feuille, "saison")

    -- feuille change de couleur en sept et oct        
    if espace.month == 9 or espace.month == 10 then
        --group autumn, arbre qui perde leurs feuilles
        if group_saison== 1 then
          feuille=feuille.."_autumn"
          minetest.set_node(pos, {name = feuille})
        return
        elseif group_saison==2 then
          if string.find(feuille,"default") then
            minetest.set_node(pos, {name = "default:leaves_autumn"})
          else
            minetest.set_node(pos, {name = "verger:leaves_autumn"})
          end
        end
    end

    --feuille tombe en nov et dec
    if espace.month == 11 or espace.month == 12 then

        if group_saison == 3 then
          feuille=string.gsub(feuille,"_autumn","_stick")
          minetest.set_node(pos, {name = feuille})
          leaves_fall(pos)
          return
        elseif group_saison == 1 then
          feuille=feuille.."_stick"
          minetest.set_node(pos, {name = feuille})
          leaves_fall(pos)
          return
        elseif group_saison==2 then
          if feuille=="default:leaves_with_flowers" then
            minetest.set_node(pos, {name = "default:leaves_stick"})
            leaves_fall(pos)
            return
          elseif string.find(feuille,"verger") then
            minetest.set_node(pos, {name = "verger:leaves_stick"})
            leaves_fall(pos)
            return
          end
        end
    end
      
    --feuille nouvelle en mars
      if espace.month == 3 or espace.month == 4 then

        if group_saison==4 then
          feuille=string.gsub(feuille,"_stick","")
          minetest.set_node(pos, {name = feuille})
          return
        elseif group_saison==3 then
          feuille=string.gsub(feuille,"_autumn","")
          minetest.set_node(pos, {name = feuille})
          return
        end
      end
      
    --arbre en fleur      
    if  espace.month == 5 then
        
        if feuille=="moretrees:poplar_leaves" or feuille=="default:aspen_leaves" then return end

        if string.find(feuille,"moretrees:poplar_leaves") then
          minetest.set_node(pos, {name = "moretrees:poplar_leaves"})
          return
        end

        if string.find(feuille,"default:aspen_leaves") then
          minetest.set_node(pos, {name = "default:aspen_leaves"})
          return
        end

        if group_saison==3 then 
          feuille=string.gsub(feuille,"_autumn","")
          minetest.set_node(pos, {name = feuille})
          return
        end

        if group_saison==4 then
          feuille=string.gsub(feuille,"_stick","")
          minetest.set_node(pos, {name = feuille})
          return
        end
        --compter nb de fleur, limiter a 4
        local pos1={x=pos.x-3,y=pos.y-3,z=pos.z-3}
        local pos2={x=pos.x+3,y=pos.y+3,z=pos.z+3}
        local a=minetest.find_nodes_in_area(pos1,pos2,{'verger:leaves_flowers2', 'verger:leaves_flowers3', 'verger:leaves_flowers4', 'verger:leaves_flowers5','default:leaves_flowers'})
        if #a>3 then
            return
        end
        if feuille=="default:leaves" then
          feuille="default:leaves_flowers"
        else
          feuille="verger:leaves_flowers".. math.random(2,5)
        end
        minetest.set_node(pos, {name = feuille})
        return
      end

      if  espace.month == 6 then
        if feuille=="default:leaves_flowers" then
          minetest.set_node(pos, {name = "default:leaves"})
        end
      end

    end})

--fruit pousse l'ete
minetest.register_abm({
   nodenames = {'verger:leaves', 'verger:leaves_flowers2', 'verger:leaves_flowers3', 'verger:leaves_flowers4', 'verger:leaves_flowers5'},
   interval = spd1,--260,
   chance = spd2,--40,

   action = function (pos, node)

    if pos.y <-25 or pos.y >10847 then return end
    if pos.y >1000 and pos.y <10208 then return end
       
   local n = math.random(1,10)
   
    --arbre fruitier reperer quel fruit pour ne pas melanger

        --peche
        if espace.month > 5 and espace.month < 9 then
          if n==1 then
            --local a = minetest.find_node_near(pos, 3, 'fruit:leaves_with_peach')
            local pos1={x=pos.x-4, y=pos.y-4, z=pos.z-4}
            local pos2={x=pos.x+4, y=pos.y+4, z=pos.z+4}
            local b=minetest.find_nodes_in_area(pos1,pos2, {'verger:leaves_with_plum','verger:leaves_with_pear','verger:leaves_with_orange'})
            if #b==0 then
               minetest.set_node(pos,{name = 'verger:leaves_with_peach'})
            end
            return
         
        --prune
          elseif n==3 then

            --local a = minetest.find_node_near(pos, 3, 'fruit:leaves_with_plum')
            local pos1={x=pos.x-4, y=pos.y-4, z=pos.z-4}
            local pos2={x=pos.x+4, y=pos.y+4, z=pos.z+4}
            local b=minetest.find_nodes_in_area(pos1,pos2,  {'verger:leaves_with_peach','verger:leaves_with_pear','verger:leaves_with_orange'})

            if #b==0 then
               minetest.set_node(pos,{name = 'verger:leaves_with_plum'})
            end
            return
        
        --poire
          elseif n==6 then
            --local a = minetest.find_node_near(pos, 3, 'fruit:leaves_with_pear')
            local pos1={x=pos.x-4, y=pos.y-4, z=pos.z-4}
            local pos2={x=pos.x+4, y=pos.y+4, z=pos.z+4}
            local b=minetest.find_nodes_in_area(pos1,pos2,  {'verger:leaves_with_plum','verger:leaves_with_peach','verger:leaves_with_orange'})
            if #b==0 then
               minetest.set_node(pos,{name = 'verger:leaves_with_pear'})
            end
            return
        
        --orange
          elseif n==10 then
            --local a = minetest.find_node_near(pos, 3, 'default:apple')
            local pos1={x=pos.x-4, y=pos.y-4, z=pos.z-4}
            local pos2={x=pos.x+4, y=pos.y+4, z=pos.z+4}
            local b=minetest.find_nodes_in_area(pos1,pos2,  {'verger:leaves_with_plum','verger:leaves_with_pear','verger:leaves_with_peach'})
            if #b==0 then
               minetest.set_node(pos,{name = 'verger:leaves_with_orange'})
            end
            return
          end
        end

   end
})

-- fruit die
minetest.register_abm({
   nodenames = {'verger:leaves_with_peach','verger:leaves_with_plum','verger:leaves_with_pear','verger:leaves_with_orange'},
   interval = spd1,--250,
   chance = spd2,--40,
   action = function (pos,node)

    if pos.y <-25 or pos.y >10847 then return end
    if pos.y >1000 and pos.y <10208 then return end

    local fruit=node.name
    fruit=string.gsub(fruit,"leaves_with_","")

      if espace.month>8 then

        if espace.month == 9 then 
          minetest.set_node(pos,{name = 'verger:leaves'})
        elseif espace.month == 10 then
          minetest.set_node(pos,{name = 'verger:leaves_autumn'})
        elseif espace.month > 10 then
          minetest.set_node(pos,{name = 'verger:leaves_stick'})
        end
--[[
        if math.random(1,10)==1 then
          local i = 1
          repeat
            local n = minetest.get_node({x = pos.x, y = pos.y - i, z = pos.z})
            if n.name == "air" then
               minetest.spawn_item({
                  x = pos.x,
                  y = pos.y - i,
                  z = pos.z},
                  fruit)
            end
            i = i + 1
          until n.name == "air" or i > 3
        end--]]
        return
      end

  end})

-- Removal of dead leaves from the ground
minetest.register_abm({
   nodenames = {'group:fallen_leaves'},
   interval = 200,
   chance = 40,
   action = function (pos, node)

    if pos.y <-25 or pos.y >10847 then return end
    if pos.y >1000 and pos.y <10208 then return end

    local month = espace.month
    if month == 1 or month == 2 then
        if node.name == 'farming:fall_leaves_4' then
            minetest.set_node(pos, {name = 'farming:fall_leaves_3'})
         elseif node.name == 'farming:fall_leaves_3' then
            minetest.set_node(pos, {name = 'farming:fall_leaves_2'})
         elseif node.name == 'farming:fall_leaves_2' then
            minetest.set_node(pos, {name = 'farming:fall_leaves_1'})
         elseif node.name == 'farming:fall_leaves_1' then
            minetest.set_node(pos, {name = 'air'})
         end
      end
   end
})
--]]


--============================================

--***********
--** neige **
--***********

--[[abm x 4

--]]
local function get_melt_prob(pos)
   local list1 = minetest.find_nodes_in_area({x=pos.x-1,y=pos.y-1,z=pos.z-1},
   {x=pos.x+1,y=pos.y+1,z=pos.z+1},{"default:ice", "default:snowblock"})
   local list2 = minetest.find_nodes_in_area({x=pos.x-1,y=pos.y-1,z=pos.z-1},
   {x=pos.x+1,y=pos.y+1,z=pos.z+1},{"farming:snow_cover_5","farming:snow_cover_4","farming:snow_cover_3","farming:snow_cover_2","farming:snow_cover_1"})
   
   local prob = (table.getn(list1) + table.getn(list2))*6-- + table.getn(list3)
   
   return prob
end


--Places Snow on ground

minetest.register_abm({

   nodenames = {"group:leaves", "group:soil", "default:snowblock"},
   neighbors = {"air"},
   interval = 20,
   chance = 30,

   action = function (pos, node)
     
    -- hauteur min et max
    if pos.y <-25 or pos.y >10847 then return end
    if pos.y >1000 and pos.y <10208 then return end
    
    --pas d'accumulation de neige de mars a novembre
    if espace.month>2 and espace.month<12 then return end

    local temp,meteo
    if pos.y >10208 and pos.y <10648 then
      temp,meteo=espace.biome("X",pos)
    else
      temp,meteo=espace.biome("x",pos)
    end

    if espace.meteo=="weather_snow" then meteo="weather_snow" end

    if meteo == "weather_snow" and math.random(1,4)==1 then
      local nu = minetest.get_node(pos)

      if string.find(nu.name,"cover") then return end

      pos.y = pos.y + 1 -- check above node
      local na=minetest.get_node(pos)
      if not espace.is_inside({x=pos.x,y=pos.y,z=pos.z}) and na.name=="air" then
        minetest.set_node(pos, {name = "farming:snow_cover_1"})
      end
    end

    if espace.meteo=="weather_snow_storm" then meteo="weather_snow_storm" end

    if meteo == "weather_snow_storm" then
      local nu = minetest.get_node(pos)

      if string.find(nu.name,"cover") then return end

      pos.y = pos.y + 1 -- check above node
      local na=minetest.get_node(pos)
      if not espace.is_inside({x=pos.x,y=pos.y,z=pos.z}) and na.name=="air" then
        minetest.set_node(pos, {name = "farming:snow_cover_1"})
      end
    end

end
})

--Replace grass and flowers with snow
minetest.register_abm({
  nodenames = {"group:flora", "group:plant", "group:farming"},
  neighbors = {"air"},
  interval = 20,
  chance = 30,

  action = function (pos, node)
     
    if pos.y <-25 or pos.y >10847 then return end
    if pos.y >1000 and pos.y <10208 then return end
  
    if espace.month>2 and espace.month<12 then return end

      local temp,meteo
      if pos.y >10208 and pos.y <10648 then
        temp,meteo=espace.biome("X",pos)
      else
        temp,meteo=espace.biome("x",pos)
      end
    if meteo == "weather_snow" or meteo == "weather_snow_storm" then
      if not espace.is_inside({x=pos.x,y=pos.y,z=pos.z}) then
        minetest.set_node(pos, {name="farming:snow_cover_1"})
      end
    end
  end
})

-- Changes snow to larger snow
minetest.register_abm({
   nodenames = {"farming:snow_cover_1", "farming:snow_cover_2", "farming:snow_cover_3", "farming:snow_cover_4", "farming:snow_cover_5", "default:snow"},
   neighbors = {"air"},
   interval = 20,
   chance = 30,

   action = function (pos, node)

    if pos.y <-25 or pos.y >10847 then return end
    if pos.y >1000 and pos.y <10208 then return end
     
    if espace.month>2 then
        return
    end
      
            local temp,meteo
      if pos.y >10208 and pos.y <10648 then
        temp,meteo=espace.biome("X",pos)
      else
        temp,meteo=espace.biome("x",pos)
      end
      if espace.meteo=="weather_snow" then meteo="weather_snow" end
      if espace.meteo=="weather_snow_storm" then meteo="weather_snow_storm" end
      if meteo == "weather_snow" or meteo == "weather_snow_storm" then
        --snow accumule moins de neige au sol
        if meteo == "weather_snow" and math.random(1, 4) ~= 1 then
          return
        end
        
        if node.name == "farming:snow_cover_1" then
         minetest.set_node(pos, {name = "farming:snow_cover_2"})
        elseif node.name == "farming:snow_cover_2" or node.name == "default:snow" then
         minetest.set_node(pos, {name = "farming:snow_cover_3"})
        elseif node.name == "farming:snow_cover_3" then
         minetest.set_node(pos, {name = "farming:snow_cover_4"})
        elseif node.name == "farming:snow_cover_4" then
            minetest.set_node(pos, {name = "farming:snow_cover_5"})
        elseif node.name == "farming:snow_cover_5" then
          minetest.set_node({x=pos.x,y=pos.y+1,z=pos.z}, {name = "farming:snow_cover_1"})
      end
   end
end
})

--TODO lbm pour faire fondre la neige l'ete et dans le biome tempere seulement

-- Snow Melting
minetest.register_abm({
  nodenames = {"farming:snow_cover_1", "farming:snow_cover_2", "farming:snow_cover_3", "farming:snow_cover_4", "farming:snow_cover_5"},
  neighbors = {"air"},
  interval = 30,
  chance = 1,

  action = function (pos, node)
     
    if pos.y <-25 or pos.y >10847 then return end
    if pos.y >1000 and pos.y <10208 then return end
      
    if espace.month>4 and espace.month<12 then return end
       
          local temp,meteo
      if pos.y >10208 and pos.y <10648 then
        temp,meteo=espace.biome("X",pos)
      else
        temp,meteo=espace.biome("x",pos)
      end
--
-- la neige ne fond pas quand temperature inferieur a 3 degres celsius ou en janvier et fevrier
    if temp < 5 or espace.month == 1 or espace.month == 2 then
      return
    end
    
    -- plus il fait chaud, plus la neige fond
    local melt_prob = get_melt_prob(pos)

    if temp >4 then
      melt_prob=math.ceil(melt_prob/(temp-4))
    end

    if math.random(1, melt_prob) == 1 then
    -- check if there is any blocks above it
      while minetest.get_node_or_nil({x=pos.x, y=pos.y + 1, z=pos.z}) and minetest.get_node_or_nil({x=pos.x, y=pos.y + 1, z=pos.z}).name ~= "air" do
        pos.y = pos.y + 1
        node = minetest.get_node_or_nil(pos)
      end

      if node.name == "farming:snow_cover_2" then
        minetest.set_node(pos, {name = "farming:snow_cover_1"})
      elseif node.name == "farming:snow_cover_3" then
        minetest.set_node(pos, {name = "farming:snow_cover_2"})
      elseif node.name == "farming:snow_cover_4" then
        minetest.set_node(pos, {name = "farming:snow_cover_3"})
      elseif node.name == "farming:snow_cover_5" then
        minetest.set_node(pos, {name = "farming:snow_cover_4"})
      elseif node.name == "farming:snow_cover_1" then
        minetest.remove_node(pos)
      end
    end
  end
})

end

--****************
--** LBM enable **
--****************

if lbm_enable and saison_enable then

--**************
--** SNOW LBM **
--**************
minetest.register_lbm({
	name = "farming:smelt_snow",
	nodenames = {"farming:snow_cover_1", "farming:snow_cover_2", "farming:snow_cover_3", "farming:snow_cover_4", "farming:snow_cover_5"},
	run_at_every_load = true,
	action = function (pos, node)

    if pos.y <-25 or pos.y >10847 then return end
    if pos.y >1000 and pos.y <10208 then return end

    if espace.month>4 and espace.month<11 then
      minetest.remove_node(pos)
    end
  end
})

minetest.register_lbm({
	name = "farming:snow_cover",
	nodenames = {"group:leaves", "group:soil", "default:snowblock"},
  neighbors = {"air"},
	run_at_every_load = true,
	action = function (pos, node)

    if pos.y <-25 or pos.y >10847 then return end
    if pos.y >1000 and pos.y <10208 then return end

    if espace.month==2 then

      pos.y = pos.y + 1 -- check above node
      local na=minetest.get_node(pos)
      if not espace.is_inside({x=pos.x,y=pos.y,z=pos.z}) and na.name=="air" then
        minetest.set_node(pos, {name = "farming:snow_cover_".. math.random(1,5)})
      end
    end
  end
})

-- Fallen Leaves Cleanup LBM
minetest.register_lbm({
   name = 'farming:rake',
   nodenames = {'group:fallen_leaves'},
   run_at_every_load = true,
   action = function (pos)
     
    if pos.y <-25 or pos.y >10847 then return end
    if pos.y >1000 and pos.y <10208 then return end

    local month = tonumber(espace.month)
    if month == 3 then
        minetest.set_node(pos, {name = 'air'})
    end

   end
})

--Leaf changing LBM
minetest.register_lbm({
   name = "farming:change_leaves",

   nodenames = {'group:saison'},

   run_at_every_load = true,

   action = function (pos, node)

    if pos.y <-25 or pos.y >10847 then return end
    if pos.y >1000 and pos.y <10208 then return end

    local feuille = node.name
    local group_saison=minetest.get_item_group(feuille, "saison")

    local month = tonumber(espace.month)
    local day = tonumber(espace.day)

    -- replace autumn leaves
        
    if group_saison==3 then
      if month<3 then
        feuille=string.gsub(feuille,"_autumn","_stick")
      elseif month>2 and month<9 then
        feuille=string.gsub(feuille,"_autumn","")
      end

      minetest.set_node(pos, {name = feuille})
    end

    --replace stick
    if group_saison==4 then
      if month >3 and month < 11  then
        feuille=string.gsub(feuille,"_stick","")
      elseif month >10 then
        feuille=string.gsub(feuille,"_stick","_autumn")
      end

        minetest.set_node(pos, {name = feuille})
    end

    -- replace leaves
    if group_saison== 1 then
      if month > 10 then
        feuille=feuille.."_autumn"
      elseif month < 3 then
        feuille=feuille.."_stick"
      end
        minetest.set_node(pos, {name = feuille})
    end

    -- replace flower
    if group_saison==2 then
      if string.find(feuille,"default") then
        if month >10 then
          minetest.set_node(pos, {name = "default:leaves_autumn"})
        elseif month <3 then
          minetest.set_node(pos, {name = "default:leaves_stick"})
        elseif month>2 and month <5 then
          minetest.set_node(pos, {name = "default:leaves"})
        end

      else

        if month >10 then
          minetest.set_node(pos, {name = "verger:leaves_autumn"})
        elseif month <3 then
          minetest.set_node(pos, {name = "verger:leaves_stick"})
        elseif month>2 and month <5 then
          minetest.set_node(pos, {name = "verger:leaves"})
        end
      end
    end

   end})

--LBM delete all deadplant
minetest.register_lbm({
	name = "farming:replace_deadplant",
	nodenames = {'farming:deadplant'},
	run_at_every_load = true,
	action = function (pos)

    if pos.y <-25 or pos.y >10847 then return end
    if pos.y >1000 and pos.y <10208 then return end

    if espace.month > 4 and espace.month < 10 then
        minetest.set_node(pos, {name = 'air'})
    end
end})

end
